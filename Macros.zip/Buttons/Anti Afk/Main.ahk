#Requires AutoHotkey v2.0
#NoTrayIcon
; Create the GUI and handle close event
TraySetIcon(A_ScriptDir "\Assets\Psycho_Hatcher.ico")

MyGui := Gui("+AlwaysOnTop", "Anti-AFK Timer")
MyGui.OnEvent("Close", GuiClose)  ; Handle GUI close event
MyGui.Add("Text",, "Minutes between anti-AFK actions:")
timerEdit := MyGui.Add("Edit", "w100", "5")
MyGui.Add("Button", "Default w100", "Start Timer").OnEvent("Click", StartTimer)
myGui.Show("w135 h90")

; Handle GUI close event by exiting the script
GuiClose(*) {
    ExitApp()
}

isRunning := false
currentWindow := 0

StartTimer(*) {
    global isRunning, timerEdit
    if !isRunning {
        minutes := Integer(timerEdit.Value)
        if minutes < 1
            minutes := 5
        
        SetTimer(AntiAFK, minutes * 60000)
        isRunning := true
        
        ; Auto-disappearing notification
        ToolTip("Anti-AFK timer started!`nWill trigger every " minutes " minutes")
        SetTimer(() => ToolTip(), -2000)
    }
}

; Rest of your existing code remains unchanged...
AntiAFK(*) {
    currentWindow := WinExist("A")
    robloxWindows := WinGetList("ahk_exe RobloxPlayerBeta.exe")
    ToolTip("Performing anti-AFK actions...", 10, 10)
    for hwnd in robloxWindows {
        WinActivate(hwnd)
        Sleep(500)
        Loop 3 {
            Send("{Space down}")
            Sleep(100)
            Send("{Space up}")
            Sleep(100)
        }
        WinMinimize(hwnd)
        Sleep(200)
    }
    if currentWindow
        WinActivate("ahk_id " currentWindow)
    SetTimer(() => ToolTip(), -1000)
}

A_TrayMenu.Add("Stop Timer", StopTimer)
A_TrayMenu.Add("Force Exit", ForceExit)

StopTimer(*) {
    global isRunning
    SetTimer(AntiAFK, 0)
    isRunning := false
    ToolTip("Anti-AFK timer stopped!")
    SetTimer(() => ToolTip(), -2000)
}

ForceExit(*) {
    try {
        SetTimer(AntiAFK, 0)
        ExitApp()
    }
    catch {
        hProcess := DllCall("OpenProcess", "UInt", 0x0001, "Int", false, "UInt", ProcessExist())
        if (hProcess) {
            DllCall("TerminateProcess", "Ptr", hProcess, "UInt", 0)
            DllCall("CloseHandle", "Ptr", hProcess)
        }
    }
}

F3::ForceExit()