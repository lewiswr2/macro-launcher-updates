#Requires AutoHotkey v2.0
#SingleInstance Force
#NoTrayIcon

; ========== COLOR SCHEME (MATCHING LAUNCHER) ==========
global COLORS := {
    bg: "0x0a0e14",
    bgLight: "0x13171d",
    card: "0x161b22",
    cardHover: "0x1c2128",
    accent: "0xd29922",
    accentHover: "0x2ea043",
    accentAlt: "0x1f6feb",
    text: "0xe6edf3",
    textDim: "0x7d8590",
    border: "0x21262d",
    success: "0x238636",
    warning: "0xd29922",
    danger: "0xda3633"
}

; ========== SETTINGS ==========
global SETTINGS_FILE := A_ScriptDir "\autoclicker_settings.ini"
global clickerRunning := false
global clickerThread := 0

; Default settings
global settings := {
    hours: 0,
    mins: 0,
    secs: 0,
    millisecs: 100,
    mouseButton: "Left",
    clickType: "Single",
    repeatMode: "until_stopped",
    repeatCount: 1,
    useCurrentLocation: true,
    pickX: 0,
    pickY: 0,
    hotkey: "F2",
    stopHotkey: "F2"
}

; ========== INITIALIZE ==========
LoadSettings()
SetTrayIcon()
CreateGui()

; ========== SET TRAY ICON ==========
SetTrayIcon() {
    logoPath := A_ScriptDir "\logo.png"
    if FileExist(logoPath) {
        try {
            TraySetIcon(logoPath)
        }
    }
}

; ========== LOAD/SAVE SETTINGS ==========
LoadSettings() {
    global settings, SETTINGS_FILE
    
    if !FileExist(SETTINGS_FILE)
        return
    
    try {
        settings.hours := Integer(IniRead(SETTINGS_FILE, "Interval", "Hours", 0))
        settings.mins := Integer(IniRead(SETTINGS_FILE, "Interval", "Mins", 0))
        settings.secs := Integer(IniRead(SETTINGS_FILE, "Interval", "Secs", 0))
        settings.millisecs := Integer(IniRead(SETTINGS_FILE, "Interval", "Millisecs", 100))
        
        settings.mouseButton := IniRead(SETTINGS_FILE, "Click", "MouseButton", "Left")
        settings.clickType := IniRead(SETTINGS_FILE, "Click", "ClickType", "Single")
        settings.repeatMode := IniRead(SETTINGS_FILE, "Repeat", "Mode", "until_stopped")
        settings.repeatCount := Integer(IniRead(SETTINGS_FILE, "Repeat", "Count", 1))
        
        settings.useCurrentLocation := Integer(IniRead(SETTINGS_FILE, "Position", "UseCurrent", 1))
        settings.pickX := Integer(IniRead(SETTINGS_FILE, "Position", "X", 0))
        settings.pickY := Integer(IniRead(SETTINGS_FILE, "Position", "Y", 0))
        
        settings.hotkey := IniRead(SETTINGS_FILE, "Hotkeys", "Start", "F2")
        settings.stopHotkey := IniRead(SETTINGS_FILE, "Hotkeys", "Stop", "F2")
    } catch {
        ; Use defaults
    }
}

SaveSettings() {
    global settings, SETTINGS_FILE
    
    try {
        IniWrite settings.hours, SETTINGS_FILE, "Interval", "Hours"
        IniWrite settings.mins, SETTINGS_FILE, "Interval", "Mins"
        IniWrite settings.secs, SETTINGS_FILE, "Interval", "Secs"
        IniWrite settings.millisecs, SETTINGS_FILE, "Interval", "Millisecs"
        
        IniWrite settings.mouseButton, SETTINGS_FILE, "Click", "MouseButton"
        IniWrite settings.clickType, SETTINGS_FILE, "Click", "ClickType"
        IniWrite settings.repeatMode, SETTINGS_FILE, "Repeat", "Mode"
        IniWrite settings.repeatCount, SETTINGS_FILE, "Repeat", "Count"
        
        IniWrite settings.useCurrentLocation, SETTINGS_FILE, "Position", "UseCurrent"
        IniWrite settings.pickX, SETTINGS_FILE, "Position", "X"
        IniWrite settings.pickY, SETTINGS_FILE, "Position", "Y"
        
        IniWrite settings.hotkey, SETTINGS_FILE, "Hotkeys", "Start"
        IniWrite settings.stopHotkey, SETTINGS_FILE, "Hotkeys", "Stop"
    } catch {
        MsgBox "Failed to save settings.", "Error", "Icon!"
    }
}

; ========== CREATE GUI ==========
CreateGui() {
    global mainGui, COLORS, settings
    global hoursEdit, minsEdit, secsEdit, millisecsEdit
    global mouseButtonDDL, clickTypeDDL
    global repeatRadio, repeatTimesRadio, repeatCountEdit
    global currentLocRadio, pickLocRadio, pickXEdit, pickYEdit
    global startBtn, stopBtn, statusText
    
    mainGui := Gui("-Resize +Border", "AHK Vault - Auto Clicker")
    mainGui.BackColor := COLORS.bg
    mainGui.SetFont("s9 c" COLORS.text, "Segoe UI")
    
    ; ========== HEADER ==========
    mainGui.Add("Text", "x0 y0 w480 h60 Background" COLORS.accent)
    
    ; Add logo if it exists
    logoPath := A_ScriptDir "\logo.png"
    if FileExist(logoPath) {
        try {
            logoPic := mainGui.Add("Picture", "x15 y12 w36 h36 BackgroundTrans", logoPath)
            headerText := mainGui.Add("Text", "x60 y15 w400 h100 c" COLORS.text " BackgroundTrans", "Auto Clicker")
            headerText.SetFont("s16 bold")
            statusText := mainGui.Add("Text", "x60 y40 w400 c" COLORS.text " BackgroundTrans", "Status: Stopped")
        } catch {
            ; If logo fails to load, fall back to text only
            headerText := mainGui.Add("Text", "x20 y15 w440 h100 c" COLORS.text " BackgroundTrans", "Auto Clicker")
            headerText.SetFont("s16 bold")
            statusText := mainGui.Add("Text", "x20 y40 w440 c" COLORS.text " BackgroundTrans", "Status: Stopped")
        }
    } else {
        headerText := mainGui.Add("Text", "x20 y15 w440 h100 c" COLORS.text " BackgroundTrans", "Auto Clicker")
        headerText.SetFont("s16 bold")
        statusText := mainGui.Add("Text", "x20 y40 w440 c" COLORS.text " BackgroundTrans", "Status: Stopped")
    }
    statusText.SetFont("s9")
    
    ; ========== CLICK INTERVAL ==========
    yPos := 75
    mainGui.Add("Text", "x20 y" yPos " w440 c" COLORS.text, "Click Interval").SetFont("s10 bold")
    mainGui.Add("Text", "x20 y" (yPos + 22) " w440 h1 Background" COLORS.border)
    
    yPos += 35
    
    ; Hours
    mainGui.Add("Text", "x30 y" (yPos + 5) " w60 c" COLORS.textDim, "Hours:")
    hoursEdit := mainGui.Add("Edit", "x90 y" yPos " w60 h25 Background" COLORS.bgLight " c" COLORS.text " Number", settings.hours)
    
    ; Minutes
    mainGui.Add("Text", "x165 y" (yPos + 5) " w60 c" COLORS.textDim, "Mins:")
    minsEdit := mainGui.Add("Edit", "x215 y" yPos " w60 h25 Background" COLORS.bgLight " c" COLORS.text " Number", settings.mins)
    
    ; Seconds
    mainGui.Add("Text", "x290 y" (yPos + 5) " w60 c" COLORS.textDim, "Secs:")
    secsEdit := mainGui.Add("Edit", "x340 y" yPos " w60 h25 Background" COLORS.bgLight " c" COLORS.text " Number", settings.secs)
    
    yPos += 35
    
    ; Milliseconds
    mainGui.Add("Text", "x30 y" (yPos + 5) " w100 c" COLORS.textDim, "Milliseconds:")
    millisecsEdit := mainGui.Add("Edit", "x130 y" yPos " w100 h25 Background" COLORS.bgLight " c" COLORS.text " Number", settings.millisecs)
    
    ; ========== CLICK OPTIONS ==========
    yPos += 45
    mainGui.Add("Text", "x20 y" yPos " w440 c" COLORS.text, "Click Options").SetFont("s10 bold")
    mainGui.Add("Text", "x20 y" (yPos + 22) " w440 h1 Background" COLORS.border)
    
    yPos += 35
    
    ; Mouse Button
    mainGui.Add("Text", "x30 y" (yPos + 5) " w100 c" COLORS.textDim, "Mouse button:")
    mouseButtonDDL := mainGui.Add("DropDownList", "x140 y" yPos " w130 Background" COLORS.bgLight " c" COLORS.text, 
        ["Left", "Right", "Middle", "Middle (Click)", "Middle (Down)", "Middle (Up)"])
    mouseButtonDDL.Text := settings.mouseButton
    
    ; Click Type
    mainGui.Add("Text", "x280 y" (yPos + 5) " w80 c" COLORS.textDim, "Click type:")
    clickTypeDDL := mainGui.Add("DropDownList", "x360 y" yPos " w80 Background" COLORS.bgLight " c" COLORS.text, 
        ["Single", "Double"])
    clickTypeDDL.Text := settings.clickType
    
    ; ========== CLICK REPEAT ==========
    yPos += 45
    mainGui.Add("Text", "x20 y" yPos " w200 c" COLORS.text, "Click Repeat").SetFont("s10 bold")
    
    yPos += 25
    
    repeatRadio := mainGui.Add("Radio", "x30 y" yPos " w200 c" COLORS.text " Background" COLORS.bg, "Repeat until stopped")
    repeatRadio.Value := (settings.repeatMode = "until_stopped")
    
    yPos += 30
    
    repeatTimesRadio := mainGui.Add("Radio", "x30 y" yPos " w80 c" COLORS.text " Background" COLORS.bg, "Repeat")
    repeatTimesRadio.Value := (settings.repeatMode = "times")
    
    repeatCountEdit := mainGui.Add("Edit", "x115 y" (yPos - 3) " w60 h25 Background" COLORS.bgLight " c" COLORS.text " Number", settings.repeatCount)
    repeatCountEdit.OnEvent("Focus", (*) => repeatTimesRadio.Value := 1)
    
    mainGui.Add("Text", "x180 y" yPos " w60 c" COLORS.textDim " Background" COLORS.bg, "times")
    
    ; ========== CURSOR POSITION ==========
    yPos += 45
    mainGui.Add("Text", "x20 y" yPos " w440 c" COLORS.text, "Cursor Position").SetFont("s10 bold")
    mainGui.Add("Text", "x20 y" (yPos + 22) " w440 h1 Background" COLORS.border)
    
    yPos += 35
    
    currentLocRadio := mainGui.Add("Radio", "x30 y" yPos " w150 c" COLORS.text " Background" COLORS.bg, "Current location")
    currentLocRadio.Value := settings.useCurrentLocation
    
    yPos += 30
    
    pickLocRadio := mainGui.Add("Radio", "x30 y" yPos " w120 c" COLORS.text " Background" COLORS.bg, "Pick location")
    pickLocRadio.Value := !settings.useCurrentLocation
    
    mainGui.Add("Text", "x160 y" (yPos + 5) " w20 c" COLORS.textDim " Background" COLORS.bg, "X:")
    pickXEdit := mainGui.Add("Edit", "x180 y" yPos " w70 h25 Background" COLORS.bgLight " c" COLORS.text " Number", settings.pickX)
    pickXEdit.OnEvent("Focus", (*) => pickLocRadio.Value := 1)
    
    mainGui.Add("Text", "x265 y" (yPos + 5) " w20 c" COLORS.textDim " Background" COLORS.bg, "Y:")
    pickYEdit := mainGui.Add("Edit", "x285 y" yPos " w70 h25 Background" COLORS.bgLight " c" COLORS.text " Number", settings.pickY)
    pickYEdit.OnEvent("Focus", (*) => pickLocRadio.Value := 1)
    
    pickLocationBtn := mainGui.Add("Button", "x365 y" (yPos - 2) " w75 h28 Background" COLORS.accentAlt, "Pick")
    pickLocationBtn.OnEvent("Click", PickLocation)
    
    ; ========== CONTROL BUTTONS ==========
    yPos += 50
    mainGui.Add("Text", "x20 y" yPos " w440 h1 Background" COLORS.border)
    
    yPos += 15
    
    startBtn := mainGui.Add("Button", "x30 y" yPos " w200 h40 Background" COLORS.success, "Start (" settings.hotkey ")")
    startBtn.SetFont("s11 bold")
    startBtn.OnEvent("Click", ToggleClicker)
    startBtn.OnEvent("ContextMenu", EditStartHotkey)  ; Right-click to edit
    
    stopBtn := mainGui.Add("Button", "x250 y" yPos " w200 h40 Background" COLORS.danger, "Stop (" settings.stopHotkey ")")
    stopBtn.SetFont("s11 bold")
    stopBtn.OnEvent("Click", ToggleClicker)
    stopBtn.OnEvent("ContextMenu", EditStopHotkey)  ; Right-click to edit
    stopBtn.Enabled := false
    
    ; Add instruction text
    yPos += 45
    instructionText := mainGui.Add("Text", "x30 y" yPos " w420 c" COLORS.textDim " Center", "💡 Right-click Start/Stop buttons to change hotkeys")
    instructionText.SetFont("s8")
    
    ; ========== SHOW GUI ==========
    mainGui.OnEvent("Close", OnGuiClose)
    mainGui.Show("w480 h570")
    
    ; Register hotkey
    try {
        Hotkey settings.hotkey, ToggleClicker, "On"
    } catch {
        MsgBox "Could not register hotkey: " settings.hotkey, "Warning", "Icon!"
    }
}

; ========== PICK LOCATION ==========
PickLocation(*) {
    global pickXEdit, pickYEdit, pickLocRadio
    
    mainGui.Hide()
    
    ToolTip "Move mouse to desired position and press SPACE"
    
    KeyWait "Space", "D"
    
    MouseGetPos &x, &y
    
    pickXEdit.Value := x
    pickYEdit.Value := y
    pickLocRadio.Value := 1
    
    ToolTip
    
    mainGui.Show()
}

; ========== START/STOP CLICKER ==========
ToggleClicker(*) {
    global clickerRunning
    
    if clickerRunning {
        StopClicker()
    } else {
        StartClicker()
    }
}

StartClicker(*) {
    global clickerRunning, settings, statusText, startBtn, stopBtn
    global hoursEdit, minsEdit, secsEdit, millisecsEdit
    global mouseButtonDDL, clickTypeDDL
    global repeatRadio, repeatTimesRadio, repeatCountEdit
    global currentLocRadio, pickXEdit, pickYEdit
    
    ; Save current settings
    settings.hours := Integer(hoursEdit.Value)
    settings.mins := Integer(minsEdit.Value)
    settings.secs := Integer(secsEdit.Value)
    settings.millisecs := Integer(millisecsEdit.Value)
    settings.mouseButton := mouseButtonDDL.Text
    settings.clickType := clickTypeDDL.Text
    settings.repeatMode := repeatRadio.Value ? "until_stopped" : "times"
    settings.repeatCount := Integer(repeatCountEdit.Value)
    settings.useCurrentLocation := currentLocRadio.Value
    settings.pickX := Integer(pickXEdit.Value)
    settings.pickY := Integer(pickYEdit.Value)
    
    SaveSettings()
    
    ; Calculate interval in milliseconds
    interval := (settings.hours * 3600000) + (settings.mins * 60000) + (settings.secs * 1000) + settings.millisecs
    
    if (interval < 1) {
        MsgBox "Click interval must be at least 1 millisecond!", "Error", "Icon!"
        return
    }
    
    clickerRunning := true
    statusText.Value := "Status: Running"
    startBtn.Enabled := false
    stopBtn.Enabled := true
    
    ; Start clicking in separate thread
    SetTimer ClickerLoop, interval
}

StopClicker(*) {
    global clickerRunning, statusText, startBtn, stopBtn
    
    clickerRunning := false
    statusText.Value := "Status: Stopped"
    startBtn.Enabled := true
    stopBtn.Enabled := false
    
    SetTimer ClickerLoop, 0
}

ClickerLoop() {
    global settings, clickerRunning
    static clickCount := 0
    
    if !clickerRunning
        return
    
    ; Check if we should stop (repeat X times mode)
    if (settings.repeatMode = "times") {
        clickCount++
        if (clickCount >= settings.repeatCount) {
            clickCount := 0
            StopClicker()
            return
        }
    }
    
    ; Get click position
    if settings.useCurrentLocation {
        ; Click at current mouse position (don't move cursor)
        MouseGetPos &x, &y
    } else {
        ; Click at specified position
        x := settings.pickX
        y := settings.pickY
    }
    
    ; Determine click button and action
    button := settings.mouseButton
    clickAction := ""
    
    ; Parse button format for special actions
    if InStr(button, "(Click)") {
        button := "Middle"
        clickAction := "Click"
    } else if InStr(button, "(Down)") {
        button := "Middle"
        clickAction := "Down"
    } else if InStr(button, "(Up)") {
        button := "Middle"
        clickAction := "Up"
    }
    
    ; Perform click(s)
    if settings.useCurrentLocation {
        ; Click at current position without moving
        if (clickAction = "Down") {
            Click button " Down"
        } else if (clickAction = "Up") {
            Click button " Up"
        } else if (settings.clickType = "Double") {
            Click button " " button
        } else {
            Click button
        }
    } else {
        ; Click at specific coordinates
        if (clickAction = "Down") {
            Click x, y, button " Down"
        } else if (clickAction = "Up") {
            Click x, y, button " Up"
        } else if (settings.clickType = "Double") {
            Click x, y, button
            Click x, y, button
        } else {
            Click x, y, button
        }
    }
}

; ========== EDIT START HOTKEY ==========
EditStartHotkey(*) {
    global COLORS, settings, startBtn
    
    hotkeyGui := Gui("+Owner" mainGui.Hwnd " +AlwaysOnTop", "Edit Start Hotkey")
    hotkeyGui.BackColor := COLORS.bg
    hotkeyGui.SetFont("s9 c" COLORS.text, "Segoe UI")
    
    hotkeyGui.Add("Text", "x20 y20 w300 c" COLORS.text, "Start Hotkey:").SetFont("s10 bold")
    hotkeyGui.Add("Text", "x20 y45 w300 c" COLORS.textDim, "Right-click the Start button to change")
    
    hotkeyEdit := hotkeyGui.Add("Edit", "x20 y75 w260 h25 Background" COLORS.bgLight " c" COLORS.text, settings.hotkey)
    
    hotkeyGui.Add("Text", "x20 y110 w300 c" COLORS.textDim, "Examples: F2, F3, ^c (Ctrl+C), !x (Alt+X)")
    
    saveBtn := hotkeyGui.Add("Button", "x20 y145 w120 h30 Background" COLORS.success, "Save")
    cancelBtn := hotkeyGui.Add("Button", "x160 y145 w120 h30 Background" COLORS.danger, "Cancel")
    
    saveBtn.OnEvent("Click", (*) => SaveStartHotkey(hotkeyEdit.Value, hotkeyGui))
    cancelBtn.OnEvent("Click", (*) => hotkeyGui.Destroy())
    
    hotkeyGui.Show("w300 h195 Center")
}

SaveStartHotkey(newHotkey, gui) {
    global settings, startBtn, stopBtn
    
    if (newHotkey = "") {
        MsgBox "Hotkey cannot be empty!", "Error", "Icon!"
        return
    }
    
    try {
        ; Remove old hotkey
        try {
            Hotkey settings.hotkey, "Off"
        }
        
        ; Set new hotkey
        settings.hotkey := newHotkey
        settings.stopHotkey := newHotkey  ; Keep them synchronized
        
        Hotkey settings.hotkey, ToggleClicker, "On"
        
        SaveSettings()
        
        startBtn.Text := "Start (" settings.hotkey ")"
        stopBtn.Text := "Stop (" settings.stopHotkey ")"
        
        gui.Destroy()
        MsgBox "Hotkey updated successfully!", "Success", "Iconi"
    } catch as err {
        MsgBox "Invalid hotkey: " err.Message, "Error", "Icon!"
    }
}

; ========== EDIT STOP HOTKEY ==========
EditStopHotkey(*) {
    global COLORS, settings, stopBtn
    
    hotkeyGui := Gui("+Owner" mainGui.Hwnd " +AlwaysOnTop", "Edit Stop Hotkey")
    hotkeyGui.BackColor := COLORS.bg
    hotkeyGui.SetFont("s9 c" COLORS.text, "Segoe UI")
    
    hotkeyGui.Add("Text", "x20 y20 w300 c" COLORS.text, "Stop Hotkey:").SetFont("s10 bold")
    hotkeyGui.Add("Text", "x20 y45 w300 c" COLORS.textDim, "Right-click the Stop button to change")
    
    hotkeyEdit := hotkeyGui.Add("Edit", "x20 y75 w260 h25 Background" COLORS.bgLight " c" COLORS.text, settings.stopHotkey)
    
    hotkeyGui.Add("Text", "x20 y110 w300 c" COLORS.textDim, "Examples: F2, F3, ^c (Ctrl+C), !x (Alt+X)")
    
    saveBtn := hotkeyGui.Add("Button", "x20 y145 w120 h30 Background" COLORS.success, "Save")
    cancelBtn := hotkeyGui.Add("Button", "x160 y145 w120 h30 Background" COLORS.danger, "Cancel")
    
    saveBtn.OnEvent("Click", (*) => SaveStopHotkey(hotkeyEdit.Value, hotkeyGui))
    cancelBtn.OnEvent("Click", (*) => hotkeyGui.Destroy())
    
    hotkeyGui.Show("w300 h195 Center")
}

SaveStopHotkey(newHotkey, gui) {
    global settings, startBtn, stopBtn
    
    if (newHotkey = "") {
        MsgBox "Hotkey cannot be empty!", "Error", "Icon!"
        return
    }
    
    try {
        ; Remove old hotkey
        try {
            Hotkey settings.stopHotkey, "Off"
        }
        
        ; Set new hotkey
        settings.stopHotkey := newHotkey
        settings.hotkey := newHotkey  ; Keep them synchronized
        
        Hotkey settings.hotkey, ToggleClicker, "On"
        
        SaveSettings()
        
        startBtn.Text := "Start (" settings.hotkey ")"
        stopBtn.Text := "Stop (" settings.stopHotkey ")"
        
        gui.Destroy()
        MsgBox "Hotkey updated successfully!", "Success", "Iconi"
    } catch as err {
        MsgBox "Invalid hotkey: " err.Message, "Error", "Icon!"
    }
}

; ========== GUI CLOSE EVENT ==========
OnGuiClose(*) {
    SaveSettings()
    ExitApp
}
