﻿#Requires AutoHotkey v2.0
#SingleInstance Force
#NoTrayIcon

; Font settings
global TIMES_NEW_ROMAN := A_ScriptDir "\Assets\TimesNewRoman.ttf"
global TIMES_NEW_ROMAN_INVERTED := A_ScriptDir "\Assets\TimesNewRoman-Inverted.ttf"

; Color scheme matching your launcher
global COLORS := {
    bg: "0x0a0e14",
    card: "0x161b22",
    accent: "0xd29922",
    success: "0x238636",
    text: "0xe6edf3",
    textDim: "0x7d8590"
}

; ----------------------------------------------------------------------------------------
; replaceRobloxFonts Function
; Description: Replaces default Roblox fonts with the Times New Roman font for consistent text rendering.
; Operation:
;   - Copies the Times New Roman font file to overwrite the 'FredokaOne-Regular.ttf' and 'SourceSansPro-Bold.ttf' files in the Roblox font directory.
; Dependencies:
;   - FileCopy: Function used to copy files.
;   - TIMES_NEW_ROMAN, robloxFontPath: Global variables specifying the source font file and the destination font path.
; Return: None; updates the file system by copying font files.
; ----------------------------------------------------------------------------------------
replaceRobloxFonts() {
    try {
        ; Check if Roblox is running
        if !ProcessExist("RobloxPlayerBeta.exe") {
            ShowErrorUI("Roblox is not running!`n`nPlease launch Roblox first, then run this utility.")
            return false
        }
        
        ; Check if font files exist
        if !FileExist(TIMES_NEW_ROMAN) {
            ShowErrorUI("Font file not found:`n`n" TIMES_NEW_ROMAN "`n`nMake sure the Assets folder is present.")
            return false
        }
        
        if !FileExist(TIMES_NEW_ROMAN_INVERTED) {
            ShowErrorUI("Font file not found:`n`n" TIMES_NEW_ROMAN_INVERTED "`n`nMake sure the Assets folder is present.")
            return false
        }
        
        ; Get Roblox font path
        robloxFontPath := StrReplace(WinGetProcessPath("ahk_exe RobloxPlayerBeta.exe"), "RobloxPlayerBeta.exe", "") "content\fonts\"
        
        ; Replace fonts
        FileCopy TIMES_NEW_ROMAN, robloxFontPath "FredokaOne-Regular.ttf", true
        FileCopy TIMES_NEW_ROMAN_INVERTED, robloxFontPath "SourceSansPro-Bold.ttf", true
        
        ; Show success UI
        ShowSuccessUI()
        return true
        
    } catch as err {
        ShowErrorUI("Failed to replace fonts:`n`n" err.Message "`n`nMake sure Roblox is running and you have the required font files.")
        return false
    }
}

ShowSuccessUI() {
    global COLORS
    
    successGui := Gui("-Resize +Border +AlwaysOnTop", "Font Change Complete")
    successGui.BackColor := COLORS.bg
    successGui.SetFont("s10 c" COLORS.text, "Segoe UI")
    
    ; Success icon background
    successGui.Add("Text", "x0 y0 w400 h100 Background" COLORS.success)
    
    ; Large checkmark
    checkmark := successGui.Add("Text", "x150 y20 w100 h100 c" COLORS.text " BackgroundTrans Center", "✓")
    checkmark.SetFont("s48 bold")
    
    ; Success message
    successGui.Add("Text", "x20 y110 w360 h30 c" COLORS.text " Center", "Fonts successfully changed!")
    successGui.SetFont("s11 bold c" COLORS.text, "Segoe UI")
    
    ; Instructions
    successGui.SetFont("s10 c" COLORS.textDim, "Segoe UI")
    instructText := successGui.Add("Text", "x20 y145 w360 h80 c" COLORS.textDim " Center", 
        "The fonts have been replaced.`n`n"
        . "Please rejoin your Roblox game`n"
        . "to see the changes take effect.")
    
    ; OK button
    successGui.SetFont("s10 c" COLORS.text, "Segoe UI")
    okBtn := successGui.Add("Button", "x140 y235 w120 h35 Background" COLORS.success, "OK")
    okBtn.SetFont("s11 bold")
    okBtn.OnEvent("Click", (*) => successGui.Destroy())
    
    ; Close on Escape
    successGui.OnEvent("Escape", (*) => successGui.Destroy())
    
    ; Auto-close after 10 seconds
    SetTimer () => successGui.Destroy(), -10000
    
    successGui.Show("w400 h285 Center")
}

ShowErrorUI(errorMsg) {
    global COLORS
    
    errorGui := Gui("-Resize +Border +AlwaysOnTop", "Error")
    errorGui.BackColor := COLORS.bg
    errorGui.SetFont("s10 c" COLORS.text, "Segoe UI")
    
    ; Error icon background
    errorGui.Add("Text", "x0 y0 w400 h100 Background0xda3633")
    
    ; Large X
    errorMark := errorGui.Add("Text", "x150 y20 w100 h100 cWhite BackgroundTrans Center", "✗")
    errorMark.SetFont("s48 bold")
    
    ; Error title
    errorGui.Add("Text", "x20 y110 w360 h30 c" COLORS.text " Center", "Font Change Failed")
    errorGui.SetFont("s11 bold c" COLORS.text, "Segoe UI")
    
    ; Error message
    errorGui.SetFont("s9 c" COLORS.textDim, "Segoe UI")
    errorText := errorGui.Add("Text", "x20 y145 w360 h120 c" COLORS.textDim, errorMsg)
    
    ; OK button
    errorGui.SetFont("s10 c" COLORS.text, "Segoe UI")
    okBtn := errorGui.Add("Button", "x140 y275 w120 h35 Background0xda3633", "OK")
    okBtn.SetFont("s11 bold")
    okBtn.OnEvent("Click", (*) => errorGui.Destroy())
    
    errorGui.OnEvent("Escape", (*) => errorGui.Destroy())
    
    errorGui.Show("w400 h325 Center")
}

; Execute the function
replaceRobloxFonts()

; Don't exit immediately if showing UI
Sleep 100