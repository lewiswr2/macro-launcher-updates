#Requires AutoHotkey v2.0
#SingleInstance Force
#NoTrayIcon

if FileExist(A_ScriptDir "\Icon.png") {
    TraySetIcon(A_ScriptDir "\Icon.png")
}

global COLORS := {
    headerBg: "0xd29922",
    headerText: "0x13171d",
    bg: "0x0a0e14",
    cardBg: "0x161b22",
    cardHover: "0x1c2128",
    text: "0xFFFFFF",
    textDim: "0xB0B0B0",
    border: "0x3A3A3A",
    success: "0x4CAF50",
    warning: "0xFFC107",
    danger: "0xF44336",
    buttonBg: "0xF5E6D3",
    buttonText: "0x000000"
}

global RobloxHandle := ""
global IsRunning := false
global SelectedMode := "1"
global LuckCount := 0
global TotalClicks := 0
global StartTime := 0

RobloxClick(x, y) {
    global RobloxHandle
    if (RobloxHandle == "") {
        if (!InitializeRoblox())
            return false
    }
    
    try {
        WinActivate "ahk_id " . RobloxHandle
        
        SendEvent "{Click " x " " y "}"
        return true
    } catch {
        try {
            WinActivate "ahk_id " . RobloxHandle
            SendEvent "{Click " x " " y "}"
            return true
        } catch {
            return false
        }
    }
}

RobloxSendText(text) {
    global RobloxHandle
    if (RobloxHandle == "") {
        if (!InitializeRoblox())
            return false
    }
    
    try {
        WinActivate "ahk_id " . RobloxHandle
        SendEvent text
        return true
    } catch {
        return false
    }
}

RobloxSendKey(key, holdMs := 0) {
    global RobloxHandle
    if (RobloxHandle = "") {
        if (!InitializeRoblox())
            return false
    }
    try {
        WinActivate "ahk_id " . RobloxHandle

        if (holdMs = 0) {
            SendEvent(key)
        } else {
            SendEvent("{" . key . " down}")
            Sleep holdMs
            SendEvent("{" . key . " up}")
        }
        return true
    } catch {
        try {
            ControlSend(key, , "ahk_id " . RobloxHandle)
            return true
        } catch {
            return false
        }
    }
}

MainGui := Gui("+AlwaysOnTop -MinimizeBox", "RCU Circus Minigame")
MainGui.BackColor := COLORS.bg

if FileExist(A_ScriptDir "\Icon.png") {
    try MainGui.Icon := A_ScriptDir "\Icon.png"
}

MainGui.Add("Progress", "x0 y0 w560 h100 Background" SubStr(COLORS.headerBg, 3))

MainGui.SetFont("s20 bold c" SubStr(COLORS.headerText, 3), "Segoe UI")
MainGui.Add("Text", "x0 y25 w560 Center BackgroundTrans", "🎪 RCU Circus Minigame")
MainGui.SetFont("s10 c" SubStr(COLORS.headerText, 3))
MainGui.Add("Text", "x0 y60 w560 Center BackgroundTrans", "Automated Circus Minigame")

MainGui.SetFont("s12 bold c" SubStr(COLORS.text, 3), "Segoe UI")
MainGui.Add("Text", "x20 y120 BackgroundTrans", "Mode Selection")

MainGui.SetFont("s11 c" SubStr(COLORS.text, 3))
global Radio1 := MainGui.Add("Radio", "x20 y150 Checked Group", "Use 1 at a time")
MainGui.SetFont("s9 c" SubStr(COLORS.textDim, 3))
MainGui.Add("Text", "x40 y175 BackgroundTrans", "Click coordinates: (212, 276)")

MainGui.SetFont("s11 c" SubStr(COLORS.text, 3))
global Radio25 := MainGui.Add("Radio", "x20 y205", "Use 25 at a time")
MainGui.SetFont("s9 c" SubStr(COLORS.textDim, 3))
MainGui.Add("Text", "x40 y230 BackgroundTrans", "Click coordinates: (212, 297)")

MainGui.SetFont("s11 c" SubStr(COLORS.text, 3))
global Radio100 := MainGui.Add("Radio", "x20 y260", "Use 100 at a time")
MainGui.SetFont("s9 c" SubStr(COLORS.textDim, 3))
MainGui.Add("Text", "x40 y285 BackgroundTrans", "Click coordinates: (212, 321)")

Radio1.OnEvent("Click", (*) => UpdateMode("1"))
Radio25.OnEvent("Click", (*) => UpdateMode("25"))
Radio100.OnEvent("Click", (*) => UpdateMode("100"))

MainGui.SetFont("s12 bold c" SubStr(COLORS.text, 3), "Segoe UI")
MainGui.Add("Text", "x20 y320 BackgroundTrans", "Statistics")

MainGui.Add("Progress", "x20 y350 w520 h120 Background" SubStr(COLORS.cardBg, 3))
MainGui.SetFont("s10 c" SubStr(COLORS.text, 3))
global StatusText := MainGui.Add("Text", "x35 y365 w490 c" SubStr(COLORS.textDim, 3) " BackgroundTrans", "Status: Idle")
global LuckCountText := MainGui.Add("Text", "x35 y395 w490 c" SubStr(COLORS.success, 3) " BackgroundTrans", "Luck Found: 0")
global ClickCountText := MainGui.Add("Text", "x35 y420 w490 c" SubStr(COLORS.warning, 3) " BackgroundTrans", "Total Clicks: 0")
global RuntimeText := MainGui.Add("Text", "x35 y445 w490 c" SubStr(COLORS.text, 3) " BackgroundTrans", "Runtime: 00:00:00")

global StartBtn := MainGui.Add("Button", "x20 y490 w250 h50 Background" SubStr(COLORS.cardBg, 3), "▶️ Start Macro")
StartBtn.SetFont("s11 bold c" SubStr(COLORS.text, 3))
StartBtn.OnEvent("Click", StartMacro)

global StopBtn := MainGui.Add("Button", "x290 y490 w250 h50 Background" SubStr(COLORS.cardBg, 3) " Disabled", "⏹️ Stop Macro")
StopBtn.SetFont("s11 bold c" SubStr(COLORS.text, 3))
StopBtn.OnEvent("Click", StopMacro)

MainGui.SetFont("s8 c" SubStr(COLORS.textDim, 3))
MainGui.Add("Text", "x20 y555 w520 Center BackgroundTrans", "F1: Start | F2: Pause | F3: Exit | F4: Detection Test | F5: Reload")

MainGui.Show("w560 h590")

F1::StartMacro()
F2::StopMacro()
F3::ExitApp
F4::TestOCR()
F5::Reload

TestOCR(*) {
    global RobloxHandle
    
    try {
        if (RobloxHandle == "") {
            if (!InitializeRoblox()) {
                MsgBox("Failed to initialize Roblox window for test!", "Test Error", "Icon!")
                return
            }
        }
        
        WinActivate "ahk_id " RobloxHandle
        Sleep 200
        WinGetPos &winX, &winY, &winW, &winH, "ahk_id " RobloxHandle
        
        resultText := "=== LUCK DETECTION TEST ===" 
        resultText .= "`n`nWindow Position: " winX ", " winY
        resultText .= "`nWindow Size: " winW " x " winH
        resultText .= "`n`n--- METHOD 1: COLOR SEARCH ---"
        resultText .= "`nTarget Color: 00C300 (Green)"
        resultText .= "`nTolerance: 5"
        
        UpdateCurrentStatus("Testing green color search...")
        if (PixelSearch(&foundX, &foundY, winX, winY, winX + winW, winY + winH, 0x00C300, 5)) {
            relativeX := foundX - winX
            relativeY := foundY - winY
            actualColor := PixelGetColor(foundX, foundY)
            
            resultText .= "`n✅ GREEN COLOR FOUND!"
            resultText .= "`nScreen Position: " foundX ", " foundY
            resultText .= "`nRelative Position: " relativeX ", " relativeY
            resultText .= "`nActual Color: " Format("{:06X}", actualColor)
        } else {
            resultText .= "`n❌ GREEN COLOR NOT FOUND"
        }
        
        resultText .= "`n`n--- METHOD 2: IMAGE SEARCH ---"
        luckImagePath := A_ScriptDir "\Images\Luck.png"
        resultText .= "`nImage Path: " luckImagePath
        
        if (FileExist(luckImagePath)) {
            resultText .= "`n✅ Luck.png exists"
            UpdateCurrentStatus("Testing image search...")
            
            try {
                if (ImageSearch(&imgX, &imgY, winX, winY, winX + winW, winY + winH, luckImagePath)) {
                    relativeImgX := imgX - winX
                    relativeImgY := imgY - winY
                    
                    resultText .= "`n✅ LUCK IMAGE FOUND!"
                    resultText .= "`nScreen Position: " imgX ", " imgY
                    resultText .= "`nRelative Position: " relativeImgX ", " relativeImgY
                } else {
                    resultText .= "`n❌ LUCK IMAGE NOT FOUND"
                }
            } catch as imgErr {
                resultText .= "`n❌ IMAGE SEARCH ERROR: " imgErr.Message
            }
        } else {
            resultText .= "`n❌ Luck.png does NOT exist"
            resultText .= "`nCreate folder: " A_ScriptDir "\Images\"
            resultText .= "`nPlace Luck.png in that folder"
        }
        
        MsgBox(resultText, "Luck Detection Test - F4", "Icon!")
        UpdateCurrentStatus("Test complete")
    } catch as err {
        MsgBox("Test Error: " err.Message, "Error", "Icon!")
        UpdateCurrentStatus("Test failed: " err.Message)
    }
}

UpdateMode(mode) {
    global SelectedMode := mode
    UpdateCurrentStatus("Mode changed to: " mode " at a time")
}

UpdateCurrentStatus(message) {
    global StatusText
    StatusText.Value := "Status: " message
}

UpdateStats() {
    global LuckCountText, ClickCountText, RuntimeText, StartTime
    LuckCountText.Value := "Luck Found: " LuckCount
    ClickCountText.Value := "Total Clicks: " TotalClicks
    
    if (StartTime > 0) {
        elapsed := A_TickCount - StartTime
        hours := Floor(elapsed / 3600000)
        minutes := Floor(Mod(elapsed, 3600000) / 60000)
        seconds := Floor(Mod(elapsed, 60000) / 1000)
        RuntimeText.Value := "Runtime: " Format("{:02d}:{:02d}:{:02d}", hours, minutes, seconds)
    }
}

InitializeRoblox() {
    global RobloxHandle
    UpdateCurrentStatus("Initializing Roblox window...")
    try {
        WinActivate "ahk_exe RobloxPlayerBeta.exe"
        RobloxHandle := WinGetID("ahk_exe RobloxPlayerBeta.exe")
        WinRestore RobloxHandle
        WinMove 150, 150, 800, 600, RobloxHandle
        WinActivate "ahk_exe RobloxPlayerBeta.exe"
        Sleep 500
        UpdateCurrentStatus("Roblox window initialized successfully")
        return true
    } catch as err {
        UpdateCurrentStatus("Failed to initialize Roblox window")
        MsgBox("Failed to initialize Roblox window. Make sure Roblox is running!", "Error", "Icon!")
        RobloxHandle := ""
        return false
    }
}

PerformInitialClick() {
    global SelectedMode, TotalClicks, RobloxHandle
    
    UpdateCurrentStatus("Performing initial setup...")
    
    WinActivate "ahk_id " RobloxHandle
    Sleep 200
    
    clickX := 212
    clickY := 0
    
    Switch SelectedMode {
        case "1":
            clickY := 276
            UpdateCurrentStatus("Clicking '1 at a time'...")
        case "25":
            clickY := 297
            UpdateCurrentStatus("Clicking '25 at a time'...")
        case "100":
            clickY := 321
            UpdateCurrentStatus("Clicking '100 at a time'...")
    }
    
    if (RobloxClick(clickX, clickY)) {
        TotalClicks++
    }
    Sleep 300
    
    if (RobloxClick(453, 378)) {
        TotalClicks++
    }
    Sleep 500
    
    UpdateCurrentStatus("Initial setup complete. Now just scanning for luck...")
    UpdateStats()
}

CheckForLuck() {
    global RobloxHandle, LuckCount
    
    try {
        WinGetPos &winX, &winY, &winW, &winH, "ahk_id " RobloxHandle
        
        foundSomething := false
        clickX := 0
        clickY := 0
        foundType := ""
        
        if (PixelSearch(&foundX, &foundY, winX, winY, winX + winW, winY + winH, 0x00C300, 5)) {
            foundSomething := true
            clickX := foundX
            clickY := foundY
            foundType := "Green Color"
        }
        
        luckImagePath := A_ScriptDir "\Images\Luck.png"
        if (FileExist(luckImagePath)) {
            try {
                if (ImageSearch(&imgX, &imgY, winX, winY, winX + winW, winY + winH, luckImagePath)) {
                    foundSomething := true
                    clickX := imgX
                    clickY := imgY
                    foundType := "Luck Image"
                }
            } catch {
            }
        }
        
        if (foundSomething) {
            LuckCount++
            
            SendEvent "{Click " clickX " " clickY "}"
            
            relativeX := clickX - winX
            relativeY := clickY - winY
            
            UpdateCurrentStatus("🎉 LUCK FOUND & CLICKED! (" foundType " at " relativeX ", " relativeY ") Total: " LuckCount)
            UpdateStats()
            
            return true
        }
        return false
    } catch as err {
        UpdateCurrentStatus("Luck search error: " err.Message)
        return false
    }
}

MacroLoop() {
    global IsRunning, RobloxHandle
    
    while (IsRunning) {
        WinActivate "ahk_id " RobloxHandle        
        UpdateCurrentStatus("Scanning for luck...")
        CheckForLuck()
        UpdateStats()
    }
}

StartMacro(*) {
    global IsRunning, StartBtn, StopBtn, StartTime, LuckCount, TotalClicks
    
    if (IsRunning) {
        return
    }
    
    LuckCount := 0
    TotalClicks := 0
    StartTime := A_TickCount
    UpdateStats()
    
    if (!InitializeRoblox()) {
        return
    }
    
    PerformInitialClick()
    
    IsRunning := true
    StartBtn.Enabled := false
    StopBtn.Enabled := true
    
    UpdateCurrentStatus("Macro running - scanning for luck only!")
    
    SetTimer MacroLoop, 100
}

StopMacro(*) {
    global IsRunning, StartBtn, StopBtn
    
    if (!IsRunning) {
        return
    }
    
    IsRunning := false
    SetTimer MacroLoop, 0
    StartBtn.Enabled := true
    StopBtn.Enabled := false
    
    UpdateCurrentStatus("Macro stopped by user")
    UpdateStats()
}

OnExit(ExitFunc)

ExitFunc(ExitReason, ExitCode) {
    global IsRunning
    IsRunning := false
    SetTimer MacroLoop, 0
}