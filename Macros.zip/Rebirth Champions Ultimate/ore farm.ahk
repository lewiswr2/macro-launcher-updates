﻿#Requires AutoHotkey v2.0
#SingleInstance Force
f1::{
    Send "{Right down}"
    Sleep 400
    Send "{/}"
    Send "{Right up}"
    Loop {
    SendEvent "{click }"
    WaitForTreeToBreak()
 
}
}
FarmingActive := true
f2::Pause(-1)
f3::ExitApp
f4::Reload
WaitForTreeToBreak() {
    global
    Sleep(250)
    colorFound := false
    timeout := 0
    
    while (!colorFound && timeout < 10) {
        if (!FarmingActive)
            return
        
        if (PixelSearch(&foundX, &foundY, 320, 518, 320, 518, 0x2FB7FC)) {
            colorFound := true
        } else {
            timeout++
        }
    }
    
    if (!colorFound) {
        return
    }
    
    while (PixelSearch(&foundX, &foundY, 320, 518, 320, 518, 0x2FB7FC)) {
        if (!FarmingActive)
            return
    }
}

IsTreeBroken() {
    global
    if (!PixelSearch(&foundX, &foundY, 320, 518, 320, 518, 0x2FB7FC)) {
        return true
    }
    return false
}