#Requires AutoHotkey v2.0
#SingleInstance Force
#Warn All, Off
#Include <OCR>
SetWorkingDir A_ScriptDir
CoordMode "Mouse", "Client"
CoordMode "Pixel", "Client"
SetMouseDelay 10
#NoTrayIcon

; Font file paths
TIMES_NEW_ROMAN := A_ScriptDir "\Assets\TimesNewRoman.ttf"
TIMES_NEW_ROMAN_INVERTED := A_ScriptDir "\Assets\TimesNewRoman-Inverted.ttf"
FREDOKA_ONE_REGULAR := A_ScriptDir "\Assets\FredokaOne-Regular.ttf"
SOURCE_SANS_PRO_BOLD := A_ScriptDir "\Assets\SourceSansPro-Bold.ttf"

; Dark Theme Colors
COLORS := {
    bg: "0a0e14",
    bgLight: "13171d",
    card: "161b22",
    cardHover: "1c2128",
    accent: "d29922",
    accentHover: "2ea043",
    accentAlt: "1f6feb",
    text: "e6edf3",
    textDim: "7d8590",
    border: "21262d",
    success: "238636",
    warning: "d29922",
    danger: "da3633",
    favorite: "fbbf24"
}

FarmingActive := false
CurrentWood := ""
TimeLeft := 0
QueueList := []
QueueIndex := 1
MainTimer := ""
InitializationComplete := false
RobloxHandle := ""
TimerRunning := false

SessionStartTime := 0
SessionTreeCount := 0

Stats := {
    Sessions: 0,
    TotalTime: 0,
    TotalMinutes: 0,
    TreesClicked: 0,
    WoodCounts: Map()
}

WoodTypes := [
    "🌳 Wood",
    "🌵 Cactus Wood",
    "☢️ Nuclear Wood",
    "🌊 Atlantis Wood",
    "👑 Royal Wood",
    "💎 Diamond Wood",
    "🌋 Magma Wood",
    "☁️ Heaven Wood",
    "✨ Magic Wood",
    "🎪 Circus Wood",
    "🌴 Jungle Wood",
    "⚙️ Steampunk Wood",
    "🌸 Sakura Wood"
]

for woodType in WoodTypes {
    cleanType := RegExReplace(woodType, "^[^\s]+ ", "")
    Stats.WoodCounts[cleanType] := 0
}

MainGui := ""
WoodTypeDD := ""
DurationEdit := ""
QueueList_LV := ""
StatusLabel := ""
TimeLabel := ""
ProgressBar := ""
SaveNameEdit := ""
LoadPresetDD := ""
AxeKeybindEdit := ""

SettingsFolder := A_ScriptDir "\Settings"
StatsFile := SettingsFolder "\stats.ini"
ConfigFile := SettingsFolder "\config.ini"
AxeKeybind := ""

if !DirExist(SettingsFolder)
    DirCreate(SettingsFolder)

; Replace fonts on startup
ReplaceFontsOnStartup()

CreateGUI()
LoadStats()
LoadConfig()
RefreshPresetList()
InitializeRoblox()

; Font Replacement Functions
replaceRobloxFonts() {
    try {
        robloxFontPath := StrReplace(WinGetProcessPath("ahk_exe RobloxPlayerBeta.exe"), "RobloxPlayerBeta.exe", "") "content\fonts\"
        FileCopy TIMES_NEW_ROMAN_INVERTED, robloxFontPath "FredokaOne-Regular.ttf", true
        FileCopy TIMES_NEW_ROMAN_INVERTED, robloxFontPath "SourceSansPro-Bold.ttf", true
        return true
    } catch {
        return false
    }
}

changeToDefaultFont(*) {
    try {
        robloxFontPath := StrReplace(WinGetProcessPath("ahk_exe RobloxPlayerBeta.exe"), "RobloxPlayerBeta.exe", "") "content\fonts\"
        FileCopy FREDOKA_ONE_REGULAR, robloxFontPath "FredokaOne-Regular.ttf", true
        FileCopy SOURCE_SANS_PRO_BOLD, robloxFontPath "SourceSansPro-Bold.ttf", true
        return true
    } catch {
        return false
    }
}

ReplaceFontsOnStartup() {
    if WinExist("ahk_exe RobloxPlayerBeta.exe") {
        if replaceRobloxFonts() {
            MsgBox("Fonts changed successfully!`n`nPlease reload Roblox to see the changes for better OCR accuracy.", "Font Replacement Success", "Iconi T3")
        } else {
            MsgBox("Failed to replace fonts. Make sure:`n• Roblox is running`n• Font files exist in Assets folder`n• You have write permissions", "Font Replacement Failed", "Icon! T5")
        }
    } else {
        MsgBox("Roblox is not running!`n`nPlease start Roblox first, then restart this macro to apply font changes.", "Roblox Not Found", "Icon! T5")
    }
}

CreateGUI() {
    global
    
    MainGui := Gui("+Resize -DPIScale", "Wood Farming Manager")
    MainGui.OnEvent("Close", (*) => OnExit())
    MainGui.BackColor := COLORS.bg
    MainGui.SetFont("s9", "Segoe UI")
    
    ; Header Section
    MainGui.Add("Text", "x0 y0 w600 h70 Background" . COLORS.accent)
    TitleText := MainGui.Add("Text", "x20 y20 w560 h35 Center c" . COLORS.bgLight " BackgroundTrans", "🪓 Wood Farming Manager")
    TitleText.SetFont("s18 Bold", "Segoe UI")
    
    ; Left Column - Add to Queue
    MainGui.SetFont("s9 Bold", "Segoe UI")
    MainGui.Add("Text", "x20 y80 w260 h20 c" . COLORS.text, "Add to Queue")
    MainGui.SetFont("s9", "Segoe UI")
    
    MainGui.Add("Text", "x20 y105 w260 h160 Background" . COLORS.card)
    
    MainGui.Add("Text", "x35 y120 c" . COLORS.text " BackgroundTrans", "Wood Type:")
    WoodTypeDD := MainGui.Add("DropDownList", "x35 y140 w230 Background" . COLORS.bgLight " c" . COLORS.text, WoodTypes)
    WoodTypeDD.Choose(1)
    
    MainGui.Add("Text", "x35 y175 c" . COLORS.text " BackgroundTrans", "Duration (minutes):")
    DurationEdit := MainGui.Add("Edit", "x180 y172 w85 Number Background" . COLORS.bgLight " c" . COLORS.text, "5")
    
    AddBtn := MainGui.Add("Button", "x35 y210 w100 h35 Background" . COLORS.success " c" . COLORS.text, "▶ Add")
    AddBtn.OnEvent("Click", AddToQueue)
    AddBtn.SetFont("s9 Bold")
    
    ClearBtn := MainGui.Add("Button", "x145 y210 w120 h35 Background" . COLORS.danger " c" . COLORS.text, "🗑 Clear All")
    ClearBtn.OnEvent("Click", ClearQueue)
    ClearBtn.SetFont("s9 Bold")
    
    ; Right Column - Settings
    MainGui.SetFont("s9 Bold", "Segoe UI")
    MainGui.Add("Text", "x300 y80 w280 h20 c" . COLORS.text, "Settings")
    MainGui.SetFont("s9", "Segoe UI")
    
    MainGui.Add("Text", "x300 y105 w280 h80 Background" . COLORS.card)
    
    MainGui.Add("Text", "x315 y120 c" . COLORS.text " BackgroundTrans", "Axe Keybind:")
    AxeKeybindEdit := MainGui.Add("Edit", "x410 y117 w75 Uppercase Limit1 Background" . COLORS.bgLight " c" . COLORS.text " Center", "")
    AxeKeybindEdit.OnEvent("Change", SaveAxeKeybind)
    AxeKeybindEdit.SetFont("s10 Bold")
    
    MainGui.Add("Text", "x315 y150 w250 c" . COLORS.textDim " BackgroundTrans", "(Must be set before starting)")
    
    ; Queue Display
    MainGui.SetFont("s9 Bold", "Segoe UI")
    MainGui.Add("Text", "x300 y195 w280 h20 c" . COLORS.text, "Queue")
    MainGui.SetFont("s9", "Segoe UI")
    
    MainGui.Add("Text", "x300 y220 w280 h160 Background" . COLORS.card)
    
    QueueList_LV := MainGui.Add("ListView", "x310 y230 w260 h140 -Multi ReadOnly Background" . COLORS.bgLight " c" . COLORS.text, ["Wood Type", "Duration"])
    QueueList_LV.ModifyCol(1, 170)
    QueueList_LV.ModifyCol(2, 70)
    
    ; Controls Section
    MainGui.SetFont("s9 Bold", "Segoe UI")
    MainGui.Add("Text", "x20 y390 w560 h20 c" . COLORS.text, "Controls")
    MainGui.SetFont("s9", "Segoe UI")
    
    MainGui.Add("Text", "x20 y415 w560 h135 Background" . COLORS.card)
    
    StartBtn := MainGui.Add("Button", "x35 y430 w110 h36 Background" . COLORS.success " c" . COLORS.text, "▶ Start")
    StartBtn.OnEvent("Click", StartFarming)
    StartBtn.SetFont("s10 Bold")
    
    StopBtn := MainGui.Add("Button", "x155 y430 w110 h36 Background" . COLORS.warning " c000000", "⏸ Pause")
    StopBtn.OnEvent("Click", StopFarming)
    StopBtn.SetFont("s10 Bold")
    
    StatsBtn := MainGui.Add("Button", "x275 y430 w110 h36 Background" . COLORS.accentAlt " c" . COLORS.text, "📊 Stats")
    StatsBtn.OnEvent("Click", ShowStats)
    StatsBtn.SetFont("s10 Bold")
    
    MainGui.Add("Text", "x400 y437 w80 c" . COLORS.text " BackgroundTrans Right", "Reset Stats:")
    ResetBtn := MainGui.Add("Button", "x490 y430 w75 h36 Background" . COLORS.danger " c" . COLORS.text, "🔄 Reset")
    ResetBtn.OnEvent("Click", ResetStats)
    ResetBtn.SetFont("s9 Bold")
    
    MainGui.SetFont("s9", "Segoe UI")
    MainGui.Add("Text", "x35 y483 c" . COLORS.text " BackgroundTrans", "Save As:")
    SaveNameEdit := MainGui.Add("Edit", "x95 y480 w120 Background" . COLORS.bgLight " c" . COLORS.text, "")
    
    SaveBtn := MainGui.Add("Button", "x225 y478 w90 h28 Background" . COLORS.accent " c000000", "💾 Save")
    SaveBtn.OnEvent("Click", SaveQueue)
    SaveBtn.SetFont("s9 Bold")
    
    MainGui.Add("Text", "x330 y483 c" . COLORS.text " BackgroundTrans", "Load:")
    LoadPresetDD := MainGui.Add("DropDownList", "x375 y480 w120 Background" . COLORS.bgLight " c" . COLORS.text, [""])
    
    LoadBtn := MainGui.Add("Button", "x505 y478 w60 h28 Background" . COLORS.accentAlt " c" . COLORS.text, "📂 Load")
    LoadBtn.OnEvent("Click", LoadQueue)
    LoadBtn.SetFont("s9 Bold")
    
    ; Status Section
    MainGui.SetFont("s9 Bold", "Segoe UI")
    MainGui.Add("Text", "x20 y560 w560 h20 c" . COLORS.text, "Status")
    MainGui.SetFont("s9", "Segoe UI")
    
    MainGui.Add("Text", "x20 y585 w560 h85 Background" . COLORS.card)
    
    StatusLabel := MainGui.Add("Text", "x35 y600 w530 h22 c" . COLORS.text " BackgroundTrans", "Ready")
    StatusLabel.SetFont("s10", "Segoe UI")
    
    TimeLabel := MainGui.Add("Text", "x35 y630 w220 h25 c" . COLORS.accent " BackgroundTrans", "Time: 0:00")
    TimeLabel.SetFont("s11 Bold", "Segoe UI")
    
    ProgressBar := MainGui.Add("Progress", "x270 y632 w295 h22 Background" . COLORS.bgLight " c" . COLORS.accent, 0)
    
    ; Footer
    MainGui.Add("Text", "x0 y685 w600 h40 Background" . COLORS.bgLight)
    MainGui.Add("Text", "x20 y695 w560 h20 Center c" . COLORS.textDim " BackgroundTrans", "Hotkeys: F1=Start  F2=Pause  F3=Exit  F5=Reload")
    MainGui.SetFont("s8", "Segoe UI")
    
    MainGui.Show("w600 h725")
}

UpdateCurrentStatus(message) {
    global StatusLabel
    if (StatusLabel != "")
        StatusLabel.Text := message
}

ShowStatus(message, duration := 2000) {
    global StatusLabel
    if (StatusLabel != "") {
        StatusLabel.Text := message
        SetTimer(() => StatusLabel.Text := "Ready", -duration)
    }
}

InitializeRoblox() {
    global
    UpdateCurrentStatus("Initializing Roblox window...")
    try {
        WinActivate "ahk_exe RobloxPlayerBeta.exe"
        RobloxHandle := WinGetID("ahk_exe RobloxPlayerBeta.exe")
        WinRestore RobloxHandle
        WinMove 150, 150, 800, 600, RobloxHandle
        WinActivate "ahk_exe RobloxPlayerBeta.exe"
        UpdateCurrentStatus("Roblox window initialized successfully")
        return true
    } catch {
        UpdateCurrentStatus("Failed to initialize Roblox window")
        ShowStatus("Failed to initialize Roblox window", 3000)
        RobloxHandle := ""
        return false
    }
}

RobloxClick(x, y) {
    global RobloxHandle, SessionTreeCount
    if (RobloxHandle == "") {
        if (!InitializeRoblox())
            return false
    }
    
    try {
        WinActivate "ahk_id " . RobloxHandle
        SendEvent "{Click " x " " y "}"
        SessionTreeCount++
        return true
    } catch {
        try {
            WinActivate "ahk_id " . RobloxHandle
            SendEvent "{Click " x " " y "}"
            SessionTreeCount++
            return true
        } catch {
            return false
        }
    }
}

RobloxSendText(text) {
    global RobloxHandle
    if (RobloxHandle == "") {
        if (!InitializeRoblox())
            return false
    }
    
    try {
        WinActivate "ahk_id " . RobloxHandle
        SendEvent text
        return true
    } catch {
        return false
    }
}

RobloxSendKey(key, holdMs := 0) {
    global RobloxHandle
    if (RobloxHandle = "") {
        if (!InitializeRoblox())
            return false
    }
    try {
        WinActivate "ahk_id " . RobloxHandle
        Sleep 50
        if (holdMs = 0) {
            SendEvent(key)
        } else {
            SendEvent("{" . key . " down}")
            Sleep holdMs
            SendEvent("{" . key . " up}")
        }
        return true
    } catch {
        try {
            ControlSend(key, , "ahk_id " . RobloxHandle)
            return true
        } catch {
            return false
        }
    }
}

AddToQueue(*) {
    global
    woodType := WoodTypeDD.Text
    duration := DurationEdit.Text
    
    if (woodType == "" || duration == "" || duration == 0) {
        MsgBox("Please select wood type and duration!", "Error")
        return
    }
    
    cleanWood := RegExReplace(woodType, "^[^\s]+ ", "")
    QueueList.Push({Wood: woodType, CleanWood: cleanWood, Duration: Integer(duration)})
    
    UpdateQueueDisplay()
    DurationEdit.Text := "5"
}

UpdateQueueDisplay() {
    global
    QueueList_LV.Delete()
    
    for index, item in QueueList {
        status := ""
        if (FarmingActive) {
            if (index < QueueIndex)
                status := "✓ "
            else if (index == QueueIndex)
                status := "► "
        }
        
        QueueList_LV.Add("", status . item.CleanWood, item.Duration . "m")
    }
}

ClearQueue(*) {
    global
    if (QueueList.Length == 0)
        return
        
    result := MsgBox("Clear entire queue?", "Confirm", "YesNo")
    if (result == "Yes") {
        QueueList := []
        QueueIndex := 1
        UpdateQueueDisplay()
        
        if (FarmingActive)
            StopFarming()
    }
}

StartFarming(*) {
    global
    
    if (AxeKeybind == "" || Trim(AxeKeybindEdit.Text) == "") {
        MsgBox("Please set the Axe Keybind in Settings before starting!", "Axe Keybind Required")
        return
    }
    
    if (QueueList.Length == 0) {
        MsgBox("Queue is empty! Add items first.", "Error")
        return
    }
    
    if (FarmingActive) {
        MsgBox("Already farming!", "Info")
        return
    }
    
    if (!InitializationComplete) {
        StatusLabel.Text := "Initializing farming setup..."
        PerformInitialization()
        InitializationComplete := true
    }
    
    FarmingActive := true
    QueueIndex := 1
    Stats.Sessions++
    SessionStartTime := A_TickCount
    SessionTreeCount := 0
    
    StatusLabel.Text := "Starting farming session..."
    ProcessNextItem()
}

StopFarming(*) {
    global
    
    ; Calculate session time
    if (SessionStartTime > 0) {
        sessionDuration := (A_TickCount - SessionStartTime) // 1000
        Stats.TotalTime += sessionDuration
        Stats.TotalMinutes += Round(sessionDuration / 60, 2)
        Stats.TreesClicked += SessionTreeCount
    }
    
    FarmingActive := false
    InitializationComplete := false
    if (MainTimer != "") {
        SetTimer(MainTimer, 0)
        MainTimer := ""
        TimerRunning := false
    }
    
    StatusLabel.Text := "Paused"
    TimeLabel.Text := "Time: Paused"
    ProgressBar.Value := 0
    UpdateQueueDisplay()
    SaveStats()
}

PerformInitialization() {
    global AxeKeybind
    RobloxSendKey("{" . AxeKeybind . "}")
}

ResetStats(*) {
    global
    
    result := MsgBox("Are you sure you want to reset all statistics?`n`nThis will permanently delete:`n• Session count`n• Total time farmed`n• Trees clicked count`n• Wood collection counts`n`nThis action cannot be undone!", "Reset Statistics", "YesNo Icon! Default2")
    
    if (result == "Yes") {
        Stats.Sessions := 0
        Stats.TotalTime := 0
        Stats.TotalMinutes := 0
        Stats.TreesClicked := 0
        
        for woodType in Stats.WoodCounts {
            Stats.WoodCounts[woodType] := 0
        }
        
        SaveStats()
        MsgBox("All statistics have been reset!", "Reset Complete", "Iconi")
    }
}

ProcessNextItem() {
    global
    if (!FarmingActive || QueueIndex > QueueList.Length) {
        FarmingActive := false
        StatusLabel.Text := "Queue completed!"
        TimeLabel.Text := "Time: Complete"
        ProgressBar.Value := 100
        
        ; Calculate session stats
        if (SessionStartTime > 0) {
            sessionDuration := (A_TickCount - SessionStartTime) // 1000
            Stats.TotalTime += sessionDuration
            Stats.TotalMinutes += Round(sessionDuration / 60, 2)
            Stats.TreesClicked += SessionTreeCount
        }
        
        for item in QueueList {
            Stats.WoodCounts[item.CleanWood]++
        }
        
        QueueIndex := 1
        UpdateQueueDisplay()
        SaveStats()
        
        return
    }
    
    CurrentItem := QueueList[QueueIndex]
    CurrentWood := CurrentItem.Wood
    TimeLeft := CurrentItem.Duration * 60
    
    StatusLabel.Text := "Farming: " . CurrentItem.CleanWood . " (" . QueueIndex . "/" . QueueList.Length . ")"
    UpdateQueueDisplay()
    
    MainTimer := () => UpdateTimer()
    SetTimer(MainTimer, 1000)
    
    StartWoodFarming(CurrentItem.CleanWood)
}

StartWoodFarming(woodType) {
    switch woodType {
        case "Wood":
            TeleportToSpawnWorld()
        case "Cactus Wood":
            TeleportToDesertWorld()
        case "Nuclear Wood":
            TeleportToNuclearWorld()
        case "Atlantis Wood":
            TeleportToAtlantisWorld()
        case "Royal Wood":
            TeleportToRoyalWorld()
        case "Diamond Wood":
            TeleportToDiamondWorld()
        case "Magma Wood":
            TeleportToMagmaWorld()
        case "Heaven Wood":
            TeleportToHeavenWorld()
        case "Magic Wood":
            TeleportToMagicWorld()
        case "Circus Wood":
            TeleportToCircusWorld()
        case "Jungle Wood":
            TeleportToJungleWorld()
        case "Steampunk Wood":
            TeleportToSteampunkWorld()
        case "Sakura Wood":
            TeleportToSakuraWorld()
        default:
    }
}

WaitForTreeToBreak() {
    global
    Sleep(250)
    colorFound := false
    timeout := 0
    
    while (!colorFound && timeout < 10) {
        if (!FarmingActive)
            return
        
        if (PixelSearch(&foundX, &foundY, 320, 518, 320, 518, 0x2FB7FC)) {
            colorFound := true
        } else {
            timeout++
        }
    }
    
    if (!colorFound) {
        return
    }
    
    while (PixelSearch(&foundX, &foundY, 320, 518, 320, 518, 0x2FB7FC)) {
        if (!FarmingActive)
            return
    }
}

IsTreeBroken() {
    global
    if (!PixelSearch(&foundX, &foundY, 320, 518, 320, 518, 0x2FB7FC)) {
        return true
    }
    return false
}

WaitForClickButton() {
    Sleep 250
    imagePath := A_ScriptDir "\images\Click Button.png"
    timeout := 0
    maxTimeout := 100
    
    Loop {
        if ImageSearch(&x, &y, 0, 0, A_ScreenWidth, A_ScreenHeight, "*50 " imagePath) {
            return true
        }
        Sleep 100
        timeout++
        if (timeout >= maxTimeout) {
            MsgBox("Timeout waiting for Click Button", "Error")
            return false
        }
    }
}

WaitForTeleportIcon() {
    Sleep 250
    imagePath := A_ScriptDir "\images\Teleport Icon.png"
    timeout := 0
    maxTimeout := 100
    
    Loop {
        if ImageSearch(&x, &y, 0, 0, A_ScreenWidth, A_ScreenHeight, "*50 " imagePath) {
            return true
        }
        Sleep 100
        timeout++
        if (timeout >= maxTimeout) {
            MsgBox("Timeout waiting for Teleport Icon", "Error")
            return false
        }
    }
}

LookForXButton() {
    global RobloxHandle
    
    if !WinExist("ahk_id " RobloxHandle) {
        return false
    }
    
    WinGetPos &winX, &winY, &winW, &winH, "ahk_id " RobloxHandle
    
    searchX := 577
    searchY := 134
    searchW := 639
    searchH := 193
    
    if (searchX + searchW >= winW || searchY + searchH >= winH) {
        return false
    }
    
    try {
        ImageSearch &foundX, &foundY, winX + searchX, winY + searchY, winX + searchX + searchW, winY + searchY + searchH, "*20 Images/X Button.png"
        
        WinActivate "ahk_id " RobloxHandle
        Sleep 50
        
        clickX := foundX - winX
        clickY := foundY - winY
        
        RobloxClick(clickX, clickY)
        
        UpdateCurrentStatus("X button found and clicked")
        return true
    }
    catch {
        return false
    }
}

SpawnWorldCameraSetup() {
    Loop 20 {
        RobloxSendKey("{WheelUp}")
    }
    Loop 15 {
        RobloxSendKey("{WheelDown}")
    }
}

TeleportToSpawnWorld() {
    global
    RobloxClick(705, 325)
    Sleep 100
    RobloxClick(492, 283)
    WaitForClickButton()
    Sleep 100
    SpawnWorldCameraSetup()
    FarmWoodTrees()
}

FarmWoodTrees() {
    global
    while (FarmingActive && TimeLeft > 0) {
        trees := [ 
            {x: 626, y: 156},
            {x: 771, y: 175},
            {x: 186, y: 161},
            {x: 162, y: 57},
            {x: 613, y: 256},
            {x: 124, y: 167},
            {x: 251, y: 174},
            {x: 121, y: 100},
            {x: 6, y: 103},
            {x: 748, y: 160}
        ]   
        
        for index, tree in trees {
            if (!FarmingActive)
                return
                
            RobloxClick(tree.x, tree.y)
            WaitForTreeToBreak()
            
            if (index = 8) {
                RobloxSendKey("{WheelUp}")
            }
        }

        if (TimeLeft <= 0)
            return
            
        TeleportToSpawnWorld()
    }
}

DesertWorldCameraSetup() {
    Loop 20 {
        RobloxSendKey("{WheelUp}")
    }
    Loop 15 {
        RobloxSendKey("{WheelDown}")
    }
}

TeleportToDesertWorld() {
    global
    RobloxClick(705, 325)
    Sleep 100
    RobloxClick(400, 300)
    Sleep 100
    RobloxSendKey("{WheelDown}")
    Sleep 100
    RobloxClick(492, 348)
    WaitForClickButton()
    Sleep 100
    DesertWorldCameraSetup()
    FarmCactusTrees()
}

FarmCactusTrees() {
    global
    while (FarmingActive && TimeLeft > 0) {
        trees := [ 
            {x: 502, y: 272},
            {x: 184, y: 135},
            {x: 481, y: 299},
            {x: 634, y: 331},
            {x: 525, y: 129}
        ]   
        
        for index, tree in trees {
            if (!FarmingActive)
                return
                
            RobloxClick(tree.x, tree.y)
            WaitForTreeToBreak()
            
            if (index = 4) {
                Loop 4 {
                    RobloxSendKey("{WheelUp}")
                }
            }
        }
        
        if (TimeLeft <= 0)
            return
            
        Sleep 9000
        
        if (TimeLeft <= 0)
            return
            
        TeleportToDesertWorld()
    }
}

NuclearWorldCameraSetup() {
    Loop 20 {
        RobloxSendKey("{WheelUp}")
    }
    Loop 12 {
        RobloxSendKey("{WheelDown}")
    }
}

TeleportToNuclearWorld() {
    global
    RobloxClick(705, 325)
    Sleep 100
    RobloxClick(400, 300)
    Sleep 100
    Loop 2 {
    RobloxSendKey("{WheelDown}")
    }
    Sleep 100
    RobloxClick(492, 319)
    WaitForClickButton()
    Sleep 100
    NuclearWorldCameraSetup()
    FarmNuclearTrees()
}

HoldSUntilToxic() {
    global RobloxHandle, FarmingActive

    text := "Toxic"

    if (RobloxHandle = "") {
        if (!InitializeRoblox())
            return false
    }

    WinActivate "ahk_id " . RobloxHandle
    Sleep 100

    WinGetPos &x, &y, &w, &h, "ahk_id " . RobloxHandle

    SendEvent "{s down}"

    Loop {
        if (!FarmingActive) {
            SendEvent "{s up}"
            return false
        }

        ocrObject := OCR.FromRect(x, y, w, h, , 1)

        if InStr(ocrObject.Text, text) {
            SendEvent "{s up}"
            return true
        }

        Sleep 150
    }
}

FarmNuclearTrees() {
    global
    while (FarmingActive && TimeLeft > 0) {
        trees := [ 
            {x: 737, y: 137},
            {x: 677, y: 226},
            {x: 682, y: 238},
            {x: 366, y: 312},
            {x: 540, y: 187}
        ]   
        
        for index, tree in trees {
            if (!FarmingActive)
                return
                
            RobloxClick(tree.x, tree.y)
            
            if (index = 2 || index = 5) {
                Sleep(250)
                colorFound := false
                timeout := 0
                maxLoops := (index = 2) ? 25 : 100
                
                ; Wait for tree to start breaking (blue pixel appears)
                while (!colorFound && timeout < 10) {
                    if (!FarmingActive)
                        return
                    
                    if (PixelSearch(&foundX, &foundY, 320, 518, 320, 518, 0x2FB7FC)) {
                        colorFound := true
                    } else {
                        timeout++
                    }
                }
                
                if (!colorFound) {
                    continue
                }
                
                ; Spam space while checking if tree is broken
                Loop maxLoops {
                    if (!PixelSearch(&foundX, &foundY, 320, 518, 320, 518, 0x2FB7FC)) {
                        break
                    }
                    RobloxSendKey("{Space Down}")
                    Sleep 10
                    RobloxSendKey("{Space Up}")
                    Sleep 90
                }
            } else {
                WaitForTreeToBreak()
            }
            
            if (index = 4) {
                RobloxClick(603, 167)
            }

            if (index = 3) {
                Loop 4 {
                    RobloxSendKey("{WheelUp}")
                }
                HoldSUntilToxic()
                Sleep 100
                RobloxClick(603, 167)
                Loop 4 {
                    RobloxSendKey("{WheelDown}")
                }
            }
            
            if (index = 1) {
                Loop 3 {
                    RobloxSendKey("{WheelDown}")
                }
            }
        }   
        if (TimeLeft <= 0)
            return
        Sleep 3500
        if (TimeLeft <= 0)
            return
        TeleportToNuclearWorld()
    }
}

; ===== ATLANTIS WORLD =====
AtlantisWorldCameraSetup() {
    Loop 20 {
        RobloxSendKey("{WheelUp}")
    }
    Loop 10 {
        RobloxSendKey("{WheelDown}")
    }
}

TeleportToAtlantisWorld() {
    global
    RobloxClick(705, 325)
    Sleep(100)
    RobloxClick(400, 300)
    Sleep(100)
    Loop 3 {
        RobloxSendKey("{WheelDown}")
    }
    Sleep(100)
    RobloxClick(492, 288)
    WaitForClickButton()
    Sleep(100)
    AtlantisWorldCameraSetup()
    FarmAtlantisTrees()
}

FarmAtlantisTrees() {
    global
    while (FarmingActive && TimeLeft > 0) {
        trees := [ 
            { x: 431, y: 154 },
            { x: 799, y: 207 },
            { x: 152, y: 182 }
        ]   
        
        for index, tree in trees {
            if (!FarmingActive)
                return
                
            RobloxClick(tree.x, tree.y)

            if (index = 1) {
                Loop 6 {
                    RobloxSendKey("{WheelDown}")
                }
            }

            WaitForTreeToBreak()
        }

        if (TimeLeft <= 0)
            return
        Sleep 20000
        if (TimeLeft <= 0)
            return
        TeleportToAtlantisWorld()
    }
}

; ===== ROYAL WORLD =====
RoyalWorldCameraSetup() {
    Loop 20 {
        RobloxSendKey("{WheelUp}")
    }
    Loop 11 {
        RobloxSendKey("{WheelDown}")
    }
}

TeleportToRoyalWorld() {
    global
    RobloxClick(705, 325)
    Sleep(100)
    RobloxClick(400, 300)
    Sleep(100)
    Loop 3 {
        RobloxSendKey("{WheelDown}")
    }
    Sleep(100)
    RobloxClick(492, 386)
    WaitForClickButton()
    Sleep(100)
    RoyalWorldCameraSetup()
    FarmRoyalTrees()
}

ClickAUntilMachine() {
    global RobloxHandle, FarmingActive

    text := "Machine"

    if (RobloxHandle = "") {
        if (!InitializeRoblox())
            return false
    }

    WinActivate "ahk_id " . RobloxHandle
    Sleep 100

    WinGetPos &x, &y, &w, &h, "ahk_id " . RobloxHandle

    Loop {
        if (!FarmingActive) {
            return false
        }

        ocrObject := OCR.FromRect(x, y, w, h, , 1)

        if InStr(ocrObject.Text, text) {
            Loop 10 {
                RobloxSendKey("{WheelDown}")
            }
            return true
        }

        SendEvent "{a down}"
        Sleep 10
        SendEvent "{a up}"
        Sleep 150
    }
}

FarmRoyalTrees() {
    global
    while (FarmingActive && TimeLeft > 0) {
        trees := [ 
            {x: 755, y: 144},
            {x: 146, y: 198},
            {x: 400, y: 300},
            {x: 734, y: 135},
            {x: 744, y: 144},
            {x: 400, y: 300},
            {x: 773, y: 185},
        ]   
        
        for index, tree in trees {
            if (!FarmingActive)
                return
                
            RobloxClick(tree.x, tree.y)
            
            if (index = 1) {
                Sleep(250)
                colorFound := false
                timeout := 0
                maxLoops := 100
                
                while (!colorFound && timeout < 10) {
                    if (!FarmingActive)
                        return
                    
                    if (PixelSearch(&foundX, &foundY, 320, 518, 320, 518, 0x2FB7FC)) {
                        colorFound := true
                    } else {
                        timeout++
                    }
                }
                
                if (!colorFound) {
                    continue
                }
                
                Loop maxLoops {
                    if (!PixelSearch(&foundX, &foundY, 320, 518, 320, 518, 0x2FB7FC)) {
                        break
                    }
                    RobloxSendKey("{Space Down}")
                    Sleep 10
                    RobloxSendKey("{Space Up}")
                    Sleep 90
                }
            } else {
                WaitForTreeToBreak()
            }
            
            if (index = 1) {
                RobloxClick(579, 180)
                ClickAUntilMachine()
            }
            if (index = 2) {
                RobloxClick(579, 180)
            }
            if (index = 3) {
                RobloxSendKey "{s down}"
                Sleep 5000
                RobloxSendKey "{s up}"
                RobloxSendKey "{w down}"
                Sleep 10
                RobloxSendKey "{w up}"
            }
        }

        if (TimeLeft <= 0)
            return
            
        TeleportToRoyalWorld()
    }
}

; ===== DIAMOND WORLD =====
DiamondWorldCameraSetup() {
    Loop 20 {
        RobloxSendKey("{WheelUp}")
    }
    Loop 15 {
        RobloxSendKey("{WheelDown}")
    }
}

TeleportToDiamondWorld() {
    global
    RobloxClick(705, 325)
    Sleep(100)
    RobloxClick(400, 300)
    Sleep(100)
    Loop 7 {
        RobloxSendKey("{WheelDown}")
    }
    Sleep(100)
    RobloxClick(492, 350)
    WaitForClickButton()
    Sleep(100)
    DiamondWorldCameraSetup()
    FarmDiamondTrees()
}

FarmDiamondTrees() {
    global
    while (FarmingActive && TimeLeft > 0) {
        trees := [ 
            {x: 400, y: 300}
        ]   
        
        for index, tree in trees {
            if (!FarmingActive)
                return
                
            RobloxClick(tree.x, tree.y)
            WaitForTreeToBreak()
        }

        if (TimeLeft <= 0)
            return
            
        TeleportToDiamondWorld()
    }
}

; ===== MAGMA WORLD =====
MagmaWorldCameraSetup() {
    Loop 20 {
        RobloxSendKey("{WheelUp}")
    }
    Loop 15 {
        RobloxSendKey("{WheelDown}")
    }
}

TeleportToMagmaWorld() {
    global
    RobloxClick(705, 325)
    Sleep(100)
    RobloxClick(400, 300)
    Sleep(100)
    Loop 8 {
        RobloxSendKey("{WheelDown}")
    }
    Sleep(100)
    RobloxClick(492, 350)
    WaitForClickButton()
    Sleep(100)
    MagmaWorldCameraSetup()
    FarmMagmaTrees()
}

FarmMagmaTrees() {
    global
    while (FarmingActive && TimeLeft > 0) {
        trees := [ 
            {x: 400, y: 300}
        ]   
        
        for index, tree in trees {
            if (!FarmingActive)
                return
                
            RobloxClick(tree.x, tree.y)
            WaitForTreeToBreak()
        }

        if (TimeLeft <= 0)
            return
            
        TeleportToMagmaWorld()
    }
}

; ===== HEAVEN WORLD =====
HeavenWorldCameraSetup() {
    Loop 20 {
        RobloxSendKey("{WheelUp}")
    }
    Loop 15 {
        RobloxSendKey("{WheelDown}")
    }
}

TeleportToHeavenWorld() {
    global
    RobloxClick(705, 325)
    Sleep(100)
    RobloxClick(400, 300)
    Sleep(100)
    Loop 9 {
        RobloxSendKey("{WheelDown}")
    }
    Sleep(100)
    RobloxClick(492, 350)
    WaitForClickButton()
    Sleep(100)
    HeavenWorldCameraSetup()
    FarmHeavenTrees()
}

FarmHeavenTrees() {
    global
    while (FarmingActive && TimeLeft > 0) {
        trees := [ 
            {x: 400, y: 300}
        ]   
        
        for index, tree in trees {
            if (!FarmingActive)
                return
                
            RobloxClick(tree.x, tree.y)
            WaitForTreeToBreak()
        }

        if (TimeLeft <= 0)
            return
            
        TeleportToHeavenWorld()
    }
}

TeleportToMagicWorld() {
    global
    RobloxClick(705, 325)
    Sleep(100)
    Loop 4 {
        RobloxSendKey("{WheelDown}")
    }
    RobloxClick(492, 350)
    WaitForClickButton()
    Sleep 100
    Loop 4 {
        RobloxSendKey("{WheelDown}")
    }
    Sleep 500
    FarmMagicTrees()
}

FarmMagicTrees() {
    global
    while (FarmingActive && TimeLeft > 0) {
        trees := [ 
            {x: 626, y: 156},
            {x: 771, y: 175},
            {x: 186, y: 161},
            {x: 162, y: 57},
            {x: 613, y: 256},
            {x: 124, y: 167},
            {x: 251, y: 174},
            {x: 121, y: 100},
            {x: 6, y: 103},
            {x: 748, y: 160}
        ]   
        
        for index, tree in trees {
            if (!FarmingActive)
                return
                
            RobloxClick(tree.x, tree.y)
            WaitForTreeToBreak()
            
            if (index = 8) {
                RobloxSendKey("{WheelUp}")
            }
        }

        if (TimeLeft <= 0)
            return
            
        TeleportToMagicWorld()
    }
}

; ===== CIRCUS WORLD =====
TeleportToCircusWorld() {
    global
    RobloxClick(705, 325)
    Sleep(100)
    RobloxClick(400, 300)
    Sleep(100)
    Loop 10 {
        RobloxSendKey("{WheelDown}")
    }
    Sleep(100)
    RobloxClick(492, 350)
    WaitForClickButton()
    Sleep(100)
    FarmCircusTrees()
}

FarmCircusTrees() {
    global
    while (FarmingActive && TimeLeft > 0) {
        trees := [ 
            {x: 400, y: 300}
        ]   
        
        for index, tree in trees {
            if (!FarmingActive)
                return
                
            RobloxClick(tree.x, tree.y)
            WaitForTreeToBreak()
        }

        if (TimeLeft <= 0)
            return
            
        TeleportToCircusWorld()
    }
}

; ===== JUNGLE WORLD =====
JungleWorldCameraSetup() {
    Loop 20 {
        RobloxSendKey("{WheelUp}")
    }
    Loop 15 {
        RobloxSendKey("{WheelDown}")
    }
}

TeleportToJungleWorld() {
    global
    RobloxClick(705, 325)
    Sleep(100)
    RobloxClick(400, 300)
    Sleep(100)
    Loop 11 {
        RobloxSendKey("{WheelDown}")
    }
    Sleep(100)
    RobloxClick(492, 350)
    WaitForClickButton()
    Sleep(100)
    JungleWorldCameraSetup()
    FarmJungleTrees()
}

FarmJungleTrees() {
    global
    while (FarmingActive && TimeLeft > 0) {
        trees := [ 
            {x: 400, y: 300}
        ]   
        
        for index, tree in trees {
            if (!FarmingActive)
                return
                
            RobloxClick(tree.x, tree.y)
            WaitForTreeToBreak()
        }

        if (TimeLeft <= 0)
            return
            
        TeleportToJungleWorld()
    }
}

; ===== STEAMPUNK WORLD =====
SteampunkWorldCameraSetup() {
    Loop 20 {
        RobloxSendKey("{WheelUp}")
    }
    Loop 15 {
        RobloxSendKey("{WheelDown}")
    }
}

TeleportToSteampunkWorld() {
    global
    RobloxClick(705, 325)
    Sleep(100)
    RobloxClick(400, 300)
    Sleep(100)
    Loop 12 {
        RobloxSendKey("{WheelDown}")
    }
    Sleep(100)
    RobloxClick(492, 350)
    WaitForClickButton()
    Sleep(100)
    SteampunkWorldCameraSetup()
    FarmSteampunkTrees()
}

FarmSteampunkTrees() {
    global
    while (FarmingActive && TimeLeft > 0) {
        trees := [ 
            {x: 400, y: 300}
        ]   
        
        for index, tree in trees {
            if (!FarmingActive)
                return
                
            RobloxClick(tree.x, tree.y)
            WaitForTreeToBreak()
        }

        if (TimeLeft <= 0)
            return
            
        TeleportToSteampunkWorld()
    }
}

; ===== SAKURA WORLD =====
SakuraWorldCameraSetup() {
    Loop 20 {
        RobloxSendKey("{WheelUp}")
    }
    Loop 15 {
        RobloxSendKey("{WheelDown}")
    }
}

TeleportToSakuraWorld() {
    global
    RobloxClick(705, 325)
    Sleep(100)
    RobloxClick(400, 300)
    Sleep(100)
    Loop 13 {
        RobloxSendKey("{WheelDown}")
    }
    Sleep(100)
    RobloxClick(492, 350)
    WaitForClickButton()
    Sleep(100)
    SakuraWorldCameraSetup()
    FarmSakuraTrees()
}

FarmSakuraTrees() {
    global
    while (FarmingActive && TimeLeft > 0) {
        trees := [ 
            {x: 400, y: 300}
        ]   
        
        for index, tree in trees {
            if (!FarmingActive)
                return
                
            RobloxClick(tree.x, tree.y)
            WaitForTreeToBreak()
        }

        if (TimeLeft <= 0)
            return
            
        TeleportToSakuraWorld()
    }
}

UpdateTimer() {
    global
    
    if (TimerRunning)
        return
    
    TimerRunning := true
    
    try {
        if (!FarmingActive) {
            if (MainTimer != "") {
                SetTimer(MainTimer, 0)
                MainTimer := ""
            }
            return
        }
        
        if (TimeLeft <= 0) {
            QueueIndex++
            if (MainTimer != "") {
                SetTimer(MainTimer, 0)
                MainTimer := ""
            }
            ProcessNextItem()
            return
        }
        
        TimeLeft--
        minutes := TimeLeft // 60
        seconds := Mod(TimeLeft, 60)
        TimeLabel.Text := "Time: " . minutes . ":" . Format("{:02d}", seconds)
        
        if (QueueIndex <= QueueList.Length) {
            totalTime := QueueList[QueueIndex].Duration * 60
            progress := ((totalTime - TimeLeft) / totalTime) * 100
            ProgressBar.Value := progress
        }
    } finally {
        TimerRunning := false
    }
}

SaveQueue(*) {
    global
    if (QueueList.Length == 0) {
        MsgBox("Queue is empty! Nothing to save.", "Info")
        return
    }
    
    saveName := Trim(SaveNameEdit.Text)
    if (saveName == "") {
        MsgBox("Please enter a name for the queue preset!", "Error")
        return
    }
    
    saveName := RegExReplace(saveName, '[\\/:*?"<>|]', "_")
    
    presetFile := SettingsFolder "\" saveName ".ini"
    
    try {
        if FileExist(presetFile)
            FileDelete(presetFile)
        
        for index, item in QueueList {
            IniWrite(item.Wood, presetFile, "Queue", "Wood" . index)
            IniWrite(item.CleanWood, presetFile, "Queue", "CleanWood" . index)
            IniWrite(item.Duration, presetFile, "Queue", "Duration" . index)
        }
        
        IniWrite(QueueList.Length, presetFile, "Queue", "Count")
        
        MsgBox("Queue saved successfully as: " . saveName . "`n" . QueueList.Length . " items saved.", "Queue Saved")
        
        SaveNameEdit.Text := ""
        RefreshPresetList()
        
    } catch as e {
        MsgBox("Error saving queue: " . e.Message, "Save Error")
    }
}

LoadQueue(*) {
    global
    if (FarmingActive) {
        MsgBox("Cannot load queue while farming is active!", "Error")
        return
    }
    
    presetName := LoadPresetDD.Text
    if (presetName == "" || presetName == "Select preset...") {
        MsgBox("Please select a preset to load!", "Error")
        return
    }
    
    presetFile := SettingsFolder "\" presetName ".ini"
    
    if !FileExist(presetFile) {
        MsgBox("Preset file not found!", "Error")
        RefreshPresetList()
        return
    }
    
    try {
        QueueList := []
        
        count := IniRead(presetFile, "Queue", "Count", 0)
        
        if (count > 0) {
            Loop count {
                wood := IniRead(presetFile, "Queue", "Wood" . A_Index, "")
                cleanWood := IniRead(presetFile, "Queue", "CleanWood" . A_Index, "")
                duration := IniRead(presetFile, "Queue", "Duration" . A_Index, 0)
                
                if (wood != "" && duration > 0) {
                    QueueList.Push({Wood: wood, CleanWood: cleanWood, Duration: Integer(duration)})
                }
            }
        }
        
        UpdateQueueDisplay()
        MsgBox("Queue loaded successfully!`n" . QueueList.Length . " items loaded from: " . presetName, "Queue Loaded")
        
    } catch as e {
        MsgBox("Error loading queue: " . e.Message, "Load Error")
    }
}

RefreshPresetList() {
    global LoadPresetDD
    
    presets := ["Select preset..."]
    
    Loop Files, SettingsFolder "\*.ini" {
        if (A_LoopFileName != "stats.ini" && A_LoopFileName != "config.ini") {
            presetName := StrReplace(A_LoopFileName, ".ini", "")
            presets.Push(presetName)
        }
    }
    
    LoadPresetDD.Delete()
    LoadPresetDD.Add(presets)
    LoadPresetDD.Choose(1)
}

ShowStats(*) {
    global
    
    statsText := "═══════════════════════════════════`n"
    statsText .= "         FARMING STATISTICS`n"
    statsText .= "═══════════════════════════════════`n`n"
    
    statsText .= "📊 Sessions Completed: " . Stats.Sessions . "`n"
    statsText .= "⏱️ Total Time Farmed: " . FormatDuration(Stats.TotalTime) . "`n"
    statsText .= "🌲 Trees Clicked: " . Stats.TreesClicked . "`n`n"
    
    statsText .= "═══════════════════════════════════`n"
    statsText .= "       WOOD COLLECTION COUNT`n"
    statsText .= "═══════════════════════════════════`n"
    
    hasWood := false
    for woodType, count in Stats.WoodCounts {
        if (count > 0) {
            hasWood := true
            statsText .= woodType . ": " . count . " sessions`n"
        }
    }
    
    if (!hasWood)
        statsText .= "No wood collected yet`n"
    
    statsText .= "`n═══════════════════════════════════"
    
    MsgBox(statsText, "Statistics", "Icon!")
}

FormatDuration(seconds) {
    hours := seconds // 3600
    minutes := (seconds - hours * 3600) // 60
    secs := Mod(seconds, 60)
    
    if (hours > 0)
        return hours . "h " . minutes . "m " . secs . "s"
    if (minutes > 0)
        return minutes . "m " . secs . "s"
    return secs . "s"
}

SaveStats() {
    global
    try {
        IniWrite(Stats.Sessions, StatsFile, "Stats", "Sessions")
        IniWrite(Stats.TotalTime, StatsFile, "Stats", "TotalTime")
        IniWrite(Stats.TotalMinutes, StatsFile, "Stats", "TotalMinutes")
        IniWrite(Stats.TreesClicked, StatsFile, "Stats", "TreesClicked")
        
        for woodType, count in Stats.WoodCounts {
            IniWrite(count, StatsFile, "WoodCounts", woodType)
        }
        
    } catch {
    }
}

LoadStats() {
    global
    try {
        if FileExist(StatsFile) {
            Stats.Sessions := Integer(IniRead(StatsFile, "Stats", "Sessions", 0))
            Stats.TotalTime := Integer(IniRead(StatsFile, "Stats", "TotalTime", 0))
            Stats.TotalMinutes := Float(IniRead(StatsFile, "Stats", "TotalMinutes", 0))
            Stats.TreesClicked := Integer(IniRead(StatsFile, "Stats", "TreesClicked", 0))
            
            for woodType in Stats.WoodCounts {
                count := IniRead(StatsFile, "WoodCounts", woodType, 0)
                Stats.WoodCounts[woodType] := Integer(count)
            }
        }
    } catch {
    }
}

SaveAxeKeybind(*) {
    global
    newKeybind := Trim(AxeKeybindEdit.Text)
    if (newKeybind != "") {
        AxeKeybind := newKeybind
        try {
            IniWrite(AxeKeybind, ConfigFile, "Settings", "AxeKeybind")
        } catch {
        }
    }
}

LoadConfig() {
    global
    try {
        if FileExist(ConfigFile) {
            loadedKeybind := IniRead(ConfigFile, "Settings", "AxeKeybind", "")
            if (loadedKeybind != "") {
                AxeKeybind := loadedKeybind
                if (AxeKeybindEdit != "")
                    AxeKeybindEdit.Text := AxeKeybind
            }
        }
    } catch {
        AxeKeybind := ""
    }
}

F1::StartFarming()
F2::StopFarming()
F3::OnExit()
F5::Reload()

OnExit(*) {
    global
    try {
        SaveStats()
        if (MainTimer != "")
            SetTimer(MainTimer, 0)
    } catch {
    }
    ExitApp()
}