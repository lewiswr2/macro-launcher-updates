#Requires AutoHotkey v2.0  ; Ensures the script runs only on AutoHotkey version 2.0, which supports the syntax and functions used in this script.

; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
; AutoHotKey 2.0 Macro for Pet Simulator 99
; Written by reversals 
; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
; DIRECTIVES & CONFIGURATIONS
; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

#SingleInstance Force  ; Forces the script to run only in a single instance. If this script is executed again, the new instance will replace the old one.
#NoTrayIcon
CoordMode "Mouse", "Client"  ; Sets the coordinate mode for mouse functions (like Click, MouseMove) to be relative to the active window's client area, ensuring consistent mouse positioning across different window states.
CoordMode "Pixel", "Client"  ; Sets the coordinate mode for pixel functions (like PixelSearch, PixelGetColor) to be relative to the active window's client area, improving accuracy in color detection and manipulation.
SetMouseDelay 10  ; Sets the delay between mouse events to 10 milliseconds, balancing speed and reliability of automated mouse actions.
SendMode "Input"

; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
; LIBRARIES
; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

; Third-party Libraries:
#Include <OCR>
#Include <JXON>

; Macro Related Libraries:
#Include "%A_ScriptDir%\Modules"
#Include LeaderboardMenu.ahk
#Include Gui-Main.ahk
#Include Gui-Log.ahk
#Include Movement.ahk

; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
; GLOBAL VARIABLES
; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

global MacroState := {
    running: false,
    currentItem: "",
    itemsProcessed: 0,
    itemsPurchased: 0,
    consecutiveErrors: 0,
    startTime: 0
}

global MAX_CONSECUTIVE_ERRORS := 5

; Macro details.
MACRO_TITLE := "Plaza Snipe"
MACRO_VERSION := "1.0.0"

; File settings.
STUFF_JSON := A_ScriptDir "\data.json"
PRICE_CHARACTERS := A_ScriptDir "\Assets\PriceCharacters\"
TERMINAL_BUTTONS := A_ScriptDir "\Assets\TerminalButtons\"
UI_ICONS := A_ScriptDir "\Assets\Icons\"
SETTINGS_INI := A_ScriptDir "\Settings.ini"
LOG_FOLDER := ""

LOG_DATE := FormatTime(A_Now, "yyyyMMdd")

START_MACRO := getSetting("startMacroKey")
PAUSE_MACRO := getSetting("pauseMacroKey")
EXIT_MACRO := getSetting("exitMacroKey")

JSON_OBJECT := ""

ICON_MAP := Map(
    "Application", {icon: "Application.ico"},
    "Discord", {icon: "Discord.ico"},
    "Donate", {icon: "Donate.ico"},
    "PlayPause", {icon: "PlayPause.ico"},
    "PsychoHatcher", {icon: "PsychoHatcher.ico"}
)
global COLORS := {
    bg: "0a0e14",
    bgLight: "13171d",
    card: "161b22",
    cardHover: "1c2128",
    accent: "d29922",
    accentHover: "2ea043",
    accentAlt: "1f6feb",
    text: "e6edf3",
    textDim: "7d8590",
    border: "21262d",
    success: "238636",
    warning: "d29922",
    danger: "da3633",
    favorite: "fbbf24"
}
ITEMS_INI := A_ScriptDir "\Items.ini"
; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
; MACRO
; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

runMacro()

runMacro() {
    activateRoblox()  ; Ensure the Roblox window is active.

    itemCoordinates := [403, 323]
    SendEvent "{Click, " itemCoordinates[1] ", " itemCoordinates[2] ", 1}"

    completeInitialisationTasks() 
    displayMainGui()
    global JSON_OBJECT := loadJsonFromFile(STUFF_JSON)  ; Load the JSON data from the specified RAP JSON file.
}

validateSetup() {
    requiredFiles := [
        STUFF_JSON,
        SETTINGS_INI,
        PRICE_CHARACTERS "0.bmp",
        PRICE_CHARACTERS "k.bmp",
        PRICE_CHARACTERS "m.bmp",
        PRICE_CHARACTERS "b.bmp",
        TERMINAL_BUTTONS "Pets.bmp",
        TERMINAL_BUTTONS "Items.bmp"
    ]
    
    missingFiles := []
    for file in requiredFiles {
        if !FileExist(file)
            missingFiles.Push(file)
    }
    
    if (missingFiles.Length > 0) {
        errorMsg := "Missing required files:`n`n"
        for file in missingFiles
            errorMsg .= "• " file "`n"
        
        MsgBox errorMsg, "Setup Error", "Icon! 16"
        ExitApp
    }
}

teleportToPlazaBooth(maxRetries := 3) {
    Loop maxRetries {
        writeToActivityLog(" > Attempting teleport (" A_Index "/" maxRetries ")")
        
        if !teleportToTradingPlaza() {
            writeToActivityLog(" > ERROR: Teleport failed")
            Sleep 1000
            continue
        }
        
        if moveToTerminal() {
            return true
        }
        
        writeToActivityLog(" > ERROR: Failed to reach terminal")
        Sleep 1000
    }
    
    writeToActivityLog(" > FATAL: All teleport attempts failed")
    return false
}

teleportToTradingPlaza() {
    closeAllWindows()

    teleportButton := [106, 152]
    SendEvent "{Click, " teleportButton[1] ", " teleportButton[2] ", 1}"

    Loop 100 {
        if isTradingPlazaTeleportOpen()
            break
        Sleep 10
    }   

    clickTradingPlazaNormalButton()

    ; Wait for teleport to start
    Loop 2000 {
        if !isHoverboardButtonDisplayed()
            break  
        Sleep 10  
    }

    ; Wait for teleport to complete
    Loop 5000 {
        if isHoverboardButtonDisplayed()
            return true
        Sleep 10
    }
    
    return false
}

readValue() {
    startX := 60
    startY := 237
    endX := 171
    endY := 268

    imageMap := Map(
        "0", {image: "0.bmp"},
        "1", {image: "1.bmp"},
        "2", {image: "2.bmp"},
        "3", {image: "3.bmp"},
        "4", {image: "4.bmp"},
        "5", {image: "5.bmp"},
        "6", {image: "6.bmp"},
        "7", {image: "7.bmp"},
        "8", {image: "8.bmp"},
        "9", {image: "9.bmp"},
        "k", {image: "k.bmp"},
        "m", {image: "m.bmp"},
        "b", {image: "b.bmp"},
        ".", {image: "decimal.bmp"}
    )

    foundCharacter := []  ; Initialize an empty array.
    resultString := ""  ; Initialize the result string.
    
    for key, value in imageMap {
        currentX := startX  ; Reset search start position for each character.
        filePath := PRICE_CHARACTERS value.image ; Construct the file path for each image.
        
        if not FileExist(filePath) {
            writeToActivityLog (" > ERROR: Unable to find the image for the '" key "' character.") 
            return -1
        }

        ; Loop to keep matching until no match is found.
        while true {
            if ImageSearch(&foundX, &foundY, currentX, startY, endX, endY, filePath) {
                foundCharacter.Push([key, foundX])  ; Store the character and its foundX in the array.
                currentX := foundX + 1  ; Move the search start position to the right of the found image.
            } else {
                break  ; Exit the loop if no match is found.
            }
        }
    }

    ; Loop until the foundCharacter array is empty
    while foundCharacter.Length > 0 {
        ; Find the index of the smallest foundX
        minIndex := 1
        for i, pair in foundCharacter {
            if pair[2] < foundCharacter[minIndex][2] {
                minIndex := i
            }
        }

        ; Add the smallest foundX pair to the result string
        resultString .= foundCharacter[minIndex][1]

        ; Remove the smallest foundX pair from the foundCharacter array
        foundCharacter.RemoveAt(minIndex)
    }

    convertedNumber := convertToNumber(resultString)

    if IsInteger(convertedNumber)
        return convertedNumber
    else
        return -1
}

convertToNumber(value, defaultValue := -1) {
    value := Trim(value)
    if (value = "")
        return defaultValue

    value := StrLower(value)
    
    ; Remove currency symbols
    value := RegExReplace(value, "[$€£¥]", "")

    ; Normalize words
    replacements := Map(
        "million", "m",
        "mil", "m",
        "billion", "b",
        "bil", "b",
        "trillion", "t",
        "thousand", "k"
    )
    
    for old, new in replacements
        value := StrReplace(value, old, new)

    ; Remove commas, spaces, underscores
    value := RegExReplace(value, "[,\s_']", "")
    value := RegExReplace(value, "[^0-9.kmbt]", "")

    if (value = "")
        return defaultValue

    ; Extract suffix
    suffix := RegExMatch(value, "[kmbt]$") ? SubStr(value, -1) : ""
    numText := suffix ? SubStr(value, 1, -1) : value

    ; Validate number format
    if !RegExMatch(numText, "^\d+\.?\d*$")
        return defaultValue

    num := Float(numText)
    
    ; Apply multiplier
    multipliers := Map("k", 1000, "m", 1000000, "b", 1000000000, "t", 1000000000000)
    multiplier := multipliers.Has(suffix) ? multipliers[suffix] : 1
    
    return Round(num * multiplier)
}

readPriceReliable(minReads := 9, confidenceThreshold := 0.55) {
    values := Map()
    validReads := 0
    
    Loop minReads {
        price := readValue()
        
        if (Type(price) = "String")
            price := convertToNumber(price, -1)
        
        if (price > 0) {
            validReads++
            if values.Has(price)
                values[price]++
            else
                values[price] := 1
        }
        Sleep 60
    }
    
    if (validReads = 0)
        return -1
    
    ; Find most common value
    maxCount := 0
    bestPrice := -1
    for price, count in values {
        if (count > maxCount) {
            maxCount := count
            bestPrice := price
        }
    }
    
    ; Require confidence threshold
    if (maxCount >= validReads * confidenceThreshold)
        return bestPrice
    
    return -1
}

median(nums) {
    if (nums.Length = 0)
        return -1
        
    arr := []
    for _, v in nums
        arr.Push(v)

    ; Bubble sort
    Loop arr.Length - 1 {
        i := A_Index
        Loop arr.Length - i {
            j := A_Index
            if (arr[j] > arr[j+1]) {
                tmp := arr[j]
                arr[j] := arr[j+1]
                arr[j+1] := tmp
            }
        }
    }
    
    return arr[Ceil(arr.Length / 2)]
}

readValueStable(tries := 7) {
    vals := []
    Loop tries {
        v := readValue()

        if (Type(v) = "String")
            v := convertToNumber(v, -1)

        if (v > 0)
            vals.Push(v)

        Sleep 60
    }
    return (vals.Length ? median(vals) : -1)
}




moveToTerminal() {
    closeLeaderboard()
    closeAllWindows()

    updateStatus("Moving to Terminal")

    ; Move towards the terminal.
    moveDirection("d", 500)

    Send "{d down}"
    maxLoops := 250
    Loop maxLoops {
        updateStatus("Moving to Terminal (" A_Index "/" maxLoops ")")
        SendEvent "{e}"
        Sleep 10 
        if isTerminalWindowOpen() {
            Send "{d up}"
            updateStatus()
            return true
        }

        ; Move around the tree if stuck.
        if A_Index == 100
            moveDirection("w", 150)

    }

    Send "{d up}"
    writeToActivityLog (" > ERROR: Failed to move to the terminal.")
    closeAllWindows()
    updateStatus()
    return false
}



; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
; GUI INITIALISATION
; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

maxPriceEntered(control, index) {
    maxPrice := control.GetText(index)
    maxPriceConverted := convertToNumber(maxPrice)
    control.Modify(index, , maxPriceConverted)
}



loadJsonFromFile(filePath) {
    
    if not FileExist(filePath) {
        writeToActivityLog(" > ERROR: Unable to find the JSON file.") 
        return ""
    }

    jsonString := FileRead(filePath, "UTF-8")  ; Read the content of the specified JSON file into a string.
    return Jxon_Load(&jsonString)  ; Parse the JSON string into a JSON object using the Jxon library and return it.
}


; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
; GUI FUNCTIONS
; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

snipeStuff() {
    global buyList, MacroState, MAX_CONSECUTIVE_ERRORS

    ynToBool(val) {
        val := Trim(val)
        return (val = "Yes" || val = "YES" || val = "True" || val = "true" || val = "1")
    }

    MacroState.running := true
    MacroState.startTime := A_TickCount

    Loop {
        ; Check pause state
        while (A_IsPaused) {
            Sleep 100
            ToolTip "Macro Paused - Press " PAUSE_MACRO " to resume"
        }
        ToolTip
        
        ; Check consecutive errors
        if (MacroState.consecutiveErrors >= MAX_CONSECUTIVE_ERRORS) {
            writeToActivityLog(" > FATAL: Too many consecutive errors (" MacroState.consecutiveErrors "). Stopping macro.")
            MsgBox "Macro stopped due to repeated errors. Check activity log.", "Error Limit Reached", "Icon! 16"
            MacroState.running := false
            return
        }
        
        ; Memory cleanup every 50 loops
        if (Mod(A_Index, 50) = 0) {
            DllCall("SetProcessWorkingSetSize", "UInt", -1, "Int", -1, "Int", -1)
            writeToActivityLog(" > Memory cleaned (Loop " A_Index ")")
        }
        
        listLoop := A_Index
        itemCount := buyList.GetCount()

        if (itemCount = 0) {
            Sleep 250
            continue
        }

        Loop itemCount {
            itemNumber := A_Index

            fullName := buyList.GetText(itemNumber, 1)
            category := buyList.GetText(itemNumber, 2)
            maxPriceText := buyList.GetText(itemNumber, 3)
            maxPrice := convertToNumber(maxPriceText, -1)
            
            if (maxPrice <= 0) {
                writeToActivityLog(" > ERROR: Invalid max price for '" fullName "': '" maxPriceText "'")
                MacroState.consecutiveErrors++
                continue
            }

            isShiny := ynToBool(buyList.GetText(itemNumber, 4))
            isRainbow := ynToBool(buyList.GetText(itemNumber, 5))
            isGolden := ynToBool(buyList.GetText(itemNumber, 6))

            plazaName := fullName
            offset := 1
            noLongerAvailableMessage := false
            
            MacroState.currentItem := fullName

            Loop {
                writeToActivityLog(fullName " (Loop: " listLoop ")(Item: " itemNumber "/" itemCount ")(Search: " A_Index ")")
                
                closeAllWindows()
                
                if !teleportToPlazaBooth() {
                    MacroState.consecutiveErrors++
                    break
                }

                ; Search the trading terminal
                searchSuccess := false
                loop {
                    if !clickTerminalButton(category) {
                        writeToActivityLog(" > ERROR: Failed to click category button")
                        MacroState.consecutiveErrors++
                        break
                    }

                    searchItemInTerminal(plazaName, category, isGolden, isRainbow, isShiny)

                    maxUnableToLocateItem := 10
                    itemLocated := false
                    
                    loop maxUnableToLocateItem {
                        if clickItemInTerminal(offset) {
                            itemLocated := true
                            break
                        }

                        writeToActivityLog(" > ERROR: Unable to locate item (" A_Index "/" maxUnableToLocateItem ")")

                        if (A_Index = maxUnableToLocateItem) {
                            moveAwayFromTerminal()
                            MacroState.consecutiveErrors++
                            break 3
                        }
                    }
                    
                    if !itemLocated
                        break

                    ; Wait for screen transition
                    Loop 100 {
                        if isScreenTransitionedBlack()
                            break
                        Sleep 100
                    }

                    ; Wait for teleport completion
                    teleportSuccess := false
                    Loop 5000 {
                        if isHoverboardButtonDisplayed() {
                            teleportSuccess := true
                            break
                        }
                        if isServerFullMessageDisplayed() {
                            writeToActivityLog(" > DEBUG: Server full")
                            closeServerFullMessage()
                            break
                        }
                        Sleep 10
                    }

                    if !teleportSuccess {
                        MacroState.consecutiveErrors++
                        break
                    }

                    closeLeaderboard()

                    if openBooth() {
                        if !searchItemInBoothAndClick(fullName) {
                            MacroState.consecutiveErrors++
                            break
                        }

                        if isItemSold() {
                            writeToActivityLog(" > DEBUG: Item sold")
                            closeAllWindows()
                            MacroState.consecutiveErrors++
                            break
                        }

                        ; Read booth price using improved function
                        itemValue := readPriceReliable(9, 0.55)

                        if (itemValue <= 0) {
                            writeToActivityLog(" > ERROR: Unable to read price reliably")
                            closeAllWindows()
                            MacroState.consecutiveErrors++
                            break
                        }

                        writeToActivityLog(" > DEBUG: Booth price: " itemValue)

                        ; Additional verification for prices below 50% of max
                        lessThanHalfPrice := (itemValue <= (maxPrice * 0.5))

                        if lessThanHalfPrice {
                            writeToActivityLog(" > DEBUG: Secondary check (price < 50% max)")
                            secondCheck := readPriceReliable(12, 0.65)
                            
                            if (secondCheck > 0)
                                itemValue := secondCheck
                            else {
                                writeToActivityLog(" > ERROR: Secondary check failed")
                                closeAllWindows()
                                MacroState.consecutiveErrors++
                                break
                            }
                        }

                        itemValueFormatted := RegExReplace(itemValue, "\G\d+?(?=(\d{3})+(?:\D|$))", "$0,")
                        buyItem := (itemValue <= maxPrice)
                        difference := Abs(itemValue - maxPrice)

                        if !buyItem {
                            differenceFormatted := RegExReplace(difference, "\G\d+?(?=(\d{3})+(?:\D|$))", "$0,")
                            writeToActivityLog(" > DEBUG: Item too expensive (+" differenceFormatted ")")
                            closeAllWindows()
                            MacroState.consecutiveErrors := 0  ; Reset on normal operation
                            break
                        }

                        if buyPlazaItem(plazaName, difference) {
                            MacroState.itemsPurchased++
                            MacroState.consecutiveErrors := 0
                        }
                        else {
                            MacroState.consecutiveErrors++
                        }
                        
                        closeAllWindows()
                    }
                    else {
                        noLongerAvailableMessage := false
                        Loop 50 {
                            if isnoLongerAvailableMessage() {
                                writeToActivityLog(" > DEBUG: No longer available")
                                clicknoLongerAvailableMessageNoButton()
                                noLongerAvailableMessage := true
                                MacroState.consecutiveErrors := 0
                                break 2
                            }
                            Sleep 10
                        }
                        
                        if noLongerAvailableMessage
                            break

                        writeToActivityLog(" > ERROR: Unable to find booth")
                        MacroState.consecutiveErrors++
                    }
                }
                
                MacroState.itemsProcessed++
            }
        }
    }
}

isScreenTransitionedBlack() {
    search := {x1: 4, y1: 4, colour: "0x070711"}
    return PixelSearch(&x, &y, search.x1, search.y1, search.x1, search.y1, search.colour, 2)
}

checkAllValuesAreEqual(array) {
    firstValue := array[1] ; Get the first value in the array
    for index, value in array {
        if (value != firstValue) {
            return false ; If any value is different, return false
        }
    }
    return true ; If loop completes, all values are the same
}

buyPlazaItem(plazaName, difference) {
    boothItem1 := [110, 196]
    buyButton := [404, 496]
    yesButton := [350, 418]
    noButton := [508, 418]
    okButton := [400, 448]

    SendEvent "{Shift down}"
    SendEvent "{Click, " boothItem1[1] ", " boothItem1[2] ", 1}"
    SendEvent "{Shift up}"

    Loop 50 {
        if isBoothBuyButtonVisible()
            break
        Sleep 10
    }

    if isBoothBuyButtonGrey(buyButton) {
        writeToActivityLog(" > FAIL: Cannot afford item(s)")
        return false  ; ADD THIS
    }

    if !isBoothBuyButtonGreen(buyButton) {
        writeToActivityLog(" > ERROR: Buy button not grey or green")
        return false  ; ADD THIS
    }

    Loop 50 {
        SendEvent "{Click, " buyButton[1] ", " buyButton[2] ", 1}"
        if !isBoothMenuOpen()
            break
        Sleep 10
    }
    
    Loop 50 {
        if isBoothHeyMessageDisplayed()
            break
        Sleep 10
    }

    itemCoordinates := [403, 323]
    SendEvent "{Click, " itemCoordinates[1] ", " itemCoordinates[2] ", 1}"

    Loop 100 {
        if isTooltipDisplayed()
            break
        Sleep 10
    }
    
    tooltipOcr := getItemNameWithOcr(itemCoordinates)

    if tooltipOcr = "" {
        writeToActivityLog(" > ERROR: OCR failed") 
        Loop 50 {
            SendEvent "{Click, " noButton[1] ", " noButton[2] ", 1}"
            if !isBoothHeyMessageDisplayed()
                break
            Sleep 10
        }
        return false  ; ADD THIS
    }

    foundIndex := InStr(tooltipOcr, plazaName)
    buyItem := (foundIndex > 0)
    purchaseItem := buyItem ? plazaName : tooltipOcr

    writeToActivityLog(" * " plazaName " (OCR: " purchaseItem ")(Buy: " buyItem ")")
    
    if !buyItem {
        Loop 50 {
            SendEvent "{Click, " noButton[1] ", " noButton[2] ", 1}"
            if !isBoothHeyMessageDisplayed()
                break
            Sleep 10
        }
        writeToActivityLog(" > ERROR: Incorrect item, not purchased")
        return false  ; ADD THIS
    }

    Loop 50 {
        SendEvent "{Click, " yesButton[1] ", " yesButton[2] ", 1}"
        if !isBoothHeyMessageDisplayed()
            break
        Sleep 10
    }

    Loop 500 {
        if isBoothHeyMessageDisplayed()
            break
        Sleep 10
    }

    Loop 50 {
        SendEvent "{Click, " okButton[1] ", " okButton[2] ", 1}"
        if !isBoothHeyMessageDisplayed()
            break
        Sleep 10
    }

    differenceFormatted := RegExReplace(difference, "\G\d+?(?=(\d{3})+(?:\D|$))", "$0,")
    writeToActivityLog(" > SUCCESS: Item bought! Saved " differenceFormatted " gems")

    return true  ; ADD THIS
}


isBoothBuyButtonVisible() {
    return !PixelSearch(&foundX, &foundY, 404, 478, 404, 478, "0x2A2B31", 2)
}

isBoothBuyButtonGrey(pixel) {
    return PixelSearch(&foundX, &foundY, pixel[1], pixel[2], pixel[1], pixel[2], "0x9C9EB2", 2)
}

isBoothBuyButtonGreen(pixel) {
    return PixelSearch(&foundX, &foundY, pixel[1], pixel[2], pixel[1], pixel[2], "0x66F104", 2)
}

isBoothHeyMessageDisplayed() {
    return PixelSearch(&foundX, &foundY, 394, 160, 394, 160, "0x3BC7FF", 2)
}

closeServerFullMessage() {
    okButton := [398, 388]
    Loop 100 {
        SendEvent "{Click, " okButton[1] ", " okButton[2] ", 1}"
        if !isServerFullMessageDisplayed()
            break
    }
}

moveAwayFromTerminal() {
    Send "{w down}"
    Sleep 1000
    Send "{w up}"
}

/*
closeBoothWindow() {
    boothClose := [730, 109]
    Loop 50 {
        SendEvent "{Click, " boothClose[1] ", " boothClose[2] ", 1}"
        if !isBoothMenuOpen()
            break
        Sleep 10
    }
}
*/
isLeaderboardMenuOpen() {
    rankIcon := Map("Start", [565, 41], "End", [711, 100], "Colour", "0xB98335", "Tolerance", 25)
    diamondIcon := Map("Start", [565, 41], "End", [750, 100], "Colour", "0x4D84B6", "Tolerance", 25)
    rankIconFound := PixelSearch(&foundX, &foundY,  ; Perform a pixel search.
        rankIcon["Start"][1], rankIcon["Start"][2],  ; Starting coordinates for the search area.
        rankIcon["End"][1], rankIcon["End"][2],  ; Ending coordinates for the search area.
        rankIcon["Colour"], rankIcon["Tolerance"])   ; Color and tolerance for the search.
    diamondIconFound := PixelSearch(&foundX, &foundY,  ; Perform a pixel search.
        diamondIcon["Start"][1], diamondIcon["Start"][2],  ; Starting coordinates for the search area.
        diamondIcon["End"][1], diamondIcon["End"][2],  ; Ending coordinates for the search area.
        diamondIcon["Colour"], diamondIcon["Tolerance"])   ; Color and tolerance for the search.
    return (rankIconFound && diamondIconFound)
}

searchItemInBoothAndClick(fullName) {

    searchBox := [536, 106]
    boothIcon := [64, 119]
    
    if !PixelSearch(&foundX, &foundY, searchBox[1], searchBox[2], searchBox[1], searchBox[2], "0xFFFFFF", 2) 
        closeLeaderboard()

    searchSuccess := false
    Loop 50 {
        SendEvent "{Click, " searchBox[1] ", " searchBox[2] ", 1}"
        Sleep 10
        SendText fullName
        Loop 25 {
            if isBoothSearchTextEntered() {
                searchSuccess := true
                break
            }
            Sleep 10
        }
        if searchSuccess
            break
        Sleep 10
    }

    if searchSuccess {

        ;SendEvent "{Click, " boothIcon[1] ", " boothIcon[2] ", 1}"
        return true
    }

    writeToActivityLog (" > ERROR: Booth search unsuccessful.")
    return false


}

openBooth() {
    Loop 50 {
        SendEvent "{e}"
        if isBoothMenuOpen()
            return true       
        Sleep 10        
    }
    writeToActivityLog (" > ERROR: Unable to open booth.")
    return false
}

clickPetSizeFilter(petName) {
    ; Convert to lowercase for case-insensitive matching
    petNameLower := StrLower(petName)
    
    ; Define size filter coordinates
    hugeButton := [291, 104]
    titanicButton := [333, 107]
    gargantuanButton := [374, 105]
    
    ; Check for size keywords and click appropriate button
    if InStr(petNameLower, "huge") {
        SendEvent "{Click, " hugeButton[1] ", " hugeButton[2] ", 1}"
        Sleep 50
        return "Huge"
    }
    else if InStr(petNameLower, "titanic") {
        SendEvent "{Click, " titanicButton[1] ", " titanicButton[2] ", 1}"
        Sleep 50
        return "Titanic"
    }
    else if InStr(petNameLower, "gargantuan") {
        SendEvent "{Click, " gargantuanButton[1] ", " gargantuanButton[2] ", 1}"
        Sleep 50
        return "Gargantuan"
    }
    
    return ""  ; No size filter applied
}

searchItemInTerminal(plazaName, category, isGolden, isRainbow, isShiny) {
    terminalSection := [146, 132]
    searchBox := [583, 108]
    
    activateRoblox()
    closeLeaderboard()

    SendEvent "{Click, " searchBox[1] ", " searchBox[2] ", 1}"
    Sleep 50

    if isTerminalSearchTextEntered()
        SendEvent "{Click, " terminalSection[1] ", " terminalSection[2] ", 1}"

    SendText plazaName 

    Loop 50 {
        Sleep 10
        if isTerminalSearchTextEntered()
            break
    }

    if category == "Pets" {
        clickTerminalButton("Items")
        clickTerminalButton("Pets")
        Sleep 100
        waitForFilterSectionToBeDisplayed()
        
        ; Click the size filter based on pet name (Huge, Titanic, or Gargantuan)
        sizeApplied := clickPetSizeFilter(plazaName)
        if sizeApplied != ""
            writeToActivityLog(" > DEBUG: Applied " sizeApplied " size filter")
        
        ; Apply variant filters (Normal/Golden/Rainbow)
        if isRainbow
            enableRainbowFilter()
        else if isGolden
            enableGoldenFilter()
        else
            enableNormalFilter()
        
        ; Apply shiny filter
        enableShinyFilter(isShiny)
    }
}

waitForFilterSectionToBeDisplayed() {
    loop 100 {
        if PixelSearch(&X, &Y, 272, 108, 272, 108, "0xffffff", 1)
            break
        Sleep 10
    }
}

clickItemInTerminal(offset) {
    itemMiddle := [504, 201]
    SendEvent "{Click, " itemMiddle[1] + offset ", " itemMiddle[2] ", 1}"

    Loop 100 {
        if isMessageBoxDisplayed()
            break
        Sleep 10
    }
    
    itemFound := ableToLocate()
    clickGreenButton()
    return itemFound
}

enableGoldenFilter() {
    goldenPetButton := [451, 104]
    SendEvent "{Click, " goldenPetButton[1] ", " goldenPetButton[2] ", 1}"
    Sleep 50
}

enableRainbowFilter() {
    rainbowPetButton := [497, 105]
    SendEvent "{Click, " rainbowPetButton[1] ", " rainbowPetButton[2] ", 1}"
    Sleep 50
}

enableNormalFilter() {
    normalPetButton := [411, 102]  ; ✅ Correct coordinates
    SendEvent "{Click, " normalPetButton[1] ", " normalPetButton[2] ", 1}"  ; ✅ Always click
    Sleep 50
}

enableShinyFilter(isShiny) {
    if !isShiny  ; ✅ Only proceed if shiny needed
        return
        
    shinyPetButton := [546, 102]  ; ✅ Correct coordinates
    SendEvent "{Click, " shinyPetButton[1] ", " shinyPetButton[2] ", 1}"  ; ✅ Simple click
    Sleep 50
}

clickGreenButton() {
    Loop 50 {
        if PixelSearch(&foundX, &foundY, 197, 407, 611, 460, "0x80F60E", 2) {
            SendEvent "{Click, " foundX ", " foundY ", 1}"
            Sleep 10
            if !isMessageBoxDisplayed
                break
        }
    }
}

clickTradingPlazaNormalButton() {
    Loop 50 {
        if PixelSearch(&foundX, &foundY, 179, 360, 621, 447, "0x7DF6FA", 2) {
            SendEvent "{Click, " foundX ", " foundY ", 1}"
            Sleep 10
            if !isTradingPlazaTeleportOpen
                break
        }
    }
}

clicknoLongerAvailableMessageNoButton() {
    Loop 50 {
        if PixelSearch(&foundX, &foundY, 181, 383, 617, 465, "0xFF1761", 2) {
            SendEvent "{Click, " foundX ", " foundY ", 1}"
            Sleep 10
            if !isTradingPlazaTeleportOpen
                break
        }
    }
}

closeTerminalWindow() {
    terminalClose := [731, 110]
    Loop 50 {
        SendEvent "{Click, " terminalClose[1] ", " terminalClose[2] ", 1}"        
        if !isTerminalWindowOpen()
            break
        Sleep 10
    }
}



isTerminalItem(itemX, itemY) {
    return PixelSearch(&foundX, &foundY, itemX, itemY, itemX, itemY, "0xFFFFFF", 2)
}

isServerFullMessageDisplayed() {
    messageStart := [324, 185]  ; Define the start coordinates for the disconnection window.
    messageEnd := [150, 25]   ; Define the size of the disconnection window.

    activateRoblox()  ; Focus the Roblox window.
    
    ; Perform OCR on the specified window area with a scaling factor of 20.
    try
        ocrTextResult := getOcrResult(messageStart, messageEnd, 20)
    catch {
        writeToActivityLog (" > ERROR: OCR failed.")
        return true
    }
    return (ocrTextResult.Text == "Teleport Failed")
}

isnoLongerAvailableMessage() {
    return PixelSearch(&foundX, &foundY, 230, 192, 230, 192, "0xFFCC4D", 2)
}

isItemSold() {
    return PixelSearch(&foundX, &foundY, 83, 156, 83, 156, "0xFFFFFF", 2)
}

isTerminalWindowOpen() {
    return PixelSearch(&foundX, &foundY, 53, 119, 53, 119, "0xFCCD3A", 2)
}

isTradingPlazaTeleportOpen() {
    return PixelSearch(&foundX, &foundY, 603, 109, 603, 109, "0xFF165F", 2)  
}

isTooltipDisplayed() {
    return PixelSearch(&foundX, &foundY, 416, 338, 416, 338, "0xFFFFFF", 2)  
}


isBoothMenuOpen() {
    return PixelSearch(&foundX, &foundY, 730, 109, 730, 109, "0xFF165F", 2)  
}

isHoverboardButtonDisplayed() {
    return PixelSearch(&foundX, &foundY, 2, 173, 69, 235, "0xFF9114", 10)    
}

isMessageBoxDisplayed() {
    return PixelSearch(&foundX, &foundY, 603, 109, 603, 109, "0xFF165F", 2)
}

isTerminalSearchTextEntered() {
    return PixelSearch(&foundX, &foundY, 524, 107, 699, 107, "0x1E1E1E", 2)
}

isBoothSearchTextEntered() {
    return PixelSearch(&foundX, &foundY, 531, 97, 702, 117, "0x1E1E1E", 2)
}

ableToLocate() {
    return PixelSearch(&foundX, &foundY, 232, 210, 232, 210, "0x77B255", 2)
}

clickTerminalButton(button) {
    terminalSection := [146, 132]

    imageMap := Map(
        "Boards", {image: "Boards.bmp"},
        "Booths", {image: "Booths.bmp"},
        "Cards", {image: "Cards.bmp"},
        "Charms", {image: "Charms.bmp"},
        "Eggs", {image: "Eggs.bmp"},
        "Enchants", {image: "Enchants.bmp"},
        "Items", {image: "Items.bmp"},
        "Pets", {image: "Pets.bmp"},
        "Potions", {image: "Potions.bmp"},
        "Ultimates", {image: "Ultimates.bmp"}
    )

    ; Scroll the terminal button section to the top.
    SendEvent "{Click, " terminalSection[1] ", " terminalSection[2] ", 1}"
    scrollMouseWheel("{WheelUp}", 5)

    buttons := [57, 137, 244, 473]  ; Search coordinates for the buttons section.

    filePath := TERMINAL_BUTTONS imageMap[button].image  ; Construct the file path for each image.

    if not FileExist(filePath) {
        writeToActivityLog (" > ERROR: Unable to find the image for the " button " button.") 
        return false
    }

    buttonFound := false
    Loop 2 {
        Loop 10 {
            Sleep 10
            if ImageSearch(&foundX, &foundY, buttons[1], buttons[2], buttons[3], buttons[4], " *10 " filePath) {
                SendEvent "{Click, " foundX + Random(-2, -2) ", " foundY + Random(2, 2) ", 1}"
                Sleep 10
                buttonFound := true
                break
            }
        }
        if buttonFound
            break        
        ; Scroll the terminal button section to the bottom.
        MouseMove terminalSection[1], terminalSection[2]
        scrollMouseWheel("{WheelDown}", 5)
    }
    
    if !buttonFound {
        writeToActivityLog (" > ERROR: Unable to find the " button " button.")
        return false
    }

    Sleep 50

    return true

}

; ----------------------------------------------------------------------------------------
; pauseMacro Function
; Description: Toggles the pause state of the macro.
; Operation:
;   - Sends a keystroke to simulate a pause/unpause command.
;   - Toggles the pause state of the script.
; Dependencies:
;   - Send: Function to simulate keystrokes.
; Parameters:
;   - None
; Return: None; toggles the paused state of the macro.
; ----------------------------------------------------------------------------------------
pauseMacro(*) {
    Pause -1
    if A_IsPaused
        writeToActivityLog(" > MACRO PAUSED")
    else
        writeToActivityLog(" > MACRO RESUMED")
}


reloadMacro(*) {
    Reload
}

; ----------------------------------------------------------------------------------------
; exitMacro Function
; Description: Exits the macro application completely.
; Operation:
;   - Terminates the application.
; Dependencies:
;   - ExitApp: Command to exit the application.
; Parameters:
;   - None
; Return: None; closes the application.
; ----------------------------------------------------------------------------------------
exitMacro(*) {
    updateStatus()
    ExitApp  ; Exit the macro application.
}

; ----------------------------------------------------------------------------------------
; openHowTo Function
; Description: Opens a help text file in Notepad for user assistance.
; Operation:
;   - Executes Notepad with a specified file path to display help documentation.
; Dependencies:
;   - Run: Function to execute external applications.
; Parameters:
;   - None; uses a global variable for the file path.
; Return: None; opens a text file for user reference.
; ----------------------------------------------------------------------------------------
openHowTo(*) {
    Run ""
}

openDiscord(*) {
    Run "https://discord.gg/v1ln"
}

openWebsite(*) {
    Run ""
}

openDonate(*) {
    Run ""
}

; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
; SETTINGS.INI FUNCTIONS
; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

; ----------------------------------------------------------------------------------------
; getSetting Function
; Description: Retrieves a setting value from an INI file based on a given key.
; Parameters:
;   - Key: The setting key whose value is to be retrieved.
; Operation:
;   - Reads the value associated with the specified key from a designated INI file section.
; Dependencies:
;   - IniRead: Function used to read data from an INI file.
;   - SETTINGS_INI: Global variable specifying the path to the INI file.
; Return: The value of the specified setting key, returned as a string.
; ----------------------------------------------------------------------------------------
getSetting(keyName) {
    return IniRead(SETTINGS_INI, "Settings", keyName)  ; Read and return the setting value from the INI file.
}


; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
; INITIALISATION SETTINGS/FUNCTIONS
; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰



completeInitialisationTasks() {
    validateSetup()
    updateTrayIcon()  ; Update the tray icon to indicate that the macro is running.
    resizeRobloxWindow()  ; Resize the Roblox window to a predefined size.
    defineHotKeys()  ; Define hotkeys for various macro functions.
    getLogFolder()
}


updateTrayIcon() {
    TraySetIcon UI_ICONS ICON_MAP["Application"].icon
}


defineHotKeys() {
    HotKey START_MACRO, startMacro  ; Bind pause macro hotkey.
    HotKey PAUSE_MACRO, pauseMacro  ; Bind pause macro hotkey.
    HotKey EXIT_MACRO, exitMacro  ; Bind exit macro hotkey.
}


; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
; ROBLOX CLIENT FUNCTIONS
; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰


resizeRobloxWindow() {
    WinActivate "ahk_exe RobloxPlayerBeta.exe"  ; Activate the Roblox window.
    WinRestore "ahk_exe RobloxPlayerBeta.exe"   ; Restore the Roblox window if it is minimized.
    
    ; Resize the window twice to fix any scaling issues with the Supercomputer.
    WinMove , , A_ScreenWidth, 600, "ahk_exe RobloxPlayerBeta.exe"  ; Resize the window to screen width by 600 pixels height.
    WinMove , , 800, 600, "ahk_exe RobloxPlayerBeta.exe"  ; Resize the window to 800x600 pixels dimensions.
}


activateRoblox() {
    try {
        WinActivate "ahk_exe RobloxPlayerBeta.exe"  ; Try to activate the Roblox game window.
    } catch {
        MsgBox "Roblox window not found.", MACRO_TITLE  ; Display an error message if the window is not found.
        ExitApp  ; Exit the application.
    }
    Sleep 100  ; Pause briefly to ensure the window is activated.
}

scrollMouseWheel(scrollDirection, timesToScroll := 1) {
    Loop timesToScroll {  ; Repeat scroll for the number of specified increments.
        Send scrollDirection  ; Send scroll command in the specified direction.
        Sleep 50  ; Short pause to mimic natural scrolling behavior.
    }
}

writeToActivityLog(logMessage) {
    global activityLog, LOG_FOLDER, LOG_DATE

    ; Always write to file (even if GUI isn't ready yet)
    logDateTime := FormatTime(A_Now, "yyyy-MM-ddTHH:mm:ssZ")
    formattedMessage := "[" logDateTime "]   " logMessage "`n"
    logFile := LOG_FOLDER LOG_DATE ".log"

    FileEncoding "UTF-8"
    try FileAppend(formattedMessage, logFile)

    ; If the Activity Log ListView isn't created yet, stop here (prevents crash)
    if !IsSet(activityLog) || !IsObject(activityLog)
        return

    ; Update GUI list safely
    try {
        activityLog.Add(, logMessage)
        count := activityLog.GetCount()

        if (count > 0) {
            activityLog.Modify(count, "Select")
            activityLog.Modify(count, "Vis")
            activityLog.Modify(0, "Select")
        }
    }
}



getOcrResult(ocrStart, ocrSize, ocrScale) {
    WinGetClientPos &windowTopLeftX, &windowTopLeftY, , , "ahk_exe RobloxPlayerBeta.exe"  ; Retrieve the position of the client area of the Roblox window.
    ocrStart := [ocrStart[1] + windowTopLeftX, ocrStart[2] + windowTopLeftY]  ; Adjust the OCR start coordinates based on the window position.

    ; Perform OCR on the specified rectangular area.
    ocrObjectResult := OCR.FromRect(ocrStart[1], ocrStart[2], ocrSize[1], ocrSize[2], , ocrScale)
    
    return ocrObjectResult  ; Return the OCR result object.
}


getItemNameWithOcr(itemCoordinates) {
    toolTipStart := [itemCoordinates[1] + 10, 120]
    toolTipSize := [200, 480]
    ;toolTipStart := [itemCoordinates[1] + 10, itemCoordinates[2] + 10]  ; Define the start coordinates for the tooltip area.
    ;toolTipSize := [200, 50]  ; Define the size of the tooltip area.

    ocrResult := getOcrResult(toolTipStart, toolTipSize, 5)  ; Perform OCR on the tooltip area to capture the item name.

    ; Ensure OCR worked.
    if ocrResult.Lines.Length = 0 {
        return ""
    }

    itemName := ocrResult.Text   
    ;itemName := ocrResult.Lines[1].Text

    ; Correct OCR issues.
    itemName := RegExReplace(itemName, "Pifiata", "Piñata")
    itemName := RegExReplace(itemName, "ö", "ñ")

    return itemName
}


closeAllPopups() {
    POPUP_X_SEARCH := {x1: 450, y1: 80, x2: 780, y2: 140}
    search := POPUP_X_SEARCH
    if PixelSearch(&x, &y, search.x1, search.y1, search.x2, search.y2, "0xff155e", 2)
        SendEvent "{Click, " x ", " y ", 1}"
}

getLogFolder() {
    global

    try {
        processPath := WinGetProcessPath("ahk_exe Psycho Hatcher.exe")
    } catch {
        processPath := ""  ; Set to empty if the process is not found
    }

    if processPath
        LOG_FOLDER := StrReplace(processPath, "Psycho Hatcher.exe", "") "Logs\MarketSnipe\"
    else
        LOG_FOLDER := A_ScriptDir "\Logs\"
}


closeAllWindows() {
    closeLeaderboard()

    X_SEARCH_AREA := {x1: 430, y1: 90, x2: 770, y2: 130}
    search := X_SEARCH_AREA

    activateRoblox()

    loop {
        if !PixelSearch(&x, &y, search.x1, search.y1, search.x2, search.y2, "0xff155e", 2)
            return true
        else {
            SendEvent "{Click, " x ", " y ", 1}"
            Sleep 100
        }
    }

}


updateStatus(message := "") {
    defaultTitle := (message = "") ? "Roblox" : "Roblox: "
    try WinSetTitle(defaultTitle message, "ahk_exe RobloxPlayerBeta.exe")
}