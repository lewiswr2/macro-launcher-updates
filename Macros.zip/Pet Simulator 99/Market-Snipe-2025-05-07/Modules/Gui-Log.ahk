#Requires AutoHotkey v2.0

displaylogGui() {
    global mainGui, logGui, activityLog
    
    ; Initialize the log GUI
    logGui := Gui("-MinimizeBox -MaximizeBox -SysMenu +AlwaysOnTop")
    logGui.Title := "Activity Log"
    logGui.SetFont("s9", "Segoe UI")
    logGui.BackColor := COLORS.bg
    
    ; Header bar
    headerBar := logGui.AddProgress("x0 y0 w400 h60 Background" COLORS.accent " -Smooth")
    logGui.AddText("xp+20 yp+15 w360 h30 c" COLORS.bg " BackgroundTrans", "Activity Log")
        .SetFont("s14 bold", "Segoe UI")
    
    ; Activity log list
    activityLog := logGui.AddListView("x10 y70 w380 h560 -Hdr Background" COLORS.card " c" COLORS.text, ["Activity"])
    activityLog.ModifyCol(1, 360)
    
    ; Get position of main GUI
    WinGetPos &x, &y, &width, &height, mainGui.Hwnd
    logGui.Show("x" x + width - 16 " y" y " w400 h650")
}
