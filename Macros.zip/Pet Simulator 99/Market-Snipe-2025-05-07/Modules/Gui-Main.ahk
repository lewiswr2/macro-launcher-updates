#Requires AutoHotkey v2.0

displayMainGui() {
    global mainGui, logGui, buyList, itemNameInput, maxPriceInput, categoryDropdown
    global shinyCheck, rainbowCheck, goldenCheck, activityLog
    
    ; Initialize the main GUI
    mainGui := Gui("+AlwaysOnTop")
    mainGui.Title := MACRO_TITLE " v" MACRO_VERSION
    mainGui.SetFont("s9", "Segoe UI")
    mainGui.BackColor := COLORS.bg
    
    ; Create menu bar
    fileMenu := Menu()
    startText := "Start Macro`t" START_MACRO
    pauseText := "Pause Macro`t" PAUSE_MACRO
    exitText := "Exit Macro`t" EXIT_MACRO
    fileMenu.Add(startText, startMacro)
    fileMenu.Add()
    fileMenu.Add(pauseText, pauseMacro)
    fileMenu.Add("Reload Macro", reloadMacro)
    fileMenu.Add()
    fileMenu.Add(exitText, exitMacro)
    

    
    MyMenuBar := MenuBar()
    MyMenuBar.Add("&File", fileMenu)

    mainGui.MenuBar := MyMenuBar
    
    ; Yellow accent header bar
    headerBar := mainGui.AddProgress("x0 y0 w600 h60 Background" COLORS.accent " -Smooth")
    mainGui.AddText("xp+20 yp+15 w560 h30 c" COLORS.bg " BackgroundTrans", MACRO_TITLE)
        .SetFont("s16 bold", "Segoe UI")
    
    ; Add Item Section
    mainGui.AddText("x20 y80 c" COLORS.text " BackgroundTrans", "Add New Item")
        .SetFont("s10 bold")
    
    ; Item Name Input
    mainGui.AddText("x20 y110 c" COLORS.textDim " BackgroundTrans", "Item Name:")
    itemNameInput := mainGui.AddEdit("x20 y130 w350 h25 Background" COLORS.card " c" COLORS.text)
    
    ; Category Dropdown
    mainGui.AddText("x20 y165 c" COLORS.textDim " BackgroundTrans", "Category:")
    categoryDropdown := mainGui.AddDropDownList("x20 y185 w170 Background" COLORS.card " c" COLORS.text, 
        ["Items", "Pets", "Boards", "Booths", "Cards", "Charms", "Eggs", "Enchants", "Potions", "Ultimates"])
    categoryDropdown.Choose(1)
    
    ; Max Price Input
    mainGui.AddText("x200 y165 c" COLORS.textDim " BackgroundTrans", "Max Price:")
    maxPriceInput := mainGui.AddEdit("x200 y185 w170 h25 Background" COLORS.card " c" COLORS.text)
    
    ; Category Checkboxes
    mainGui.AddText("x20 y220 c" COLORS.textDim " BackgroundTrans", "Item Type:")
    shinyCheck := mainGui.AddCheckbox("x20 y240 c" COLORS.text " Background" COLORS.bg, "Shiny")
    rainbowCheck := mainGui.AddCheckbox("x100 y240 c" COLORS.text " Background" COLORS.bg, "Rainbow")
    goldenCheck := mainGui.AddCheckbox("x200 y240 c" COLORS.text " Background" COLORS.bg, "Golden")
    
    ; Add Item Button
    addItemBtn := mainGui.AddButton("x20 y275 w350 h35 Background" COLORS.accent, "Add Item to List")
    addItemBtn.SetFont("s10 bold", "Segoe UI")
    addItemBtn.OnEvent("Click", (*) => addItemToList())
    
    ; Separator
    mainGui.AddProgress("x20 y325 w560 h2 Background" COLORS.border " -Smooth")
    
    ; Buy List Section
    mainGui.AddText("x20 y340 c" COLORS.text " BackgroundTrans", "Active Macro Items")
        .SetFont("s10 bold")
    
    mainGui.AddText("x20 y365 c" COLORS.textDim " BackgroundTrans", "Items below will be sniped when macro runs")
        .SetFont("s8")
    
    ; Buy List
    buyList := mainGui.AddListView("x20 y390 w560 h200 -ReadOnly Background" COLORS.card " c" COLORS.text, 
        ["Item Name", "Category", "Max Price", "Shiny", "Rainbow", "Golden"])
    buyList.ModifyCol(1, 200)
    buyList.ModifyCol(2, 100)
    buyList.ModifyCol(3, 100)
    buyList.ModifyCol(4, 60)
    buyList.ModifyCol(5, 60)
    buyList.ModifyCol(6, 60)
    
    ; Control Buttons
    deleteBtn := mainGui.AddButton("x20 y605 w130 h30 Background" COLORS.danger, "Delete Selected")
    deleteBtn.OnEvent("Click", (*) => deleteSelectedItem())
    
    clearAllBtn := mainGui.AddButton("x160 y605 w130 h30 Background" COLORS.danger, "Clear All")
    clearAllBtn.OnEvent("Click", (*) => clearAllItems())
    
    saveBtn := mainGui.AddButton("x300 y605 w130 h30 Background" COLORS.success, "Save Macro")
    saveBtn.OnEvent("Click", (*) => saveMacroItems())
    
    loadBtn := mainGui.AddButton("x440 y605 w140 h30 Background" COLORS.accentAlt, "Load Saved")
    loadBtn.OnEvent("Click", (*) => loadMacroItems())
    
    ; Show GUI (top-left of screen)
    mainGui.Show("w600 h650 x0 y0")
    
    ; Load saved items on startup
    loadMacroItems()
    
    displaylogGui()
    
    OnMessage(0x0003, syncGuiHandler)
    
    syncGuiHandler(wParam, lParam, msg, hwnd) {
        global mainGui, logGui
        WinGetPos &x, &y, &width, &height, mainGui.Hwnd
        logGui.Move(x + width - 16, y)
        return 0
    }
    
    ; Function to add item to list
addItemToList() {
    global buyList, itemNameInput, categoryDropdown, maxPriceInput
    global shinyCheck, rainbowCheck, goldenCheck

    itemName := itemNameInput.Value
    category := categoryDropdown.Text
maxPriceRaw := maxPriceInput.Value
maxPriceNum := convertToNumber(maxPriceRaw)

if (maxPriceNum <= 0) {
    MsgBox "Invalid Max Price. Examples:`n1500000`n1,500,000`n1.5m`n1500k", "Bad Price", "Icon!"
    return
}



    if (itemName = "" || maxPriceRaw = "") {
        MsgBox "Please enter both Item Name and Max Price!", "Missing Information", "Icon!"
        return
    }



    ; pretty display with commas
    maxPriceDisplay := RegExReplace(maxPriceNum, "\G\d+?(?=(\d{3})+(?:\D|$))", "$0,")

    isShiny := shinyCheck.Value ? "Yes" : "No"
    isRainbow := rainbowCheck.Value ? "Yes" : "No"
    isGolden := goldenCheck.Value ? "Yes" : "No"

    buyList.Add(, itemName, category, maxPriceDisplay, isShiny, isRainbow, isGolden)

    ; clear inputs...
    itemNameInput.Value := ""
    maxPriceInput.Value := ""
    shinyCheck.Value := 0
    rainbowCheck.Value := 0
    goldenCheck.Value := 0
    categoryDropdown.Choose(1)

    itemNameInput.Focus()
    writeToActivityLog(" > Item added: " itemName " (" category ")")
}

    
    ; Function to delete selected item
    deleteSelectedItem() {
        selectedRow := buyList.GetNext(0)
        if (selectedRow = 0) {
            MsgBox "Please select an item to delete!", "No Selection", "Icon!"
            return
        }
        
        itemName := buyList.GetText(selectedRow, 1)
        buyList.Delete(selectedRow)
        writeToActivityLog(" > Item removed: " itemName)
    }
    
    ; Function to clear all items
    clearAllItems() {
        result := MsgBox("Are you sure you want to clear all items?", "Confirm Clear", "YesNo Icon?")
        if (result = "Yes") {
            buyList.Delete()
            writeToActivityLog(" > All items cleared")
        }
    }
    
    ; Function to save macro items
    saveMacroItems() {
        ; Delete old items file
        if FileExist(ITEMS_INI)
            FileDelete(ITEMS_INI)
        
        ; Save each item
        rowCount := buyList.GetCount()
        if (rowCount = 0) {
            MsgBox "No items to save!", "Empty List", "Icon!"
            return
        }
        
        Loop rowCount {
            itemName := buyList.GetText(A_Index, 1)
            category := buyList.GetText(A_Index, 2)
            maxPrice := buyList.GetText(A_Index, 3)
            isShiny := buyList.GetText(A_Index, 4)
            isRainbow := buyList.GetText(A_Index, 5)
            isGolden := buyList.GetText(A_Index, 6)
            
            IniWrite(itemName, ITEMS_INI, "Item" A_Index, "Name")
            IniWrite(category, ITEMS_INI, "Item" A_Index, "Category")
            IniWrite(maxPrice, ITEMS_INI, "Item" A_Index, "MaxPrice")
            IniWrite(isShiny, ITEMS_INI, "Item" A_Index, "Shiny")
            IniWrite(isRainbow, ITEMS_INI, "Item" A_Index, "Rainbow")
            IniWrite(isGolden, ITEMS_INI, "Item" A_Index, "Golden")
        }
        
        ; Save total count
        IniWrite(rowCount, ITEMS_INI, "Settings", "TotalItems")
        
        MsgBox "Macro saved successfully! " rowCount " items saved.", "Success", "Iconi"
        writeToActivityLog(" > Macro saved: " rowCount " items")
    }
    
    ; Function to load macro items
    loadMacroItems() {
        if !FileExist(ITEMS_INI)
            return
        
        buyList.Delete()
        
        totalItems := IniRead(ITEMS_INI, "Settings", "TotalItems", 0)
        
        Loop totalItems {
            itemName := IniRead(ITEMS_INI, "Item" A_Index, "Name", "")
            category := IniRead(ITEMS_INI, "Item" A_Index, "Category", "")
            maxPrice := IniRead(ITEMS_INI, "Item" A_Index, "MaxPrice", "")
            isShiny := IniRead(ITEMS_INI, "Item" A_Index, "Shiny", "No")
            isRainbow := IniRead(ITEMS_INI, "Item" A_Index, "Rainbow", "No")
            isGolden := IniRead(ITEMS_INI, "Item" A_Index, "Golden", "No")
            
            if (itemName != "")
                buyList.Add(, itemName, category, maxPrice, isShiny, isRainbow, isGolden)
        }
        
        if (totalItems > 0)
            writeToActivityLog(" > Loaded " totalItems " items from saved macro")
    }
}

startMacro(*) {
    activateRoblox()
    writeToActivityLog("*** MACRO STARTED ***")
    
    closeAllWindows()
    
    ; Get items from buy list and start sniping
    rowCount := buyList.GetCount()
    if (rowCount = 0) {
        MsgBox "No items in the buy list! Add items before starting.", "Empty List", "Icon!"
        return
    }
    
    writeToActivityLog(" > Sniping " rowCount " items...")
    teleportToTradingPlaza()
    moveToTerminal()
    snipeStuff()
    ; Main snipe loop would go here
    ; This is where you'd implement the actual sniping logic
    ; using the items from buyList
}
