#Requires AutoHotkey v2
#NoTrayIcon

; ▰▰▰ DIRECTIVES & CONFIGURATIONS ▰▰▰

#SingleInstance Force
#Warn All
CoordMode "Mouse", "Client"
CoordMode "Pixel", "Client"
SetMouseDelay 1
SendMode "Input"

#Include "%A_ScriptDir%\Modules\Zones.ahk"  ; Include the zones module
#Include "%A_ScriptDir%\Modules\movement.ahk"
#Include "%A_ScriptDir%\Modules\camera.ahk"  ; Include the new camera module

; ▰▰▰ LIBRARIES ▰▰▰

#Include "%A_ScriptDir%\Lib"
#Include <OCR>

; Global variables
global isRunning := false
global settingsFile := A_ScriptDir "\settings.ini"
global robloxWinTitle := "ahk_exe RobloxPlayerBeta.exe"
global lastOCRResult := ""
global logFile := A_ScriptDir "\Logs\log_" A_Now ".log"
global mapNumber := 1

; Ensure ZONE is available globally
global ZONE

; ▰▰▰ COORDINATES & WORLD DEFINITIONS ▰▰▰

TELEPORT_COORDS := Map(
    "MENU_ICON", [43,242],
    "SEARCH_BOX", [600, 107],
    "SEARCH_RESULT", [350, 245],
    "CONFIRM_TELEPORT", [356, 444],
    "CLOSE", [746, 109],
    "WORLD_1", [22, 238],
    "WORLD_2", [22, 284],
    "WORLD_3", [22, 328],
    "WORLD_CLOSE", [747, 109]
)

; World definitions
WORLDS := Map(
    1, {start: 1, end: 99, coords: TELEPORT_COORDS["WORLD_1"]},
    2, {start: 100, end: 199, coords: TELEPORT_COORDS["WORLD_2"]},
    3, {start: 200, end: 299, coords: TELEPORT_COORDS["WORLD_3"]}
)

LEADERBOARD_RANK_STAR := Map("Start", [652, 43], "End", [678, 59], "Colour", "0xB98335", "Tolerance", 50)
CHAT_ICON_WHITE := Map("Start", [81, 24], "End", [81, 24], "Colour", "0xFFFFFF", "Tolerance", 2)

; ---------- Theme ----------
global COLORS := Map(
    "bg",         0x0a0e14,
    "bgLight",    0x13171d,
    "card",       0x161b22,
    "cardHover",  0x1c2128,
    "accent",     0xd29922,
    "accentHover",0x2ea043,
    "accentAlt",  0x1f6feb,
    "text",       0xe6edf3,
    "textDim",    0x7d8590,
    "border",     0x21262d,
    "success",    0x238636,
    "warning",    0xd29922,
    "danger",     0xda3633
)

; Helper: AHK wants BGR for some WinAPI color paths; but Gui.BackColor accepts RGB.
; We’ll use Gui.BackColor for window, and SetCtlColors for edits/etc.
RGB(c) => c  ; keep as-is for Gui.BackColor

; ---------- WinAPI control recolor (Edit / DDL / Combo) ----------
; This uses WM_CTLCOLOR* messages to set background + text for certain control classes.
; Buttons/checkboxes are limited by Windows theming (won't fully recolor).
SetCtlColors(gui, bgColor, txtColor) {
    static WM_CTLCOLORDLG := 0x0136
         , WM_CTLCOLORSTATIC := 0x0138
         , WM_CTLCOLOREDIT := 0x0133
         , WM_CTLCOLORLISTBOX := 0x0134
         , TRANSPARENT := 1

    ; Create a solid brush for the background
    gui._themeBrush := DllCall("CreateSolidBrush", "UInt", bgColor, "Ptr")

    ; Store for handler
    gui._themeBg := bgColor
    gui._themeTxt := txtColor


}

Theme_WM_CTLCOLOR(wParam, lParam, msg, hwnd) {
    g := GuiFromHwnd(hwnd)
    if !IsObject(g) || !g.HasProp("_themeBrush")
        return

    ; Text color
    DllCall("SetTextColor", "Ptr", wParam, "UInt", g._themeTxt)
    ; Background color
    DllCall("SetBkColor", "Ptr", wParam, "UInt", g._themeBg)

    ; Make static text transparent on dark background
    if (msg = 0x0138) ; WM_CTLCOLORSTATIC
        DllCall("SetBkMode", "Ptr", wParam, "Int", 1) ; TRANSPARENT

    return g._themeBrush
}

GuiFromHwnd(hwnd) {
    for g in Gui.List
        if (g.Hwnd = hwnd)
            return g

    owner := DllCall("GetAncestor", "Ptr", hwnd, "UInt", 2, "Ptr") ; GA_ROOT
    for g in Gui.List
        if (g.Hwnd = owner)
            return g

    return false
}


; ---------- Your GUI ----------
TraySetIcon(A_ScriptDir "\Assets\Psycho_Hatcher.ico")

myGui := Gui()
myGui.BackColor := Format("{:06X}", RGB(COLORS["bg"]))  ; window background
myGui.SetFont("s9 c" Format("{:06X}", COLORS["text"]), "Segoe UI")

; Apply themed colors to Edit/DDL/Listbox/Static text where possible
SetCtlColors(myGui, COLORS["card"], COLORS["text"])

global Edit1 := myGui.Add("Edit", "x24 y48 w83 h21", "1")
myGui.Add("Text", "x24 y16 w120 h23 +0x200 c" Format("{:06X}", COLORS["textDim"]), "Last map unlocked:")

global ButtonStartMacro := myGui.Add("Button", "x24 y88 w80 h23", "&Start Macro")
global ButtonLoad := myGui.Add("Button", "x112 y48 w80 h21", "&Load")
global ButtonSave := myGui.Add("Button", "x200 y48 w80 h23", "&Save")

global SB := myGui.Add("StatusBar",, "Ready")

; World 1 Rebirth Checkboxes
myGui.Add("Text", "x24 y150 w120 h23 +0x200", "World 1")
global w1r1Checkbox := myGui.Add("CheckBox", "x24 y180 w80 h23", "Rebirth 1")
global w1r2Checkbox := myGui.Add("CheckBox", "x112 y180 w80 h23", "Rebirth 2")
global w1r3Checkbox := myGui.Add("CheckBox", "x200 y180 w80 h23", "Rebirth 3")
global w1r4Checkbox := myGui.Add("CheckBox", "x288 y180 w80 h23", "Rebirth 4")

; World 2 Rebirth Checkboxes
myGui.Add("Text", "x24 y220 w120 h23 +0x200", "World 2")
global w2r1Checkbox := myGui.Add("CheckBox", "x24 y250 w80 h23", "Rebirth 1")
global w2r2Checkbox := myGui.Add("CheckBox", "x112 y250 w80 h23", "Rebirth 2")
global w2r3Checkbox := myGui.Add("CheckBox", "x200 y250 w80 h23", "Rebirth 3")
global w2r4Checkbox := myGui.Add("CheckBox", "x288 y250 w80 h23", "Rebirth 4")

; Camera Settings Group
myGui.Add("GroupBox", "x24 y290 w350 h90", "Camera Settings")
myGui.Add("Text", "x34 y315 w100 h20", "Rotation Speed:")
global CameraSpeedSlider := myGui.Add("Slider", "x140 y315 w200 h20 Range1-10 TickInterval1", 5)

myGui.Add("Text", "x34 y345 w100 h20", "Scan Areas:")
global ScanAreasDropdown := myGui.Add("DropDownList", "x140 y345 w200", ["Default (4 areas)", "Comprehensive (9 areas)", "Quick (2 areas)"])
ScanAreasDropdown.Value := 1

myGui.Show()




; ▰▰▰ FUNCTION DEFINITIONS ▰▰▰

UpdateCameraSpeed(*) {
    global CAMERA_ROTATION_SPEED
    CAMERA_ROTATION_SPEED := CameraSpeedSlider.Value
    WriteLog("Camera rotation speed updated to: " . CAMERA_ROTATION_SPEED)
}

UpdateScanAreas(*) {
    global CAMERA_AREAS_TO_SCAN
    selection := ScanAreasDropdown.Value
    
    if (selection = 1) {
        ; Default (4 areas)
        CAMERA_AREAS_TO_SCAN := [
            [300, 300, 200, 100],   ; Center-middle
            [300, 400, 200, 100],   ; Lower-middle
            [200, 350, 200, 100],   ; Left-middle  
            [400, 350, 200, 100]    ; Right-middle
        ]
    } else if (selection = 2) {
        ; Comprehensive (9 areas)
        CAMERA_AREAS_TO_SCAN := [
            [300, 200, 200, 100],   ; Center-top
            [300, 300, 200, 100],   ; Center-middle
            [300, 400, 200, 100],   ; Center-bottom
            [100, 200, 200, 100],   ; Left-top
            [100, 300, 200, 100],   ; Left-middle
            [100, 400, 200, 100],   ; Left-bottom
            [500, 200, 200, 100],   ; Right-top
            [500, 300, 200, 100],   ; Right-middle
            [500, 400, 200, 100]    ; Right-bottom
        ]
    } else {
        ; Quick (2 areas)
        CAMERA_AREAS_TO_SCAN := [
            [300, 300, 200, 150],   ; Center larger area
            [300, 400, 200, 150]    ; Lower larger area
        ]
    }
    
    WriteLog("Scan areas updated to: " . selection)
}

WriteLog(message) {
    FileAppend(A_Now " - " message "`n", logFile)
}

LoadSettings(*) {
    try {
        lastMap := IniRead(settingsFile, "MapSettings", "LastUnlockedMap", "1")
        Edit1.Value := lastMap

        ; Load rebirth settings
        for world in [1, 2] {
            for rebirth in [1, 2, 3, 4] {
                checkboxVar := "w" . world . "r" . rebirth . "Checkbox"
                if (IsSet(%checkboxVar%)) {
                    value := IniRead(settingsFile, "RebirthSettings", "World" . world . "Rebirth" . rebirth, "0")
                    %checkboxVar%.Value := value
                    WriteLog("Loaded setting: World" . world . "Rebirth" . rebirth . " = " . value)
                }
            }
        }
        
        ; Load camera settings
        rotSpeed := IniRead(settingsFile, "CameraSettings", "RotationSpeed", "5")
        areaSelection := IniRead(settingsFile, "CameraSettings", "ScanAreas", "1")
        
        CameraSpeedSlider.Value := rotSpeed
        ScanAreasDropdown.Value := areaSelection
        
        UpdateCameraSpeed()
        UpdateScanAreas()

        SB.SetText("Settings loaded successfully")
        WriteLog("Settings loaded successfully")
    } catch as err {
        SB.SetText("Error loading settings: " err.Message)
        WriteLog("Error loading settings: " err.Message)
    }
}

SaveSettings(*) {
    try {
        IniWrite(Edit1.Value, settingsFile, "MapSettings", "LastUnlockedMap")

        ; Save rebirth settings
        for world in [1, 2] {
            for rebirth in [1, 2, 3, 4] {
                checkboxVar := "w" . world . "r" . rebirth . "Checkbox"
                if (IsSet(%checkboxVar%)) {
                    value := %checkboxVar%.Value
                    IniWrite(value, settingsFile, "RebirthSettings", "World" . world . "Rebirth" . rebirth)
                    WriteLog("Saved setting: World" . world . "Rebirth" . rebirth . " = " . value)
                }
            }
        }
        
        ; Save camera settings
        IniWrite(CameraSpeedSlider.Value, settingsFile, "CameraSettings", "RotationSpeed")
        IniWrite(ScanAreasDropdown.Value, settingsFile, "CameraSettings", "ScanAreas")

        SB.SetText("Settings saved successfully")
        WriteLog("Settings saved successfully")
    } catch as err {
        SB.SetText("Error saving settings: " err.Message)
        WriteLog("Error saving settings: " err.Message)
    }
}

checkForRebirth(worldNumber, mapNumber) {
    rebirthZones := [25, 50, 75, 99]
    if (worldNumber == 2) {
        rebirthZones := [125, 150, 175, 199]
    }

    for index, rebirthZone in rebirthZones {
        if (mapNumber == rebirthZone) {
            checkboxVar := "w" . worldNumber . "r" . index . "Checkbox"
            if (IsSet(%checkboxVar%) && %checkboxVar%.Value) {
                return index
            }
        }
    }
    return 0
}


    

performRebirthSequence(worldNumber, rebirthNumber) {
    global mapNumber
    
    WriteLog("Performing rebirth sequence for World " . worldNumber . ", Rebirth " . rebirthNumber)
    SB.SetText("Performing rebirth for World " . worldNumber . ", Rebirth " . rebirthNumber)
    
    ; Movement handled in movement.ahk
    if (!moveToRebirth(worldNumber, rebirthNumber)) {
        WriteLog("Warning: Failed to move to rebirth location")
    }
    WriteLog("Completed moveToRebirth")
    
    WriteLog("Attempting to perform rebirth")
    if (!performRebirth()) {
        WriteLog("Warning: Failed to perform rebirth action")
    }
    WriteLog("Completed performRebirth")
    
    ; After rebirth, teleport to one zone lower
    targetZone := mapNumber - 1
    WriteLog("Teleporting to one zone lower: " . targetZone)
    if (!teleportToZone(targetZone)) {
        WriteLog("Failed to teleport to lower zone")
        return false
    }
    
    WriteLog("Waiting 3 seconds")
    Sleep(3000)
    
    ; Teleport back to original zone
    WriteLog("Teleporting back to original zone: " . mapNumber)
    if (!teleportToZone(mapNumber)) {
        WriteLog("Failed to teleport back to original zone")
        return false
    }
    
    WriteLog("Moving to zone centre")
    if (!moveToZoneCentre(mapNumber)) {
        WriteLog("Failed to move to zone centre")
    }
    WriteLog("Moved to zone centre")
    
    ; Update settings but keep the same map number
    IniWrite(0, settingsFile, "RebirthSettings", "World" worldNumber "Rebirth" rebirthNumber)
    LoadSettings()
    
    WriteLog("Completed performRebirthSequence")
    return true
}

getWorldForZone(zoneNumber) {
    for worldNum, worldInfo in WORLDS {
        if (zoneNumber >= worldInfo.start && zoneNumber <= worldInfo.end) {
            return worldNum
        }
    }
    return 1
}

ToggleMacroHandler(*) {
    global isRunning
    if (!isRunning) {
        StartMacro()
    } else {
        StopMacro()
    }
}

resizeRobloxWindow() {
    if !WinExist(robloxWinTitle) {
        WriteLog("Roblox window not found")
        return false
    }

    try {
        WinActivate(robloxWinTitle)
        WinRestore(robloxWinTitle)
        Sleep 100

        WinMove(, , A_ScreenWidth, 600, robloxWinTitle)
        Sleep 50
        WinMove(, , 800, 600, robloxWinTitle)
        Sleep 100
        WriteLog("Roblox window resized successfully")
        return true
    } catch as err {
        SB.SetText("Window resize error: " err.Message)
        WriteLog("Window resize error: " err.Message)
        return false
    }
}

EnsureRobloxActive() {
    if !WinActive(robloxWinTitle) {
        WriteLog("Roblox window not active, attempting to activate")
        WinActivate(robloxWinTitle)
        Sleep 500
        if !WinActive(robloxWinTitle) {
            WriteLog("Failed to activate Roblox window")
            return false
        }
    }
    return true
}

leftClickMouse(coords) {
    WriteLog("Attempting left click at: " . coords[1] . ", " . coords[2])
    MouseClick("left", coords[1], coords[2])
    WriteLog("Left clicked at: " . coords[1] . ", " . coords[2])
}

clickAt(x, y) {
    WriteLog("Attempting to click at: " . x . ", " . y)
    SendEvent "{Click down, " x ", " y ", 1}"
    Sleep 50  ; Short delay to ensure the click is registered
    SendEvent "{Click up}"
    Sleep 50  ; Short delay after the click
    WriteLog("Clicked at: " . x . ", " . y)
    return true
}

SmoothMove(x, y, speed) {
    MouseGetPos(&startX, &startY)
    dx := x - startX
    dy := y - startY
    steps := Sqrt(dx*dx + dy*dy) / speed
    steps := Ceil(steps)
    Loop steps {
        MouseMove(startX + (dx * A_Index / steps), startY + (dy * A_Index / steps), 0)
        Sleep(5)
    }
    MouseMove(x, y)
    WriteLog("Mouse moved to: " . x . ", " . y)
}

SmoothClick(x, y, speed) {
    WriteLog("Attempting smooth click at: " . x . ", " . y)
    SmoothMove(x, y, speed * 2)
    Sleep 50  ; Short delay before click
    Click()
    Sleep 50  ; Short delay after click
    WriteLog("Smooth clicked at: " . x . ", " . y)
    return true
}

closeLeaderboard() {
    robloxWindow := WinExist("ahk_exe RobloxPlayerBeta.exe")
    if !robloxWindow {
        return
    }
    WinGetPos(&x, &y, &w, &h, robloxWindow)
    
    rankArea := Map("Start", [655, 105], "End", [720, 129])
    diamondArea := Map("Start", [721, 105], "End", [800, 129])
    
    performOCR(area) {
        return OCR.FromRect(x + area["Start"][1], y + area["Start"][2], 
                            area["End"][1] - area["Start"][1], 
                            area["End"][2] - area["Start"][2]).Text
    }
    
    ; Check for "Rank" or "Diamonds" text
    rankText := performOCR(rankArea)
    diamondText := performOCR(diamondArea)
    
    if (InStr(rankText, "Rank") || InStr(diamondText, "Diamond")) {
        SendEvent "{Tab}"
        Sleep 500  ; Wait for 500ms
        
        ; Verify if the leaderboard is closed
        rankTextAfter := performOCR(rankArea)
        diamondTextAfter := performOCR(diamondArea)
        
        if (!InStr(rankTextAfter, "Rank") && !InStr(diamondTextAfter, "Diamond")) {
            ; Leaderboard successfully closed
            return true
        }
    }
    
    return false
}

closeChatLog() {
    if PixelSearch(&foundX, &foundY,  
        CHAT_ICON_WHITE["Start"][1], CHAT_ICON_WHITE["Start"][2], 
        CHAT_ICON_WHITE["End"][1], CHAT_ICON_WHITE["End"][2],  
        CHAT_ICON_WHITE["Colour"], CHAT_ICON_WHITE["Tolerance"]) 
    {
        leftClickMouse([foundX, foundY])
        WriteLog("Closed chat log")
    }
}

teleportToWorld(worldNumber) {
    try {
        if !EnsureRobloxActive()
            throw Error("Failed to activate Roblox window")
        
        WriteLog("Teleporting to world " worldNumber)
        Sleep 500
        
        closeLeaderboard()
        closeChatLog()
        
        if !EnsureRobloxActive()
            throw Error("Lost focus on Roblox window before clicking menu icon")
        
        if (!clickAt(TELEPORT_COORDS["MENU_ICON"][1], TELEPORT_COORDS["MENU_ICON"][2]))
            throw Error("Failed to click menu icon")
        Sleep 1000
        
        worldCoords := WORLDS[worldNumber].coords
        if (!SmoothClick(worldCoords[1], worldCoords[2], 10))
            throw Error("Failed to click world button")
        Sleep 1000
        
        if (!clickAt(369, 423))
            throw Error("Failed to click 'Here' to accept world teleport")
        Sleep 25000
        
        if (!SmoothClick(TELEPORT_COORDS["WORLD_CLOSE"][1], TELEPORT_COORDS["WORLD_CLOSE"][2], 10))
            throw Error("Failed to close world selection")
        Sleep 1000
        
        SB.SetText("Successfully teleported to world " worldNumber)
        WriteLog("Successfully teleported to world " worldNumber)
        return true
    } catch as err {
        SB.SetText("World teleport error: " err.Message)
        WriteLog("World teleport error: " err.Message)
        return false
    }
}

teleportToZone(zoneNumber) {
    try {
        if !EnsureRobloxActive()
            throw Error("Failed to activate Roblox window")
        
        WriteLog("Teleporting to zone " zoneNumber)
        Sleep 1500
        
        closeLeaderboard()
        closeChatLog()
        
        if !EnsureRobloxActive()
            throw Error("Lost focus on Roblox window before clicking menu icon")
        
        WriteLog("Attempting to click menu icon")
        if (!clickAt(TELEPORT_COORDS["MENU_ICON"][1], TELEPORT_COORDS["MENU_ICON"][2])) {
            throw Error("Failed to click menu icon")
        }
        WriteLog("Clicked menu icon successfully")
        Sleep 1500
        
        WriteLog("Attempting to click search box")
        if (!SmoothClick(TELEPORT_COORDS["SEARCH_BOX"][1], TELEPORT_COORDS["SEARCH_BOX"][2], 10)) {
            throw Error("Failed to click search box")
        }
        WriteLog("Clicked search box successfully")
        Sleep 1500
        
        SendInput "^a"
        Sleep 300
        SendInput "{Backspace}"
        Sleep 300
        zoneName := ZONE.Has(zoneNumber) ? ZONE[zoneNumber] : "Unknown Zone"
        SendText(zoneName)
        WriteLog("Typed zone name: " . zoneName)
        Sleep 1500
        
        WriteLog("Attempting to click search result")
        if (!SmoothClick(TELEPORT_COORDS["SEARCH_RESULT"][1], TELEPORT_COORDS["SEARCH_RESULT"][2], 10)) {
            throw Error("Failed to click search result")
        }
        WriteLog("Clicked search result successfully")
        Sleep 1500
        
        WriteLog("Attempting to confirm teleport")
        if (!SmoothClick(TELEPORT_COORDS["CONFIRM_TELEPORT"][1], TELEPORT_COORDS["CONFIRM_TELEPORT"][2], 10)) {
            throw Error("Failed to confirm teleport")
        }
        WriteLog("Confirmed teleport successfully")
        Sleep 10000
        
        WriteLog("Attempting to close teleport menu")
        if (!SmoothClick(TELEPORT_COORDS["CLOSE"][1], TELEPORT_COORDS["CLOSE"][2], 10)) {
            throw Error("Failed to close teleport menu")
        }
        WriteLog("Closed teleport menu successfully")
        
        SB.SetText("Successfully teleported to zone " zoneNumber)
        WriteLog("Successfully teleported to zone " zoneNumber)
        return true
    } catch as err {
        SB.SetText("Zone teleport error: " err.Message)
        WriteLog("Zone teleport error: " err.Message)
        return false
    }
}

ContinuousLeaderboardCheck() {
    while true {
        if PixelSearch(&foundX, &foundY,  
            LEADERBOARD_RANK_STAR["Start"][1], LEADERBOARD_RANK_STAR["Start"][2], 
            LEADERBOARD_RANK_STAR["End"][1], LEADERBOARD_RANK_STAR["End"][2],  
            LEADERBOARD_RANK_STAR["Colour"], LEADERBOARD_RANK_STAR["Tolerance"]) 
        {
            SendEvent "{Tab}"
            WriteLog("Closed leaderboard (continuous check)")
        }
        Sleep 1000  ; Check every second
    }
}

StartMacro(*) {
    global isRunning, ZONE, mapNumber
    if (isRunning) {
        return
    }

    isRunning := true
    ButtonStartMacro.Text := "&Stop Macro"

    mapNumber := Round(Edit1.Value)
    worldNumber := getWorldForZone(mapNumber)
    
    mapName := (ZONE.Has(mapNumber)) ? ZONE[mapNumber] : "Unknown"
    SB.SetText("Starting Macro for World " worldNumber ", Map: " mapName)
    WriteLog("Starting Macro for World " worldNumber ", Map: " mapName)

    if (!WinExist(robloxWinTitle)) {
        SB.SetText("Roblox window not found")
        WriteLog("Roblox window not found")
        StopMacro()
        return
    }

    if (!resizeRobloxWindow()) {
        SB.SetText("Failed to resize Roblox window")
        WriteLog("Failed to resize Roblox window")
        StopMacro()
        return
    }
    
    SetTimer ContinuousLeaderboardCheck, 100

    if (!teleportToWorld(worldNumber)) {
        SB.SetText("Failed to teleport to world " worldNumber)
        WriteLog("Failed to teleport to world " worldNumber)
        StopMacro()
        return
    }
    
    if (!teleportToZone(mapNumber)) {
        SB.SetText("Failed to teleport to zone " mapNumber)
        WriteLog("Failed to teleport to zone " mapNumber)
        StopMacro()
        return
    }
    
    moveToZoneCentre(mapNumber)

    while (isRunning) {
        RunMacroLoop()
        Sleep 2000
    }
}

StopMacro(*) {
    global isRunning
    if (!isRunning)
        return

    isRunning := false
    ButtonStartMacro.Text := "&Start Macro"
    SB.SetText("Macro stopped")
    WriteLog("Macro stopped")

    SetTimer ContinuousLeaderboardCheck, 0
}

getClientArea() {
    if !WinExist(robloxWinTitle) {
        throw Error("Roblox window not found")
    }
    
    WinGetClientPos(&clientX, &clientY, &clientW, &clientH, robloxWinTitle)
    return { x: clientX, y: clientY, w: clientW, h: clientH }
}

ReadAndHighlight(relativeX, relativeY, w, h, lang := "en-US", highlightColor := "Red", highlightThickness := 2) {
    try {
        clientArea := getClientArea()
        absoluteX := clientArea.x + relativeX
        absoluteY := clientArea.y + relativeY
        
        ocrResult := OCR.FromRect(absoluteX, absoluteY, w, h, lang)
        Highlight(absoluteX, absoluteY, w, h, 2000, highlightColor, highlightThickness)
        WriteLog("OCR Result: " . ocrResult.Text)
        return ocrResult.Text
    } catch as err {
        SB.SetText("OCR error: " err.Message)
        WriteLog("OCR error: " err.Message)
        return ""
    }
}

Highlight(x?, y?, w?, h?, showTime := 0, color := "Red", d := 2) {
    static guis := []
    if !IsSet(x) {
        for _, r in guis
            r.Destroy()
        guis := []
        return
    }
    if (!guis.Length) {
        Loop 4
            guis.Push(Gui("+AlwaysOnTop -Caption +ToolWindow -DPIScale +E0x08000000"))
    }
    Loop 4 {
        i := A_Index
        , x1 := (i = 2 ? x + w : x - d)
        , y1 := (i = 3 ? y + h : y - d)
        , w1 := (i = 1 or i = 3 ? w + 2 * d : d)
        , h1 := (i = 2 or i = 4 ? h + 2 * d : d)
        guis[i].BackColor := color
        guis[i].Show("NA x" . x1 . " y" . y1 . " w" . w1 . " h" . h1)
    }
    if (showTime > 0) {
        Sleep(showTime)
        Highlight()
    }
}

SendText(text) {
    for char in StrSplit(text) {
        SendInput char
        Sleep 50
    }
    WriteLog("Sent text: " . text)
}



RunMacroLoop(*) {
    global isRunning, ZONE, mapNumber
    if (!isRunning || !WinExist(robloxWinTitle)) {
        WriteLog("Macro stopped: isRunning = " . isRunning . ", Roblox window exists = " . WinExist(robloxWinTitle))
        StopMacro()
        return
    }

    try {
        WriteLog("Starting RunMacroLoop at map " . mapNumber)
        
        worldNumber := getWorldForZone(mapNumber)
        rebirthNumber := checkForRebirth(worldNumber, mapNumber)
        
        if (rebirthNumber > 0) {
            WriteLog("Rebirth required at map " . mapNumber . ", rebirth number " . rebirthNumber)
            if (performRebirthSequence(worldNumber, rebirthNumber)) {
                WriteLog("Rebirth sequence completed successfully")
            } else {
                WriteLog("Rebirth sequence failed, but continuing macro")
            }
            WriteLog("Rebirth sequence completed, continuing from map " . mapNumber)
            SaveSettings()
            return
        }

        ; Use the simplified color-detection rotation scan for Buy button
        WriteLog("Starting color detection scan for Buy button")
        SB.SetText("Scanning for Buy button...")
        
        scanResult := ScanForBuyButton()
        
        if (scanResult.found) {
            if (scanResult.succeeded) {
                WriteLog("Buy button clicked successfully. Color disappeared.")
                SB.SetText("Purchase successful!")
                
                ; Progress to next map
                mapNumber += 1
                Edit1.Value := mapNumber
                SaveSettings()

                if (ZONE.Has(mapNumber)) {
                    newWorldNumber := getWorldForZone(mapNumber)
                    currentWorldNumber := getWorldForZone(mapNumber - 1)
                    
                    if (newWorldNumber != currentWorldNumber) {
                        WriteLog("Teleporting to new world: " . newWorldNumber)
                        if (!teleportToWorld(newWorldNumber)) {
                            WriteLog("Failed to teleport to new world")
                            throw Error("Failed to teleport to new world")
                        }
                        Sleep 2000
                    }
                    
                    WriteLog("Teleporting to zone: " . mapNumber)
                    if (!teleportToZone(mapNumber)) {
                        WriteLog("Failed to teleport to next zone")
                        throw Error("Failed to teleport to next zone")
                    }
                    
                    WriteLog("Teleported to Map: " . ZONE[mapNumber])
                    SB.SetText("Teleported to Map: " . ZONE[mapNumber])
                    moveToZoneCentre(mapNumber)
                } else {
                    WriteLog("Next map not found in zone list.")
                    SB.SetText("Next map not found in zone list.")
                    StopMacro()
                }
            } else {
                WriteLog("Buy button was clicked but color still present. Will retry.")
                SB.SetText("Purchase may have failed. Retrying...")
            }
        } else {
            WriteLog("Buy button color not found in 360-degree scan. Waiting for next loop.")
            SB.SetText("Buy button not found. Waiting...")
        }
    } catch as err {
        WriteLog("Error in macro loop: " . err.Message)
        SB.SetText("Error in macro loop: " . err.Message)
        WriteLog("Continuing to next iteration despite error")
    }
    
    WriteLog("RunMacroLoop completed. Waiting for next iteration.")
}

; ▰▰▰ EVENT HANDLERS & GUI SETUP ▰▰▰

ButtonLoad.OnEvent("Click", LoadSettings)
ButtonStartMacro.OnEvent("Click", ToggleMacroHandler)
ButtonSave.OnEvent("Click", SaveSettings)
myGui.OnEvent('Close', (*) => ExitApp())

myGui.Title := "PS99 LVL UP"
myGui.Show("w400 h400")  ; Increased height for camera settings

LoadSettings()

; ▰▰▰ HOTKEYS ▰▰▰

Hotkey("F1", ToggleMacroHandler)
Hotkey("F2", (*) => Reload())
Hotkey("F3", (*) => ExitApp())

; Start continuous checks
SetTimer ContinuousLeaderboardCheck, 100

; Keep the script running
return