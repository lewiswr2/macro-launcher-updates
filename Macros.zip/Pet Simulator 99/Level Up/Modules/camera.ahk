﻿; ▰▰▰ CAMERA ROTATION WITH COLOR DETECTION ▰▰▰

; Configuration 
global BUY_BUTTON_COLOR := "0x95FF00"  ; Bright yellow-green color of the Buy button
global COLOR_TOLERANCE := 30           ; Tolerance for color matching (0-255)
global ROTATION_STEPS := 36            ; Number of steps for full 360° rotation (10° per step)
global ROTATION_SPEED := 7             ; Pixels to move per step (adjust based on sensitivity)
global SCREEN_CENTER_X := 400          ; Center X of 800x600 window
global SCREEN_CENTER_Y := 300          ; Center Y of 800x600 window
global WAIT_AFTER_CLICK := 2000        ; Time to wait after clicking (ms)
global VERIFICATION_CHECKS := 3        ; Number of times to verify color is gone
global VERIFICATION_DELAY := 1000      ; Delay between verification checks (ms)
global CLICK_ATTEMPTS := 4             ; Number of times to click the button
global CLICK_DELAY := 300              ; Delay between clicks (ms)

; Rotates camera 360° while searching for buy button color
ScanForBuyButton() {
    WriteLog("Starting 360° scan for Buy button color: " . BUY_BUTTON_COLOR)
    
    ; Store original mouse position
    MouseGetPos(&originalX, &originalY)
    
    ; Variables to track results
    buyFound := false
    buyX := 0
    buyY := 0
    currentStep := 0
    
    ; Scan area - rectangle around center of screen
    scanStartX := SCREEN_CENTER_X - 150
    scanStartY := SCREEN_CENTER_Y - 150
    scanEndX := SCREEN_CENTER_X + 150
    scanEndY := SCREEN_CENTER_Y + 150
    
    ; Start camera rotation
    Click "Right Down"
    Sleep 200
    
    ; Perform rotation and scan in steps
    Loop ROTATION_STEPS {
        currentStep := A_Index
        
        ; Move mouse to rotate camera
        MouseMove ROTATION_SPEED, 0, 10, "R"
        Sleep 150
        
        ; Search for the buy button color
        if PixelSearch(&foundX, &foundY, 
                      scanStartX, scanStartY, 
                      scanEndX, scanEndY, 
                      BUY_BUTTON_COLOR, COLOR_TOLERANCE) {
            buyFound := true
            buyX := foundX
            buyY := foundY
            WriteLog("Found Buy button color at step " . currentStep . ", coordinates: " . buyX . ", " . buyY)
            break
        }
    }
    
    ; Release right mouse button
    Click "Right Up"
    Sleep 200
    
    ; If not found, return false
    if (!buyFound) {
        WriteLog("Buy button color not found in 360° scan")
        MouseMove(originalX, originalY)
        return {found: false}
    }
    
    ; Move to where the color was found
    MouseMove(buyX, buyY, 10)
    Sleep 300
    
    ; Click multiple times to ensure it registers
    WriteLog("Clicking green button " . CLICK_ATTEMPTS . " times")
    Loop CLICK_ATTEMPTS {
        Click
        WriteLog("Click attempt #" . A_Index)
        Sleep(CLICK_DELAY)
        
        ; Small random mouse movement between clicks to simulate human behavior
        ; and handle any potential slight UI shifts
        if (A_Index < CLICK_ATTEMPTS) {
            MouseMove(buyX + Random(-3, 3), buyY + Random(-3, 3), 5)
            Sleep(50)
        }
    }
    
    ; Initial wait after clicking sequence
    Sleep(WAIT_AFTER_CLICK)
    
    ; Perform multiple verification checks
    colorStillPresent := false
    checksPassed := 0
    
    WriteLog("Beginning " . VERIFICATION_CHECKS . " verification checks")
    
    Loop VERIFICATION_CHECKS {
        checkNumber := A_Index
        
        if PixelSearch(&afterX, &afterY, 
                     buyX - 20, buyY - 20, 
                     buyX + 20, buyY + 20, 
                     BUY_BUTTON_COLOR, COLOR_TOLERANCE) {
            colorStillPresent := true
            WriteLog("Verification check #" . checkNumber . ": FAILED - Color still present")
            
            ; If color still present and this isn't the last check,
            ; try clicking a few more times
            if (A_Index < VERIFICATION_CHECKS) {
                WriteLog("Color still present - trying additional clicks")
                MouseMove(afterX, afterY, 10)  ; Move to the exact color location
                Sleep(200)
                
                ; Additional click attempts
                Loop 2 {
                    Click
                    Sleep(200)
                }
                
                ; Return to buy location for continued checking
                MouseMove(buyX, buyY, 10)
            }
            
            break  ; If color found in any check, fail immediately
        } else {
            WriteLog("Verification check #" . checkNumber . ": PASSED - Color not found")
            checksPassed++
        }
        
        ; Wait between checks (except after the last one)
        if (A_Index < VERIFICATION_CHECKS) {
            Sleep(VERIFICATION_DELAY)
        }
    }
    
    ; Determine overall success
    allChecksPassed := (checksPassed == VERIFICATION_CHECKS)
    
    if (allChecksPassed) {
        WriteLog("All " . VERIFICATION_CHECKS . " verification checks passed - Purchase confirmed")
    } else {
        WriteLog("Only " . checksPassed . " of " . VERIFICATION_CHECKS . " checks passed - Purchase failed")
    }
    
    ; IMPORTANT: Rotate camera back to original position
    WriteLog("Rotating camera back to original position")
    RotateBackToOriginal(currentStep)
    
    ; Return to original mouse position
    MouseMove(originalX, originalY, 10)
    
    return {found: true, succeeded: allChecksPassed}
}

; Function to rotate camera back to original angle
RotateBackToOriginal(stepsToReverse) {
    if (stepsToReverse = 0) {
        return
    }
    
    WriteLog("Rotating back " . stepsToReverse . " steps")
    
    ; Calculate opposite direction movement
    reverseAmount := -ROTATION_SPEED * stepsToReverse
    
    ; Hold right mouse button
    Click "Right Down"
    Sleep 200
    
    ; Move mouse to rotate camera back to original position
    MouseMove reverseAmount, 0, 50, "R"
    Sleep 500
    
    ; Release right mouse button
    Click "Right Up"
    Sleep 200
    
    WriteLog("Camera rotation reset complete")
}