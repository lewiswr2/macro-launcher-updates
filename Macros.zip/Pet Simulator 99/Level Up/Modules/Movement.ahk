#Requires AutoHotkey v2.0
; This file will be included in the main code to enable movement handling
global currentAction := ""
global robloxWinTitle := "ahk_exe RobloxPlayerBeta.exe"

setCurrentAction(actionText) {
    global currentAction
    currentAction := actionText
    ToolTip "Current Action: " actionText
}

DIRECTION_MAP := Map()
DIRECTION_MAP["Up"] := "W"
DIRECTION_MAP["Down"] := "S"
DIRECTION_MAP["Left"] := "A"
DIRECTION_MAP["Right"] := "D"
DIRECTION_MAP["UpRight"] := ["D", "W"]
DIRECTION_MAP["UpLeft"] := ["A", "W"]
DIRECTION_MAP["DownRight"] := ["D", "S"]
DIRECTION_MAP["DownLeft"] := ["A", "S"]

SendInputToRoblox(input) {
    try {
        if WinActive(robloxWinTitle) {
            SendInput input
        } else {
            WinActivate(robloxWinTitle)
            Sleep 100
            SendInput input
        }
        return true
    } catch as err {
        WriteLog("Error in SendInputToRoblox: " . err.Message)
        return false
    }
}

moveDirection(direction, time) {
    try {
        WriteLog("Moving " . (IsObject(direction) ? "multiple directions" : direction) . " for " . time . "ms")
        if IsObject(direction) {
            if direction.Length > 0 {
                for _, key in direction {
                    WriteLog("Pressing key: " . key)
                    SendInputToRoblox("{" . key . " down}")
                }
                Sleep time
                for _, key in direction {
                    WriteLog("Releasing key: " . key)
                    SendInputToRoblox("{" . key . " up}")
                }
            } else {
                WriteLog("Error: Direction object is empty")
                return false
            }
        } else if direction is String {
            WriteLog("Pressing key: " . direction)
            SendInputToRoblox("{" . direction . " down}")
            Sleep time
            WriteLog("Releasing key: " . direction)
            SendInputToRoblox("{" . direction . " up}")
        } else {
            WriteLog("Error: Invalid direction type")
            return false
        }
        WriteLog("Completed moving " . (IsObject(direction) ? "multiple directions" : direction))
        return true
    } catch as err {
        WriteLog("Error in moveDirection: " . err.Message)
        return false
    }
}

moveToRebirth(world, rebirthNumber) {
    WriteLog("Starting moveToRebirth for World " . world . ", Rebirth " . rebirthNumber)
    setCurrentAction("Moving To Rebirth Point")
    clickHoverboard(true)

    try {
        if (world == 1) {
            Switch rebirthNumber {
                Case 1:
                    WriteLog("Moving Up for 950ms")
                    moveDirection("w", 950)
                Case 2:
                    WriteLog("Moving Down for 650ms, then Right for 850ms")

                    moveDirection("d", 1300)
                Case 3:
                    WriteLog("Moving Right for 1900ms")
                    moveDirection("d", 1900)
                Case 4:
                    WriteLog("Moving Up for 750ms")

                    moveDirection("w", 750)
            }
        } else if (world == 2) {
            Switch rebirthNumber {
                Case 1:
                    WriteLog("Moving Right for 1900ms")
                    moveDirection("d", 1900)
                Case 2:
                    WriteLog("Moving Down for 1900ms")
                    moveDirection("s", 1900)
                Case 3:
                    WriteLog("Moving Right for 1900ms")
                    moveDirection("d", 1900)
                Case 4:
                    WriteLog("Moving Right for 650ms, then Up for 750ms")
                    moveDirection("up", 1200)
                           }
        } else {
            throw Error("Invalid world number: " . world)
        }

        clickHoverboard(false)
        setCurrentAction("-")
        WriteLog("Completed moveToRebirth successfully")
        return true
    } catch as err {
        WriteLog("Error in moveToRebirth: " . err.Message)
        return false
    }
}

clickHoverboard(activate := true) {
    if (activate) {
        SendInputToRoblox("{Q down}")
        Sleep 100
        SendInputToRoblox("{Q up}")
    } else {
        SendInputToRoblox("{Q down}")
        Sleep 100
        SendInputToRoblox("{Q up}")
    }
}

; Function to move to the center of the zone after teleportation
moveToZoneCentre(zoneNumber) {
    global ZONE
    setCurrentAction("Moving To Centre Of Zone")  ; Update the current action status

    ; Activate the hoverboard before moving
    clickHoverboard(true)  ; Press 'Q' to ride the hoverboard

    ; Define movement direction and time for each specific zone
    Switch zoneNumber {
        Case 1, 2, 3, 4:
            direction := DIRECTION_MAP["Up"]
            time := 625
        Case 5:
            direction := DIRECTION_MAP["Up"]
            time := 625
        Case 6:
            direction := DIRECTION_MAP["Right"]
            time := 625
        Case 7, 8, 9, 10:
            direction := DIRECTION_MAP["Down"]
            time := 625
        Case 11:
            direction := DIRECTION_MAP["Right"]
            time := 625
        Case 12, 13, 14, 15:
            direction := DIRECTION_MAP["Up"]
            time := 625
        Case 16:
            direction := DIRECTION_MAP["Right"]
            time := 625
        Case 17, 18, 19, 20:
            direction := DIRECTION_MAP["Down"]
            time := 625
        Case 21:
            direction := DIRECTION_MAP["Right"]
            time := 625
        Case 22, 23, 24, 25:
            direction := DIRECTION_MAP["Up"]
            time := 625
        Case 26:
            direction := DIRECTION_MAP["Right"]
            time := 625
        Case 27, 28, 29, 30:
            direction := DIRECTION_MAP["Down"]
            time := 625
        Case 31:
            direction := DIRECTION_MAP["Right"]
            time := 625
        Case 32, 33, 34, 35, 36:
            direction := DIRECTION_MAP["Up"]
            time := 625
        Case 37:
            direction := DIRECTION_MAP["Right"]
            time := 625
        Case 38, 39, 40:
            direction := DIRECTION_MAP["Down"]
            time := 275
        Case 41:
            direction := DIRECTION_MAP["Right"]
            time := 625
        Case 42, 43, 44, 45, 46:
            direction := DIRECTION_MAP["Up"]
            time := 625
        Case 47, 48:
            direction := DIRECTION_MAP["Right"]
            time := 625
        Case 49, 50, 51, 52, 53, 54:
            direction := DIRECTION_MAP["Down"]
            time := 1150
        Case 55, 56:
            direction := DIRECTION_MAP["Right"]
            time := 625
        Case 57:
            direction := DIRECTION_MAP["Down"]
            time := 625
        Case 58, 59, 60, 61, 62, 63:
            direction := DIRECTION_MAP["Up"]
            time := 625
        Case 64, 65, 66:
            direction := DIRECTION_MAP["Right"]
            time := 275
        Case 67, 68, 69, 70, 71, 72:
            direction := DIRECTION_MAP["Down"]
            time := 625
        Case 73, 74, 75:
            direction := DIRECTION_MAP["Right"]
            time := 625
        Case 76, 77, 78, 79:
            direction := DIRECTION_MAP["Up"]
            time := 625
        Case 80, 81, 82:
            direction := DIRECTION_MAP["Right"]
            time := 625
        Case 83, 84, 85, 86, 87, 88:
            direction := DIRECTION_MAP["Down"]
            time := 625

        Case 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99:
            direction := DIRECTION_MAP["Right"]
            time := 625
        Case 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110:
            direction := DIRECTION_MAP["Up"]
            time := 625
        Case 111, 112, 113:
            direction := DIRECTION_MAP["Right"]
            time := 625
        Case 114, 115, 116, 117, 118, 119, 120, 121, 122:
            direction := DIRECTION_MAP["Down"]
            time := 625
        Case 123, 124, 125:
            direction := DIRECTION_MAP["Right"]
            time := 625
        Case 126:
            direction := DIRECTION_MAP["Down"]
            time := 625
        Case 127, 128, 129, 130, 131:
            direction := DIRECTION_MAP["Up"]
            time := 625
        Case 132, 133, 134, 135, 136, 137, 138, 139:
            direction := DIRECTION_MAP["Right"]
            time := 625
        Case 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150:
            direction := DIRECTION_MAP["Down"]
            time := 625
        Case 151, 152, 153:
            direction := DIRECTION_MAP["Right"]
            time := 625
        Case 154, 155, 156, 157, 158:
            direction := DIRECTION_MAP["Up"]
            time := 625
        Case 159, 160, 161:
            direction := DIRECTION_MAP["Right"]
            time := 625
        Case 162, 160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170:
            direction := DIRECTION_MAP["Down"]
            time := 625
        Case 171, 172, 173, 174, 175:
            direction := DIRECTION_MAP["Right"]
            time := 625
        Case 176, 177, 178, 179, 180, 181, 182:
            direction := DIRECTION_MAP["Up"]
            time := 625
        Case 183, 184, 185:
            direction := DIRECTION_MAP["Right"]
            time := 625
        Case 186, 187, 188, 189, 190, 191:
            direction := DIRECTION_MAP["Down"]
            time := 625
        Case 192, 193, 194, 195, 196, 197, 198, 199:
            direction := DIRECTION_MAP["Right"]
            time := 850
        Case 200, 201, 202, 203, 204:
            direction := DIRECTION_MAP["Right"]
            time := 625
        Case 205:
            direction := DIRECTION_MAP["Left"]
            time := 625
        Case 206:
            direction := DIRECTION_MAP["Left"]
            time := 625
        Case 207:
            direction := DIRECTION_MAP["Left"]
            time := 625
        Case 208:
            direction := DIRECTION_MAP["Left"]
            time := 625
        Case 209:
            direction := DIRECTION_MAP["Left"]
            time := 625
        Case 210:
            direction := DIRECTION_MAP["Left"]
            time := 625
        Case 211:
            direction := DIRECTION_MAP["Right"]
            time := 625
        Case 212:
            direction := DIRECTION_MAP["Down"]
            time := 625
        Case 213:
            direction := DIRECTION_MAP["Left"]
            time := 625
        Case 214:
            direction := DIRECTION_MAP["Up"]
            time := 625
        Case 215, 216, 217, 218, 219:
            direction := DIRECTION_MAP["Right"]
            time := 625
        Case 220, 221, 222, 223, 224:
            direction := DIRECTION_MAP["Right"]
            time := 625
        Case 225, 226, 227, 228, 229:
            direction := DIRECTION_MAP["Right"]
            time := 625
        ; Add more zones if necessary...
        Default:
            direction := DIRECTION_MAP["Up"]
            time := 500
    }

    moveDirection(direction, time)

    clickHoverboard(false)

    setCurrentAction("-")
}

performRebirth() {
    try {
        WriteLog("Clicking to confirm rebirth")
        ClickAt(397, 425)  ; Click to confirm rebirth
        Sleep(30000)  ; Wait for 30 seconds
        
        WriteLog("Spamming clicks in the middle of the Roblox window")
        ; Spam clicks in the middle of the Roblox window for 10 seconds
        Loop 100 {
            ClickAt(400, 300)  ; Assuming 800x600 window, click in the middle
            Sleep(100)
        }
        
        WriteLog("Completed performRebirth")
        return true
    } catch as err {
        WriteLog("Error in performRebirth: " . err.Message)
        return false
    }
}

ClickInRoblox(x, y) {
    if ActivateRobloxWindow() {  ; Call the renamed function
        ToolTip "Clicking at: " x ", " y  ; Show tooltip for debugging
        Sleep 1000 ; Wait 1 second to view the tooltip
        ; Perform the click without holding any mouse buttons down longer than needed
        Click %x%, %y%
        ToolTip  ; Clear the tooltip
    }
}

ActivateRobloxWindow() {  ; Renamed from EnsureRobloxActive
    if !WinActive(robloxWinTitle) {
        WinActivate(robloxWinTitle)
        WinWaitActive(robloxWinTitle,, 2)
    }
    return WinActive(robloxWinTitle)
}

