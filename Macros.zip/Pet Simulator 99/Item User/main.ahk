﻿#Requires AutoHotkey v2.0
#SingleInstance Force
#NoTrayIcon

; Global variables
global IsPaused := false
global ClickDelay := 100
global ItemUseDelay := 5000
global SetupDelay := 2500
global UseRandomization := false
global RandomVariance := 500
global LogActions := false
global LogFile := "macro_log.txt"

; Color scheme
global COLORS := {
    headerBg: "0xd29922",
    headerText: "0x13171d",
    bg: "0x0a0e14",
    cardBg: "0x161b22",
    cardHover: "0x1c2128",
    text: "0xFFFFFF",
    textDim: "0xB0B0B0",
    border: "0x3A3A3A",
    success: "0x4CAF50",
    warning: "0xFFC107",
    danger: "0xF44336",
    buttonBg: "0xF5E6D3",
    buttonText: "0x000000"
}

; Create the GUI with modern styling
myGui := Gui("+Resize +MinSize400h650")
myGui.BackColor := COLORS.bg

; Header section
myGui.Add("Progress", "x0 y0 w400 h100 Background" SubStr(COLORS.headerBg, 3))
myGui.SetFont("s20 bold c" SubStr(COLORS.headerText, 3), "Segoe UI")
myGui.Add("Text", "x0 y25 w400 Center BackgroundTrans", "🎮 PS99 Item User")
myGui.SetFont("s10 c" SubStr(COLORS.headerText, 3))
myGui.Add("Text", "x0 y60 w400 Center BackgroundTrans", "Automate item usage for Pet Simulator 99")

; Reset font for content
myGui.SetFont("s10 c" SubStr(COLORS.text, 3), "Segoe UI")

; Create tabs
tabs := myGui.Add("Tab3", "x0 y100 w400 h550 Background" SubStr(COLORS.bg, 3), ["Items", "Settings", "Statistics"])

; ========== Items tab ==========
tabs.UseTab(1)

; Instructions card
myGui.Add("Text", "x10 y135 w380 h90 Background" SubStr(COLORS.cardBg, 3))
myGui.SetFont("s9 c" SubStr(COLORS.textDim, 3))
myGui.Add("Text", "x20 y145", "1. Join PS99 Fantasy World first")
myGui.Add("Text", "x20 y165", "2. Don't move or touch anything after loading in")
myGui.Add("Text", "x20 y185", "3. Make sure all letters you type into the GUI are lowercase")
myGui.Add("Text", "x20 y205", "4. F1: Start | F4: Pause | F5: Reload | F3: Exit")
myGui.SetFont("s10 c" SubStr(COLORS.text, 3))

; Items section
yPos := 240
myGui.Add("Text", "x20 y" yPos " c" SubStr(COLORS.textDim, 3), "Select Items to Use:")
yPos += 25

myGui.Add("Checkbox", "x20 y" yPos " vUseCoinJar c" SubStr(COLORS.text, 3), "Coin Jar:")
coinJarKey := myGui.Add("Edit", "x+10 yp w30 Background" SubStr(COLORS.cardBg, 3) " c" SubStr(COLORS.text, 3) " vCoinJarKey")

yPos += 30
myGui.Add("Checkbox", "x20 y" yPos " vUsePinata c" SubStr(COLORS.text, 3), "Piñata:")
pinataKey := myGui.Add("Edit", "x+10 yp w30 Background" SubStr(COLORS.cardBg, 3) " c" SubStr(COLORS.text, 3) " vPinataKey")

yPos += 30
myGui.Add("Checkbox", "x20 y" yPos " vUseGiantJar c" SubStr(COLORS.text, 3), "Giant Coin Jar:")
giantJarKey := myGui.Add("Edit", "x+10 yp w30 Background" SubStr(COLORS.cardBg, 3) " c" SubStr(COLORS.text, 3) " vGiantJarKey")

yPos += 30
myGui.Add("Checkbox", "x20 y" yPos " vUsePartyBox c" SubStr(COLORS.text, 3), "Party Box:")
partyBoxKey := myGui.Add("Edit", "x+10 yp w30 Background" SubStr(COLORS.cardBg, 3) " c" SubStr(COLORS.text, 3) " vPartyBoxKey")

yPos += 30
myGui.Add("Checkbox", "x20 y" yPos " vUseComet c" SubStr(COLORS.text, 3), "Comet:")
cometKey := myGui.Add("Edit", "x+10 yp w30 Background" SubStr(COLORS.cardBg, 3) " c" SubStr(COLORS.text, 3) " vCometKey")

yPos += 30
myGui.Add("Checkbox", "x20 y" yPos " vUseItemJar c" SubStr(COLORS.text, 3), "Item Jar:")
itemJarKey := myGui.Add("Edit", "x+10 yp w30 Background" SubStr(COLORS.cardBg, 3) " c" SubStr(COLORS.text, 3) " vItemJarKey")

yPos += 30
myGui.Add("Checkbox", "x20 y" yPos " vUseLuckyBlock c" SubStr(COLORS.text, 3), "Lucky Block:")
luckyBlockKey := myGui.Add("Edit", "x+10 yp w30 Background" SubStr(COLORS.cardBg, 3) " c" SubStr(COLORS.text, 3) " vLuckyBlockKey")

yPos += 30
myGui.Add("Checkbox", "x20 y" yPos " vUseMagnetFlag c" SubStr(COLORS.text, 3), "Magnet Flag:")
magnetFlagKey := myGui.Add("Edit", "x+10 yp w30 Background" SubStr(COLORS.cardBg, 3) " c" SubStr(COLORS.text, 3) " vMagnetFlagKey")

; Control buttons
yPos += 40
myGui.Add("Button", "x20 y" yPos " w170 Background" SubStr(COLORS.buttonBg, 3) " c" SubStr(COLORS.buttonText, 3), "Select All").OnEvent("Click", SelectAll)
myGui.Add("Button", "x+10 yp w170 Background" SubStr(COLORS.buttonBg, 3) " c" SubStr(COLORS.buttonText, 3), "Deselect All").OnEvent("Click", DeselectAll)
myGui.Add("Button", "x20 y+10 w170 Background" SubStr(COLORS.buttonBg, 3) " c" SubStr(COLORS.buttonText, 3), "Save Settings").OnEvent("Click", SaveSettings)
myGui.Add("Button", "x+10 yp w170 Background" SubStr(COLORS.buttonBg, 3) " c" SubStr(COLORS.buttonText, 3), "Load Settings").OnEvent("Click", LoadSettings)

; Status and start
statusBar := myGui.Add("Text", "x20 y+0 w360 Center c" SubStr(COLORS.success, 3), "Ready")
myGui.Add("Button", "x20 y+5 w360 h35 Background" SubStr(COLORS.success, 3) " c" SubStr(COLORS.headerText, 3), "Start Macro (F1)").OnEvent("Click", StartMacro)

; ========== Settings tab ==========
tabs.UseTab(2)

; Timing Settings
myGui.Add("Text", "x20 y135 w360 c" SubStr(COLORS.textDim, 3), "⏱️ Timing Settings (milliseconds)")
myGui.Add("Text", "x10 y155 w380 h2 Background" SubStr(COLORS.border, 3))

myGui.Add("Text", "x20 y170 c" SubStr(COLORS.text, 3), "Click Delay:")
clickDelayEdit := myGui.Add("Edit", "x+10 yp-3 w80 Number Background" SubStr(COLORS.cardBg, 3) " c" SubStr(COLORS.text, 3) " vClickDelayEdit", ClickDelay)
myGui.Add("Text", "x+5 yp+3 c" SubStr(COLORS.textDim, 3), "ms (default: 100)")

myGui.Add("Text", "x20 y+15 c" SubStr(COLORS.text, 3), "Item Use Delay:")
itemDelayEdit := myGui.Add("Edit", "x+10 yp-3 w80 Number Background" SubStr(COLORS.cardBg, 3) " c" SubStr(COLORS.text, 3) " vItemDelayEdit", ItemUseDelay)
myGui.Add("Text", "x+5 yp+3 c" SubStr(COLORS.textDim, 3), "ms (default: 5000)")

myGui.Add("Text", "x20 y+15 c" SubStr(COLORS.text, 3), "Setup Delay:")
setupDelayEdit := myGui.Add("Edit", "x+10 yp-3 w80 Number Background" SubStr(COLORS.cardBg, 3) " c" SubStr(COLORS.text, 3) " vSetupDelayEdit", SetupDelay)
myGui.Add("Text", "x+5 yp+3 c" SubStr(COLORS.textDim, 3), "ms (default: 2500)")

myGui.Add("Button", "x20 y+15 w170 Background" SubStr(COLORS.buttonBg, 3) " c" SubStr(COLORS.buttonText, 3), "Apply Timing").OnEvent("Click", ApplyTiming)
myGui.Add("Button", "x+10 yp w170 Background" SubStr(COLORS.buttonBg, 3) " c" SubStr(COLORS.buttonText, 3), "Reset to Defaults").OnEvent("Click", ResetTiming)

; Randomization
myGui.Add("Text", "x20 y+30 w360 c" SubStr(COLORS.textDim, 3), "🎲 Randomization")
myGui.Add("Text", "x10 y+5 w380 h2 Background" SubStr(COLORS.border, 3))

randomCheck := myGui.Add("Checkbox", "x20 y+10 vUseRandomization c" SubStr(COLORS.text, 3), "Enable Random Delays")
myGui.Add("Text", "x20 y+10 c" SubStr(COLORS.text, 3), "Variance Range: ±")
varianceEdit := myGui.Add("Edit", "x+5 yp-3 w80 Number Background" SubStr(COLORS.cardBg, 3) " c" SubStr(COLORS.text, 3) " vRandomVariance", RandomVariance)
myGui.Add("Text", "x+5 yp+3 c" SubStr(COLORS.textDim, 3), "ms")
myGui.Add("Text", "x20 y+5 w340 c" SubStr(COLORS.textDim, 3), "(Adds random variation to delays to appear more human-like)")

; Logging
myGui.Add("Text", "x20 y+20 w360 c" SubStr(COLORS.textDim, 3), "📝 Logging & Debugging")
myGui.Add("Text", "x10 y+5 w380 h2 Background" SubStr(COLORS.border, 3))

logCheck := myGui.Add("Checkbox", "x20 y+10 vLogActions c" SubStr(COLORS.text, 3), "Enable Action Logging")
myGui.Add("Text", "x20 y+10 w340 c" SubStr(COLORS.textDim, 3), "Logs all macro actions to: macro_log.txt")

myGui.Add("Button", "x20 y+10 w170 Background" SubStr(COLORS.buttonBg, 3) " c" SubStr(COLORS.buttonText, 3), "Open Log File").OnEvent("Click", OpenLog)
myGui.Add("Button", "x+10 yp w170 Background" SubStr(COLORS.buttonBg, 3) " c" SubStr(COLORS.buttonText, 3), "Clear Log").OnEvent("Click", ClearLog)

; ========== Statistics tab ==========
tabs.UseTab(3)

myGui.Add("Text", "x20 y135 w360 c" SubStr(COLORS.textDim, 3), "📊 Session Statistics")
myGui.Add("Text", "x10 y155 w380 h2 Background" SubStr(COLORS.border, 3))

myGui.Add("Text", "x20 y170 c" SubStr(COLORS.textDim, 3), "Session Start Time:")
sessionStartText := myGui.Add("Text", "x+10 yp w250 c" SubStr(COLORS.text, 3), "Not started")

myGui.Add("Text", "x20 y+15 c" SubStr(COLORS.textDim, 3), "Runtime:")
runtimeText := myGui.Add("Text", "x+10 yp w250 c" SubStr(COLORS.text, 3), "0h 0m 0s")

myGui.Add("Text", "x20 y+15 c" SubStr(COLORS.textDim, 3), "Total Items Used:")
itemsUsedText := myGui.Add("Text", "x+10 yp w250 c" SubStr(COLORS.text, 3), "0")

myGui.Add("Text", "x20 y+15 c" SubStr(COLORS.textDim, 3), "Current Status:")
currentStatusText := myGui.Add("Text", "x+10 yp w250 c" SubStr(COLORS.warning, 3), "Idle")

myGui.Add("Text", "x20 y+15 c" SubStr(COLORS.textDim, 3), "Loops Completed:")
loopsText := myGui.Add("Text", "x+10 yp w250 c" SubStr(COLORS.text, 3), "0")

; Item stats
myGui.Add("Text", "x20 y+30 w360 c" SubStr(COLORS.textDim, 3), "📦 Items Usage Count")
myGui.Add("Text", "x10 y+5 w380 h2 Background" SubStr(COLORS.border, 3))

itemStatsY := 385
myGui.Add("Text", "x20 y" itemStatsY " c" SubStr(COLORS.textDim, 3), "Coin Jars:")
coinJarStat := myGui.Add("Text", "x+10 yp w80 c" SubStr(COLORS.text, 3), "0")
myGui.Add("Text", "x200 y" itemStatsY " c" SubStr(COLORS.textDim, 3), "Piñatas:")
pinataStat := myGui.Add("Text", "x+10 yp w80 c" SubStr(COLORS.text, 3), "0")

itemStatsY += 25
myGui.Add("Text", "x20 y" itemStatsY " c" SubStr(COLORS.textDim, 3), "Giant Jars:")
giantJarStat := myGui.Add("Text", "x+10 yp w80 c" SubStr(COLORS.text, 3), "0")
myGui.Add("Text", "x200 y" itemStatsY " c" SubStr(COLORS.textDim, 3), "Party Boxes:")
partyBoxStat := myGui.Add("Text", "x+10 yp w80 c" SubStr(COLORS.text, 3), "0")

itemStatsY += 25
myGui.Add("Text", "x20 y" itemStatsY " c" SubStr(COLORS.textDim, 3), "Comets:")
cometStat := myGui.Add("Text", "x+10 yp w80 c" SubStr(COLORS.text, 3), "0")
myGui.Add("Text", "x200 y" itemStatsY " c" SubStr(COLORS.textDim, 3), "Item Jars:")
itemJarStat := myGui.Add("Text", "x+10 yp w80 c" SubStr(COLORS.text, 3), "0")

itemStatsY += 25
myGui.Add("Text", "x20 y" itemStatsY " c" SubStr(COLORS.textDim, 3), "Lucky Blocks:")
luckyBlockStat := myGui.Add("Text", "x+10 yp w80 c" SubStr(COLORS.text, 3), "0")
myGui.Add("Text", "x200 y" itemStatsY " c" SubStr(COLORS.textDim, 3), "Magnet Flags:")
magnetFlagStat := myGui.Add("Text", "x+10 yp w80 c" SubStr(COLORS.text, 3), "0")

myGui.Add("Button", "x20 y+30 w360 Background" SubStr(COLORS.danger, 3) " c" SubStr(COLORS.text, 3), "Reset Statistics").OnEvent("Click", ResetStats)

tabs.UseTab()

; Global statistics variables
global SessionStartTime := ""
global TotalItemsUsed := 0
global LoopsCompleted := 0
global CoinJarCount := 0
global PinataCount := 0
global GiantJarCount := 0
global PartyBoxCount := 0
global CometCount := 0
global ItemJarCount := 0
global LuckyBlockCount := 0
global MagnetFlagCount := 0

; Timer for runtime display
SetTimer(UpdateRuntime, 1000)

UpdateRuntime() {
    global SessionStartTime, runtimeText
    if (SessionStartTime != "") {
        elapsed := A_TickCount - SessionStartTime
        hours := Floor(elapsed / 3600000)
        minutes := Floor(Mod(elapsed, 3600000) / 60000)
        seconds := Floor(Mod(elapsed, 60000) / 1000)
        runtimeText.Value := hours "h " minutes "m " seconds "s"
    }
}

ApplyTiming(*) {
    global ClickDelay := Integer(clickDelayEdit.Value)
    global ItemUseDelay := Integer(itemDelayEdit.Value)
    global SetupDelay := Integer(setupDelayEdit.Value)
    MsgBox("Timing settings applied!`n`nClick Delay: " ClickDelay "ms`nItem Delay: " ItemUseDelay "ms`nSetup Delay: " SetupDelay "ms")
}

ResetTiming(*) {
    global ClickDelay := 100
    global ItemUseDelay := 5000
    global SetupDelay := 2500
    clickDelayEdit.Value := ClickDelay
    itemDelayEdit.Value := ItemUseDelay
    setupDelayEdit.Value := SetupDelay
    MsgBox("Timing settings reset to defaults!")
}

OpenLog(*) {
    global LogFile
    if FileExist(LogFile) {
        Run(LogFile)
    } else {
        MsgBox("Log file doesn't exist yet. Enable logging and run the macro first.")
    }
}

ClearLog(*) {
    global LogFile
    try {
        FileDelete(LogFile)
        MsgBox("Log file cleared!")
    } catch {
        MsgBox("Could not clear log file. Make sure it's not open.")
    }
}

LogAction(action) {
    global LogActions, LogFile
    if (LogActions) {
        try {
            logText := FormatTime(, "yyyy-MM-dd HH:mm:ss") " - " action "`n"
            FileAppend(logText, LogFile)
        }
    }
}

GetRandomDelay(baseDelay) {
    global UseRandomization, RandomVariance
    if (UseRandomization) {
        variance := Random(-RandomVariance, RandomVariance)
        return Max(50, baseDelay + variance)
    }
    return baseDelay
}

; Load settings on startup
LoadSettings()
LoadStatistics()
myGui.Title := "Item User Macro"
myGui.Show("w400")

SaveSettings(*) {
    settings := Map()
    
    ; Save checkboxes and keybinds
    settings["UseCoinJar"] := myGui["UseCoinJar"].Value
    settings["CoinJarKey"] := coinJarKey.Value
    settings["UsePinata"] := myGui["UsePinata"].Value
    settings["PinataKey"] := pinataKey.Value
    settings["UseGiantJar"] := myGui["UseGiantJar"].Value
    settings["GiantJarKey"] := giantJarKey.Value
    settings["UsePartyBox"] := myGui["UsePartyBox"].Value
    settings["PartyBoxKey"] := partyBoxKey.Value
    settings["UseComet"] := myGui["UseComet"].Value
    settings["CometKey"] := cometKey.Value
    settings["UseItemJar"] := myGui["UseItemJar"].Value
    settings["ItemJarKey"] := itemJarKey.Value
    settings["UseLuckyBlock"] := myGui["UseLuckyBlock"].Value
    settings["LuckyBlockKey"] := luckyBlockKey.Value
    settings["UseMagnetFlag"] := myGui["UseMagnetFlag"].Value
    settings["MagnetFlagKey"] := magnetFlagKey.Value
    
    ; Save timing settings
    settings["ClickDelay"] := ClickDelay
    settings["ItemUseDelay"] := ItemUseDelay
    settings["SetupDelay"] := SetupDelay
    
    ; Save randomization settings
    settings["UseRandomization"] := randomCheck.Value
    settings["RandomVariance"] := varianceEdit.Value
    
    ; Save logging settings
    settings["LogActions"] := logCheck.Value
    
    ; Convert to JSON and save
    try {
        jsonStr := MapToJSON(settings)
        settingsFile := FileOpen("macro_settings.json", "w")
        settingsFile.Write(jsonStr)
        settingsFile.Close()
        MsgBox("Settings saved successfully!")
    } catch as err {
        MsgBox("Error saving settings: " err.Message)
    }
}

LoadSettings(*) {
    try {
        if FileExist("macro_settings.json") {
            jsonStr := FileRead("macro_settings.json")
            settings := JSONToMap(jsonStr)
            
            ; Load checkboxes and keybinds
            if settings.Has("UseCoinJar")
                myGui["UseCoinJar"].Value := settings["UseCoinJar"]
            if settings.Has("CoinJarKey")
                coinJarKey.Value := settings["CoinJarKey"]
            if settings.Has("UsePinata")
                myGui["UsePinata"].Value := settings["UsePinata"]
            if settings.Has("PinataKey")
                pinataKey.Value := settings["PinataKey"]
            if settings.Has("UseGiantJar")
                myGui["UseGiantJar"].Value := settings["UseGiantJar"]
            if settings.Has("GiantJarKey")
                giantJarKey.Value := settings["GiantJarKey"]
            if settings.Has("UsePartyBox")
                myGui["UsePartyBox"].Value := settings["UsePartyBox"]
            if settings.Has("PartyBoxKey")
                partyBoxKey.Value := settings["PartyBoxKey"]
            if settings.Has("UseComet")
                myGui["UseComet"].Value := settings["UseComet"]
            if settings.Has("CometKey")
                cometKey.Value := settings["CometKey"]
            if settings.Has("UseItemJar")
                myGui["UseItemJar"].Value := settings["UseItemJar"]
            if settings.Has("ItemJarKey")
                itemJarKey.Value := settings["ItemJarKey"]
            if settings.Has("UseLuckyBlock")
                myGui["UseLuckyBlock"].Value := settings["UseLuckyBlock"]
            if settings.Has("LuckyBlockKey")
                luckyBlockKey.Value := settings["LuckyBlockKey"]
            if settings.Has("UseMagnetFlag")
                myGui["UseMagnetFlag"].Value := settings["UseMagnetFlag"]
            if settings.Has("MagnetFlagKey")
                magnetFlagKey.Value := settings["MagnetFlagKey"]
            
            ; Load timing settings
            if settings.Has("ClickDelay") {
                global ClickDelay := Integer(settings["ClickDelay"])
                clickDelayEdit.Value := ClickDelay
            }
            if settings.Has("ItemUseDelay") {
                global ItemUseDelay := Integer(settings["ItemUseDelay"])
                itemDelayEdit.Value := ItemUseDelay
            }
            if settings.Has("SetupDelay") {
                global SetupDelay := Integer(settings["SetupDelay"])
                setupDelayEdit.Value := SetupDelay
            }
            
            ; Load randomization settings
            if settings.Has("UseRandomization") {
                global UseRandomization := Integer(settings["UseRandomization"])
                randomCheck.Value := UseRandomization
            }
            if settings.Has("RandomVariance") {
                global RandomVariance := Integer(settings["RandomVariance"])
                varianceEdit.Value := RandomVariance
            }
            
            ; Load logging settings
            if settings.Has("LogActions") {
                global LogActions := Integer(settings["LogActions"])
                logCheck.Value := LogActions
            }
        }
    }
}

SaveStatistics() {
    global SessionStartTime, TotalItemsUsed, LoopsCompleted
    global CoinJarCount, PinataCount, GiantJarCount, PartyBoxCount
    global CometCount, ItemJarCount, LuckyBlockCount, MagnetFlagCount
    
    stats := Map()
    
    stats["SessionStartTime"] := SessionStartTime
    stats["TotalItemsUsed"] := TotalItemsUsed
    stats["LoopsCompleted"] := LoopsCompleted
    stats["CoinJarCount"] := CoinJarCount
    stats["PinataCount"] := PinataCount
    stats["GiantJarCount"] := GiantJarCount
    stats["PartyBoxCount"] := PartyBoxCount
    stats["CometCount"] := CometCount
    stats["ItemJarCount"] := ItemJarCount
    stats["LuckyBlockCount"] := LuckyBlockCount
    stats["MagnetFlagCount"] := MagnetFlagCount
    
    try {
        jsonStr := MapToJSON(stats)
        statsFile := FileOpen("macro_statistics.json", "w")
        statsFile.Write(jsonStr)
        statsFile.Close()
    } catch as err {
        LogAction("Error saving statistics: " err.Message)
    }
}

JSONToMap(jsonStr) {
    mapObj := Map()
    
    ; Remove outer braces
    jsonStr := Trim(jsonStr)
    jsonStr := SubStr(jsonStr, 2, StrLen(jsonStr) - 2)
    
    ; Split by comma
    pairs := StrSplit(jsonStr, ",")
    
    for pair in pairs {
        if (pair = "")
            continue
            
        ; Find the colon separator
        colonPos := InStr(pair, ":")
        if (colonPos = 0)
            continue
            
        ; Extract key and value
        key := Trim(SubStr(pair, 1, colonPos - 1))
        value := Trim(SubStr(pair, colonPos + 1))
        
        ; Remove quotes from key
        key := StrReplace(key, '"', '')
        
        ; Remove quotes from value if it's a string
        if (SubStr(value, 1, 1) = '"')
            value := StrReplace(value, '"', '')
        
        mapObj[key] := value
    }
    
    return mapObj
}

EscapeJSON(str) {
    str := StrReplace(str, '\', '\\')
    str := StrReplace(str, '"', '\"')
    str := StrReplace(str, '`n', '\n')
    str := StrReplace(str, '`r', '\r')
    str := StrReplace(str, '`t', '\t')
    return str
}

ResetStats(*) {
    global TotalItemsUsed := 0
    global LoopsCompleted := 0
    global CoinJarCount := 0
    global PinataCount := 0
    global GiantJarCount := 0
    global PartyBoxCount := 0
    global CometCount := 0
    global ItemJarCount := 0
    global LuckyBlockCount := 0
    global MagnetFlagCount := 0
    global SessionStartTime := ""
    
    UpdateStatsDisplay()
    sessionStartText.Value := "Not started"
    runtimeText.Value := "0h 0m 0s"
    currentStatusText.Value := "Idle"
    
    SaveStatistics()
    
    MsgBox("Statistics have been reset!")
}

UpdateStatsDisplay() {
    global TotalItemsUsed, LoopsCompleted
    global CoinJarCount, PinataCount, GiantJarCount, PartyBoxCount
    global CometCount, ItemJarCount, LuckyBlockCount, MagnetFlagCount
    
    itemsUsedText.Value := TotalItemsUsed
    loopsText.Value := LoopsCompleted
    coinJarStat.Value := CoinJarCount
    pinataStat.Value := PinataCount
    giantJarStat.Value := GiantJarCount
    partyBoxStat.Value := PartyBoxCount
    cometStat.Value := CometCount
    itemJarStat.Value := ItemJarCount
    luckyBlockStat.Value := LuckyBlockCount
    magnetFlagStat.Value := MagnetFlagCount
    
    SaveStatistics()
}

LoadStatistics() {
    global SessionStartTime, TotalItemsUsed, LoopsCompleted
    global CoinJarCount, PinataCount, GiantJarCount, PartyBoxCount
    global CometCount, ItemJarCount, LuckyBlockCount, MagnetFlagCount
    
    try {
        if FileExist("macro_statistics.json") {
            jsonStr := FileRead("macro_statistics.json")
            stats := JSONToMap(jsonStr)
            
            if stats.Has("SessionStartTime") {
                SessionStartTime := stats["SessionStartTime"]
                if (SessionStartTime != "" && SessionStartTime != "0") {
                    sessionStartText.Value := FormatTime(, "yyyy-MM-dd HH:mm:ss")
                }
            }
            if stats.Has("TotalItemsUsed")
                TotalItemsUsed := Integer(stats["TotalItemsUsed"])
            if stats.Has("LoopsCompleted")
                LoopsCompleted := Integer(stats["LoopsCompleted"])
            if stats.Has("CoinJarCount")
                CoinJarCount := Integer(stats["CoinJarCount"])
            if stats.Has("PinataCount")
                PinataCount := Integer(stats["PinataCount"])
            if stats.Has("GiantJarCount")
                GiantJarCount := Integer(stats["GiantJarCount"])
            if stats.Has("PartyBoxCount")
                PartyBoxCount := Integer(stats["PartyBoxCount"])
            if stats.Has("CometCount")
                CometCount := Integer(stats["CometCount"])
            if stats.Has("ItemJarCount")
                ItemJarCount := Integer(stats["ItemJarCount"])
            if stats.Has("LuckyBlockCount")
                LuckyBlockCount := Integer(stats["LuckyBlockCount"])
            if stats.Has("MagnetFlagCount")
                MagnetFlagCount := Integer(stats["MagnetFlagCount"])
            
            UpdateStatsDisplay()
        }
    }
}

MapToJSON(mapObj) {
    jsonStr := "{"
    first := true
    for key, value in mapObj {
        if (!first)
            jsonStr .= ","
        first := false
        
        jsonStr .= '"' . EscapeJSON(key) . '":'
        
        if (IsInteger(value) || IsFloat(value))
            jsonStr .= value
        else
            jsonStr .= '"' . EscapeJSON(value) . '"'
    }
    jsonStr .= "}"
    return jsonStr
}

SelectAll(*) {
    myGui["UseCoinJar"].Value := 1
    myGui["UsePinata"].Value := 1
    myGui["UseGiantJar"].Value := 1
    myGui["UsePartyBox"].Value := 1
    myGui["UseComet"].Value := 1
    myGui["UseItemJar"].Value := 1
    myGui["UseLuckyBlock"].Value := 1
    myGui["UseMagnetFlag"].Value := 1
}

DeselectAll(*) {
    myGui["UseCoinJar"].Value := 0
    myGui["UsePinata"].Value := 0
    myGui["UseGiantJar"].Value := 0
    myGui["UsePartyBox"].Value := 0
    myGui["UseComet"].Value := 0
    myGui["UseItemJar"].Value := 0
    myGui["UseLuckyBlock"].Value := 0
    myGui["UseMagnetFlag"].Value := 0
}

updateStatus(text) {
    statusBar.Value := text
    currentStatusText.Value := text
    LogAction(text)
}

StartMacro(*) {
    ; Declare all global variables used in this function
    global SessionStartTime, TotalItemsUsed, LoopsCompleted
    global CoinJarCount, PinataCount, GiantJarCount, PartyBoxCount
    global CometCount, ItemJarCount, LuckyBlockCount, MagnetFlagCount
    global UseRandomization, RandomVariance, LogActions
    global IsPaused, ItemUseDelay
    
    ; Check if any items are selected
    if !(myGui["UseCoinJar"].Value || myGui["UsePinata"].Value || myGui["UseGiantJar"].Value || 
         myGui["UsePartyBox"].Value || myGui["UseComet"].Value || myGui["UseItemJar"].Value || 
         myGui["UseLuckyBlock"].Value || myGui["UseMagnetFlag"].Value) {
        MsgBox("Please select at least one item to use!")
        return
    }
    
    ; Initialize session
    SessionStartTime := A_TickCount
    sessionStartText.Value := FormatTime(, "yyyy-MM-dd HH:mm:ss")
    
    ; Update settings from GUI
    UseRandomization := randomCheck.Value
    RandomVariance := Integer(varianceEdit.Value)
    LogActions := logCheck.Value

    ; Activate Roblox window and resize
    if WinExist("Roblox") {
        WinActivate("Roblox")
        WinMove(0, 0, 800, 600, "Roblox")
    }

    ; Initial setup
    updateStatus("Starting game setup...")
    
    Sleep(GetRandomDelay(SetupDelay))
    checkForPlayerFullyLoaded()
    findTeleportButton()
    Sleep(GetRandomDelay(500))
    SendEvent("{Click 612, 104}")
    Sleep(GetRandomDelay(500))

    ; Search for area
    updateStatus("Searching for game...")
    SendText("Toadstool Throne")
    Sleep(GetRandomDelay(1000))
    SendEvent("{Click 395, 232}")
    Sleep(GetRandomDelay(500))

    ; Wait for player to load
    Sleep(GetRandomDelay(10000))

    ; Character setup sequence
    updateStatus("Setting up character...")
    Send("{q}")
    Sleep(GetRandomDelay(200))
    
    Send("{d down}")
    Sleep(GetRandomDelay(500))
    Send("{d up}")

    MouseMove(400, 300)
    Sleep(GetRandomDelay(100))
    SendEvent("{Click right down}")
    Sleep(GetRandomDelay(100))
    MouseMove(400, 500)
    Sleep(GetRandomDelay(100))
    SendEvent("{Click right up}")
    Loop 30 {
        SendEvent("{WheelDown}")
    }
    Sleep(GetRandomDelay(500))

    ; Start the infinite item usage loop
    updateStatus("Setup complete! Starting item loop...")
    Loop {
        while IsPaused {
            Sleep(100)
            updateStatus("PAUSED - Press F4 to resume")
        }
        
        ; Use items one at a time with delays
        if (myGui["UseCoinJar"].Value && coinJarKey.Value) {
            Send(coinJarKey.Value)
            Sleep(GetRandomDelay(100))
            SendEvent("{Click 402, 415}")
            CoinJarCount++
            TotalItemsUsed++
            UpdateStatsDisplay()
            updateStatus("Used Coin Jar (" CoinJarCount " total)")
            Sleep(GetRandomDelay(ItemUseDelay))
        }
        if (myGui["UsePinata"].Value && pinataKey.Value) {
            Send(pinataKey.Value)
            Sleep(GetRandomDelay(100))
            SendEvent("{Click 402, 415}")
            PinataCount++
            TotalItemsUsed++
            UpdateStatsDisplay()
            updateStatus("Used Piñata (" PinataCount " total)")
            Sleep(GetRandomDelay(ItemUseDelay))
        }
        if (myGui["UseGiantJar"].Value && giantJarKey.Value) {
            Send(giantJarKey.Value)
            Sleep(GetRandomDelay(100))
            SendEvent("{Click 402, 415}")
            GiantJarCount++
            TotalItemsUsed++
            UpdateStatsDisplay()
            updateStatus("Used Giant Jar (" GiantJarCount " total)")
            Sleep(GetRandomDelay(ItemUseDelay))
        }
        if (myGui["UsePartyBox"].Value && partyBoxKey.Value) {
            Send(partyBoxKey.Value)
            Sleep(GetRandomDelay(100))
            SendEvent("{Click 402, 415}")
            PartyBoxCount++
            TotalItemsUsed++
            UpdateStatsDisplay()
            updateStatus("Used Party Box (" PartyBoxCount " total)")
            Sleep(GetRandomDelay(ItemUseDelay))
        }
        if (myGui["UseComet"].Value && cometKey.Value) {
            Send(cometKey.Value)
            Sleep(GetRandomDelay(100))
            SendEvent("{Click 402, 415}")
            CometCount++
            TotalItemsUsed++
            UpdateStatsDisplay()
            updateStatus("Used Comet (" CometCount " total)")
            Sleep(GetRandomDelay(ItemUseDelay))
        }
        if (myGui["UseItemJar"].Value && itemJarKey.Value) {
            Send(itemJarKey.Value)
            Sleep(GetRandomDelay(100))
            SendEvent("{Click 402, 415}")
            ItemJarCount++
            TotalItemsUsed++
            UpdateStatsDisplay()
            updateStatus("Used Item Jar (" ItemJarCount " total)")
            Sleep(GetRandomDelay(ItemUseDelay))
        }
        if (myGui["UseLuckyBlock"].Value && luckyBlockKey.Value) {
            Send(luckyBlockKey.Value)
            Sleep(GetRandomDelay(100))
            SendEvent("{Click 402, 415}")
            LuckyBlockCount++
            TotalItemsUsed++
            UpdateStatsDisplay()
            updateStatus("Used Lucky Block (" LuckyBlockCount " total)")
            Sleep(GetRandomDelay(ItemUseDelay))
        }
        if (myGui["UseMagnetFlag"].Value && magnetFlagKey.Value) {
            Send(magnetFlagKey.Value)
            Sleep(GetRandomDelay(100))
            SendEvent("{Click 402, 415}")
            MagnetFlagCount++
            TotalItemsUsed++
            UpdateStatsDisplay()
            updateStatus("Used Magnet Flag (" MagnetFlagCount " total)")
            Sleep(GetRandomDelay(ItemUseDelay))
        }
        
        LoopsCompleted++
        UpdateStatsDisplay()
    }
}

checkLeaderBoard() {
    updateStatus("Checking if the leaderboard is open...")
    
    static colors := [
        "0x121215",
        "0x49494B",
        "0x000000",
        "0x262B34",
        "0x192030",
        "0x272931",
        "0x1A1A1D",
        "0x323438",
        "0x222428"
    ]
    
    foundColor := false
    maxAttempts := 5
    
    Loop maxAttempts {
        updateStatus("Leaderboard Check Attempt " . A_Index . "/" . maxAttempts)
        
        for color in colors {
            try {
                currentColor := PixelGetColor(547, 71)
                colorDiff := Abs((currentColor & 0xFF) - (color & 0xFF)) + 
                           Abs(((currentColor >> 8) & 0xFF) - ((color >> 8) & 0xFF)) + 
                           Abs(((currentColor >> 16) & 0xFF) - ((color >> 16) & 0xFF))
                
                if (colorDiff < 90) {
                    updateStatus("Leaderboard found - closing")
                    foundColor := true
                    SendEvent("{Click 488, 69}")
                    Sleep(100)
                    return true
                }
            } catch {
                continue
            }
        }
        
        Sleep(200)
    }
    
    if (!foundColor) {
        Sleep(100)
    }
    
    return true
}

checkChatBoard() {
    updateStatus("Checking if the Chat is open...")
    
    static colors := [
        "0xF1F1F3"
    ]
    
    foundColor := false
    maxAttempts := 5
    
    Loop maxAttempts {
        updateStatus("Chat Check Attempt " . A_Index . "/" . maxAttempts)
        
        for color in colors {
            try {
                currentColor := PixelGetColor(130, 30)
                colorDiff := Abs((currentColor & 0xFF) - (color & 0xFF)) + 
                           Abs(((currentColor >> 8) & 0xFF) - ((color >> 8) & 0xFF)) + 
                           Abs(((currentColor >> 16) & 0xFF) - ((color >> 16) & 0xFF))
                
                if (colorDiff < 90) {
                    updateStatus("Chat is open - closing")
                    foundColor := true
                    SendEvent("{Click 130, 30}")
                    return true
                }
            } catch {
                continue
            }
        }
    }
    
    if (!foundColor) {
        Sleep(100)
    }
    
    return true
}

findTeleportButton() {
    updateStatus("Clicking the teleport button...")
    try {
        if (ImageSearch(&foundX, &foundY, 2, 109, 144, 435, "*15 Teleport.png")) {
            SendEvent("{Click " foundX ", " foundY "}")
            Sleep(500)
            return
        }
    }
}

checkForPlayerFullyLoaded() {
    updateStatus("Waiting for player to load...")
    Loop {
        SendEvent("{Click 400, 300}")
        Sleep(500)
        try {
            if ImageSearch(&foundX, &foundY, 0, 0, 800, 600, "*30 inventory.png") {
                Sleep(500)
                SendEvent("{Click 488, 69}")
                Sleep(100)
                return true
            }
        }
        Sleep(500)
    }
}

TogglePause(*) {
    global IsPaused := !IsPaused
    if (IsPaused) {
        updateStatus("PAUSED - Press F4 to resume")
        LogAction("Macro paused by user")
    } else {
        updateStatus("Resumed")
        LogAction("Macro resumed by user")
    }
}

; Hotkeys
F1:: StartMacro()
F4:: TogglePause()
F5:: Reload()
F3:: ExitApp()