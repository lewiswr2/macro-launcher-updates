﻿#Requires AutoHotkey v2.0
#SingleInstance Force
#Warn All, Off
SetWorkingDir A_ScriptDir
CoordMode "Mouse", "Client"
CoordMode "Pixel", "Client"
SetMouseDelay 10
#NoTrayIcon

; Include OCR library
#Include <OCR>

; Font file paths
TIMES_NEW_ROMAN := A_ScriptDir "\Assets\TimesNewRoman.ttf"
TIMES_NEW_ROMAN_INVERTED := A_ScriptDir "\Assets\TimesNewRoman-Inverted.ttf"
FREDOKA_ONE_REGULAR := A_ScriptDir "\Assets\FredokaOne-Regular.ttf"
SOURCE_SANS_PRO_BOLD := A_ScriptDir "\Assets\SourceSansPro-Bold.ttf"

; Set tray icon
TraySetIcon(A_ScriptDir "\Icon.png")

class WorldState {
    static currentWorld := "Normal"
    static UpdateWorld(world) {
        this.currentWorld := world
        updateStatus("World changed to: " world)
    }
}

mainGui := ""
lvStatus := ""
useCheck := ""
combineCheck := ""
combineOneRadio := ""
combineAllRadio := ""
useCrystalCheck := ""
useTechCheck := ""
useVoidCheck := ""
useFantasyCheck := ""
useMvpCheck := ""
combineCrystalCheck := ""
combineTechCheck := ""
combineVoidCheck := ""
combineFantasyCheck := ""
combineSecretCheck := ""
combineMvpCheck := ""
combineTreasureCheck := ""
SCRIPT_TITLE := "PS99 Key Master"
isRunning := false
isPaused := false
USE_MODE := true
COMBINE_MODE := true
COMBINE_ALL := false
USE_CRYSTAL := true
USE_TECH := true
USE_VOID := true
USE_FANTASY := true
USE_MVP := true
COMBINE_CRYSTAL := true
COMBINE_TECH := true
COMBINE_VOID := true
COMBINE_FANTASY := true
COMBINE_SECRET := true
COMBINE_MVP := true
COMBINE_TREASURE := true

tabControl := ""
currentTab := 1

class PixelLocations {
    static hoverboard := Map("Start", [29, 372], "End", [29, 372], "Colour", "0xFF911A", "Tolerance", 2)
    static inventoryopen := Map("Start", [51, 119], "End", [51, 119], "Colour", "0xFF2F92", "Tolerance", 2)
    static inventoryButton := Map("Start", [390, 508], "End", [390, 508], "Colour", "0x15DCCE", "Tolerance", 2)
    static itemsBoostsLine := Map("Start", [301, 152], "End", [301, 152], "Colour", "0xE9E9E9", "Tolerance", 2)
    static searchCursor := Map("Start", [620, 118], "End", [650, 118], "Colour", "0xAFAFAF", "Tolerance", 2)
    static searchTerm := Map("Start", [693, 98], "End", [703, 114], "Colour", "0x1E1E1E", "Tolerance", 2)
    static stupidCat := Map("Start", [301, 152], "End", [301, 152], "Colour", "0xFFB232", "Tolerance", 2)
    static leftBorder := Map("Start", [160, 366], "End", [160, 366], "Colour", "0x2A2B31", "Tolerance", 2)
    static successBorder := Map("Start", [169, 366], "End", [169, 366], "Colour", "0x2A2B31", "Tolerance", 2)
    static item1 := Map("Start", [109, 235], "End", [109, 235], "Colour", "0xFCFDFD", "Tolerance", 2)
    static crystalKey := Map("Start", [109, 235], "End", [109, 235], "Colour", "0x5EE2F6", "Tolerance", 5)
    static techKey := Map("Start", [109, 235], "End", [109, 235], "Colour", "0x4A84AE", "Tolerance", 5)
    static voidKey := Map("Start", [109, 235], "End", [109, 235], "Colour", "0xDDE8F7", "Tolerance", 5)
    static fantasyKey := Map("Start", [136, 251], "End", [109, 235], "Colour", "0xFFACBB", "Tolerance", 5)
    static secretKey := Map("Start", [109, 235], "End", [109, 235], "Colour", "0xA686ED", "Tolerance", 5)
    static mvpKey := Map("Start", [138, 246], "End", [138, 246], "Colour", "0xD9BCFF", "Tolerance", 5)
    static treasureKey := Map("Start", [109, 235], "End", [109, 235], "Colour", "0xBAD2F1", "Tolerance", 5)
}

class ClickLocations {
    static searchBox := [540, 107]
    static inventoryIcon := [49, 95]
    static itemsTab := [26, 205]
    static item1 := [109, 235]
    static combineOne := [287, 409]
    static combineAll := [521, 426]
    static combineSuccess := [397, 409]
    static closeButton := [746, 109]
}

saveSettings() {
    IniWrite(USE_MODE ? 1 : 0, A_ScriptDir "\settings.ini", "Settings", "UseMode")
    IniWrite(COMBINE_MODE ? 1 : 0, A_ScriptDir "\settings.ini", "Settings", "CombineMode")
    IniWrite(COMBINE_ALL ? 1 : 0, A_ScriptDir "\settings.ini", "Settings", "CombineAll")
    IniWrite(USE_CRYSTAL ? 1 : 0, A_ScriptDir "\settings.ini", "Settings", "UseCrystal")
    IniWrite(USE_TECH ? 1 : 0, A_ScriptDir "\settings.ini", "Settings", "UseTech")
    IniWrite(USE_VOID ? 1 : 0, A_ScriptDir "\settings.ini", "Settings", "UseVoid")
    IniWrite(USE_FANTASY ? 1 : 0, A_ScriptDir "\settings.ini", "Settings", "UseFantasy")
    IniWrite(USE_MVP ? 1 : 0, A_ScriptDir "\settings.ini", "Settings", "UseMvp")
    IniWrite(COMBINE_CRYSTAL ? 1 : 0, A_ScriptDir "\settings.ini", "Settings", "CombineCrystal")
    IniWrite(COMBINE_TECH ? 1 : 0, A_ScriptDir "\settings.ini", "Settings", "CombineTech")
    IniWrite(COMBINE_VOID ? 1 : 0, A_ScriptDir "\settings.ini", "Settings", "CombineVoid")
    IniWrite(COMBINE_FANTASY ? 1 : 0, A_ScriptDir "\settings.ini", "Settings", "CombineFantasy")
    IniWrite(COMBINE_SECRET ? 1 : 0, A_ScriptDir "\settings.ini", "Settings", "CombineSecret")
    IniWrite(COMBINE_MVP ? 1 : 0, A_ScriptDir "\settings.ini", "Settings", "CombineMvp")
    IniWrite(COMBINE_TREASURE ? 1 : 0, A_ScriptDir "\settings.ini", "Settings", "CombineTreasure")
    updateStatus("Settings saved")
}

loadSettings() {
    global USE_MODE := IniRead(A_ScriptDir "\settings.ini", "Settings", "UseMode", 1)
    global COMBINE_MODE := IniRead(A_ScriptDir "\settings.ini", "Settings", "CombineMode", 1)
    global COMBINE_ALL := IniRead(A_ScriptDir "\settings.ini", "Settings", "CombineAll", 0)
    global USE_CRYSTAL := IniRead(A_ScriptDir "\settings.ini", "Settings", "UseCrystal", 1)
    global USE_TECH := IniRead(A_ScriptDir "\settings.ini", "Settings", "UseTech", 1)
    global USE_VOID := IniRead(A_ScriptDir "\settings.ini", "Settings", "UseVoid", 1)
    global USE_FANTASY := IniRead(A_ScriptDir "\settings.ini", "Settings", "UseFantasy", 1)
    global USE_MVP := IniRead(A_ScriptDir "\settings.ini", "Settings", "UseMvp", 1)
    global COMBINE_CRYSTAL := IniRead(A_ScriptDir "\settings.ini", "Settings", "CombineCrystal", 1)
    global COMBINE_TECH := IniRead(A_ScriptDir "\settings.ini", "Settings", "CombineTech", 1)
    global COMBINE_VOID := IniRead(A_ScriptDir "\settings.ini", "Settings", "CombineVoid", 1)
    global COMBINE_FANTASY := IniRead(A_ScriptDir "\settings.ini", "Settings", "CombineFantasy", 1)
    global COMBINE_SECRET := IniRead(A_ScriptDir "\settings.ini", "Settings", "CombineSecret", 1)
    global COMBINE_MVP := IniRead(A_ScriptDir "\settings.ini", "Settings", "CombineMvp", 1)
    global COMBINE_TREASURE := IniRead(A_ScriptDir "\settings.ini", "Settings", "CombineTreasure", 1)
}

applySettingsToGui() {
    useCheck.Value := USE_MODE
    combineCheck.Value := COMBINE_MODE
    combineOneRadio.Value := !COMBINE_ALL
    combineAllRadio.Value := COMBINE_ALL
    useCrystalCheck.Value := USE_CRYSTAL
    useTechCheck.Value := USE_TECH
    useVoidCheck.Value := USE_VOID
    useFantasyCheck.Value := USE_FANTASY
    useMvpCheck.Value := USE_MVP
    combineCrystalCheck.Value := COMBINE_CRYSTAL
    combineTechCheck.Value := COMBINE_TECH
    combineVoidCheck.Value := COMBINE_VOID
    combineFantasyCheck.Value := COMBINE_FANTASY
    combineSecretCheck.Value := COMBINE_SECRET
    combineMvpCheck.Value := COMBINE_MVP
    combineTreasureCheck.Value := COMBINE_TREASURE
}

replaceRobloxFonts() {
    try {
        robloxPath := WinGetProcessPath("ahk_exe RobloxPlayerBeta.exe")
        robloxFontPath := StrReplace(robloxPath, "RobloxPlayerBeta.exe", "") "content\fonts\"
        FileCopy TIMES_NEW_ROMAN, robloxFontPath "FredokaOne-Regular.ttf", true
        FileCopy TIMES_NEW_ROMAN, robloxFontPath "SourceSansPro-Bold.ttf", true
        return true
    } catch {
        return false
    }
}

changeToDefaultFont(*) {
    try {
        robloxPath := WinGetProcessPath("ahk_exe RobloxPlayerBeta.exe")
        robloxFontPath := StrReplace(robloxPath, "RobloxPlayerBeta.exe", "") "content\fonts\"
        FileCopy FREDOKA_ONE_REGULAR, robloxFontPath "FredokaOne-Regular.ttf", true
        FileCopy SOURCE_SANS_PRO_BOLD, robloxFontPath "SourceSansPro-Bold.ttf", true
        return true
    } catch {
        return false
    }
}

ReplaceFontsOnStartup() {
    if WinExist("ahk_exe RobloxPlayerBeta.exe") {
        if replaceRobloxFonts() {
            updateStatus("Fonts changed successfully - Reload Roblox for changes")
            MsgBox("Fonts changed successfully!`n`nPlease reload Roblox to see the changes for better OCR accuracy.", "Font Replacement Success", "Iconi T3")
        } else {
            updateStatus("Failed to replace fonts")
            MsgBox("Failed to replace fonts. Make sure:`n• Roblox is running`n• Font files exist in Assets folder`n• You have write permissions", "Font Replacement Failed", "Icon! T5")
        }
    } else {
        updateStatus("Roblox not running - skipping font replacement")
        MsgBox("Roblox is not running!`n`nPlease start Roblox first, then restart this macro to apply font changes.", "Roblox Not Found", "Icon! T5")
    }
}

createGui() {
    global COLORS := {
        headerBg: "0xd29922",
        headerText: "0x13171d",
        bg: "0x0a0e14",
        cardBg: "0x161b22",
        cardHover: "0x1c2128",
        text: "0xFFFFFF",
        textDim: "0xB0B0B0",
        border: "0x3A3A3A",
        success: "0x4CAF50",
        warning: "0xFFC107",
        danger: "0xF44336",
        buttonBg: "0xF5E6D3",
        buttonText: "0x000000"
    }
    
    mainGui := Gui("+AlwaysOnTop -MaximizeBox")
    mainGui.MarginX := 0
    mainGui.MarginY := 0
    mainGui.BackColor := COLORS.bg
    mainGui.Title := SCRIPT_TITLE
    
    screenWidth := A_ScreenWidth
    screenHeight := A_ScreenHeight
    guiWidth := 350
    guiHeight := 590
    xPos := screenWidth - guiWidth - 20
    yPos := 20

    ; Header with progress bar background
    mainGui.Add("Progress", "x0 y0 w" guiWidth " h100 Background" SubStr(COLORS.headerBg, 3))
    
    mainGui.SetFont("s20 bold c" SubStr(COLORS.headerText, 3), "Segoe UI")
    mainGui.Add("Text", "x0 y25 w" guiWidth " Center BackgroundTrans", "✨ PS99 Key Master")
    mainGui.SetFont("s10 c" SubStr(COLORS.headerText, 3))
    mainGui.Add("Text", "x0 y60 w" guiWidth " Center BackgroundTrans", "Automate key combining and usage")
    
    ; Status Section
    mainGui.SetFont("s9 bold c" COLORS.text, "Segoe UI")
    mainGui.AddGroupBox("x8 y110 w" guiWidth-16 " h80 Background" COLORS.cardBg " c" COLORS.textDim, "✅ Status")
    mainGui.SetFont("s9 norm c" COLORS.text, "Segoe UI")
    global lvStatus := mainGui.AddListView("x20 y130 r1 w" guiWidth-40 " -Hdr Background" COLORS.cardBg " c" COLORS.text, ["Action"])
    lvStatus.Add(, "Waiting to start - Start in Normal World")
    lvStatus.ModifyCol(1, guiWidth-65)
    
    ; What to Do Section
    mainGui.SetFont("s9 bold c" COLORS.text, "Segoe UI")
    mainGui.AddGroupBox("x8 y200 w" guiWidth-16 " h120 Background" COLORS.cardBg " c" COLORS.textDim, "🛠️ What to Do")
    mainGui.SetFont("s9 norm c" COLORS.text, "Segoe UI")
    global combineCheck := mainGui.AddCheckbox("x20 y225 c" COLORS.text " Checked", "Combine Keys")
    global useCheck := mainGui.AddCheckbox("x20 y250 c" COLORS.text " Checked", "Use Keys")
    
    global combineOneRadio := mainGui.AddRadio("x40 y275 c" COLORS.text " Checked", "Combine One (Better for Mastery)")
    global combineAllRadio := mainGui.AddRadio("x40 y295 c" COLORS.text, "Combine All (Faster)")

    ; Tab Control
    global tabControl := mainGui.Add("Tab3", "x8 y330 w" guiWidth-16 " h190 c" COLORS.textDim, ["Keys to Combine", "Keys to Use"])
    
    tabControl.UseTab(1)
    mainGui.SetFont("s9 bold c" COLORS.text, "Segoe UI")
    mainGui.AddGroupBox("x14 y360 w" guiWidth-30 " h150 Background" COLORS.cardBg " c" COLORS.textDim, "🧩 Keys to Combine")
    mainGui.SetFont("s9 norm c" COLORS.text, "Segoe UI")
    
    global combineCrystalCheck := mainGui.AddCheckbox("x20 y380 c" COLORS.text " Checked", "Crystal Keys")
    global combineTechCheck := mainGui.AddCheckbox("x180 y380 c" COLORS.text " Checked", "Tech Keys")
    global combineVoidCheck := mainGui.AddCheckbox("x20 y405 c" COLORS.text " Checked", "Void Keys")
    global combineFantasyCheck := mainGui.AddCheckbox("x180 y405 c" COLORS.text " Checked", "Fantasy Keys")
    global combineSecretCheck := mainGui.AddCheckbox("x180 y430 c" COLORS.text " Checked", "Secret Keys")
    global combineMvpCheck := mainGui.AddCheckbox("x20 y430 c" COLORS.text " Checked", "MVP Keys")
    global combineTreasureCheck := mainGui.AddCheckbox("x20 y455 c" COLORS.text " Checked", "Treasure Hideout Keys")

    tabControl.UseTab(2)
    mainGui.SetFont("s9 bold c" COLORS.text, "Segoe UI")
    mainGui.AddGroupBox("x14 y360 w" guiWidth-30 " h150 Background" COLORS.cardBg " c" COLORS.textDim, "🔑 Keys to Use")
    mainGui.SetFont("s9 norm c" COLORS.text, "Segoe UI")
    
    global useCrystalCheck := mainGui.AddCheckbox("x20 y380 c" COLORS.text " Checked", "Crystal Keys")
    global useTechCheck := mainGui.AddCheckbox("x180 y380 c" COLORS.text " Checked", "Tech Keys")
    global useVoidCheck := mainGui.AddCheckbox("x20 y405 c" COLORS.text " Checked", "Void Keys")
    global useFantasyCheck := mainGui.AddCheckbox("x180 y405 c" COLORS.text " Checked", "Fantasy Keys")
    global useMvpCheck := mainGui.AddCheckbox("x20 y430 c" COLORS.text " Checked", "MVP Keys")
    
    tabControl.UseTab()
    
    ; Buttons
    mainGui.SetFont("s9 norm c" COLORS.text, "Segoe UI")
    btnStart := mainGui.AddButton("x13 y535 w78 h45", "▶️ Start`n(F1)")
    btnPause := mainGui.AddButton("x95 y535 w78 h45", "⏸️ Pause`n(F2)")
    btnReload := mainGui.AddButton("x177 y535 w78 h45", "🔄 Reload`n(F5)")
    btnStop := mainGui.AddButton("x259 y535 w78 h45", "⏹️ Stop`n(F3)")
    
    useCheck.OnEvent("Click", updateModes)
    combineCheck.OnEvent("Click", updateModes)
    combineOneRadio.OnEvent("Click", updateCombineMode)
    combineAllRadio.OnEvent("Click", updateCombineMode)
    useCrystalCheck.OnEvent("Click", updateKeyOptions)
    useTechCheck.OnEvent("Click", updateKeyOptions)
    useVoidCheck.OnEvent("Click", updateKeyOptions)
    useFantasyCheck.OnEvent("Click", updateKeyOptions)
    useMvpCheck.OnEvent("Click", updateKeyOptions)
    combineCrystalCheck.OnEvent("Click", updateCombineOptions)
    combineTechCheck.OnEvent("Click", updateCombineOptions)
    combineVoidCheck.OnEvent("Click", updateCombineOptions)
    combineFantasyCheck.OnEvent("Click", updateCombineOptions)
    combineSecretCheck.OnEvent("Click", updateCombineOptions)
    combineMvpCheck.OnEvent("Click", updateCombineOptions)
    combineTreasureCheck.OnEvent("Click", updateCombineOptions)
    btnStart.OnEvent("Click", startMacro)
    btnReload.OnEvent("Click", (*) => Reload())
    btnStop.OnEvent("Click", (*) => ExitApp())
    
    mainGui.Show("w" guiWidth " h" guiHeight " x" xPos " y" yPos)
    
    updateModes()
}

togglePause(*) {
    global isPaused := !isPaused
    if (isPaused) {
        updateStatus("Script Paused")
        Suspend true
        Pause -1
    } else {
        Suspend false
        Pause
        updateStatus("Script Resumed")
    }
}

isInventoryOpen() {
    updateStatus("Checking if your inventory is open")
    loc := PixelLocations.inventoryopen
    return PixelSearch(&foundX, &foundY, loc["Start"][1], loc["Start"][2], loc["End"][1], loc["End"][2], loc["Colour"], loc["Tolerance"])
}

isInventoryButtonCentered() {
    updateStatus("Looking for your inventory button")
    loc := PixelLocations.inventoryButton
    return PixelSearch(&foundX, &foundY, loc["Start"][1], loc["Start"][2], loc["End"][1], loc["End"][2], loc["Colour"], loc["Tolerance"])
}

isItemsTabOpen() {
    updateStatus("Checking if the items tab is open")
    loc := PixelLocations.itemsBoostsLine
    return PixelSearch(&foundX, &foundY, loc["Start"][1], loc["Start"][2], loc["End"][1], loc["End"][2], loc["Colour"], loc["Tolerance"])
}

isInventorySearchBoxSelected() {
    updateStatus("Checking if its typing in the search box")
    
    ; Use OCR to find "Search" text - only in Roblox window
    try {
        WinActivate "ahk_exe RobloxPlayerBeta.exe"
        Sleep 50
        WinGetPos(&winX, &winY, &winWidth, &winHeight, "ahk_exe RobloxPlayerBeta.exe")
        
        ocrObject := OCR.FromRect(winX + 400, winY + 80, winX + 700, winY + 140, , 1)
        if InStr(ocrObject.Text, "Search") {
            updateStatus("Search box found via OCR")
            return true
        }
    } catch {
        ; Fallback to pixel search if OCR fails
        loc := PixelLocations.searchCursor
        return PixelSearch(&foundX, &foundY, loc["Start"][1], loc["Start"][2], loc["End"][1], loc["End"][2], loc["Colour"], loc["Tolerance"])
    }
    
    ; Try pixel search as backup
    loc := PixelLocations.searchCursor
    return PixelSearch(&foundX, &foundY, loc["Start"][1], loc["Start"][2], loc["End"][1], loc["End"][2], loc["Colour"], loc["Tolerance"])
}

isSearchTermEntered() {
    updateStatus("Checking if text is entered correctly")
    loc := PixelLocations.searchTerm
    return PixelSearch(&foundX, &foundY, loc["Start"][1], loc["Start"][2], loc["End"][1], loc["End"][2], loc["Colour"], loc["Tolerance"])
}

isCombineWindowOpen() {
    try {
        ; Get the Roblox window position
        WinGetPos(&winX, &winY, , , "ahk_exe RobloxPlayerBeta.exe")
        
        ; Calculate absolute screen coordinates for the OCR region
        searchX1 := winX + 200
        searchY1 := winY + 190
        searchX2 := winX + 338
        searchY2 := winY + 242
        
        ; Perform OCR on the specified region
        ocrResult := OCR.FromRect(searchX1, searchY1, searchX2, searchY2, , 1)
        
        ; Check if "create" is found in the OCR text (case insensitive)
        if InStr(ocrResult.Text, "create", false) {
            updateStatus("Combine window detected - found 'create'")
            return true
        }
        
        updateStatus("Combine window not detected")
        return false
    } catch {
        updateStatus("OCR check failed for combine window")
        return false
    }
}

isSuccessWindowOpen() {
    updateStatus("Checking if the success window is open")
    loc := PixelLocations.successBorder
    return PixelSearch(&foundX, &foundY, loc["Start"][1], loc["Start"][2], loc["End"][1], loc["End"][2], loc["Colour"], loc["Tolerance"])
}

hasItem() {
    updateStatus("Checking if you have any upper halves")
    loc := PixelLocations.item1
    return !PixelSearch(&foundX, &foundY, loc["Start"][1], loc["Start"][2], loc["End"][1], loc["End"][2], loc["Colour"], loc["Tolerance"])
}

isItemKey() {
    updateStatus("Checking if the item is a upper half")
    loc1 := PixelLocations.crystalKey
    if PixelSearch(&foundX, &foundY, loc1["Start"][1], loc1["Start"][2], loc1["End"][1], loc1["End"][2], loc1["Colour"], loc1["Tolerance"]) {
        updateStatus("Found Crystal Key: Upper Half")
        return true
    }

    loc2 := PixelLocations.techKey
    if PixelSearch(&foundX, &foundY, loc2["Start"][1], loc2["Start"][2], loc2["End"][1], loc2["End"][2], loc2["Colour"], loc2["Tolerance"]) {
        updateStatus("Found Tech Key: Upper Half")
        return true
    }

    loc3 := PixelLocations.voidKey
    if PixelSearch(&foundX, &foundY, loc3["Start"][1], loc3["Start"][2], loc3["End"][1], loc3["End"][2], loc3["Colour"], loc3["Tolerance"]) {
        updateStatus("Found Void Key: Upper Half")
        return true
    }

    loc4 := PixelLocations.fantasyKey
    if PixelSearch(&foundX, &foundY, loc4["Start"][1], loc4["Start"][2], loc4["End"][1], loc4["End"][2], loc4["Colour"], loc4["Tolerance"]) {
        updateStatus("Found Fantasy Key: Upper Half")
        return true
    }
        
    loc5 := PixelLocations.mvpKey
    if PixelSearch(&foundX, &foundY, loc5["Start"][1], loc5["Start"][2], loc5["End"][1], loc5["End"][2], loc5["Colour"], loc5["Tolerance"]) {
        updateStatus("Found MVP Key: Upper Half")
        return true
    }
        
    loc6 := PixelLocations.secretKey
    if PixelSearch(&foundX, &foundY, loc6["Start"][1], loc6["Start"][2], loc6["End"][1], loc6["End"][2], loc6["Colour"], loc6["Tolerance"]) {
        updateStatus("Found Secret Key: Upper Half")
        return true
    }

    loc7 := PixelLocations.treasureKey
    if PixelSearch(&foundX, &foundY, loc7["Start"][1], loc7["Start"][2], loc7["End"][1], loc7["End"][2], loc7["Colour"], loc7["Tolerance"]) {
        updateStatus("Found Treasure Key: Upper Half")
        return true
    }

    updateStatus("No upper half found")
    return false
}

openInventoryMenu() {
    updateStatus("Opening your inventory")
    if isInventoryOpen() {
        updateStatus("Inventory is already open")
        return true
    }

    if isInventoryButtonCentered() {
        updateStatus("Clicking inventory button")
        SendEvent "{f}"
        Sleep 200
    }

    Loop 5 {
        updateStatus("Waiting for inventory to open: Attempt " A_Index)
        if isInventoryOpen() {
            updateStatus("Inventory opened successfully")
            return true
        }
        Sleep 20
    }
    updateStatus("Failed to open inventory")
    return false
}

openItemsTab() {
    updateStatus("Opening the items tab")
    Loop 50 {
        if isInventoryOpen() {
            updateStatus("Inventory is open, proceeding to items tab")
            break
        }
        Sleep 20
    }

    if isItemsTabOpen() {
        updateStatus("Items tab is already open")
        return true
    }

    Loop 5 {
        updateStatus("Clicking items tab: Attempt " A_Index)
        SendEvent "{Click, " ClickLocations.itemsTab[1] ", " ClickLocations.itemsTab[2] ", 1}"
        Sleep 50

        Loop 10 {
            if isItemsTabOpen() {
                updateStatus("Items tab opened successfully")
                return true
            }
            Sleep 20
        }
    }
    updateStatus("Failed to open items tab")
    return false
}

clickInventorySearchBox() {
    updateStatus("Clicking the search box at 638, 107")
    
    ; Clear any previous search first
    if isSearchTermEntered() {
        updateStatus("Clearing previous search")
        SendEvent "{Click, " ClickLocations.inventoryIcon[1] ", " ClickLocations.inventoryIcon[2] ", 1}"
        Sleep 100
    }
    
    ; Direct click at the specified coordinates
    SendEvent "{Click, 638, 107, 1}"
    
    updateStatus("Search box clicked")
    return true
}

enterSearchTerm(Item) {
    updateStatus("Entering the search: " Item)
    
    ; Just type the item directly
    SendText Item
    Sleep 150
    
    updateStatus("Search entered")
    return true
}

leftClickUseItem() {
    updateStatus("Attempting to click item")
    Loop 10 {
        if isItemKey() {
            updateStatus("Clicking on the halve")
            SendEvent "{Click, " ClickLocations.item1[1] ", " ClickLocations.item1[2] ", 1}"
            Sleep 150
            Loop 20 {
                Sleep 20
                if !isInventoryOpen() {
                    updateStatus("Half clicked successfully")
                    return true
                }
            }
        }
        else {
            updateStatus("No upperhalf found to use")
            return false
        }
    }
    updateStatus("Failed to click the half")
    return false
}

leftClickCombineOne() {
    updateStatus("Processing combine window")
    Loop 20 {
        if isCombineWindowOpen() {
            updateStatus("Combine window detected")
            break
        }
        Sleep 100
    }

    Loop 20 {
        if (COMBINE_ALL) {
            updateStatus("Clicking the 'Combine All' button")
            Sleep 150
            SendEvent "{Click, " ClickLocations.combineAll[1] ", " ClickLocations.combineAll[2] ", 1}"
        } else {
            updateStatus("Clicking the 'Combine One' button")
            Sleep 150
            SendEvent "{Click, " ClickLocations.combineOne[1] ", " ClickLocations.combineOne[2] ", 1}"
        }
        Sleep 150
        if !isCombineWindowOpen() {
            updateStatus("Key combined successfully")
            break
        }
    }
}

leftClickCombineSuccess() {
    updateStatus("Processing success window")
    Loop 20 {
        if isSuccessWindowOpen() {
            updateStatus("Success window detected")
            break
        }
        Sleep 100
    }

    Loop 1 {
        updateStatus("Clicking the ok button")
        SendEvent "{Click, " ClickLocations.combineSuccess[1] ", " ClickLocations.combineSuccess[2] ", 1}"
        Sleep 50
        if !isSuccessWindowOpen() {
            updateStatus("Clicked the ok button")
            break
        }
    }

    Loop 20 {
        Sleep 50
        if isInventoryOpen() {
            updateStatus("Returned to the inventory")
            break
        }
    }
}

closeInventoryMenu() {
    updateStatus("Closing the inventory menu")
    if !isInventoryOpen() {
        updateStatus("Inventory is already closed")
        return
    }

    Loop 10 {
        updateStatus("Clicking close button: Attempt " A_Index)
        SendEvent "{Click, " ClickLocations.closeButton[1] ", " ClickLocations.closeButton[2] ", 1}"
        Sleep 50
        if !isInventoryOpen() {
            updateStatus("Inventory is closed successfully")
            break
        }
    }
}

useItem(itemToUse) {
    updateStatus("Processing item: " itemToUse)
    if !openInventoryMenu() {
        updateStatus("Failed to open your inventory for " itemToUse)
        return true
    }

    Sleep 50

    if !openItemsTab() {
        updateStatus("Failed to open the items tab for " itemToUse)
        return true
    }

    Sleep 50

    if !clickInventorySearchBox() {
        updateStatus("Failed to click the search box for " itemToUse)
        return true
    }

    Sleep 50

    if !enterSearchTerm(itemToUse) {
        updateStatus("Failed to enter the search for " itemToUse)
        return true
    }

    Sleep 50

    if !hasItem() {
        updateStatus("No " itemToUse " found")
        return false
    }

    updateStatus("Found " itemToUse ", attempting to use")
    if leftClickUseItem() {
        updateStatus("Successfully clicked " itemToUse)
        Sleep 200
        leftClickCombineOne()
        Sleep 200
        leftClickCombineSuccess()
    }
    return true
}

enableCombineControls(enable) {
    if (enable) {
        updateStatus("Enabling combine controls")
        combineCrystalCheck.Enabled := true
        combineTechCheck.Enabled := true
        combineVoidCheck.Enabled := true
        combineFantasyCheck.Enabled := true
        combineSecretCheck.Enabled := true
        combineMvpCheck.Enabled := true
        combineTreasureCheck.Enabled := true
        
        combineCrystalCheck.Opt("c" COLORS.text)
        combineTechCheck.Opt("c" COLORS.text)
        combineVoidCheck.Opt("c" COLORS.text)
        combineFantasyCheck.Opt("c" COLORS.text)
        combineSecretCheck.Opt("c" COLORS.text)
        combineMvpCheck.Opt("c" COLORS.text)
        combineTreasureCheck.Opt("c" COLORS.text)
    } else {
        updateStatus("Disabling combine controls")
        combineCrystalCheck.Enabled := false
        combineTechCheck.Enabled := false
        combineVoidCheck.Enabled := false
        combineFantasyCheck.Enabled := false
        combineSecretCheck.Enabled := false
        combineMvpCheck.Enabled := false
        combineTreasureCheck.Enabled := false
        
        combineCrystalCheck.Opt("c" COLORS.textDim)
        combineTechCheck.Opt("c" COLORS.textDim)
        combineVoidCheck.Opt("c" COLORS.textDim)
        combineFantasyCheck.Opt("c" COLORS.textDim)
        combineSecretCheck.Opt("c" COLORS.textDim)
        combineMvpCheck.Opt("c" COLORS.textDim)
        combineTreasureCheck.Opt("c" COLORS.textDim)
    }
}

enableUseControls(enable) {
    if (enable) {
        updateStatus("Enabling use controls")
        useCrystalCheck.Enabled := true
        useTechCheck.Enabled := true
        useVoidCheck.Enabled := true
        useFantasyCheck.Enabled := true
        useMvpCheck.Enabled := true
        
        useCrystalCheck.Opt("c" COLORS.text)
        useTechCheck.Opt("c" COLORS.text)
        useVoidCheck.Opt("c" COLORS.text)
        useFantasyCheck.Opt("c" COLORS.text)
        useMvpCheck.Opt("c" COLORS.text)
    } else {
        updateStatus("Disabling use controls")
        useCrystalCheck.Enabled := false
        useTechCheck.Enabled := false
        useVoidCheck.Enabled := false
        useFantasyCheck.Enabled := false
        useMvpCheck.Enabled := false
        
        useCrystalCheck.Opt("c" COLORS.textDim)
        useTechCheck.Opt("c" COLORS.textDim)
        useVoidCheck.Opt("c" COLORS.textDim)
        useFantasyCheck.Opt("c" COLORS.textDim)
        useMvpCheck.Opt("c" COLORS.textDim)
    }
}

updateModes(*) {
    global USE_MODE := useCheck.Value
    global COMBINE_MODE := combineCheck.Value
    
    updateStatus("Updating mode settings")
    enableCombineControls(COMBINE_MODE)
    enableUseControls(USE_MODE)
    
    if (COMBINE_MODE) {
        combineOneRadio.Enabled := true
        combineAllRadio.Enabled := true
    } else {
        combineOneRadio.Enabled := false
        combineAllRadio.Enabled := false
    }
    
    saveSettings()
}

; Modify updateCombineMode to save settings
updateCombineMode(*) {
    global COMBINE_ALL := combineAllRadio.Value
    updateStatus("Combine mode updated: " (COMBINE_ALL ? "Combine All" : "Combine One"))
    saveSettings()
}

; Modify updateKeyOptions to save settings
updateKeyOptions(*) {
    global USE_CRYSTAL := useCrystalCheck.Value
    global USE_TECH := useTechCheck.Value
    global USE_VOID := useVoidCheck.Value
    global USE_FANTASY := useFantasyCheck.Value
    global USE_MVP := useMvpCheck.Value
    updateStatus("Key usage options updated")
    saveSettings()
}

; Modify updateCombineOptions to save settings
updateCombineOptions(*) {
    global COMBINE_CRYSTAL := combineCrystalCheck.Value
    global COMBINE_TECH := combineTechCheck.Value
    global COMBINE_VOID := combineVoidCheck.Value
    global COMBINE_FANTASY := combineFantasyCheck.Value
    global COMBINE_SECRET := combineSecretCheck.Value
    global COMBINE_MVP := combineMvpCheck.Value
    global COMBINE_TREASURE := combineTreasureCheck.Value
    updateStatus("Key combine options updated")
    saveSettings()
}

updateStatus(status) {
    lvStatus.Modify(1,, status)
}

doCombineKeys() {
    keysToProcess := []
    
    if (COMBINE_CRYSTAL) {
        keysToProcess.Push("Crystal Key: Upper Half")
    }
    
    if (COMBINE_TECH) {
        keysToProcess.Push("Tech Key: Upper Half")
    }
    
    if (COMBINE_VOID) {
        keysToProcess.Push("Void Key: Upper Half")
    }
    
    if (COMBINE_FANTASY) {
        keysToProcess.Push("Fantasy Key: Upper Half")
    }
    
    if (COMBINE_SECRET) {
        keysToProcess.Push("Secret Key: Upper Half")
    }

    if (COMBINE_MVP) {
        keysToProcess.Push("MVP Key: Upper Half")
    }
    
    if (COMBINE_TREASURE) {
        keysToProcess.Push("Treasure Hideout Key: Upper Half")
    }
    
    for key in keysToProcess {
        updateStatus("Starting to combine: " . key)
        Loop {
            hasItem := useItem(key)
            if !hasItem {
                updateStatus("No more " . key . " to combine")
                break
            }
            Sleep 200
        }
    }
    closeInventoryMenu()
}

GoToTechWorld() {
    WorldState.UpdateWorld("Tech")
    updateStatus("Moving to Tech World - Looking for teleport button")
    Sleep 100
    findTeleportButton()
    updateStatus("Selecting Tech World from the teleport menu")
    Sleep 750
    SendEvent "{Click 20, 275}"
    Sleep 750
    updateStatus("Confirming world selection")
    SendEvent "{Click 285, 415}"
    Sleep 1000
    updateStatus("Waiting for Tech World to load")
    checkForPlayerFullyLoaded()
    checkLeaderBoard()
    checkChatBoard()
}

GoToVoidWorld() {
    WorldState.UpdateWorld("Void")
    updateStatus("Moving to Void World - Looking for teleport button")
    Sleep 100
    findTeleportButton()
    updateStatus("Selecting Void World from the teleport menu")
    Sleep 750
    SendEvent "{Click 20, 320}"
    Sleep 750
    updateStatus("Confirming world selection")
    SendEvent "{Click 285, 415}"
    Sleep 1000
    updateStatus("Waiting for Void World to load")
    checkForPlayerFullyLoaded()
    checkLeaderBoard()
    checkChatBoard()
}

GoToFantasyWorld() {
    WorldState.UpdateWorld("Fantasy")
    updateStatus("Moving to Fantasy World - Looking for teleport button")
    Sleep 100
    findTeleportButton()
    updateStatus("Selecting Fantasy World from the teleport menu")
    Sleep 750
    SendEvent "{Click 20, 365}"
    Sleep 750
    updateStatus("Confirming world selection")
    SendEvent "{Click 285, 415}"
    Sleep 1000
    updateStatus("Waiting for Fantasy World to load")
    checkForPlayerFullyLoaded()
    checkLeaderBoard()
    checkChatBoard()
}

DoCrystalKeys() {
    if (!USE_MODE || !USE_CRYSTAL)
        return
    updateStatus("Using Crystal Keys")
    Sleep 500
    findTeleportButton()
    updateStatus("Using Crystal Keys")
    Sleep 750
    SendEvent "{Click 480, 193}"
    Sleep 750
    checkForPlayerFullyTp()
    updateStatus("Using Crystal Keys")
    Sleep 100
    Send "{q down}"
    Sleep 203
    Send "{q up}"
    Sleep 297
    Send "{w down}"
    Sleep 593
    Send "{w up}"
    Sleep 282
    Send "{a down}"
    Sleep 2175
    Send "{a up}"
    Sleep 550
    Send "{s down}"
    Sleep 313
    Send "{s up}"
    findGreenButton()
    updateStatus("Using Crystal Keys")
    findTeleportButton()
    updateStatus("Using Crystal Keys")
    Sleep 750
    SendEvent "{Click 133, 224}"
}

DoMvpKeys() {
    if (!USE_MODE || !USE_MVP)
        return
    updateStatus("Using MVP Keys")
    Send "{q down}"
    Sleep 1
    Send "{q up}"
    Sleep 300
    Send "{w down}"
    Sleep 1
    Send "{w up}"
    checkForPlayerFullyTpSpawn()
    updateStatus("Using MVP Keys")
    Sleep 500
    findTeleportButton()
    updateStatus("Using MVP Keys")
    Sleep 750
    SendEvent "{Click 480, 193}"
    Sleep 750
    checkForPlayerFullyTp()
    updateStatus("Using MVP Keys")
    Sleep 100
    Send "{q down}"
    Sleep 203
    Send "{q up}"
    Sleep 297
    Send "{w down}"
    Sleep 593
    Send "{w up}"
    Sleep 282
    Send "{a down}"
    Sleep 2175
    Send "{a up}"
    Sleep 550
    Send "{w down}"
    Sleep 313
    Send "{w up}"
    findGreenButton()
}

DoTechKeys() {
    if (!USE_MODE || !USE_TECH)
        return
    updateStatus("Using Tech Keys")
    Sleep 500
    findTeleportButton()
    updateStatus("Using Tech Keys")
    Sleep 750
    SendEvent "{Click 480, 193}"
    Sleep 750
    checkForPlayerFullyTp()
    updateStatus("Using Tech Keys")
    Sleep 100
    findTeleportButton()
    updateStatus("Using Tech Keys")
    Sleep 750
    SendEvent "{Click 135, 217}"
    Sleep 750
    checkForPlayerFullyTpSpawn()
    updateStatus("Using Tech Keys")
    Sleep 100
    Send "{q down}"
    Sleep 94
    Send "{q up}"
    Sleep 609
    Send "{w down}"
    Sleep 94
    Send "{w up}"
    Sleep 468
    Send "{a down}"
    Sleep 516
    Send "{a up}"
    Sleep 313
    Send "{w down}"
    Sleep 796
    Send "{w up}"
    Sleep 125
    Send "{a down}"
    Sleep 1900
    Send "{a up}"
    Sleep 188
    Send "{w down}"
    Sleep 1250
    Send "{w up}"
    Send "{space down}"
    Sleep 150
    Send "{space up}"
    Send "{w down}"
    Sleep 275
    Send "{w up}"
    findGreenButton()
}

DoVoidKeys() {
    if (!USE_MODE || !USE_VOID)
        return
    updateStatus("Using Void Keys")
    Sleep 500
    findTeleportButton()
    Sleep 750
    SendEvent "{Click 135, 217}"
    Sleep 2500
    checkForPlayerFullyLoaded()
    updateStatus("Using Void Keys")
    checkLeaderBoard()
    updateStatus("Using Void Keys")
    checkChatBoard()
    updateStatus("Using Void Keys")
    findTeleportButton()
    updateStatus("Using Void Keys")
    Sleep 750
    SendEvent "{Click 20, 320}"
    Sleep 750
    SendEvent "{Click 285, 415}"
    Sleep 3000
    SendEvent "{Click 0, 0}"
    checkForPlayerFullyLoaded()
    updateStatus("Using Void Keys")
    Send "{Q}"
    Sleep 500
    Send "{D down}"
    Sleep 500
    Send "{D up}"
    SendEvent "{Click 746, 101}"
    Sleep 500
    Send "{S down}"
    Sleep 1050
    Send "{S up}"
    Sleep 300
    Send "{A down}"
    Sleep 550
    Send "{A up}"
    SendEvent "{Click 746, 101}"
    findGreenButton()
}

DoFantasyKeys() {
    if (!USE_MODE || !USE_FANTASY)
        return
    updateStatus("Using Fantasy Keys")
    Sleep 500
    findTeleportButton()
    Sleep 750
    SendEvent "{Click 480, 193}"
    Sleep 750
    checkForPlayerFullyTp()
    updateStatus("Using Fantasy Keys")
    Sleep 100
    findTeleportButton()
    updateStatus("Using Fantasy Keys")
    Sleep 750
    SendEvent "{Click 135, 217}"
    Sleep 750
    checkForPlayerFullyTpSpawn()
    updateStatus("Using Fantasy Keys")
    Sleep 500
    Send "{q down}"
    Sleep 203
    Send "{q up}"
    Sleep 300
    Send "{w down}"
    Sleep 650
    Send "{w up}"
    Sleep 300
    Send "{a down}"
    Sleep 3550
    Send "{a up}"
    Sleep 300
    Send "{w down}"
    Sleep 700
    Send "{w up}"
    Sleep 300
    Send "{a down}"
    Sleep 450
    Send "{a up}"
    Sleep 300
    Send "{w down}"
    Sleep 450
    Send "{w up}"
    findGreenButton()
}

safeClick(x, y) {
    MouseMove x-1, y-1
    Sleep 50
    MouseMove x+1, y+1
    Sleep 50
    MouseMove x, y
    Sleep 50
    SendEvent "{Click " x ", " y "}"
    Sleep 50
}

checkForPlayerFullyLoaded() {
    updateStatus("Waiting for player to load into the game...")
    Loop {
        SendEvent "{Click 400, 300}"
        Sleep 150
        
        try {
            if (ImageSearch(&foundX, &foundY, 0, 0, 800, 600, "*30 " A_ScriptDir "\Images\inventory.png")) {
                Sleep(100)
                return true
            }
        }
        Sleep 100
    }
}

checkForPlayerFullyTp() {
    updateStatus("Waiting for player to teleport to the area...")
    findTeleportButton()
    updateStatus("Waiting for player to teleport to the area...")
    
    Loop {
        if (PixelSearch(&foundX, &foundY, 517, 190, 517, 190, "0x82FBFA", 30)) {
            SendEvent "{Click 747, 104}"
            return
        }
        Sleep 500
    }
}

checkForPlayerFullyTpSpawn() {
    updateStatus("Waiting for player to teleport to the spawn area...")
    findTeleportButton()
    updateStatus("Waiting for player to teleport to the spawn area...")

    Loop {
        SendEvent "{Click 400, 50}"
        if (PixelSearch(&foundX, &foundY, 176, 196, 176, 196, "0x7FF8FA", 30)) {
            SendEvent "{Click 747, 104}"
            return
        }
        Sleep 500
    }
}

findGreenButton() {
    SendEvent "{Click 400, 42}"
    Sleep 200
    
    WinActivate "ahk_exe RobloxPlayerBeta.exe"
    Sleep 50
    WinGetPos(&winX, &winY, &winWidth, &winHeight, "ahk_exe RobloxPlayerBeta.exe")
    
    okFound := false
    while (!okFound) {
        Send "{e down}"
        Sleep 50
        Send "{e up}"
        Sleep 50
        
        MouseMove 0, 0
        Sleep 100
        
        MouseMove -100, -100
        Sleep 100
        
        try {
            ocrObject := OCR.FromRect(winX, winY, winX + winWidth, winY + winHeight, , 1)
            if InStr(ocrObject.Text, "You need a") {
                updateStatus("Chest is locked - no more keys available")
                SendEvent "{Click 400, 400}"
                okFound := true
                break
            }
        }
        
        ; Check for OK button - only in Roblox window
        try {
            ocrObject := OCR.FromRect(winX + 297, winY + 382, winX + 496, winY + 455, , 1)
            if InStr(ocrObject.Text, "Ok") {
                for item in ocrObject.Words {
                    if InStr(item.Text, "Ok") {
                        centerX := item.x + (item.w / 2)
                        centerY := item.y + (item.h / 2)
                        SendEvent "{Click " centerX ", " centerY "}"
                        Sleep 1000
                        okFound := true
                        break
                    }
                }
                continue
            }
        }
        
        ; Fallback to pixel search for green button
        x := 627
        while (x >= 161) {
            try {
                if (PixelSearch(&foundX, &foundY, x, 400, x, 470, "0x97FA17", 30)) {
                    SendEvent "{Click " foundX ", " foundY "}"
                    Sleep 100
                    
                    Loop 2 {
                        clickX := foundX - (A_Index * 10)
                        SendEvent "{Click " clickX ", " foundY "}"
                        Sleep 100
                    }
                    Sleep 5000
                    break
                }
            }
            x--
        }
        
        Sleep 200
    }
}

findTeleportButton() {
    updateStatus("Clicking the teleport button...")
    try {
        if (ImageSearch(&foundX, &foundY, 0, 0, 800, 600, "*15 " A_ScriptDir "\Images\Teleport.png")) {
            SendEvent "{Click " foundX ", " foundY "}"
            Sleep 500
            return true
        }
    }
    return false
}

useKeysInSequence() {
    updateStatus("Starting the key usage sequence...")
    
    if (USE_CRYSTAL) {
        DoCrystalKeys()
    }
    
    if (USE_MVP) {
        DoMvpKeys()
    }
    
    if (USE_TECH) {
        updateStatus("Moving to the Tech World...")
        GoToTechWorld()
        DoTechKeys()
    }
    
    if (USE_VOID) {
        updateStatus("Moving to the Void World...")
        GoToVoidWorld()
        DoVoidKeys()
    }
    
    if (USE_FANTASY) {
        updateStatus("Moving to the Fantasy World...")
        GoToFantasyWorld()
        DoFantasyKeys()
    }
}

checkLeaderBoard() {
    updateStatus("Checking if the leaderboard is open...")
    
    static colors := [
        "0x121215",
        "0x49494B",
        "0x000000",
        "0x262B34",
        "0x192030",
        "0x272931",
        "0x1A1A1D",
        "0x323438",
        "0x222428"
    ]
    
    foundColor := false
    maxAttempts := 5
    
    Loop maxAttempts {
        updateStatus("Leaderboard Check Attempt " . A_Index . "/" . maxAttempts)
        
        for color in colors {
            try {
                currentColor := PixelGetColor(547, 71)
                colorDiff := Abs((currentColor & 0xFF) - (color & 0xFF)) + 
                           Abs(((currentColor >> 8) & 0xFF) - ((color >> 8) & 0xFF)) + 
                           Abs(((currentColor >> 16) & 0xFF) - ((color >> 16) & 0xFF))
                
                if (colorDiff < 90) {
                    updateStatus("Leaderboard found - closing")
                    foundColor := true
                    SendEvent "{Click 487, 74}"
                    Sleep 100
                    return true
                }
            } catch {
                continue
            }
        }
        
        Sleep 200
    }
    
    if (!foundColor) {
        Sleep 100
    }
    
    return true
}

checkChatBoard() {
    updateStatus("Checking if the Chat is open...")
    
    static colors := [
        "0xF1F1F3"
    ]
    
    foundColor := false
    maxAttempts := 5
    
    Loop maxAttempts {
        updateStatus("Chat Check Attempt " . A_Index . "/" . maxAttempts)
        
        for color in colors {
            try {
                currentColor := PixelGetColor(130, 30)
                colorDiff := Abs((currentColor & 0xFF) - (color & 0xFF)) + 
                           Abs(((currentColor >> 8) & 0xFF) - ((color >> 8) & 0xFF)) + 
                           Abs(((currentColor >> 16) & 0xFF) - ((color >> 16) & 0xFF))
                
                if (colorDiff < 90) {
                    updateStatus("Chat is open - closing")
                    foundColor := true
                    SendEvent "{Click 130, 30}"
                    return true
                }
            } catch {
                continue
            }
        }
    }
    
    if (!foundColor) {
        Sleep 100
    }
    
    return true
}
    
startMacro(*) {
    if (isRunning)
        return
    global isRunning := true
    updateStatus("Starting macro...")
    
    try {
        updateStatus("Activating Roblox...")
        WinActivate "ahk_exe RobloxPlayerBeta.exe"
        Sleep 500
        
        updateStatus("Resizing window...")
        try {
            windowHandle := WinGetID("ahk_exe RobloxPlayerBeta.exe")
            WinRestore windowHandle
            WinMove , , 800, 600, windowHandle
        } catch {
            updateStatus("Error: Couldn't resize window")
            return
        }
        
        Sleep 1000
        WinActivate "ahk_exe RobloxPlayerBeta.exe"
        Sleep 500
        checkLeaderBoard()
        checkChatBoard()

        if (COMBINE_MODE) {
            updateStatus("Combining Keys...")
            doCombineKeys()
        }

        if (USE_MODE)
            useKeysInSequence()
    } catch as err {
        updateStatus("Error: " err.Message)
    }
    
    global isRunning := false
    updateStatus("Macro completed!")
}

F1::startMacro()
F2::togglePause()
F5::Reload()
F4::testOCR()
F3::ExitApp()

; Initialize
loadSettings()
createGui()
applySettingsToGui()
updateModes()
ReplaceFontsOnStartup()

testOCR(*) {
    try {
        ; Activate Roblox window first
        WinActivate "ahk_exe RobloxPlayerBeta.exe"
        Sleep 200
        
        ; Get the Roblox window position and size
        WinGetPos(&winX, &winY, &winWidth, &winHeight, "ahk_exe RobloxPlayerBeta.exe")
        
        ; Capture only the Roblox window
        ocrResult := OCR.FromRect(winX, winY, winX + winWidth, winY + winHeight, , 1)
        
        ; Build output text
        outputText := "=== OCR Text Found in Roblox Window ===`n`n"
        outputText .= ocrResult.Text
        
        ; Show results in message box
        MsgBox(outputText, "OCR Screen Test", "T30")
        
        ; Also update status
        updateStatus("OCR Test Complete - Found " ocrResult.Words.Length " words")
        
    } catch as err {
        MsgBox("OCR Error: " err.Message, "OCR Test Failed", "Icon!")
        updateStatus("OCR Test Failed: " err.Message)
    }
}

OnExit((*) => saveSettings())