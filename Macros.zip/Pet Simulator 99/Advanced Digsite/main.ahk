﻿#Requires AutoHotkey v2.0
#SingleInstance Force
CoordMode "Mouse", "Client"
CoordMode "Pixel", "Client"
SetMouseDelay 10
SendMode "Input"
#NoTrayIcon
#Include <OCR>

#Include "%A_ScriptDir%\Modules"
#Include "Teleport.ahk"
#Include "Zones.ahk"

global COLORS := {
    headerBg: "0xd29922",
    headerText: "0x13171d",
    bg: "0x0a0e14",
    cardBg: "0x161b22",
    cardHover: "0x1c2128",
    text: "0xFFFFFF",
    textDim: "0xB0B0B0",
    border: "0x3A3A3A",
    success: "0x4CAF50",
    warning: "0xFFC107",
    danger: "0xF44336",
    buttonBg: "0xF5E6D3",
    buttonText: "0x000000"
}

MACRO_TITLE := "Advanced Digsite"
MACRO_VERSION := "0.2.0"

LOG_FOLDER := A_ScriptDir "\Logs\"
SETTINGS_INI := A_ScriptDir "\Settings.ini"

LOG_DATE := FormatTime(A_Now, "yyyyMMdd")
ONE_SECOND := 1000

MACRO_ICON := A_WorkingDir . "\Assets\Bucket_O_Magic.ico"
DISCORD_ICON := A_WorkingDir . "\Assets\Discord.ico"
GITHUB_ICON := A_WorkingDir . "\Assets\Github.ico"
PSYCHO_HATCHER_ICON := A_WorkingDir . "\Assets\PsychoHatcher.ico"
PAUSE_ICON := A_WorkingDir . "\Assets\PlayPause.ico"
FONT_ICON := A_WorkingDir . "\Assets\Font.ico"

FREDOKA_ONE_REGULAR := A_ScriptDir "\Assets\FredokaOne-Regular.ttf"
SOURCE_SANS_PRO_BOLD := A_ScriptDir "\Assets\SourceSansPro-Bold.ttf"

EXCLUSION_GUI := A_ScriptDir "\Assets\GUI.png"

DIGSITE_HOLES := [
    [2, 12], [2, 7], [2, 2],
    [3, 14], [3, 9], [3, 4],
    [4, 11], [4, 6],
    [5, 13], [5, 8], [5, 3],
    [6, 15], [6, 10], [6, 5],
    [7, 12], [7, 7], [7, 2],
    [8, 14], [8, 9], [8, 4],
    [9, 11], [9, 6],
    [10, 13], [10, 8], [10, 3],
    [11, 15], [11, 10], [11, 5],
    [12, 12], [12, 7], [12, 2],
    [13, 14], [13, 9], [13, 4],
    [14, 11], [14, 6],
    [15, 13], [15, 8], [15, 3]
]

DIG_POSITION := [403, 344]
TILE_SIZE := 467
DIG_TIME := getSetting("DigTime")
OPTIMISED_DIG_PATTERN := getSetting("OptimisedPattern")

START_MACRO := getSetting("startMacroKey")
PAUSE_MACRO := getSetting("pauseMacroKey")
EXIT_MACRO := getSetting("exitMacroKey")

runMacro()

runMacro() {
    activateRoblox()
    completeInitialisationTasks()
    displayMainGui()
}

digHole(hole) {
    changeCameraToOverheadView()

    txtHole.Value := hole[1] ", " hole[2]
    txtAction.Value := "Moving to the dig location"

    moveDirection("a", 70)
    moveDirection("w", 350)

    directionToMoveX := hole[1] <= 8 ? "a" : "d"
    tilesToMoveX := hole[1] <= 8 ? 8 - hole[1] : hole[1] - 9
    distanceToMove := (tilesToMoveX * TILE_SIZE) + (TILE_SIZE / 2) + 20
    moveDirection(directionToMoveX, distanceToMove)

    distanceToMove := ((hole[2] - 1) * TILE_SIZE) + 375
    moveDirection("w", distanceToMove)

    timeToDigUntil := A_TickCount + DIG_TIME

    createExclusionGuis()

    activateRoblox()

    txtAction.Value := "Digging a hole"

    Loop {
        SendEvent "{Click, " DIG_POSITION[1] ", " DIG_POSITION[2] ", 1, Down}"

        if isBedrock()
            break
        if isShovelNotStrongEnough()
            break
        findChest()
        findMagicPool()

        if A_TickCount > timeToDigUntil {
            Click "Up"
            findChest()
            break
        }
    }
    Click "Up"

    destroyExclusionGuis()

    txtHole.Value := "-"

    checkForDisconnection()

    exitDigsite()
    enterDigsite()
}

isShovelNotStrongEnough() {
    searchArea := [263, 407, 534, 433]
    textColours := [
        "0xFF0000", "0xBA0D11", "0xF90101"
    ]

    activateRoblox()

    for index, colour in textColours {
        if PixelSearch(&foundX, &foundY, searchArea[1], searchArea[2], searchArea[3], searchArea[4], colour, 5)
            return true
        Sleep 10
    }

    return false
}

isBedrock() {
    bedrockColours := [
        "0x0D1216", "0x1C2A24", "0x202D28", "0x121A1B"
    ]
    bedrockChecksRequired := 5
    
    activateRoblox()

    bedrockChecks := 0

    Loop 5 {
        for index, colour in bedrockColours {
            if PixelSearch(&foundX, &foundY, DIG_POSITION[1], DIG_POSITION[2], DIG_POSITION[1], DIG_POSITION[2], colour, 20) 
                bedrockChecks++
            if bedrockChecks >= bedrockChecksRequired
                return true
            Sleep 10
        }
    }

    return false
}

findChest() {
    searchArea := [2, 2, 805, 596]

    chestColours := [
        "0x8F7EEC", "0xFE3E00", "0xEC7600", "0xEA7C10",
        "0xE87200", "0xCD0C00", "0xE200E8", "0xC36FF7",
        "0xCC2CE8", "0xCB5400", "0xB777EA", "0xB766EE",
        "0x92139B", "0x8A1296", "0xE500FF", "0xE57000",
        "0x2371DF", "0x1A43AD", "0x0E27B1", "0xFF4200",
        "0xD18F00", "0xE48800", "0xF79408", "0xE28700",
        "0xE68900", "0x8C1D00", "0xBD0000", "0xEA6F00",
        "0xE71924", "0xFC9A1F", "0xEC4F00", "0xFDD600",
        "0xEE0E00", "0xD8BA00", "0xF8DC1E", "0xFFD60A",
        "0xDAB300", "0xC079FA", "0x830E8B", "0xD500D5",
        "0x9D84FB", "0x735EE6", "0x183CA9", "0x4C89EA",
        "0xDB5900"
    ]

    activateRoblox()

    for index, colour in chestColours {
        if PixelSearch(&foundX, &foundY, searchArea[1], searchArea[2], searchArea[3], searchArea[4], colour, 5) {
            Click "Up"
            Loop 5 {
                if PixelSearch(&foundX, &foundY, searchArea[1], searchArea[2], searchArea[3], searchArea[4], colour, 5) {
                    SendEvent "{Click down, " foundX ", " foundY ", 1}"
                    Sleep 10
                }
                else {
                    SendEvent "{Space down}"
                    Sleep 100
                    SendEvent "{Space up}"
                    break
                }
            }
        }
    }
}

createExclusionGuis() {
    WinGetPos &X, &Y, &W, &H, "ahk_exe RobloxPlayerBeta.exe"

    global exclusionGui := Gui("+AlwaysOnTop +E0x20 +LastFound -Caption")
    exclusionGui.BackColor := "0x000000"

    exclusionGui.Show("x" X - 2 " y" Y + 24 " w" W " h" H)
    exclusionGui.AddPicture("w800 h600 BackgroundTrans", EXCLUSION_GUI)

    WinSetTransColor((exclusionGui.BackColor := "0x000000") ' 255', exclusionGui)
}

destroyExclusionGuis() {
    exclusionGui.Destroy()
}

findMagicPool() {
    searchArea := [200, 150, 600, 450]
    poolColours := [
        "0xC000FF", "0xBF00FF", "0xB800FF"
    ]

    activateRoblox()

    Loop 10 {
        magicPool := false
        for index, colour in poolColours {
            if PixelSearch(&foundX, &foundY, searchArea[1], searchArea[2], searchArea[3], searchArea[4], colour, 2) {

                txtAction.Value := "Collecting magic"

                magicPool := true
                SendEvent "{Click, " DIG_POSITION[1] ", " DIG_POSITION[2] ", 1, Up}"

                Loop 10 {
                    SendEvent "{Click, " foundX ", " foundY ", 1}"

                    if isOutOfBuckets()
                        return

                    SendEvent "{Click, " foundX ", " foundY ", 1, Down}"
                    Sleep 5000
                    SendEvent "{Click, " foundX ", " foundY ", 1, Up}"

                    if !PixelSearch(&foundX, &foundY, searchArea[1], searchArea[2], searchArea[3], searchArea[4], colour, 2)
                        break
                }
            }
        }
        if !magicPool
            break
    }
}

isOutOfBuckets() {
    searchArea := [263, 407, 534, 433]
    textColours := [
        "0xFF0000", "0xBA0D11", "0xF90101"
    ]

    activateRoblox()

    for index, colour in textColours {
        if PixelSearch(&foundX, &foundY, searchArea[1], searchArea[2], searchArea[3], searchArea[4], colour, 5)
            return true
        Sleep 10
    }

    return false
}

changeCameraToOverheadView() {
    activateRoblox()
    Sleep 500
    zoomCameraOut(2000)

    Sleep 100

    SendEvent "{Click, " 600 ", " 400 ", 1}"
    Sleep 200
    SendEvent "{RButton down}"
    Sleep 200
    MouseMove 0, 30, 50, "R"
    Sleep 200 
    Loop 4 {
        DllCall("mouse_event", "uint", 0x0001, "int", -1, "int", 0, "uint", 0, "ptr", 0)
        Sleep 1
    }
    Sleep 200
    SendEvent "{RButton up}"
    Sleep 200

    scrolls := getSetting("ZoomInScrolls")
    scrollCameraIn(scrolls)

    return true
}

isViewOverhead() {
    activateRoblox()
    ground := [174, 270]    
    return PixelSearch(&foundX, &foundY, ground[1], ground[2], ground[1], ground[2], "0x68D0FF", 2)
}  

scrollCameraOut(scrolls) {
    Loop scrolls {
        Send "{WheelDown}"
        Sleep 50
    }
}

zoomCameraOut(time) {
    Send "{o down}"
    Sleep time
    Send "{o up}"
}

scrollCameraIn(scrolls) {
    Loop scrolls {
        Send "{WheelUp}"
        Sleep 50       
    }
}

exitDigsite() {
    txtAction.Value := "Exiting the digsite"

    homeButton := [400, 519]

    Loop 100 {
        clickX := homeButton[1] + Random(-3, 3)
        clickY := homeButton[2] + Random(-3, 3)
        SendEvent "{Click, " clickX ", " clickY ", 1}"
        Sleep 10
        if isTransitionScreen()
            break
    }

    Loop 100 {
        if !isTransitionScreen()
            break
        Sleep 10
    }
}

enterDigsite() {
    txtAction.Value := "Entering the digsite"

    transitionSuccess := false

    activateRoblox()

    moveDirection("s", 800)

    Loop 100 {
        if isTransitionScreen() {
            transitionSuccess := true
            break
        }
        moveDirection("w", 25)
        moveDirection("s", 100)    
        Sleep 10
    }

    if !transitionSuccess {
        reconnectClient()
        startMacro()
    }

    Loop 100 {
        if isHomeButtonVisible()
            break
        Sleep 10
    }
}

displayMainGui() {
    global mainGui := Gui("+AlwaysOnTop")
    mainGui.Title := MACRO_TITLE " v" MACRO_VERSION
    mainGui.BackColor := SubStr(COLORS.bg, 3)
    mainGui.MarginX := 0
    mainGui.MarginY := 0
    
    mainGui.Add("Progress", "x0 y0 w450 h120 Background" SubStr(COLORS.headerBg, 3))
    
    mainGui.SetFont("s24 bold c" SubStr(COLORS.headerText, 3), "Segoe UI")
    mainGui.Add("Text", "x0 y30 w450 Center BackgroundTrans", "⛏️ " MACRO_TITLE)
    mainGui.SetFont("s9 c" SubStr(COLORS.headerText, 3))
    mainGui.Add("Text", "x0 y75 w450 Center BackgroundTrans", "Digging Macro v" MACRO_VERSION)

    closeBtn := mainGui.Add("Text", "x415 y10 w25 h25 BackgroundTrans c" SubStr(COLORS.headerText, 3) " Center", "✕")
    closeBtn.SetFont("s14 bold")
    closeBtn.OnEvent("Click", (*) => ExitApp())

    mainGui.Add("Progress", "x0 y120 w450 h280 Background" SubStr(COLORS.bg, 3))

    mainGui.SetFont("s10 c" SubStr(COLORS.text, 3), "Segoe UI")

    yPos := 145

    statusBox := mainGui.Add("Progress", "x20 y" yPos " w410 h160 Background" SubStr(COLORS.cardBg, 3))
    
    mainGui.SetFont("s11 bold c" SubStr(COLORS.text, 3))
    mainGui.Add("Text", "x35 y" yPos+15 " BackgroundTrans", "📊 Macro Status")
    
    mainGui.SetFont("s9 c" SubStr(COLORS.textDim, 3))
    mainGui.Add("Text", "x35 y" yPos+50 " BackgroundTrans", "Current Action")
    mainGui.SetFont("s10 c" SubStr(COLORS.text, 3))
    global txtAction := mainGui.Add("Text", "x35 y" yPos+70 " w370 BackgroundTrans", "Ready to start...")

    mainGui.SetFont("s9 c" SubStr(COLORS.textDim, 3))
    mainGui.Add("Text", "x35 y" yPos+95 " BackgroundTrans", "Dig Pattern")
    mainGui.SetFont("s10 c" SubStr(COLORS.text, 3))
    patternType := OPTIMISED_DIG_PATTERN == "true" ? "🎯 Optimised" : "🎲 Random"
    global txtPattern := mainGui.Add("Text", "x35 y" yPos+115 " w370 BackgroundTrans", patternType)

    mainGui.SetFont("s9 c" SubStr(COLORS.textDim, 3))
    mainGui.Add("Text", "x240 y" yPos+50 " BackgroundTrans", "Current Hole")
    mainGui.SetFont("s10 c" SubStr(COLORS.text, 3))
    global txtHole := mainGui.Add("Text", "x240 y" yPos+70 " w165 BackgroundTrans", "-")

    yPos += 175

    btnStart := mainGui.Add("Button", "x20 y" yPos " w130 h40", "▶️ Start")
    btnStart.SetFont("s10 bold")
    btnStart.OnEvent("Click", startMacro)

    btnPause := mainGui.Add("Button", "x160 y" yPos " w130 h40", "⏸️ Pause")
    btnPause.SetFont("s10 bold")
    btnPause.OnEvent("Click", pauseMacro)

    btnReload := mainGui.Add("Button", "x300 y" yPos " w130 h40", "🔄 Reload")
    btnReload.SetFont("s10 bold")
    btnReload.OnEvent("Click", reloadMacro)

    yPos += 50

    mainGui.Show("w450 h" yPos+30)
}

startMacro(*) {
    activateRoblox()
    closeLeaderboard()
    closeChatLog()
    travelToAdvancedDigsite()

    Loop {
        if OPTIMISED_DIG_PATTERN == "true" {
            for index, hole in DIGSITE_HOLES {
                digHole(hole)
            }            
        } else {
            hole := [Random(1, 16), Random(1, 16)]
            digHole(hole)
        }
    }
}

pauseMacro(*) {
    Pause -1
}

reloadMacro(*) {
    Reload
}

openSettings(*) {
    Run "notepad.exe " SETTINGS_INI
}

exitMacro(*) {
    ExitApp
}

openWiki(*) {
    Run "https://github.com/waktool/AdvancedDigsite/wiki"
}

openDiscord(*) {
    Run "https://discord.gg/psychohatcher"
}

openWebsite(*) {
    Run "https://psychohatcher.com/"
}

getSetting(keyName) {
    return IniRead(SETTINGS_INI, "Settings", keyName)
}

completeInitialisationTasks() {
    updateTrayIcon()
    resizeRobloxWindow()
    defineHotKeys()
}

updateTrayIcon() {
    TraySetIcon MACRO_ICON
}

defineHotKeys() {
    HotKey START_MACRO, startMacro
    HotKey PAUSE_MACRO, pauseMacro
    HotKey EXIT_MACRO, exitMacro
}

resizeRobloxWindow() {
    WinActivate "ahk_exe RobloxPlayerBeta.exe"
    WinRestore "ahk_exe RobloxPlayerBeta.exe"
    
    WinMove , , A_ScreenWidth, 600, "ahk_exe RobloxPlayerBeta.exe"
    WinMove , , 800, 600, "ahk_exe RobloxPlayerBeta.exe"
}

activateRoblox() {
    try {
        WinActivate "ahk_exe RobloxPlayerBeta.exe"
    } catch {
        MsgBox "Roblox window not found."
        ExitApp
    }
    Sleep 100
}

isTransitionScreen() {
    pixel := [43, 63]
    colour := "0x070711"
    return PixelSearch(&foundX, &foundY, pixel[1], pixel[2], pixel[1], pixel[2], colour, 2)
}

isHomeButtonVisible() {
    pixel := [401, 495]
    colour := "0xDB1B05"
    return PixelSearch(&foundX, &foundY, pixel[1], pixel[2], pixel[1], pixel[2], colour, 2)
}

checkForDisconnection() {
    txtAction.Value := "Checking connection"

    isDisconnected := checkForDisconnect()
    if (isDisconnected == true) {
        reconnectClient()
        startMacro()
    }

    txtAction.Value := "-"
}

reconnectClient(*) {
    txtAction.Value := "Reconnecting"
    reconnectTime := getSetting("ReconnectTimeSeconds")

    privateServerLinkCode := getSetting("PrivateServerLinkCode")
    if (privateServerLinkCode == "") {
        try Run "roblox://placeID=8737899170"
    }
    else {
        try Run "roblox://placeID=8737899170&linkCode=" privateServerLinkCode
    }

    Loop reconnectTime {
        txtAction.Value := "Reconnecting (" A_Index "/" reconnectTime ")"
        Sleep ONE_SECOND
    }
}

checkForDisconnect() {
    disconnectedWindowStart := [201, 175]
    disconnectedWindowSize := [398, 248]

    activateRoblox()
    
    ocrTextResult := getOcrResult(disconnectedWindowStart, disconnectedWindowSize, 20)
    
    return (regexMatch(ocrTextResult.Text, "Disconnected|Reconnect|Leave"))
}

travelToAdvancedDigsite() {
    txtAction.Value := "Travelling to the digsite"

    travelToWorld1()
    closeLeaderboard()
    travelToZone80()
    moveToAdvancedDigsite()
}

travelToWorld1() {
    if getWorld() != 1
        teleportToWorld(1)
}

travelToZone80() {
    Loop 500 {
        alreadyInZone := teleportToZone(80)
        if alreadyInZone
            teleportToZone(81)
        else
            break
        Sleep 10
    }
}

moveToAdvancedDigsite() {
    Sleep 500

    transitionSuccess := false

    equipHoverboard("a")
    moveDirection("a", 800)

    Sleep 200

    moveDirection("w", 1500)

    Loop 100 {
        if isTransitionScreen() {
            transitionSuccess := true
            break
        }
        moveDirection("w", 25)
        Sleep 10
    }

    if !transitionSuccess {
        reconnectClient()
        startMacro()
    }

    Loop 100 {
        if isHomeButtonVisible()
            break
        Sleep 10
    }
}

moveDirection(key, milliseconds) {
    Send "{" key " down}"
    Sleep milliseconds
    Send "{" key " up}"
}

equipHoverboard(direction) {
    SendEvent "{q}"
    Sleep 2000

    Loop 3 {
        moveDirection(direction, 10)
        Sleep 10
    }

    Sleep 2000
}

unequipHoverboard() {
    SendEvent "{q}"
}

closeChatLog() {
    pixel := [81, 24]
    colour := "0xFFFFFF"
    
    if PixelSearch(&foundX, &foundY, pixel[1], pixel[2], pixel[1], pixel[2], colour, 2)
        SendEvent "{Click, " foundX ", " foundY ", 1}"
}

changeToDefaultFont(*) {
    robloxFontPath := StrReplace(WinGetProcessPath("ahk_exe RobloxPlayerBeta.exe"), "RobloxPlayerBeta.exe", "") "content\fonts\"
    FileCopy FREDOKA_ONE_REGULAR, robloxFontPath "FredokaOne-Regular.ttf", true
    FileCopy SOURCE_SANS_PRO_BOLD, robloxFontPath "SourceSansPro-Bold.ttf", true
    reconnectClient()
}

getOcrResult(ocrStart, ocrSize, ocrScale) {
    WinGetClientPos &windowTopLeftX, &windowTopLeftY, , , "ahk_exe RobloxPlayerBeta.exe"
    ocrStart := [ocrStart[1] + windowTopLeftX, ocrStart[2] + windowTopLeftY]

    ocrObjectResult := OCR.FromRect(ocrStart[1], ocrStart[2], ocrSize[1], ocrSize[2], , ocrScale)
    
    return ocrObjectResult
}