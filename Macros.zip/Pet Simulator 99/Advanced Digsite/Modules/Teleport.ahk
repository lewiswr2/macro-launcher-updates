﻿#Requires AutoHotkey v2.0

; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
; DIRECTIVES & CONFIGURATIONS
; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

#SingleInstance Force  ; Forces the script to run only in a single instance. If this script is executed again, the new instance will replace the old one.
CoordMode "Mouse", "Client"  ; Sets the coordinate mode for mouse functions (like Click, MouseMove) to be relative to the active window's client area, ensuring consistent mouse positioning across different window states.
CoordMode "Pixel", "Client"  ; Sets the coordinate mode for pixel functions (like PixelSearch, PixelGetColor) to be relative to the active window's client area, improving accuracy in color detection and manipulation.
SetMouseDelay 10  ; Sets the delay between mouse events to 10 milliseconds, balancing speed and reliability of automated mouse actions.


; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
; LIBRARIES
; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

; Macro Related Libraries:
#Include "%A_ScriptDir%\Modules"
#Include "Zones.ahk"


; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
; GLOBAL VARIABLES
; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

; ----------------------------------------------------------------------------------------
; TELEPORT_PIXEL Map
; Description: Defines the pixel color and coordinates for various elements in the teleport menu.
; ----------------------------------------------------------------------------------------
TELEPORT_PIXEL := Map(
    "MENU_ICON", Map("Start", [66, 108], "End", [66, 108], "Colour", "0xD81140", "Tolerance", 2),
    "SEARCH_CURSOR", Map("Start", [610, 117], "End", [630, 117], "Colour", "0xAFAFAF", "Tolerance", 2),
    "SEARCH_TERM", Map("Start", [676, 100], "End", [685, 115], "Colour", "0x1E1E1E", "Tolerance", 2),
    "DESTINATION_BLUE", Map("Start", [441, 245], "End", [441, 245], "Colour", "0x5ADAFF", "Tolerance", 2),
    "DESTINATION_GREEN", Map("Start", [224, 145], "End", [502, 316], "Colour", "0x60F002", "Tolerance", 2),
    "DESTINATION_WHITE", Map("Start", [441, 245], "End", [441, 245], "Colour", "0xFFFFFF", "Tolerance", 2),
    "CONFIRM_TELEPORT", Map("Start", [187, 126], "End", [187, 126], "Colour", "0x53E3FF", "Tolerance", 2),
    "CONTROL", Map("Start", [109, 190], "End", [109, 190], "Colour", "0xC80A2F", "Tolerance", 2),
    "SKIP_BUTTON", Map("Start", [365, 575], "End", [365, 575], "Colour", "0xFD9E42", "Tolerance", 2)
)

; ----------------------------------------------------------------------------------------
; TELEPORT_COORDS Map
; Description: Defines the coordinates for various buttons and elements in the teleport menu.
; ----------------------------------------------------------------------------------------
TELEPORT_COORDS := Map(
    "CONTROL", [109, 154],
    "MENU_ICON", [66, 108],
    "SEARCH_BOX", [600, 107],
    "SEARCH_ZONE", [398, 193],
    "CLOSE", [746, 109],
    "WORLD_1", [22, 238],
    "WORLD_2", [22, 284],
    "WORLD_3", [22, 328],
    "CONFIRM_TELEPORT", [291, 422],
    "SKIP_BUTTON", [365, 575]
)


; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
; TELEPORT FUNCTIONS
; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

; ----------------------------------------------------------------------------------------
; teleportToZone Function
; Description: Teleports the player to the specified zone in the game.
; Operation:
;   - Activates the Roblox window.
;   - Opens and interacts with the teleport menu.
;   - Searches for the specified zone and initiates teleportation.
; Dependencies: 
;   - activateRoblox: Function to activate the Roblox window.
;   - closeTeleportMenu: Function to close the teleport menu.
;   - openTeleportMenu: Function to open the teleport menu.
;   - clickTeleportSearchBox: Function to click the search box in the teleport menu.
;   - enterTeleportSearchTerm: Function to enter the zone number into the search box.
;   - isDestinationGreen: Function to check if the destination is available.
;   - clickTeleportButton: Function to click the teleport button.
; Parameters:
;   - zoneNumber: The zone number to which the player should be teleported.
; Return: Boolean indicating if the player is already in the zone.
; ----------------------------------------------------------------------------------------
teleportToZone(zoneNumber) {
    activateRoblox()  ; Ensure Roblox window is active.
    closeTeleportMenu()  ; Close the teleport menu if it is open.
    openTeleportMenu()  ; Open the teleport menu.
    clickTeleportSearchBox()  ; Click on the search box within the teleport menu.
    enterTeleportSearchTerm(zoneNumber)  ; Enter the zone number into the search box.

    alreadyInZone := false  ; Initialize flag to check if already in the zone.
    if isDestinationGreen()  ; Check if the destination is available.
        clickTeleportButton(zoneNumber)  ; Click the button to initiate teleportation.
    else
        alreadyInZone := true  ; Set flag to true if already in the zone.
        
    closeTeleportMenu()  ; Close the teleport menu.
    return alreadyInZone  ; Return the flag indicating if already in the zone.
}

; ----------------------------------------------------------------------------------------
; openTeleportMenu Function
; Description: Opens the teleport menu if it is not already open.
; Operation:
;   - Checks if the teleport menu is open.
;   - Clicks the button to open the teleport menu.
;   - Waits for the menu to open.
; Dependencies: TELEPORT_COORDS, isTeleportMenuOpen.
; Parameters: None.
; Return: None.
; ----------------------------------------------------------------------------------------
openTeleportMenu() {
    if isTeleportMenuOpen()
        return  ; Return if the teleport menu is already open.

    button := TELEPORT_COORDS["CONTROL"]

    Loop 100 {
        SendEvent "{Click, " button[1] ", " button[2] ", 1}"  ; Click to open the teleport menu.
        Loop 25 {  ; Loop to check if the menu has opened.
            Sleep 10  ; Brief pause between checks to reduce CPU usage.
            if isTeleportMenuOpen()  ; Check if the teleport menu is open.
                return  ; Exit the loop if the teleport menu is open.
        }
    }
}

; ----------------------------------------------------------------------------------------
; clickTeleportMenuIcon Function
; Description: Clicks the teleport menu icon to open the teleport menu.
; Operation:
;   - Clicks the button to open the teleport menu.
;   - Waits for the menu to open.
; Dependencies: TELEPORT_COORDS, isTeleportMenuOpen.
; Parameters: None.
; Return: None.
; ----------------------------------------------------------------------------------------
clickTeleportMenuIcon() {
    button := TELEPORT_COORDS["MENU_ICON"]

    Loop 100 {
        SendEvent "{Click, " button[1] ", " button[2] ", 1}"  ; Click on the teleport menu icon.
        Loop 25 {  ; Loop to check if the menu has opened.
            Sleep 10  ; Brief pause between checks to reduce CPU usage.
            if isTeleportMenuOpen()  ; Check if the teleport menu is open.
                return  ; Exit the loop if the teleport menu is open.
        }
    }
}

; ----------------------------------------------------------------------------------------
; clickTeleportSearchBox Function
; Description: Clicks the search box in the teleport menu.
; Operation:
;   - Closes the leaderboard.
;   - Clicks the button to select the search box.
;   - Waits for the search box to be selected.
; Dependencies: TELEPORT_COORDS, closeLeaderboard, isTeleportSearchBoxSelected.
; Parameters: None.
; Return: None.
; ----------------------------------------------------------------------------------------
clickTeleportSearchBox() {
    button := TELEPORT_COORDS["SEARCH_BOX"]

    closeLeaderboard()  ; Close the leaderboard.

    Loop 100 {
        SendEvent "{Click, " button[1] ", " button[2] ", 1}"  ; Click on the teleport search box.
        Loop 25 {  ; Loop to check if the search box is selected.
            Sleep 10  ; Brief pause between checks to reduce CPU usage.
            if isTeleportSearchBoxSelected()  ; Check if the search box is selected.
                return  ; Exit the loop if the search box is selected.
        }
    }
}

; ----------------------------------------------------------------------------------------
; enterTeleportSearchTerm Function
; Description: Enters the specified zone number into the teleport search box.
; Operation:
;   - Sends the text corresponding to the specified zone number.
;   - Checks if the search term has been entered.
; Dependencies: ZONE_MAP, isTeleportSearchTermEntered.
; Parameters:
;   - zoneNumber: The number of the zone to search for.
; Return: None.
; ----------------------------------------------------------------------------------------
enterTeleportSearchTerm(zoneNumber) {
    SendText ZONE_MAP.Get(zoneNumber)  ; Enter the text for the specified zone number into the search box.

    Loop 100 {  ; Loop to check if the search term has been entered.
        if isTeleportSearchTermEntered()  ; Check if the search term is entered.
            return  ; Exit the loop if the search term is entered.
        Sleep 10  ; Brief pause between checks to reduce CPU usage.
    }
}

; ----------------------------------------------------------------------------------------
; clickTeleportButton Function
; Description: Clicks the teleport button and handles the teleport menu interactions.
; Operation:
;   - Clicks the teleport button.
;   - Closes and reopens the teleport menu.
;   - Re-enters the zone number into the search box.
;   - Checks if the destination is ready.
; Dependencies: TELEPORT_COORDS, closeTeleportMenu, openTeleportMenu, clickTeleportSearchBox, enterTeleportSearchTerm, isDestinationBlue.
; Parameters:
;   - zoneNumber: The number of the zone to search for.
; Return: None.
; ----------------------------------------------------------------------------------------
clickTeleportButton(zoneNumber) {
    button := TELEPORT_COORDS["SEARCH_ZONE"]
    SendEvent "{Click, " button[1] ", " button[2] ", 1}"  ; Click on the teleport button.
    
    closeTeleportMenu()  ; Close the teleport menu.
    openTeleportMenu()  ; Reopen the teleport menu.
    clickTeleportSearchBox()  ; Click on the search box within the teleport menu.
    enterTeleportSearchTerm(zoneNumber)  ; Re-enter the zone number into the search box.
    
    Loop 250 {  ; Loop to check if the destination is ready again.
        if isDestinationBlue()  ; Check if the destination is ready.
            break  ; Exit the loop if the destination is ready.
        Sleep 10  ; Brief pause between checks to reduce CPU usage.
    }
}

; ----------------------------------------------------------------------------------------
; closeTeleportMenu Function
; Description: Closes the teleport menu if it is open.
; Operation:
;   - Checks if the teleport menu is open.
;   - Clicks the close button to close the teleport menu.
;   - Waits until the teleport menu is closed.
; Dependencies: TELEPORT_COORDS, isTeleportMenuOpen.
; Parameters: None.
; Return: None.
; ----------------------------------------------------------------------------------------
closeTeleportMenu() {
    if isTeleportMenuOpen() {
        button := TELEPORT_COORDS["CLOSE"]
        SendEvent "{Click, " button[1] ", " button[2] ", 1}"  ; Click on the close button of the teleport menu.
        Loop 100 {
            if !isTeleportMenuOpen()
                break
            Sleep 10  ; Brief pause between checks to reduce CPU usage.
        }
    }
}


; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
; PIXEL CHECKS
; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

; ----------------------------------------------------------------------------------------
; isTeleportMenuOpen Function
; Description: Checks if the teleport menu is open by performing a pixel search on the menu icon.
; Operation:
;   - Retrieves the coordinates and color for the teleport menu icon.
;   - Performs a pixel search in the specified area.
; Dependencies: TELEPORT_PIXEL map.
; Parameters: None
; Return: Boolean indicating whether the teleport menu is open.
; ----------------------------------------------------------------------------------------
isTeleportMenuOpen() {
    pixel := TELEPORT_PIXEL["MENU_ICON"]
    return PixelSearch(&foundX, &foundY,  ; Perform a pixel search.
        pixel["Start"][1], pixel["Start"][2],  ; Starting coordinates for the search area.
        pixel["End"][1], pixel["End"][2],  ; Ending coordinates for the search area.
        pixel["Colour"], pixel["Tolerance"])  ; Color and tolerance for the search.
}

; ----------------------------------------------------------------------------------------
; isTeleportSearchBoxSelected Function
; Description: Checks if the teleport search box is selected by performing a pixel search.
; Operation:
;   - Retrieves the coordinates and color for the search cursor.
;   - Performs a pixel search in the specified area.
; Dependencies: TELEPORT_PIXEL map.
; Parameters: None
; Return: Boolean indicating whether the search box is selected.
; ----------------------------------------------------------------------------------------
isTeleportSearchBoxSelected() {
    pixel := TELEPORT_PIXEL["SEARCH_CURSOR"]
    return PixelSearch(&foundX, &foundY,  ; Perform a pixel search.
        pixel["Start"][1], pixel["Start"][2],  ; Starting coordinates for the search area.
        pixel["End"][1], pixel["End"][2],  ; Ending coordinates for the search area.
        pixel["Colour"], pixel["Tolerance"])  ; Color and tolerance for the search.
}

; ----------------------------------------------------------------------------------------
; isTeleportSearchTermEntered Function
; Description: Checks if the search term is entered in the teleport menu by performing a pixel search.
; Operation:
;   - Retrieves the coordinates and color for the search term.
;   - Performs a pixel search in the specified area.
; Dependencies: TELEPORT_PIXEL map.
; Parameters: None
; Return: Boolean indicating whether the search term is entered.
; ----------------------------------------------------------------------------------------
isTeleportSearchTermEntered() {
    pixel := TELEPORT_PIXEL["SEARCH_TERM"]
    return PixelSearch(&foundX, &foundY,  ; Perform a pixel search.
        pixel["Start"][1], pixel["Start"][2],  ; Starting coordinates for the search area.
        pixel["End"][1], pixel["End"][2],  ; Ending coordinates for the search area.
        pixel["Colour"], pixel["Tolerance"])  ; Color and tolerance for the search.
}

; ----------------------------------------------------------------------------------------
; isDestinationBlue Function
; Description: Checks if the destination is blue by performing a pixel search.
; Operation:
;   - Retrieves the coordinates and color for the blue destination.
;   - Performs a pixel search in the specified area.
; Dependencies: TELEPORT_PIXEL map.
; Parameters: None
; Return: Boolean indicating whether the destination is blue.
; ----------------------------------------------------------------------------------------
isDestinationBlue() {
    pixel := TELEPORT_PIXEL["DESTINATION_BLUE"]
    return PixelSearch(&foundX, &foundY,  ; Perform a pixel search.
        pixel["Start"][1], pixel["Start"][2],  ; Starting coordinates for the search area.
        pixel["End"][1], pixel["End"][2],  ; Ending coordinates for the search area.
        pixel["Colour"], pixel["Tolerance"])  ; Color and tolerance for the search.
}

; ----------------------------------------------------------------------------------------
; isDestinationGreen Function
; Description: Checks if the destination is green by performing a pixel search.
; Operation:
;   - Retrieves the coordinates and color for the green destination.
;   - Performs a pixel search in the specified area.
; Dependencies: TELEPORT_PIXEL map.
; Parameters: None
; Return: Boolean indicating whether the destination is green.
; ----------------------------------------------------------------------------------------
isDestinationGreen() {
    pixel := TELEPORT_PIXEL["DESTINATION_GREEN"]
    return PixelSearch(&foundX, &foundY,  ; Perform a pixel search.
        pixel["Start"][1], pixel["Start"][2],  ; Starting coordinates for the search area.
        pixel["End"][1], pixel["End"][2],  ; Ending coordinates for the search area.
        pixel["Colour"], pixel["Tolerance"])  ; Color and tolerance for the search.
}

; ----------------------------------------------------------------------------------------
; isDestinationWhite Function
; Description: Checks if the destination is white by performing a pixel search.
; Operation:
;   - Retrieves the coordinates and color for the white destination.
;   - Performs a pixel search in the specified area.
; Dependencies: TELEPORT_PIXEL map.
; Parameters: None
; Return: Boolean indicating whether the destination is white.
; ----------------------------------------------------------------------------------------
isDestinationWhite() {
    pixel := TELEPORT_PIXEL["DESTINATION_WHITE"]
    return PixelSearch(&foundX, &foundY,  ; Perform a pixel search.
        pixel["Start"][1], pixel["Start"][2],  ; Starting coordinates for the search area.
        pixel["End"][1], pixel["End"][2],  ; Ending coordinates for the search area.
        pixel["Colour"], pixel["Tolerance"])  ; Color and tolerance for the search.
}

; ----------------------------------------------------------------------------------------
; isTeleportWorldConfirmationOpen Function
; Description: Checks if the teleport world confirmation window is open by performing a pixel search.
; Operation:
;   - Retrieves the coordinates and color for the confirm teleport button.
;   - Performs a pixel search in the specified area.
; Dependencies: TELEPORT_PIXEL map.
; Parameters: None
; Return: Boolean indicating whether the confirmation window is open.
; ----------------------------------------------------------------------------------------
isTeleportWorldConfirmationOpen() {
    pixel := TELEPORT_PIXEL["CONFIRM_TELEPORT"]
    return PixelSearch(&foundX, &foundY,  ; Perform a pixel search.
        pixel["Start"][1], pixel["Start"][2],  ; Starting coordinates for the search area.
        pixel["End"][1], pixel["End"][2],  ; Ending coordinates for the search area.
        pixel["Colour"], pixel["Tolerance"])  ; Color and tolerance for the search.
}

; ----------------------------------------------------------------------------------------
; isTeleportControlVisible Function
; Description: Checks if the teleport control is visible by performing a pixel search.
; Operation:
;   - Retrieves the coordinates and color for the teleport control.
;   - Performs a pixel search in the specified area.
; Dependencies: TELEPORT_PIXEL map.
; Parameters: None
; Return: Boolean indicating whether the teleport control is visible.
; ----------------------------------------------------------------------------------------
isTeleportControlVisible() {
    pixel := TELEPORT_PIXEL["CONTROL"]
    return PixelSearch(&foundX, &foundY,  ; Perform a pixel search.
        pixel["Start"][1], pixel["Start"][2],  ; Starting coordinates for the search area.
        pixel["End"][1], pixel["End"][2],  ; Ending coordinates for the search area.
        pixel["Colour"], pixel["Tolerance"])  ; Color and tolerance for the search.
}

; ----------------------------------------------------------------------------------------
; isSkipButtonShown Function
; Description: Checks if the skip button is shown by performing a pixel search.
; Operation:
;   - Retrieves the coordinates and color for the skip button.
;   - Performs a pixel search in the specified area.
; Dependencies: TELEPORT_PIXEL map.
; Parameters: None
; Return: Boolean indicating whether the skip button is shown.
; ----------------------------------------------------------------------------------------
isSkipButtonShown() {
    pixel := TELEPORT_PIXEL["SKIP_BUTTON"]
    return PixelSearch(&foundX, &foundY,  ; Perform a pixel search.
        pixel["Start"][1], pixel["Start"][2],  ; Starting coordinates for the search area.
        pixel["End"][1], pixel["End"][2],  ; Ending coordinates for the search area.
        pixel["Colour"], pixel["Tolerance"])  ; Color and tolerance for the search.
}


; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
; WORLD FUNCTIONS
; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

; ----------------------------------------------------------------------------------------
; getWorld Function
; Description: Determines the current world by interacting with the teleport menu and searching for specific spawn points.
; Operation:
;   - Opens the teleport menu and iteratively checks spawn points for each world.
;   - Reopens the teleport menu up to 10 times if the initial search fails.
;   - Identifies the world by checking if the search term matches the spawn point.
; Dependencies:
;   - openTeleportMenu: Function to open the teleport menu.
;   - clickTeleportMenuIcon: Function to click on the teleport menu icon.
;   - clickTeleportSearchBox: Function to click on the search box within the teleport menu.
;   - enterTeleportSearchTerm: Function to enter the search term in the teleport search box.
;   - isDestinationWhite: Function to check if the destination is white.
;   - closeTeleportMenu: Function to close the teleport menu.
; Parameters: None
; Return: The index of the current world, or -1 if not found.
; ----------------------------------------------------------------------------------------
getWorld() {
    worldSpawns := [15, 100, 200]  ; List of spawn points for different worlds.
    world := -1  ; Initialize world as -1 (not found).

    Loop 10 {
        openTeleportMenu()  ; Reopen the teleport menu.

        ; Check each spawn point to determine the current world.
        Loop 3 {
            clickTeleportMenuIcon()  ; Click on the teleport menu icon.
            clickTeleportSearchBox()  ; Click on the search box within the teleport menu.
            enterTeleportSearchTerm(worldSpawns[A_Index])  ; Enter the spawn point number into the search box.

            ; Check if the destination is not white, indicating the world is found.
            if !isDestinationWhite() {
                world := A_Index  ; Set the current world index.
                break  ; Exit the loop if the world is found.
            }
        }

        ; If the world is found, close the teleport menu and return the world index.
        if world != -1 {
            closeTeleportMenu()  ; Close the teleport menu.
            return world  ; Return the current world index.
        }
    }

    return world  ; Return the world index (-1 if not found).
}

; ----------------------------------------------------------------------------------------
; teleportToWorld Function
; Description: Teleports the player to a specified world by interacting with the teleport menu and handling various confirmation and control windows.
; Operation:
;   - Opens the teleport menu.
;   - Clicks the button for the specified world.
;   - Clicks the confirm button if the world confirmation window is open.
;   - Waits until the teleport control is no longer visible.
;   - Handles the skip button if shown during the teleportation process.
; Dependencies:
;   - openTeleportMenu: Function to open the teleport menu.
;   - TELEPORT_COORDS: Map containing coordinates for various teleport-related buttons.
;   - isTeleportMenuOpen: Function to check if the teleport menu is open.
;   - isTeleportWorldConfirmationOpen: Function to check if the teleport world confirmation window is open.
;   - isTeleportControlVisible: Function to check if the teleport control is visible.
;   - isSkipButtonShown: Function to check if the skip button is shown.
; Parameters:
;   - worldNumber: The number of the world to which the player should be teleported.
; Return: None
; ----------------------------------------------------------------------------------------
teleportToWorld(worldNumber) {
    openTeleportMenu()  ; Open the teleport menu.

    button := TELEPORT_COORDS["WORLD_" worldNumber]  ; Get the coordinates of the world button.
    Loop {
        SendEvent "{Click, " button[1] ", " button[2] ", 1}"  ; Click the world button.
        Sleep 10
        if !isTeleportMenuOpen()  ; Check if the teleport menu is closed.
            break  ; Exit the loop if the teleport menu is closed.
    }
    
    button := TELEPORT_COORDS["CONFIRM_TELEPORT"]  ; Get the coordinates of the confirm button.
    Loop 100 {
        if isTeleportWorldConfirmationOpen() {  ; Check if the world confirmation window is open.
            SendEvent "{Click, " button[1] ", " button[2] ", 1}"  ; Click the confirm button.
            break  ; Exit the loop after clicking the confirm button.
        }
        Sleep 10
    }

    Loop 100 {
        if !isTeleportControlVisible()  ; Check if the teleport control is no longer visible.
            break  ; Exit the loop if the teleport control is no longer visible.
        Sleep 10
    }

    button := TELEPORT_COORDS["SKIP_BUTTON"]  ; Get the coordinates of the skip button.
    Loop {
        if isTeleportControlVisible()  ; Check if the teleport control is visible.
            break  ; Exit the loop if the teleport control is visible.
        if isSkipButtonShown()  ; Check if the skip button is shown.
            SendEvent "{Click, " button[1] ", " button[2] ", 1}"  ; Click the skip button if shown.
        Sleep 100
    }
}

; ----------------------------------------------------------------------------------------
; closeLeaderboard Function
; Description: Searches for the leaderboard rank star icon on the screen and closes the leaderboard if found.
; Operation:
;   - Uses PixelSearch to find the leaderboard rank star icon within specified coordinates and color.
;   - If the leaderboard rank star icon is found, sends the Tab key to close the leaderboard.
; Dependencies: None
; Parameters: None
; Return: None; performs the search and send key operations to close the leaderboard.
; ----------------------------------------------------------------------------------------
closeLeaderboard() {
    Loop 50{
    PixelSearch(&Px, &Py, 549, 78, 793, 326, 0x121215, 3)
   SendEvent "{click 491, 70}"
   break 
    }
}