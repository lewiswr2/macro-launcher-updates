#Requires AutoHotkey v2.0

SAVED_SETTINGS_FOLDER := A_ScriptDir "\Settings\"

SETTINGS_MAP := Map()

initialiseSettings() {
    global
    SETTINGS_MAP := Map(
        "Legacy", Map(
            "accountNameSetting", accountNameSetting,
            "startModeSetting", startModeSetting,
            "pauseModeSetting", pauseModeSetting,
            "exitModeSetting", exitModeSetting,
            "bestZoneSetting", bestZoneSetting,
            "numberOfLoopsSetting", numberOfLoopsSetting,
            "do1StarQuestsSetting", do1StarQuestsSetting,
            "do2StarQuestsSetting", do2StarQuestsSetting,
            "do3StarQuestsSetting", do3StarQuestsSetting,
            "do4StarQuestsSetting", do4StarQuestsSetting,
            "eatFruitSetting", eatFruitSetting,
            "gamepassAutoFarmSetting", gamepassAutoFarmSetting,
            "gamepassVipSetting", gamepassVipSetting,
            "gamepassDoubleStarsSetting", gamepassDoubleStarsSetting,
            "gamepassSuperDropsSetting", gamepassSuperDropsSetting,
            "vipUseFlagSetting", vipUseFlagSetting,
            "vipUseSprinklerSetting", vipUseSprinklerSetting,
            "eggsAtOnceSetting", eggsAtOnceSetting,
            "shinyHoverboardSetting", shinyHoverboardSetting,
            "reconnectAfterLoopsCompleteSetting", reconnectAfterLoopsCompleteSetting,
            "reconnectionTimeSecondsSetting", reconnectionTimeSecondsSetting,
            "privateServerLinkCodeSetting", privateServerLinkCodeSetting,
            "numberPetsToMakeGoldenSetting", numberPetsToMakeGoldenSetting,
            "numberPetsToMakeRainbowSetting", numberPetsToMakeRainbowSetting,
            "numberPotionsToUpgradeSetting", numberPotionsToUpgradeSetting,
            "potionsToUpgradeSetting", potionsToUpgradeSetting,
            "numberEnchantsToUpgradeSetting", numberEnchantsToUpgradeSetting,
            "enchantsToUpgradeSetting", enchantsToUpgradeSetting,
            "breakPinatasSetting", breakPinatasSetting,
            "breakLuckyBlocksSetting", breakLuckyBlocksSetting,
            "breakBasicCoinJarsSetting", breakBasicCoinJarsSetting,
            "breakCometsSetting", breakCometsSetting,
            "breakMiniChestsSetting", breakMiniChestsSetting,
            "breakBreakablesSetting", breakBreakablesSetting,
            "breakDiamondBreakablesSetting", breakDiamondBreakablesSetting,
            "breakSuperiorMiniChestsSetting", breakSuperiorMiniChestsSetting,
            "earnDiamondsSetting", earnDiamondsSetting,
            "hasSupercomputerRadioSetting", hasSupercomputerRadioSetting,
            "questFlagSetting", questFlagSetting,
            "bestAreaUseFlagSetting", bestAreaUseFlagSetting,
            "bestAreaFlagSetting", bestAreaFlagSetting,
            "bestAreaUseSprinklerSetting", bestAreaUseSprinklerSetting,       
        ),        
        "Keybinds", Map(
            "keybindHastyFlag", kbHastyFlag,
            "keybindCoinsFlag", kbCoinsFlag,
            "keybindDiamondsFlag", kbDiamondsFlag,
            "keybindMagnetFlag", kbMagnetFlag,
            "keybindFortuneFlag", kbFortuneFlag,
            "keybindLuckyBlock", kbLuckyBlock,
            "keybindCoinJar", kbCoinJar,
            "keybindComet", kbComet,
            "keybindPinata", kbPinata,
            "keybindCoins1", kbCoins1,
            "keybindCoins2", kbCoins2,
            "keybindCoins3", kbCoins3,
            "keybindCoins4", kbCoins4,
            "keybindCoins5", kbCoins5,
            "keybindSprinkler", kbSprinkler,
            "keybindSupercomputer", kbSupercomputer,
        )
    )
}

savePlayerSettings(*) {
    global

    initialiseSettings()

    if accountNameSetting.Value == "" {
        MsgBox "Account name required.", MACRO_TITLE, 48
        return
    }

    filename := SAVED_SETTINGS_FOLDER accountNameSetting.Value ".cfg"
    saveSettings(filename, SETTINGS_MAP)
    populatePlayerSettingsDropdown()
    SETTINGS_GUI_VISIBLE := false
    settingsGui.Hide()

}

loadPlayerSettings(*) {

    initialiseSettings()

    filePath := SAVED_SETTINGS_FOLDER playerSettings.Text

    if !FileExist(filePath)
        return

    for section, keys in SETTINGS_MAP {
        for key, control in keys {
            val := IniRead(filePath, section, key, control.Value)
            try control.Value := val
        }
    }
}

saveSettings(filename, settings) {
    for section, keys in SETTINGS_MAP {
        for key, control in keys {
            IniWrite control.Value, filename, section, key
        }
    }
}

populatePlayerSettingsDropdown() {
    fileList := []

    Loop Files SAVED_SETTINGS_FOLDER "\*.cfg" {
        fileList.Push(A_LoopFileName)
    }

    playerSettings.Delete()

    if fileList.Length > 0 {
        playerSettings.Add(fileList)
        playerSettings.Choose(1)
        loadPlayerSettings()
    }
}

deleteSelectedSetting(*) {
    filePath := SAVED_SETTINGS_FOLDER playerSettings.Text

    if FileExist(filePath) {
        FileDelete(filePath)
    }
    populatePlayerSettingsDropdown()
}
