#Requires AutoHotkey v2.0

; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
; IMPROVED COLOR SCHEME - Modern Dark Theme
; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

global COLORS := {
    ; Header - Rich gold gradient
    headerBg: "0xFFB84D",
    headerAccent: "0xd29922",
    headerText: "0x1a1a1a",
    
    ; Backgrounds
    bg: "0x0d1117",
    cardBg: "0x161b22",
    cardHover: "0x1f2428",
    inputBg: "0x0d1117",
    
    ; Text
    text: "0xe6edf3",
    textDim: "0x7d8590",
    textBright: "0xffffff",
    
    ; UI Elements
    border: "0x30363d",
    divider: "0x21262d",
    
    ; Status Colors
    success: "0x3fb950",
    warning: "0xd29922",
    danger: "0xf85149",
    info: "0x58a6ff",
    
    ; Buttons
    buttonPrimary: "0xFFB84D",
    buttonPrimaryText: "0x1a1a1a",
    buttonSecondary: "0x21262d",
    buttonSecondaryText: "0xe6edf3",
    buttonDanger: "0xda3633",
    buttonDangerText: "0xffffff"
}

; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
; GUI INITIALIZATION
; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

displayQuestsGui() {
    global

    ; Initialize the main GUI
    mainGui := Gui()
    mainGui.Title := MACRO_TITLE " v" MACRO_VERSION
    mainGui.BackColor := COLORS.bg
    mainGui.MarginX := 0
    mainGui.MarginY := 0

    ; ═══════════════════════════════════════════════════
    ; HEADER SECTION - Enhanced with gradient effect
    ; ═══════════════════════════════════════════════════
    
    mainGui.Add("Progress", "x0 y0 w700 h120 Background" SubStr(COLORS.headerBg, 3))
    
    mainGui.SetFont("s24 bold c" SubStr(COLORS.headerText, 3), "Segoe UI")
    mainGui.Add("Text", "x0 y30 w700 Center BackgroundTrans", "⭐ " MACRO_TITLE)
    
    mainGui.SetFont("s9 c" SubStr(COLORS.headerText, 3))
    mainGui.Add("Text", "x0 y70 w700 Center BackgroundTrans", "Automated Quest Ranking System v" MACRO_VERSION)

    ; ═══════════════════════════════════════════════════
    ; MENU BAR
    ; ═══════════════════════════════════════════════════
    
    fileMenu := Menu()
    startText := "Start Macro`tF1"
    pauseText := "Pause Macro`tF2"
    exitText := "Exit Macro`tF3"
    fileMenu.Add(startText, startMacro)
    fileMenu.Add()
    fileMenu.Add(pauseText, pauseMacro)
    fileMenu.Add("Reload Macro", reloadMacro)
    fileMenu.Add()
    fileMenu.Add(exitText, exitMacro)
    fileMenu.SetIcon(startText, "imageres.dll", 282)
    fileMenu.SetIcon(pauseText, ICON_FOLDER ICON_MAP["PlayPause"].icon)
    fileMenu.SetIcon("Reload Macro", "imageres.dll", 230)
    fileMenu.SetIcon(exitText, "imageres.dll", 94)

    toolsMenu := Menu()
    toolsMenu.Add("Keybinds", setKeybinds)
    toolsMenu.Add()    
    toolsMenu.Add("Reconnect", reconnectClient)
    toolsMenu.Add("Standard Font", changeToDefaultFont)
    toolsMenu.SetIcon("Reconnect", WinGetProcessPath("ahk_exe RobloxPlayerBeta.exe"), 1)
    toolsMenu.SetIcon("Standard Font", ICON_FOLDER ICON_MAP["Font"].icon)


    
    MyMenuBar := MenuBar()
    MyMenuBar.Add("&File", fileMenu)
    MyMenuBar.Add("&Tools", toolsMenu)    

    mainGui.MenuBar := MyMenuBar

    ; ═══════════════════════════════════════════════════
    ; MAIN CONTENT AREA
    ; ═══════════════════════════════════════════════════
    
    mainGui.SetFont("s9 c" COLORS.text, "Segoe UI")

    ; Section Header
    mainGui.SetFont("s10 bold c" COLORS.textBright)
    mainGui.Add("Text", "x20 y135", "Active Quests")
    mainGui.SetFont("s9 c" COLORS.text, "Segoe UI")

    ; Quests List View - Enhanced styling
    lvQuests := mainGui.AddListView("x20 y160 r4 w660 NoSortHdr Background" COLORS.cardBg " c" COLORS.text, 
        ["★", "Type", "Quest", "Amount", "Priority", "Status", "Zone", "OCR"])
    lvQuests.ModifyCol(1, 30)
    lvQuests.ModifyCol(2, 0)
    lvQuests.ModifyCol(3, 220)
    lvQuests.ModifyCol(4, 60)
    lvQuests.ModifyCol(5, 60)
    lvQuests.ModifyCol(6, 70)
    lvQuests.ModifyCol(7, 50)
    lvQuests.ModifyCol(8, 150)

    ; Spacer
    mainGui.Add("Progress", "x20 y+10 w660 h2 Background" SubStr(COLORS.divider, 3))

    ; Section Header
    mainGui.SetFont("s10 bold c" COLORS.textBright)
    mainGui.Add("Text", "x20 y+15", "Current Activity")
    mainGui.SetFont("s9 c" COLORS.text, "Segoe UI")

    ; Current Activity List View
    lvCurrent := mainGui.AddListView("x20 y+10 r1 w660 NoSortHdr Background" COLORS.cardBg " c" COLORS.text, 
        ["Loop", "Zone", "Area", "Quest", "Action", "Time"])
    lvCurrent.Add(, "-", "-", "-", "-", "-", "-")
    lvCurrent.ModifyCol(1, 50)
    lvCurrent.ModifyCol(2, 50)
    lvCurrent.ModifyCol(3, 110)
    lvCurrent.ModifyCol(4, 200)
    lvCurrent.ModifyCol(5, 190)
    lvCurrent.ModifyCol(6, 50)

    ; Spacer
    mainGui.Add("Progress", "x20 y+10 w660 h2 Background" SubStr(COLORS.divider, 3))

    ; ═══════════════════════════════════════════════════
    ; PLAYER SETTINGS SECTION - Redesigned
    ; ═══════════════════════════════════════════════════
    
    mainGui.SetFont("s10 bold c" COLORS.textBright)
    mainGui.Add("Text", "x20 y+15", "Player Settings")
    mainGui.SetFont("s9 c" COLORS.text, "Segoe UI")

    ; Settings Controls Row
    mainGui.Add("Text", "x20 y+10 c" COLORS.textDim, "Profile:")
    playerSettings := mainGui.AddDropDownList("x+10 yp-3 w200 Sort Background" COLORS.inputBg " c" COLORS.text,)
    playerSettings.OnEvent("Change", (*) => loadPlayerSettings())
    
    openSettings := mainGui.AddButton("x+15 yp w100 h26", "⚙️ Settings")
    openSettings.OnEvent("Click", (*) => openSettingsGui())
    
    deleteSettings := mainGui.AddButton("x+10 yp w100 h26", "🗑️ Delete")
    deleteSettings.OnEvent("Click", (*) => deleteSelectedSetting())

    ; Status Bar
    statusBar := mainGui.AddStatusBar(, "")

    ; Display the GUI window
    mainGui.Show("x-8 y0 w700 h470")

    createSettingsGui()
    populatePlayerSettingsDropdown()
}

; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
; GUI FUNCTIONS
; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

pauseMacro(*) {
    writeToLogFile("*** PAUSED ***")
    Pause -1
}

exitMacro(*) {
    updateTitle()
    ExitApp
}

openHowTo(*) {
    Run "https://psychohatcher.com/rankup-tutorial/"
}

openDiscord(*) {
    Run "https://discord.gg/psychohatcher"
}

openWebsite(*) {
    Run "https://psychohatcher.com/"
}

openDonate(*) {
    Run "https://psychohatcher.com/donate/"
}

reloadMacro(*) {
    Reload
}
