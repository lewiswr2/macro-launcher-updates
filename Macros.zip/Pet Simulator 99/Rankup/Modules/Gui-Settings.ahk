#Requires AutoHotkey v2.0

SETTINGS_GUI_VISIBLE := false

createSettingsGui() {
    global

    global settingsGui := Gui("+Border")
    settingsGui.Title := "Settings"
    settingsGui.BackColor := COLORS.bg
    settingsGui.MarginX := 0
    settingsGui.MarginY := 0

    ; ═══════════════════════════════════════════════════
    ; HEADER
    ; ═══════════════════════════════════════════════════
    
    settingsGui.Add("Progress", "x0 y0 w780 h85 Background" SubStr(COLORS.headerBg, 3))
    settingsGui.SetFont("s20 bold c" SubStr(COLORS.headerText, 3), "Segoe UI")
    settingsGui.Add("Text", "x0 y22 w780 Center BackgroundTrans", "⚙️ Settings")
    settingsGui.SetFont("s9 c" SubStr(COLORS.headerText, 3))
    settingsGui.Add("Text", "x0 y52 w780 Center BackgroundTrans", "Configure your macro preferences")

    ; ═══════════════════════════════════════════════════
    ; TABS
    ; ═══════════════════════════════════════════════════
    
    settingsGui.SetFont("s9 c" COLORS.text, "Segoe UI")
    tabControl := settingsGui.Add("Tab3", "x15 y100 w750 h555", ["General", "Upgrades", "Breakables", "Keybinds"])
    
    ; ═══════════════════════════════════════════════════
    ; TAB 1: GENERAL
    ; ═══════════════════════════════════════════════════
    
    tabControl.UseTab(1)
    
    ; Account
    settingsGui.SetFont("s10 bold c" COLORS.textBright)
    settingsGui.Add("Text", "x35 y135", "Account")
    settingsGui.SetFont("s9 c" COLORS.text)
    settingsGui.AddGroupBox("x35 y155 w230 h65 Background" COLORS.cardBg " c" COLORS.border, "")
    settingsGui.Add("Text", "x45 y170 c" COLORS.textDim, "Account Name")
    accountNameSetting := settingsGui.AddEdit("x45 y188 w210 Background" COLORS.inputBg " c" COLORS.text, "")
    
    ; Progress
    settingsGui.SetFont("s10 bold c" COLORS.textBright)
    settingsGui.Add("Text", "x35 y235", "Game Progress")
    settingsGui.SetFont("s9 c" COLORS.text)
    settingsGui.AddGroupBox("x35 y255 w230 h65 Background" COLORS.cardBg " c" COLORS.border, "")
    settingsGui.Add("Text", "x45 y270 c" COLORS.textDim, "Best Zone Unlocked")
    bestZoneSetting := settingsGui.AddDropDownList("x45 y288 w210 Background" COLORS.inputBg, 
        [274, 269, 264, 259, 249, 239, 235, 230, 225, 220, 215, 210, 205, 199, 99])
    
    ; Quests
    settingsGui.SetFont("s10 bold c" COLORS.textBright)
    settingsGui.Add("Text", "x35 y335", "Quest Configuration")
    settingsGui.SetFont("s9 c" COLORS.text)
    settingsGui.AddGroupBox("x35 y355 w230 h165 Background" COLORS.cardBg " c" COLORS.border, "")
    settingsGui.Add("Text", "x45 y370 c" COLORS.textDim, "Number of Loops")
    numberOfLoopsSetting := settingsGui.AddEdit("x45 y388 w210 Background" COLORS.inputBg " c" COLORS.text, "")
    do1StarQuestsSetting := settingsGui.AddCheckBox("x45 y418 Checked c" COLORS.text, "Complete 1-Star Quests")
    do2StarQuestsSetting := settingsGui.AddCheckBox("x45 y440 Checked c" COLORS.text, "Complete 2-Star Quests")
    do3StarQuestsSetting := settingsGui.AddCheckBox("x45 y462 Checked c" COLORS.text, "Complete 3-Star Quests")
    do4StarQuestsSetting := settingsGui.AddCheckBox("x45 y484 Checked c" COLORS.text, "Complete 4-Star Quests")
    
    ; Gamepasses
    settingsGui.SetFont("s10 bold c" COLORS.textBright)
    settingsGui.Add("Text", "x285 y135", "Gamepasses")
    settingsGui.SetFont("s9 c" COLORS.text)
    settingsGui.AddGroupBox("x285 y155 w230 h115 Background" COLORS.cardBg " c" COLORS.border, "")
    gamepassAutoFarmSetting := settingsGui.AddCheckBox("x295 y175 c" COLORS.text, "Auto Farm")
    gamepassVipSetting := settingsGui.AddCheckBox("x295 y197 c" COLORS.text, "VIP")
    gamepassDoubleStarsSetting := settingsGui.AddCheckBox("x295 y219 c" COLORS.text, "Double Stars")
    gamepassSuperDropsSetting := settingsGui.AddCheckBox("x295 y241 c" COLORS.text, "Super Drops")
    
    ; Equipment
    settingsGui.SetFont("s10 bold c" COLORS.textBright)
    settingsGui.Add("Text", "x285 y285", "Equipment")
    settingsGui.SetFont("s9 c" COLORS.text)
    settingsGui.AddGroupBox("x285 y305 w230 h150 Background" COLORS.cardBg " c" COLORS.border, "")
    hasSupercomputerRadioSetting := settingsGui.AddCheckBox("x295 y325 c" COLORS.text, "Has Supercomputer Radio")
    shinyHoverboardSetting := settingsGui.AddCheckBox("x295 y347 c" COLORS.text, "Shiny Hoverboard")
    settingsGui.Add("Text", "x295 y372 c" COLORS.textDim, "Best Area")
    bestAreaUseFlagSetting := settingsGui.AddCheckBox("x295 y390 c" COLORS.text, "Use Flag")
    bestAreaUseSprinklerSetting := settingsGui.AddCheckBox("x395 y390 c" COLORS.text, "Use Sprinkler")
    settingsGui.Add("Text", "x295 y412 c" COLORS.textDim, "VIP Area")
    vipUseFlagSetting := settingsGui.AddCheckBox("x295 y430 Checked c" COLORS.text, "Use Flag")
    vipUseSprinklerSetting := settingsGui.AddCheckBox("x395 y430 Checked c" COLORS.text, "Use Sprinkler")
    
    ; Reconnection
    settingsGui.SetFont("s10 bold c" COLORS.textBright)
    settingsGui.Add("Text", "x535 y135", "Reconnection")
    settingsGui.SetFont("s9 c" COLORS.text)
    settingsGui.AddGroupBox("x535 y155 w210 h140 Background" COLORS.cardBg " c" COLORS.border, "")
    reconnectAfterLoopsCompleteSetting := settingsGui.AddCheckBox("x545 y175 Checked c" COLORS.text, "Auto-Reconnect")
    settingsGui.Add("Text", "x545 y200 c" COLORS.textDim, "Wait Time (30-120s)")
    reconnectionTimeSecondsSetting := settingsGui.AddSlider("x545 y218 w190 Range30-120 ToolTipTop TickInterval30")
    settingsGui.Add("Text", "x545 y248 c" COLORS.textDim, "Private Server Code")
    privateServerLinkCodeSetting := settingsGui.AddEdit("x545 y266 w190 Background" COLORS.inputBg " c" COLORS.text, "")
    
    ; Hatching
    settingsGui.SetFont("s10 bold c" COLORS.textBright)
    settingsGui.Add("Text", "x535 y310", "Hatching")
    settingsGui.SetFont("s9 c" COLORS.text)
    settingsGui.AddGroupBox("x535 y330 w210 h85 Background" COLORS.cardBg " c" COLORS.border, "")
    settingsGui.Add("Text", "x545 y345 c" COLORS.textDim, "Eggs Per Hatch")
    eggsAtOnceSetting := settingsGui.AddEdit("x545 y363 w85 Background" COLORS.inputBg " c" COLORS.text, "")
    settingsGui.Add("Text", "x645 y345 c" COLORS.textDim, "Rare (5-20)")
    rareEggHatchesSetting := settingsGui.AddSlider("x645 y363 w85 Range5-20 ToolTipTop TickInterval5")
    
    ; Fruit
    settingsGui.SetFont("s10 bold c" COLORS.textBright)
    settingsGui.Add("Text", "x535 y430", "Fruit")
    settingsGui.SetFont("s9 c" COLORS.text)
    settingsGui.AddGroupBox("x535 y450 w210 h90 Background" COLORS.cardBg " c" COLORS.border, "")
    eatFruitSetting := settingsGui.AddCheckBox("x545 y470 Checked c" COLORS.text, "Eat Fruit")
    checkFruitMastery := settingsGui.AddButton("x545 y495 w190", "Check Fruit Mastery")
    checkFruitMastery.OnEvent("Click", (*) => getEatFruitSetting())
    
    ; Hotkeys
    settingsGui.SetFont("s10 bold c" COLORS.textBright)
    settingsGui.Add("Text", "x35 y535", "Macro Hotkeys")
    settingsGui.SetFont("s9 c" COLORS.text)
    settingsGui.AddGroupBox("x35 y555 w480 h85 Background" COLORS.cardBg " c" COLORS.border, "")
    settingsGui.Add("Text", "x45 y570 c" COLORS.textDim, "Start")
    startModeSetting := settingsGui.AddHotkey("x120 y568 w90")
    settingsGui.Add("Text", "x230 y570 c" COLORS.textDim, "Pause")
    pauseModeSetting := settingsGui.AddHotkey("x305 y568 w90")
    settingsGui.Add("Text", "x415 y570 c" COLORS.textDim, "Exit")
    exitModeSetting := settingsGui.AddHotkey("x470 y568 w90")
    
    ; ═══════════════════════════════════════════════════
    ; TAB 2: UPGRADES
    ; ═══════════════════════════════════════════════════
    
    tabControl.UseTab(2)
    
    ; Golden Pets
    settingsGui.SetFont("s10 bold c" COLORS.textBright)
    settingsGui.Add("Text", "x35 y135", "Golden Pets")
    settingsGui.SetFont("s9 c" COLORS.text)
    settingsGui.AddGroupBox("x35 y155 w230 h95 Background" COLORS.cardBg " c" COLORS.border, "")
    settingsGui.Add("Text", "x45 y170 c" COLORS.textDim, "Pets Needed for Upgrade")
    numberPetsToMakeGoldenSetting := settingsGui.AddDropDownList("x45 y188 w210 Background" COLORS.inputBg, [10, 9, 8])
    checkPetsMasteryGolden := settingsGui.AddButton("x45 y218 w210", "Check Mastery Status")
    checkPetsMasteryGolden.OnEvent("Click", (*) => getGoldenPetsRequiredForUpgrade())
    
    ; Rainbow Pets
    settingsGui.SetFont("s10 bold c" COLORS.textBright)
    settingsGui.Add("Text", "x35 y265", "Rainbow Pets")
    settingsGui.SetFont("s9 c" COLORS.text)
    settingsGui.AddGroupBox("x35 y285 w230 h95 Background" COLORS.cardBg " c" COLORS.border, "")
    settingsGui.Add("Text", "x45 y300 c" COLORS.textDim, "Pets Needed for Upgrade")
    numberPetsToMakeRainbowSetting := settingsGui.AddDropDownList("x45 y318 w210 Background" COLORS.inputBg, [10, 9, 8])
    checkPetsMasteryRainbow := settingsGui.AddButton("x45 y348 w210", "Check Mastery Status")
    checkPetsMasteryRainbow.OnEvent("Click", (*) => getRainbowPetsRequiredForUpgrade())
    
    ; Potions
    settingsGui.SetFont("s10 bold c" COLORS.textBright)
    settingsGui.Add("Text", "x285 y135", "Potion Upgrades")
    settingsGui.SetFont("s9 c" COLORS.text)
    settingsGui.AddGroupBox("x285 y155 w230 h155 Background" COLORS.cardBg " c" COLORS.border, "")
    settingsGui.Add("Text", "x295 y170 c" COLORS.textDim, "Potions Needed")
    numberPotionsToUpgradeSetting := settingsGui.AddDropDownList("x295 y188 w210 Background" COLORS.inputBg, [5, 4, 3])
    checkPotionsMastery := settingsGui.AddButton("x295 y218 w210", "Check Mastery Status")
    checkPotionsMastery.OnEvent("Click", (*) => getPotionsRequiredForUpgrade())
    settingsGui.Add("Text", "x295 y253 c" COLORS.textDim, "Potions to Upgrade (| separated)")
    potionsToUpgradeSetting := settingsGui.AddEdit("x295 y271 w210 r2 Background" COLORS.inputBg " c" COLORS.text, "")
    
    ; Enchants
    settingsGui.SetFont("s10 bold c" COLORS.textBright)
    settingsGui.Add("Text", "x535 y135", "Enchant Upgrades")
    settingsGui.SetFont("s9 c" COLORS.text)
    settingsGui.AddGroupBox("x535 y155 w210 h155 Background" COLORS.cardBg " c" COLORS.border, "")
    settingsGui.Add("Text", "x545 y170 c" COLORS.textDim, "Enchants Needed")
    numberEnchantsToUpgradeSetting := settingsGui.AddDropDownList("x545 y188 w190 Background" COLORS.inputBg, [7, 6, 5])
    checkEnchantsMastery := settingsGui.AddButton("x545 y218 w190", "Check Mastery Status")
    checkEnchantsMastery.OnEvent("Click", (*) => getEnchantsRequiredForUpgrade())
    settingsGui.Add("Text", "x545 y253 c" COLORS.textDim, "Enchants to Upgrade (| sep.)")
    enchantsToUpgradeSetting := settingsGui.AddEdit("x545 y271 w190 r2 Background" COLORS.inputBg " c" COLORS.text, "")
    
    ; ═══════════════════════════════════════════════════
    ; TAB 3: BREAKABLES
    ; ═══════════════════════════════════════════════════
    
    tabControl.UseTab(3)
    
    settingsGui.SetFont("s10 bold c" COLORS.textBright)
    settingsGui.Add("Text", "x35 y135", "Breakables Configuration")
    settingsGui.SetFont("s9 c" COLORS.text)
    settingsGui.AddGroupBox("x35 y155 w710 h360 Background" COLORS.cardBg " c" COLORS.border, "")
    
    ; Column 1
    settingsGui.Add("Text", "x50 y180 c" COLORS.textDim, "Piñatas (5-30)")
    breakPinatasSetting := settingsGui.AddSlider("x175 y177 w150 Range5-30 ToolTipTop TickInterval5")
    
    settingsGui.Add("Text", "x50 y220 c" COLORS.textDim, "Lucky Blocks (5-30)")
    breakLuckyBlocksSetting := settingsGui.AddSlider("x175 y217 w150 Range5-30 ToolTipTop TickInterval5")
    
    settingsGui.Add("Text", "x50 y260 c" COLORS.textDim, "Coin Jars (5-30)")
    breakBasicCoinJarsSetting := settingsGui.AddSlider("x175 y257 w150 Range5-30 ToolTipTop TickInterval5")
    
    settingsGui.Add("Text", "x50 y300 c" COLORS.textDim, "Comets (5-30)")
    breakCometsSetting := settingsGui.AddSlider("x175 y297 w150 Range5-30 ToolTipTop TickInterval5")
    
    settingsGui.Add("Text", "x50 y340 c" COLORS.textDim, "Mini Chests (30-60)")
    breakMiniChestsSetting := settingsGui.AddSlider("x175 y337 w150 Range30-60 ToolTipTop TickInterval5")
    
    ; Column 2
    settingsGui.Add("Text", "x390 y180 c" COLORS.textDim, "Breakables (30-60)")
    breakBreakablesSetting := settingsGui.AddSlider("x540 y177 w150 Range30-60 ToolTipTop TickInterval5")
    
    settingsGui.Add("Text", "x390 y220 c" COLORS.textDim, "Diamond Break. (30-60)")
    breakDiamondBreakablesSetting := settingsGui.AddSlider("x540 y217 w150 Range30-60 ToolTipTop TickInterval5")
    
    settingsGui.Add("Text", "x390 y260 c" COLORS.textDim, "Superior Chests (30-60)")
    breakSuperiorMiniChestsSetting := settingsGui.AddSlider("x540 y257 w150 Range30-60 ToolTipTop TickInterval5")
    
    settingsGui.Add("Text", "x390 y300 c" COLORS.textDim, "Earn Diamonds (30-60)")
    earnDiamondsSetting := settingsGui.AddSlider("x540 y297 w150 Range30-60 ToolTipTop TickInterval5")
    
    ; Flags
    settingsGui.SetFont("s10 bold c" COLORS.textBright)
    settingsGui.Add("Text", "x35 y530", "Flag Configuration")
    settingsGui.SetFont("s9 c" COLORS.text)
    settingsGui.AddGroupBox("x35 y550 w710 h75 Background" COLORS.cardBg " c" COLORS.border, "")
    settingsGui.Add("Text", "x50 y570 c" COLORS.textDim, "Quest Flag")
    questFlagSetting := settingsGui.AddDropDownList("x150 y568 w180 Background" COLORS.inputBg, 
        ["Coins Flag", "Diamonds Flag", "Hasty Flag", "Magnet Flag"])
    settingsGui.Add("Text", "x390 y570 c" COLORS.textDim, "Best Area Flag")
    bestAreaFlagSetting := settingsGui.AddDropDownList("x510 y568 w180 Background" COLORS.inputBg, 
        ["Coins Flag", "Diamonds Flag", "Fortune Flag", "Hasty Flag", "Magnet Flag"])
    
    ; ═══════════════════════════════════════════════════
    ; TAB 4: KEYBINDS
    ; ═══════════════════════════════════════════════════
    
    tabControl.UseTab(4)
    
    ; Flags
    settingsGui.SetFont("s10 bold c" COLORS.textBright)
    settingsGui.Add("Text", "x35 y135", "Flag Keybinds")
    settingsGui.SetFont("s9 c" COLORS.text)
    settingsGui.AddGroupBox("x35 y155 w710 h95 Background" COLORS.cardBg " c" COLORS.border, "")
    settingsGui.Add("Text", "x50 y175 w70 c" COLORS.textDim, "Hasty")
    kbHastyFlag := settingsGui.AddHotkey("x125 y173 w90")
    settingsGui.Add("Text", "x235 y175 w70 c" COLORS.textDim, "Coins")
    kbCoinsFlag := settingsGui.AddHotkey("x310 y173 w90")
    settingsGui.Add("Text", "x420 y175 w70 c" COLORS.textDim, "Diamonds")
    kbDiamondsFlag := settingsGui.AddHotkey("x495 y173 w90")
    settingsGui.Add("Text", "x605 y175 w70 c" COLORS.textDim, "Magnet")
    kbMagnetFlag := settingsGui.AddHotkey("x665 y173 w70")
    
    settingsGui.Add("Text", "x50 y215 w70 c" COLORS.textDim, "Fortune")
    kbFortuneFlag := settingsGui.AddHotkey("x125 y213 w90")
    
    ; Breakables
    settingsGui.SetFont("s10 bold c" COLORS.textBright)
    settingsGui.Add("Text", "x35 y265", "Breakable Keybinds")
    settingsGui.SetFont("s9 c" COLORS.text)
    settingsGui.AddGroupBox("x35 y285 w710 h55 Background" COLORS.cardBg " c" COLORS.border, "")
    settingsGui.Add("Text", "x50 y305 w70 c" COLORS.textDim, "Lucky Block")
    kbLuckyBlock := settingsGui.AddHotkey("x125 y303 w90")
    settingsGui.Add("Text", "x235 y305 w70 c" COLORS.textDim, "Coin Jar")
    kbCoinJar := settingsGui.AddHotkey("x310 y303 w90")
    settingsGui.Add("Text", "x420 y305 w70 c" COLORS.textDim, "Comet")
    kbComet := settingsGui.AddHotkey("x495 y303 w90")
    settingsGui.Add("Text", "x605 y305 w70 c" COLORS.textDim, "Piñata")
    kbPinata := settingsGui.AddHotkey("x665 y303 w70")
    
    ; Potions
    settingsGui.SetFont("s10 bold c" COLORS.textBright)
    settingsGui.Add("Text", "x35 y355", "Potion Keybinds")
    settingsGui.SetFont("s9 c" COLORS.text)
    settingsGui.AddGroupBox("x35 y375 w710 h95 Background" COLORS.cardBg " c" COLORS.border, "")
    settingsGui.Add("Text", "x50 y395 w70 c" COLORS.textDim, "Tier I")
    kbCoins1 := settingsGui.AddHotkey("x125 y393 w90")
    settingsGui.Add("Text", "x235 y395 w70 c" COLORS.textDim, "Tier II")
    kbCoins2 := settingsGui.AddHotkey("x310 y393 w90")
    settingsGui.Add("Text", "x420 y395 w70 c" COLORS.textDim, "Tier III")
    kbCoins3 := settingsGui.AddHotkey("x495 y393 w90")
    settingsGui.Add("Text", "x605 y395 w70 c" COLORS.textDim, "Tier IV")
    kbCoins4 := settingsGui.AddHotkey("x665 y393 w70")
    
    settingsGui.Add("Text", "x50 y435 w70 c" COLORS.textDim, "Tier V")
    kbCoins5 := settingsGui.AddHotkey("x125 y433 w90")
    
    ; Other
    settingsGui.SetFont("s10 bold c" COLORS.textBright)
    settingsGui.Add("Text", "x35 y485", "Other Keybinds")
    settingsGui.SetFont("s9 c" COLORS.text)
    settingsGui.AddGroupBox("x35 y505 w710 h55 Background" COLORS.cardBg " c" COLORS.border, "")
    settingsGui.Add("Text", "x50 y525 w80 c" COLORS.textDim, "Sprinkler")
    kbSprinkler := settingsGui.AddHotkey("x135 y523 w90")
    settingsGui.Add("Text", "x245 y525 w110 c" COLORS.textDim, "Supercomputer")
    kbSupercomputer := settingsGui.AddHotkey("x360 y523 w90")
    
    tabControl.UseTab()
    
    ; ═══════════════════════════════════════════════════
    ; BOTTOM BUTTONS
    ; ═══════════════════════════════════════════════════
    
    saveButton := settingsGui.AddButton("x15 y670 w150 h35", "💾 Save && Close")
    saveButton.OnEvent("Click", (*) => savePlayerSettings())
    
    resetButton := settingsGui.AddButton("x+10 yp w150 h35", "🔄 Reset to Defaults")
    resetButton.OnEvent("Click", (*) => resetSettings())
    
    cancelButton := settingsGui.AddButton("x+10 yp w150 h35", "❌ Cancel")
    cancelButton.OnEvent("Click", (*) => closeSettings())
    
    tier1PotionToUseSetting := "Coins Potion I"
    tier2PotionToUseSetting := "Coins Potion II" 
    tier3PotionToUseSetting := "Coins Potion III"
    tier4PotionToUseSetting := "Coins Potion IV"
    tier5PotionToUseSetting := "Coins Potion V"
}

resetSettings() {
    accountNameSetting.Value := ""
    startModeSetting.Value := ""
    pauseModeSetting.Value := ""
    exitModeSetting.Value := ""
    bestZoneSetting.Text := 239
    numberOfLoopsSetting.Value := 20
    do1StarQuestsSetting.Value := true
    do2StarQuestsSetting.Value := true
    do3StarQuestsSetting.Value := true
    do4StarQuestsSetting.Value := true
    eatFruitSetting.Value := true
    gamepassAutoFarmSetting.Value := false
    gamepassVipSetting.Value := false
    gamepassDoubleStarsSetting.Value := false
    gamepassSuperDropsSetting.Value := false
    vipUseFlagSetting.Value := true
    vipUseSprinklerSetting.Value := true
    eggsAtOnceSetting.Value := 50
    shinyHoverboardSetting.Value := false
    reconnectAfterLoopsCompleteSetting.Value := true
    reconnectionTimeSecondsSetting.Value := 60
    privateServerLinkCodeSetting.Value := ""
    numberPetsToMakeGoldenSetting.Text := 10
    numberPetsToMakeRainbowSetting.Text := 10
    numberPotionsToUpgradeSetting.Text := 5
    potionsToUpgradeSetting.Value := "Coins Potion II|Damage Potion II|Diamonds Potion II|Lucky Eggs Potion II|Treasure Hunter Potion II"
    numberEnchantsToUpgradeSetting.Text := 7
    enchantsToUpgradeSetting.Value := "Coins II|Criticals II|Diamonds II|Lucky Eggs II|Magnet II|Speed II|Strong Pets II|Tap Power II|Treasure Hunter II"
    breakPinatasSetting.Value := 20
    breakLuckyBlocksSetting.Value := 20
    breakBasicCoinJarsSetting.Value := 20
    breakCometsSetting.Value := 20
    breakMiniChestsSetting.Value := 30
    breakBreakablesSetting.Value := 30
    breakDiamondBreakablesSetting.Value := 30
    breakSuperiorMiniChestsSetting.Value := 30
    earnDiamondsSetting.Value := 30
    hasSupercomputerRadioSetting.Value := false
    questFlagSetting.Text := "Coins Flag"
    bestAreaUseFlagSetting.Value := false
    bestAreaFlagSetting.Text := "Hasty Flag"
    bestAreaUseSprinklerSetting.Value := false
}

openSettingsGui(*) {
    global
    if SETTINGS_GUI_VISIBLE {
        settingsGui.Hide()
        SETTINGS_GUI_VISIBLE := false
    }
    else {
        settingsGui.Show("w780 h720")
        mainGui.GetPos(&mainX, &mainY, &mainW, &mainH)
        newX := mainX
        newY := (mainY + mainH - 8)
        settingsGui.Move(newX, newY)
        SETTINGS_GUI_VISIBLE := true
    }
}

closeSettings() {
    global
    SETTINGS_GUI_VISIBLE := false  
    settingsGui.Hide()
}
