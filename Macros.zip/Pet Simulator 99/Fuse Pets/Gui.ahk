#Requires AutoHotkey v2.0
#SingleInstance Force

; ========== COLOR SCHEME ==========
global COLORS := {
    bg: "0x0a0e14",
    bgLight: "0x13171d",
    card: "0x161b22",
    cardHover: "0x1c2128",
    accent: "0xd29922",
    accentHover: "0x2ea043",
    accentAlt: "0x1f6feb",
    text: "0xe6edf3",
    textDim: "0x7d8590",
    border: "0x21262d",
    success: "0x238636",
    warning: "0xd29922",
    danger: "0xda3633"
}

; ========== CONSTANTS ==========
FRUIT_DELAY_MINIMUM := 5
FRUIT_DELAY_MAXIMUM := 30
VENDING_DELAY_MINIMUM := 5
VENDING_DELAY_MAXIMUM := 30
RECONNECT_DELAY_MINIMUM := 30
RECONNECT_DELAY_MAXIMUM := 240

EXCLUSION_GUIS := []

ICON_FOLDER := A_ScriptDir "\Assets\Icons\"

ICON_MAP := Map(
    "Application", {icon: "Application.ico"},
    "AdoptMe", {icon: "AdoptMe.ico"},
    "Discord", {icon: "Discord.ico"},
    "Donate", {icon: "Donate.ico"},
    "PlayPause", {icon: "PlayPause.ico"},
    "PsychoHatcher", {icon: "AHKvault.ico"},
    "Roblox", {icon: "Roblox.ico"}
)

; ========== GLOBAL VARIABLES ==========
global mainGui := {}
global logoPath := A_ScriptDir "\logo.png"
global iconPath := A_ScriptDir "\Icon.png"

; ========== SET TRAY ICON ==========
SetTrayIcon() {
    if FileExist(iconPath) {
        try {
            TraySetIcon(iconPath)
        }
    }
}

SetTrayIcon()

; ========== DISPLAY MAIN GUI ==========
displayMainGui() {
    global mainGui, COLORS, logoPath

    mainGui := Gui("-Resize +Border")
    mainGui.Title := "AHK Vault - Fuse Pets"
    mainGui.BackColor := COLORS.bg
    mainGui.SetFont("s9 c" COLORS.text, "Segoe UI")

    ; ========== HEADER ==========
    mainGui.Add("Text", "x0 y0 w420 h70 Background" COLORS.accent)
    
    ; Add logo
    if FileExist(logoPath) {
        try {
            mainGui.Add("Picture", "x15 y15 w40 h40 BackgroundTrans", logoPath)
            headerText := mainGui.Add("Text", "x65 y18 w340 h50 c" COLORS.text " BackgroundTrans", "Fuse Pets")
            headerText.SetFont("s16 bold")
            subText := mainGui.Add("Text", "x65 y45 w340 h50 c" COLORS.text " BackgroundTrans", "AHK Vault")
        } catch {
            headerText := mainGui.Add("Text", "x20 y18 w380 h50 c" COLORS.text " BackgroundTrans", "Fuse Pets")
            headerText.SetFont("s16 bold")
            subText := mainGui.Add("Text", "x20 y45 w380 h50 c" COLORS.text " BackgroundTrans", "AHK Vault")
        }
    } else {
        headerText := mainGui.Add("Text", "x20 y18 w380 h50 c" COLORS.text " BackgroundTrans", "Fuse Pets")
        headerText.SetFont("s16 bold")
        subText := mainGui.Add("Text", "x20 y45 w380 h50 c" COLORS.text " BackgroundTrans", "AHK Vault")
    }
    subText.SetFont("s9")

    ; ========== PET SELECTION SECTION ==========
    yPos := 90
    mainGui.Add("Text", "x20 y" yPos " w380 c" COLORS.text, "Pet Selection").SetFont("s10 bold")
    mainGui.Add("Text", "x20 y" (yPos + 22) " w380 h1 Background" COLORS.border)
    
    yPos += 35
    
    mainGui.Add("Text", "x30 y" (yPos + 5) " w350 c" COLORS.textDim, "Choose the pet to fuse:")
    
    yPos += 30
    
    mainGui.Add("Edit", "x30 y" yPos " w360 h50 vMyInput Background" COLORS.bgLight " c" COLORS.text)

    ; ========== CONTROL BUTTONS ==========
    yPos += 75
    mainGui.Add("Text", "x20 y" yPos " w380 h1 Background" COLORS.border)
    
    yPos += 20
    
    startBtn := mainGui.Add("Button", "x30 y" yPos " w165 h40 Background" COLORS.success, "Start")
    startBtn.SetFont("s10 bold")
    
    pauseBtn := mainGui.Add("Button", "x215 y" yPos " w85 h40 Background" COLORS.warning, "Pause")
    pauseBtn.SetFont("s10 bold")
    pauseBtn.OnEvent("Click", pauseMacro)
    
    exitBtn := mainGui.Add("Button", "x320 y" yPos " w70 h40 Background" COLORS.danger, "Exit")
    exitBtn.SetFont("s10 bold")
    exitBtn.OnEvent("Click", exitMacro)

    ; ========== HELP MENU ==========
    helpMenu := Menu()
    helpMenu.Add("How To", (*) => openHowTo())
    helpMenu.Add()
    helpMenu.Add("Discord", (*) => openDiscord())
    helpMenu.Add("Website", (*) => openWebsite())
    helpMenu.Add()
    helpMenu.Add("Donate", (*) => openDonate())
    helpMenu.Add()
    helpMenu.Add("Reload", (*) => reloadMacro())
    
    if FileExist(ICON_FOLDER "Discord.ico")
        helpMenu.SetIcon("Discord", ICON_FOLDER ICON_MAP["Discord"].icon)
    if FileExist(ICON_FOLDER "AHKvault.ico")
        helpMenu.SetIcon("Website", ICON_FOLDER ICON_MAP["PsychoHatcher"].icon)
    if FileExist(ICON_FOLDER "Donate.ico")
        helpMenu.SetIcon("Donate", ICON_FOLDER ICON_MAP["Donate"].icon)
    
    try helpMenu.SetIcon("How To", "imageres.dll", 95)
    try helpMenu.SetIcon("Reload", "imageres.dll", 239)
       
    MyMenuBar := MenuBar()
    MyMenuBar.Add("&Help", helpMenu)
    mainGui.MenuBar := MyMenuBar

    ; ========== INFO SECTION ==========
    yPos += 55
    mainGui.Add("Text", "x20 y" yPos " w380 h1 Background" COLORS.border)
    
    yPos += 15
    infoText := mainGui.Add("Text", "x30 y" yPos " w360 c" COLORS.textDim " Center", 
        "💡 Need help? Check the Help menu above")
    infoText.SetFont("s8")

    ; ========== SHOW GUI ==========
    mainGui.OnEvent("Close", (*) => ExitApp())
    guiHeight := yPos + 30
    mainGui.Show("w420 h" guiHeight)
    
    ; Center window at top of screen
    CenterWindow(mainGui)
}

; ========== HELPER FUNCTIONS ==========
CenterWindow(GuiObj) {
    MonitorGet(MonitorGetPrimary(), &Left, &Top, &Right, &Bottom)
    WinGetPos(, , &w, &h, GuiObj)
    x := Left + (Right - Left - w) // 2
    y := Top + 50
    WinMove(x, y, , , GuiObj)
}

pauseMacro(*) { 
    Pause -1 
}

exitMacro(*) {
    ExitApp
}

openHowTo(*) {
    Run "https://docs.google.com/document/d/1Z3_9i0TE8WTX0J5o9iwnJ1ybOJ7LFtKeuhTpcumtHXk/edit?tab=t.0"
}

openDiscord(*) {
    Run "https://discord.gg/xVmSTVxQt9"
}

openWebsite(*) {
    Run ""
}

openDonate(*) {
    Run ""
}

reloadMacro(*) {
    Reload
}