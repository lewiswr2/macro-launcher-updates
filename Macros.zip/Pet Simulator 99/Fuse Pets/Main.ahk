﻿#Requires AutoHotkey v2.0
#include Gui.ahk

; -----------------------------
; COORD MODES (your coords are Screen coords)


; -----------------------------
; GLOBAL CONSTANTS / PIXELS
; Must be ABOVE hotkeys
; -----------------------------
global ROBLOX_EXE := "ahk_exe RobloxPlayerBeta.exe"
global ROBLOX_W := 800
global ROBLOX_H := 600

global JOURNAL_CLOSE_BUTTON := { x: 772, y: 122, colour: 0xD82A3F }

; confirmed gray-visible color from your screenshots
global NO_BUTTON := { x: 133, y: 436, colour: 0xA9ACC1 }

; leaderboard detection (if seen, press Tab)
global LEADERBOARD := { x: 537, y: 77, colour: 0x121215 }

; -----------------------------
; GUI (show first, do nothing else)
; -----------------------------
displayMainGui()
EnsureRoblox800x600()
   CheckLeaderboard()
; -----------------------------
; HOTKEYS (auto-execute ends here)
; -----------------------------
f1::startMacro()
f2::togglePause()     ; renamed to avoid Gui.ahk conflicts
f3::ExitApp

; Debug: read NO_BUTTON pixel color
f6::{
    global NO_BUTTON
    c := PixelGetColor(NO_BUTTON.x, NO_BUTTON.y)
    MsgBox "PixelGetColor at (" NO_BUTTON.x "," NO_BUTTON.y "): " Format("0x{:06X}", c)
}

; -----------------------------
; FUNCTIONS
; -----------------------------
togglePause() {
    Pause -1
}

EnsureRoblox800x600() {
    global ROBLOX_EXE, ROBLOX_W, ROBLOX_H

    if !WinExist(ROBLOX_EXE)
        return false

    WinActivate ROBLOX_EXE
    WinWaitActive ROBLOX_EXE, , 2

    ; center 800x600
    x := (A_ScreenWidth - ROBLOX_W) // 2
    y := (A_ScreenHeight - ROBLOX_H) // 2
    WinMove x, y, ROBLOX_W, ROBLOX_H, ROBLOX_EXE
    Sleep 150
    return true
}

CheckLeaderboard() {
    global LEADERBOARD
    c := PixelGetColor(LEADERBOARD.x, LEADERBOARD.y)
    if (c = LEADERBOARD.colour) {
        SendEvent "{Tab}"
        Sleep 150
        return true
    }
    return false
}

startMacro() {
    global mainGui

    ; --- Do these AFTER mainGui, BEFORE any macro logic ---
    if !EnsureRoblox800x600() {
        MsgBox "Roblox isn't running (RobloxPlayerBeta.exe)."
        return
    }
    CheckLeaderboard()

    ; --- Macro logic begins here ---
    SendEvent "{Click 113 333}"
    CheckSuperOpen()
    SendEvent "{Click 691 412}"
    Sleep 500

    Loop {
        ; (optional) keep closing it if it pops up again
        CheckLeaderboard()

        SendEvent "{Click 662 97}"
        SendText mainGui["MyInput"].Value
        Sleep 500

        if !CheckIF3()
            continue
    }
}

CheckSuperOpen() {
    global JOURNAL_CLOSE_BUTTON
    s := JOURNAL_CLOSE_BUTTON

    Loop 10 {
        c := PixelGetColor(s.x, s.y)
        if (c = s.colour)
            return true
        Sleep 100
    }
    return false
}

CheckIF3() {
    global NO_BUTTON

    clicks := [
        [347, 203],
        [475, 211],
        [567, 197],
        [659, 203],
        [375, 313]
    ]

    for _, pt in clicks {
        ; close leaderboard if it appears mid-run
        CheckLeaderboard()

        cx := pt[1], cy := pt[2]

        ; select zone N
        SendEvent "+{Click " cx " " cy "}"
        Sleep 250

        ; gray check at fixed pixel
        c := PixelGetColor(NO_BUTTON.x, NO_BUTTON.y)
        if (c = NO_BUTTON.colour) {
            ; gray seen -> deselect -> next zone
            Sleep 100
            SendEvent "+{Click " cx " " cy "}"
            Sleep 150
            continue
        }

        ; not gray -> fallback -> restart startMacro loop body
        SendEvent "{Click 238 403}"
        Sleep 1000
        SendEvent "{Click 403 429}"
        Sleep 1000
        return false
    }

    return true
}
