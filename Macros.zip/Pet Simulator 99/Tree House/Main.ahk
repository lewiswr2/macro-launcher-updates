﻿#Requires AutoHotkey v2.0  ; Ensures the script runs only on AutoHotkey version 2.0, which supports the syntax and functions used in this script.

; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
; TREE HOUSE - AutoHotKey 2.0 Macro for Pet Simulator 99
; Written by waktool
; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
; DIRECTIVES & CONFIGURATIONS
; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

#SingleInstance Force  ; Forces the script to run only in a single instance. If this script is executed again, the new instance will replace the old one.
CoordMode "Mouse", "Client"  ; Sets the coordinate mode for mouse functions (like Click, MouseMove) to be relative to the active window's client area, ensuring consistent mouse positioning across different window states.
CoordMode "Pixel", "Client"  ; Sets the coordinate mode for pixel functions (like PixelSearch, PixelGetColor) to be relative to the active window's client area, improving accuracy in color detection and manipulation.
SetMouseDelay 10  ; Sets the delay between mouse events to 10 milliseconds, balancing speed and reliability of automated mouse actions.
#NoTrayIcon

; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
; LIBRARIES
; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

; Third-party Libraries:
#Include <OCR>
#Include <JXON>
#Include <Pin>

; Macro Related Libraries:
#Include "%A_ScriptDir%\Modules"
#Include Maps.ahk
#Include LeaderboardMenu.ahk
#Include Teleport.ahk
#Include Zones.ahk
#Include RobloxMenu.ahk
#Include HtmlLog.ahk

; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
; GLOBAL VARIABLES
; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

; Macro details.
MACRO_TITLE := "Tree House"  ; The title displayed in main GUI elements.
MACRO_VERSION := "0.4.0"  ; Script version, helpful for user support and debugging.

; API settings.
URL_RAP_API := "https://biggamesapi.io/api/rap"

; File settings.
RAP_JSON := A_ScriptDir "\Assets\rap.json"
LOG_FOLDER := ""
PRIORITY_TXT := A_ScriptDir "\priority.cfg"
SETTINGS_INI := A_ScriptDir "\Settings.ini"  ; Path to settings INI file.

ICON_FOLDER := A_ScriptDir "\a9f3d4b7e2c6a1f8b5d7e9c2a4f6b3d1e8c7a2f9b4d5e3c1a7f6b8d2e4c5a1f7b9e\"

ICON_MAP := Map(
    "Application", {icon: "c7d1e8f3a4b2f5e6c9a3b7d8e2c1f4a5b9e7d6c2a8f3b4d1e5f6a9c2b3d7e4f8a"},
    "Discord", {icon: "4a5c9e1b3f7d2e6c8a4b9f1d3c2e7b8a6d1f5c4b7e9a3d6f2b8c1e4a5f7d3b9e2"},
    "Donate", {icon: "9e3d7c1b2a6f8e4c3d5b9f2a7e6c1b4f3d8a2c5b7e9f1a4d6c3b8e2f5a7c9d4b1"},
    "PlayPause", {icon: "d2b8c5a4f9e1d3b7c6a8f2e9d4c3b1e7a6f5d9c2b3e4a1f7c8d6b9e2a5f4c1b7e"},
    "Font", {icon: "a59dc00c579f7baed19740d2efdadf02134da96daa2ef125e302fa3112e50aa0"},
    "PsychoHatcher", {icon: "a7f2c3d9b4e6a1f8c2b5d7e4c9a3f6b1d8e2c5a4b7f9d1e3c6b8a2f5d9c4e1b7f"}
)

; Replacement fonts.
TIMES_NEW_ROMAN := A_ScriptDir "\Assets\TimesNewRoman.ttf"  ; Path to Times New Roman font.
FREDOKA_ONE_REGULAR := A_ScriptDir "\Assets\FredokaOne-Regular.ttf"  ; Path to Fredoka One Regular font.

START_MACRO := getSetting("startMacroKey")
PAUSE_MACRO := getSetting("pauseMacroKey")
EXIT_MACRO := getSetting("exitMacroKey")

; Other settings.
LOG_DATE := FormatTime(A_Now, "yyyy-MM-dd")
ONE_SECOND := 1000

; Define the setting for changing worlds after a certain number of times opened.
CHANGE_WORLDS_AFTER_TIMES_OPENED := getSetting("ChangeWorldsAfterTimesOpened")

; Define a map for menu pixel positions and colors.
MENU_PIXEL := Map(
    "CHAT_ICON_WHITE", Map("START", [81, 24], "END", [81, 24], "COLOUR", "0xFFFFFF", "TOLERANCE", 2),
    "LEADERBOARD_RANK_STAR", Map("START", [652, 43], "END", [678, 59], "COLOUR", "0xB98335", "TOLERANCE", 50)
)

; Define a map for tree house pixel positions and colors.
TREE_HOUSE_PIXEL := Map(
    "TREE_BRANCH", Map("START", [359, 9], "END", [359, 9], "COLOUR", "0x6B5AB9", "TOLERANCE", 2)
)

SECRET_KEY_RAP := 0

ITEM_IMAGE_FOLDER := A_ScriptDir "\Assets\Images\Items\"

; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
; MACRO
; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

runMacro()

runMacro() {
    activateRoblox() 
    CheckForBGFup()
    completeInitialisationTasks()
    activateRoblox()
    global SECRET_KEY_RAP := updateRap()
    updatePriority()
    displayMainGui()
    initialiseHtmlLogFile()
    openHtmlLogFile()    
}

startMacro(*) {
    activateRoblox()  ; Ensure the Roblox window is active again.

    loop {
        CheckForBGFup()
        closeLeaderboard()  ; Close the leaderboard if it's open.
        closeChatLog()  ; Close the chat log if it's open.
        travelToTree()

        loop CHANGE_WORLDS_AFTER_TIMES_OPENED {
            
            ; Determine movement keys based on the iteration index.
            keyMoveTowardsTree := A_Index == 1 ? "w" : "s"
            keyMoveAwayFromTree := A_Index == 1 ? "s" : "w"

            maxLoops := 5
            loop maxLoops {
                if useSecretKey(keyMoveTowardsTree, keyMoveAwayFromTree)
                    break

                updateStatus("Failed to unlock tree house")
                travelToZone15()  ; Travel to Zone 15.
                moveToTree()  ; Move to the tree.
            }
            
            ; Check if the secret key was not consumed.
            loop 50 {
                updateStatus("Checking if key was consumed")
                SendEvent "{Click, 400, 300, 1}"  ; Click in the middle of the screen to remove the mastery.
                Sleep 10  ; Wait 10 milliseconds before the next check.
                if isSecretKeyNotConsumed() {
                    STATS_MAP["3_keys_not_consumed"].value++  ; Increment the count of keys not consumed.
                    STATS_MAP["2_keys_used"].value--  ; Decrement the count of keys used.
                    break  ; Exit the loop if the secret key was not consumed.
                }
            }
            
            ; Update the RAP value for the keys.
            STATS_MAP["4_keys_rap"].value := STATS_MAP["2_keys_used"].value * SECRET_KEY_RAP

            ; Log the usage of the key.
            writeToActivityLog("--------------------------------------------------")
            writeToActivityLog("Key " STATS_MAP["1_times_opened"].value " (Consumed: " STATS_MAP["2_keys_used"].value 
                . " | Not Consumed: " STATS_MAP["3_keys_not_consumed"].value 
                . " | Key RAP: " STATS_MAP["4_keys_rap"].value ")")

            ; Added in case key is used but entering the tree house fails.
            maxLoops := 5
            loop maxLoops {
                if enterTreeHouse(keyMoveTowardsTree, keyMoveAwayFromTree)
                    break

                updateStatus("Failed to enter tree house")
                travelToZone15()
                moveToTree()
            }

            walkToMerchant()  ; Walk to the merchant.
            scanItems()  ; Scan items in the tree house.
            bestIndex := getBestIndex()  ; Get the index of the best item.
            clickBestItem(bestIndex)  ; Click the best item.

            ; Update the balance based on RAP values.
            STATS_MAP["6_balance"].value := STATS_MAP["5_total_rap"].value - STATS_MAP["4_keys_rap"].value

            ; Log the choices made.
            writeToActivityLog("Best: " bestIndex ": " CHOICE_MAP[bestIndex].itemName " ("
                . "Priority: " CHOICE_MAP[bestIndex].priority " | XP: " CHOICE_MAP[bestIndex].xp " | RAP: " CHOICE_MAP[bestIndex].rap ")")
            writeToActivityLog("Totals: Minimum RAP: " STATS_MAP["5_total_rap"].value .
                " | Balance: " STATS_MAP["6_balance"].value " | Minimum XP: " STATS_MAP["7_total_xp"].value)

            exitTreeHouse()  ; Exit the tree house.
            
            htmlMessage := addImagesToHtml(bestIndex)
            updateHtmlLog(htmlMessage, STATS_MAP["1_times_opened"].value)

            Sleep 1000  ; Sleep for 1000 milliseconds to prevent game issues with secret keys.
                        ; Note: This delay is to prevent secret keys from being used too quickly.
                        ; If you go too fast, the free buttons in the merchant are disabled and do not work.
        }

        reconnectClient()
        STATS_MAP["8_world_changes"].value++

    }
}

addImagesToHtml(bestIndex) {
    html := ""
    loop 3 {
        index := A_Index  ; Current loop index
        html .= getImageHtml(CHOICE_MAP[index], index = bestIndex)
    }
    return html
}

getImageHtml(choiceMap, isBest := false) {
    borderClass := isBest ? "class='selected-border'" : ""  ; Apply class only if bestIndex
    return "<img src='" ITEM_IMAGE_FOLDER choiceMap.image "' alt='" choiceMap.itemName "' title='" choiceMap.itemName "' " borderClass " style='width: 50px; height: 50px; object-fit: contain;'>"
}

; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
; GUI INITIALISATION
; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

displayMainGui() {
    global

    ; Initialize the main GUI with "AlwaysOnTop" property.
    mainGui := Gui("+AlwaysOnTop")
    mainGui.Title := MACRO_TITLE " v" MACRO_VERSION  ; Set the title incorporating global variables for title and version.
    mainGui.SetFont("s8", "Segoe UI")  ; Use "Segoe UI" font for a modern look.

    fileMenu := Menu()
    startText := "Start Macro`t" START_MACRO
    pauseText := "Pause Macro`t" PAUSE_MACRO
    exitText := "Exit Macro`t" EXIT_MACRO
    fileMenu.Add(startText, startMacro)
    fileMenu.Add()
    fileMenu.Add(pauseText, pauseMacro)
    fileMenu.Add("Reload Macro", reloadMacro)
    fileMenu.Add()
    fileMenu.Add(exitText, exitMacro)
    fileMenu.SetIcon(startText, "imageres.dll", 282)
    fileMenu.SetIcon(pauseText, ICON_FOLDER ICON_MAP["PlayPause"].icon)
    fileMenu.SetIcon("Reload Macro", "imageres.dll", 230)
    fileMenu.SetIcon(exitText, "imageres.dll", 94)

    toolsMenu := Menu()
    toolsMenu.Add("Reconnect", reconnectClient)
    toolsMenu.Add("Standard Font", changeToDefaultFont)
    toolsMenu.SetIcon("Reconnect", WinGetProcessPath("ahk_exe RobloxPlayerBeta.exe"), 1)
    toolsMenu.SetIcon("Standard Font", ICON_FOLDER ICON_MAP["Font"].icon)

    helpMenu := Menu()
    helpMenu.Add("How To", openHowTo)
    helpMenu.Add()
    helpMenu.Add("Discord", openDiscord)
    helpMenu.Add("Website", openWebsite)
    helpMenu.Add()
    helpMenu.Add("Donate", openDonate)

    
    MyMenuBar := MenuBar()
    MyMenuBar.Add("&File", fileMenu)
    MyMenuBar.Add("&Tools", toolsMenu)
    MyMenuBar.Add("&Help", helpMenu)
    mainGui.MenuBar := MyMenuBar

    ; Retrieve and adjust the GUI window position to the top right of the screen.
    WinGetClientPos &rX, &rY, &rW, &rH, "ahk_exe RobloxPlayerBeta.exe"
    mainGui.Show("x" rX -8 " y" rY - 82 "w300 h0 w" rW)
}


; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
; TREE HOUSE FUNCTIONS
; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰


exitTreeHouse() {
    homeButton := [400, 519]  ; Coordinates of the home button.

    ; loop to click the home button until the screen transitions.
    loop 100 {
        clickX := homeButton[1] + Random(-3, 3) 
        clickY := homeButton[2] + Random(-3, 3) 
        SendEvent "{Click, " clickX ", " clickY ", 1}"
        Sleep 10 
        if isTransitionScreen() 
            break
    }

    ; Wait for the transition screen to complete.
    loop 100 {
        if !isTransitionScreen() 
       

break
      
    }
    Sleep 7500
    ; Close the merchant window if it is open.
    if isMerchantWindowOpen()
        closeMerchantWindow()
        isTransitionScreen() 

}




useSecretKey(keyMoveTowardsTree, keyMoveAwayFromTree) {
    updateStatus("Using key")
    Send "{" keyMoveTowardsTree " down}"  ; Start moving towards the tree.

    ; loop to interact with the secret key until the interaction window opens.
    keyUsed := false
    maxLoops := 100
    loop maxLoops {
        updateStatus("Using key (" A_Index "/" maxLoops ")")
        SendEvent "{e}" 
        Sleep 10  ; Add a short delay to prevent excessive CPU usage.
        if isUseKeyWindowOpen() {
            keyUsed := true
            break
        }
                loop 100 {
        if !isTransitionScreen() 
            break 
        Sleep 10 
    }
    }
    Send "{" keyMoveTowardsTree " up}"  ; Stop moving towards the tree.

    if !keyUsed
        return false

    yesButton := [291, 422] 

    ; loop to click the "Yes" button until the interaction window closes.
    confirmed := false
    maxLoops := 250
    loop maxLoops {
        updateStatus("Clicking confirm use key button (" A_Index "/" maxLoops ")")
        ; Send a click event to the button coordinates with a slight random offset.
        clickX := yesButton[1] + Random(-3, 3)
        clickY := yesButton[2] + Random(-3, 3)
        SendEvent "{Click, " clickX ", " clickY ", 1}"
        Sleep 10  ; Add a short delay to prevent excessive CPU usage.
        if !isUseKeyWindowOpen() {
            confirmed := true
            break
        }
    }

    if !confirmed
        return false

    ; Update statistics.
    STATS_MAP["1_times_opened"].value++
    STATS_MAP["2_keys_used"].value++

    moveDirection(keyMoveAwayFromTree, 250)  ; Move away from the tree after the interaction.

    return true
}


enterTreeHouse(keyMoveTowardsTree, keyMoveAwayFromTree) {
    updateStatus("Entering the tree house")
    activateRoblox()  ; Ensure the Roblox window is active.

    moveDirection(keyMoveTowardsTree, 800)  ; Move towards the treehouse for an initial duration.

    ; Keep moving down until the screen transitions.
    transitioned := false
    maxloops := 50
    loop maxloops {
        updateStatus("Waiting for screen to transition (" A_Index "/" maxloops ")")
        if isTransitionScreen() {
            transitioned := true
            break
        }
        moveDirection(keyMoveAwayFromTree, 50)
        moveDirection(keyMoveTowardsTree, 100)
        Sleep 50
    }

    if !transitioned
        return false

    ; Wait until the screen transition completes.
    maxloops := 1000
    loop maxloops {
        updateStatus("Waiting for screen to untransition (" A_Index "/" maxloops ")")
        if !isTransitionScreen()
            break
        Sleep 50
    }

    updateStatus()

    return true
}


walkToMerchant() {
    updateStatus("Walking to the merchant")
    Send "{w down}"  ; Start walking forward by pressing the "w" key.

    ; loop to check if the merchant window is open.
    maxloops := 1000
    loop maxloops {
        updateStatus("Waiting for merchant window to open (" A_Index "/" maxloops ")")
        if isMerchantWindowOpen()  ; Check if the merchant window is open.
            break  ; Exit the loop if the merchant window is open.
        Sleep 10  ; Add a short delay to prevent excessive CPU usage.
    }

    Send "{w up}"  ; Stop walking by releasing the "w" key.

    moveDirection("s", 500)  ; Move backward for 100 milliseconds.

    updateStatus()
}

clickBestItem(bestItem) {
    freeButton := [167, 359]  ; Initial coordinates of the free button.
    xOffset := 233  ; Horizontal offset between buttons.

    ; Calculate the coordinates of the button to be clicked based on the best item index.
    buttonToUse := [freeButton[1] + ((bestItem - 1) * xOffset), freeButton[2]]

    ; loop to click the button until the merchant window is closed.
    maxloops := 100
    loop maxloops {
        updateStatus("Selecting item and waiting for merchant window to close (" A_Index "/" maxloops ")")
        ; Send a click event to the button coordinates with a slight random offset.
        clickX := buttonToUse[1] + Random(-3, 3)
        clickY := buttonToUse[2] + Random(-3, 3)
        SendEvent "{Click, " clickX ", " clickY ", 1}"

        ; Check if the merchant window is still open.
        if !isMerchantWindowOpen()
            break  ; Exit the loop if the merchant window is closed.
        
        Sleep 10  ; Short delay to allow the click event to process.
    }

    updateStatus()
}


closeMerchantWindow() {
    xButton := [745, 111]  ; Coordinates of the close button.

    ; loop until the merchant window is closed.
    maxloops := 100
    loop maxloops {
        updateStatus("Closing merchant window (" A_Index "/" maxloops ")")

        ; Send a click event to the close button coordinates.
        SendEvent "{Click, " xButton[1] ", " xButton[2] ", 1}"
        
        ; Check if the merchant window is still open.
        if !isMerchantWindowOpen()
            break  ; Exit the loop if the merchant window is closed.
        
        Sleep 10  ; Short delay to allow the click event to process.
    }
}


scanItems() {
    item1 := [100, 200]  ; Initial coordinates of the first item.
    xOffset := 230  ; Horizontal offset between items.

    loop 3 {
        itemIndex := A_Index

        updateStatus("Scanning item: " itemIndex)

        activateRoblox()  ; Ensure the Roblox window is active.

        ; Calculate the coordinates of the current item.
        itemCoordinates := [item1[1] + ((A_Index - 1) * xOffset), item1[2]]

        itemScanned := false

        maxAttempts := 5
        loop maxAttempts {
            updateStatus("Scanning item: " itemIndex " (" A_Index "/" maxAttempts ")")
            try {
                ; Perform a click at the item coordinates to bring up its details.
                SendEvent "{Click down, " itemCoordinates[1] ", " itemCoordinates[2] ", 1}"

                ; Get the rarity details and OCR item name from the item coordinates.
                rarityDetails := getDetailsFromRarityMap(itemCoordinates)
                if rarityDetails == "Unknown" {
                    writeToErrorLog("Item " itemIndex ": Unable to determine rarity color. (Attempt " A_Index "/" maxAttempts ")")
                }

                ocrItemName := getItemNameWithOcr(itemCoordinates)

                ; Retrieve item details based on the OCR item name and rarity.
                itemDetails := getDetailsFromItemMap(ocrItemName, rarityDetails.rarity)
                if itemDetails == "" {
                    writeToErrorLog("Item " itemIndex ": No match found in item map. (Ocr: " ocrItemName ", Rarity: " rarityDetails.rarity ") (Attempt " A_Index "/" maxAttempts ")")
                }

                SendEvent "{Click up}"

                ; Log the item details.
                writeToDebugLog("--------------------------------------------------")
                writeToDebugLog("Item: " itemIndex)
                writeToDebugLog(" RARITY DETAILS")
                writeToDebugLog(" * Rarity: " rarityDetails.rarity)
                writeToDebugLog(" * Color: " rarityDetails.properties.color)
                writeToDebugLog(" * XP: " rarityDetails.properties.xp)
                writeToDebugLog(" OCR DETAILS")
                writeToDebugLog(" * Result: " ocrItemName)
                writeToDebugLog(" ITEM DETAILS")                
                writeToDebugLog(" * Item: " itemDetails.name)
                writeToDebugLog(" * Rarity: " itemDetails.properties.rarity)
                writeToDebugLog(" * Category: " itemDetails.properties.category)
                writeToDebugLog(" * Id: " itemDetails.properties.id)
                writeToDebugLog(" * Tier: " itemDetails.properties.tn)
                writeToDebugLog(" * Regex: " itemDetails.properties.regex)
                writeToDebugLog(" * Priority: " itemDetails.properties.priority)
                writeToDebugLog(" API DETAILS")                
                writeToDebugLog(" * Value: " itemDetails.properties.value)                

                ; Update the CHOICE_MAP with the retrieved item details.
                CHOICE_MAP[itemIndex] := { 
                    itemName: itemDetails.name,
                    xp: rarityDetails.properties.xp,
                    rap: itemDetails.properties.value,
                    priority: itemDetails.properties.priority,
                    image: itemDetails.properties.image
                }

                writeToActivityLog(itemIndex ": " itemDetails.name " (Priority: " itemDetails.properties.priority 
                    . " | XP: " rarityDetails.properties.xp " | RAP: " itemDetails.properties.value ")")
            }
            catch as e {
                writeToErrorLog(e.What " " e.Message)  ; Log any errors encountered during the process.
            }
            else {
                itemScanned := true
                break  ; Exit the loop if the item is successfully scanned.
            } 
        }

        if !itemScanned
            writeToErrorLog("Item " itemIndex " not scanned.")  ; Log if the item was not successfully scanned after all attempts.
    }
}

; ----------------------------------------------------------------------------------------
; getBestIndex Function
; Description: Determines the index of the item with the highest priority (lowest priority value) in the CHOICE_MAP.
; Operation:
;   - Iterates through the CHOICE_MAP to find the item with the highest priority.
;   - Compares each item's priority to the current highest priority and updates accordingly.
; Dependencies: None
; Parameters: None
; Return: The index of the item with the highest priority in the CHOICE_MAP.
; ----------------------------------------------------------------------------------------
getBestIndex() {
    highestPriority := 1000  ; Initialize the highest priority value to a large number.
    bestIndex := -1  ; Initialize the best index to -1 to indicate no valid index found yet.

    ; Iterate through the CHOICE_MAP to find the item with the highest priority.
    for index, properties in CHOICE_MAP {
        if properties.priority < highestPriority {
            highestPriority := properties.priority  ; Update the highest priority value.
            bestIndex := index  ; Update the best index.
        }
    }

    Switch CHOICE_MAP[bestIndex].itemName {
        Case "Old Boot", "Rainbow Swirl":
        Default:
            STATS_MAP["5_total_rap"].value += CHOICE_MAP[bestIndex].rap
    }
    STATS_MAP["7_total_xp"].value += CHOICE_MAP[bestIndex].xp

    return bestIndex  ; Return the index of the item with the highest priority.
}

getDetailsFromRarityMap(itemCoordinates) {

    ; Define the start coordinates and size for the tooltip area.
    toolTipStart := [itemCoordinates[1] + 10, itemCoordinates[2] + 10]
    toolTipSize := [165, 120]
    toolTipEnd := [toolTipStart[1] + toolTipSize[1], toolTipStart[2] + toolTipSize[2]]

    tolerance := 2

    ; Iterate through the COLOR_RARITY_MAP to find a matching color within the tooltip area.
    for rarity, properties in COLOR_RARITY_MAP {
        if PixelSearch(&foundX, &foundY, 
            toolTipStart[1], toolTipStart[2],  
            toolTipEnd[1], toolTipEnd[2],  
            properties.color, tolerance)
        {
            return {rarity: rarity, properties: properties}
        }
    }

    return {rarity: "Unknown", properties: {color: "Unknown", xp: 0}}
}

getItemNameWithOcr(itemCoordinates) {
    loop 5 {
        toolTipStart := [itemCoordinates[1] + 10, itemCoordinates[2] + 10]  ; Define the start coordinates for the tooltip area.
        toolTipSize := [200, 100]  ; Define the size of the tooltip area.
        ocrResult := getOcrResult(toolTipStart, toolTipSize, 10, false, false)  ; Perform OCR on the tooltip area to capture the item name.

        if ocrResult.Text = "" {
            Sleep 500
            continue
        }

        ; Check if the item is "Treasure Hunter Potion" and concatenate the second line if needed.
        if RegExMatch(ocrResult.Lines[1].Text, "i)tre.*hun") && ocrResult.Lines.Length > 1 {
            return ocrResult.Lines[1].Text " " ocrResult.Lines[2].Text  ; Concatenate the first and second lines for "Treasure Hunter Potion".
        }

    }

    return ocrResult.Lines[1].Text  ; Return the first line of the OCR result as the item name.
}


getDetailsFromItemMap(ocrItemName, rarity) {
    ; Match based on the item name.
    if ITEM_MAP.Has(ocrItemName)
        return {name: ocrItemName, properties: ITEM_MAP[ocrItemName]} 

    ; Match based on the regex and rarity.
    for item, properties in ITEM_MAP {
        if RegExMatch(ocrItemName, properties.regex) && properties.rarity == rarity {
            return {name: item, properties: properties} 
        }
    }

    return ""
}

getOcrResult(ocrStart, ocrSize, ocrScale, returnText := true, createPin := true) {
    ; Retrieve the position of the Roblox window.
    WinGetClientPos &windowTopLeftX, &windowTopLeftY, , , "ahk_exe RobloxPlayerBeta.exe"

    ; Adjust OCR start coordinates based on the window position.
    ocrStart := [ocrStart[1] + windowTopLeftX, ocrStart[2] + windowTopLeftY]

    ; Calculate end coordinates for the OCR area.
    ocrEnd := [ocrStart[1] + ocrSize[1], ocrStart[2] + ocrSize[2]]

    ; Optionally draw a border around the OCR area for visual feedback.
    if createPin
        ocrBorder := Pin(ocrStart[1], ocrStart[2], ocrEnd[1], ocrEnd[2], 1000, "b1 flash0")  ; Draw a border around the OCR area.

    ; Perform OCR on the specified rectangular area with the given scale.
    ocrObjectResult := OCR.FromRect(ocrStart[1], ocrStart[2], ocrSize[1], ocrSize[2], , ocrScale)

    if createPin
        try ocrBorder.Destroy()

    ; Return either the text result or the OCR object based on the returnText parameter.
    if (returnText)
        return ocrObjectResult.Text
    else
        return ocrObjectResult
}

activateMouseHover() {
    Sleep 50  ; Stabilizes mouse context.
    MouseMove 1, 1,, "R"  ; Move cursor right and down by 1 pixel.
    Sleep 50  ; Allows UI to react.
    MouseMove -1, -1,, "R"  ; Return cursor to original position.
    Sleep 50  ; Ensures UI updates.
}

writeToActivityLog(logMessage) {
    ; Format the current date and time in ISO 8601 format.
    logDateTime := FormatTime(A_Now, "yyyy-MM-ddTHH:mm:ssZ")

    ; Construct the log message by prefixing it with the timestamp and enclosing it in brackets.
    formattedMessage := "[" logDateTime "]   " logMessage "`n"

    ; Define the log file path using the global log directory and current date, appending ".log" to make it a log file.
    logFile := LOG_FOLDER LOG_DATE "Keys.log"

    try {
        ; Append the formatted message to the log file, automatically creating the file if it doesn't exist.
        FileAppend formattedMessage, logFile
    }
}

writeToErrorLog(logMessage) {
    ; Format the current date and time in ISO 8601 format.
    logDateTime := FormatTime(A_Now, "yyyy-MM-ddTHH:mm:ssZ")

    ; Construct the log message by prefixing it with the timestamp and enclosing it in brackets.
    formattedMessage := "[" logDateTime "]   " logMessage "`n"

    ; Define the log file path using the global log directory and "error.log" as the filename.
    logFile := LOG_FOLDER LOG_DATE "-Error.log"

    try {
        ; Append the formatted message to the log file, automatically creating the file if it doesn't exist.
        FileAppend formattedMessage, logFile
    }
}

writeToDebugLog(logMessage) {
    ; Format the current date and time in ISO 8601 format.
    logDateTime := FormatTime(A_Now, "yyyy-MM-ddTHH:mm:ssZ")

    ; Construct the log message by prefixing it with the timestamp and enclosing it in brackets.
    formattedMessage := "[" logDateTime "]   " logMessage "`n"

    ; Define the log file path using the global log directory and "debug.log" as the filename.
    logFile := LOG_FOLDER LOG_DATE "-Debug.log"

    try {
        ; Append the formatted message to the log file, automatically creating the file if it doesn't exist.
        FileAppend formattedMessage, logFile
    }
}


; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
; GUI FUNCTIONS
; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

; ----------------------------------------------------------------------------------------
; pauseMacro Function
; Description: Toggles the pause state of the macro.
; Operation:
;   - Sends a keystroke to simulate a pause/unpause command.
;   - Toggles the pause state of the script.
; Dependencies:
;   - Send: Function to simulate keystrokes.
; Parameters:
;   - None
; Return: None; toggles the paused state of the macro.
; ----------------------------------------------------------------------------------------
pauseMacro(*) {
    Pause -1  ; Toggle the pause status of the macro.
}

reloadMacro(*) {
    Reload
}

; ----------------------------------------------------------------------------------------
; exitMacro Function
; Description: Exits the macro application completely.
; Operation:
;   - Terminates the application.
; Dependencies:
;   - ExitApp: Command to exit the application.
; Parameters:
;   - None
; Return: None; closes the application.
; ----------------------------------------------------------------------------------------
exitMacro(*) {
    updateStatus()
    ExitApp  ; Exit the macro application.
}

openHowTo(*) {
    Run ""
}

openDiscord(*) {
    Run "https://discord.gg/CDuS4CzC"
}

openWebsite(*) {
    Run ""
}

openDonate(*) {
    Run ""
}

changeToDefaultFont(*) {
    robloxFontPath := StrReplace(WinGetProcessPath("ahk_exe RobloxPlayerBeta.exe"), "RobloxPlayerBeta.exe", "") "content\fonts\"  ; Path to Roblox fonts directory.
    FileCopy FREDOKA_ONE_REGULAR, robloxFontPath "FredokaOne-Regular.ttf", true  ; Copy Fredoka One font.
}


; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
; SETTINGS.INI FUNCTIONS
; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰


getSetting(keyName) {
    return IniRead(SETTINGS_INI, "Settings", keyName)  ; Read and return the setting value from the INI file.
}


; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
; INITIALISATION SETTINGS/FUNCTIONS
; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰


completeInitialisationTasks() {
    mainTask := "Completing initialisation tasks"
    updateStatus(mainTask)

    updateStatus(mainTask ": Replacing Roblox fonts")
    replaceRobloxFonts()  ; Replace the Roblox fonts for better readability.

    updateStatus(mainTask ": Updating tray icon")
    updateTrayIcon()  ; Update the tray icon to indicate that the macro is running.

    updateStatus(mainTask ": Resizing Roblox window")
    resizeRobloxWindow()  ; Resize the Roblox window to a predefined size.

    updateStatus(mainTask ": Defining hotkeys")
    defineHotKeys()  ; Define hotkeys for various macro functions.

    updateStatus(mainTask ": Downloading API data")
    downloadRapJson()  ; Download the latest RAP JSON data from a specified URL.  

    updateStatus(mainTask ": Checking scaling")
    checkDisplayScaling()

    updateStatus(mainTask ": Changing background transparency")
    changeBackgroundTransparency()

    updateStatus(mainTask ": Getting log folder")
    getLogFolder()

    updateStatus()
}

checkDisplayScaling() {
    if A_ScreenDPI == 96
        return

    Msgbox "Display scaling must be 100%.`nUpdate in Windows display settings.", "Tree House", 0x30
    ExitApp
}



replaceRobloxFonts() {
    robloxFontPath := StrReplace(WinGetProcessPath("ahk_exe RobloxPlayerBeta.exe"), "RobloxPlayerBeta.exe", "") "content\fonts\"  ; Path to Roblox fonts directory.
    FileCopy TIMES_NEW_ROMAN, robloxFontPath "FredokaOne-Regular.ttf", true  ; Replace 'FredokaOne-Regular' with Times New Roman.
}

updateTrayIcon() {
    iconFile := A_WorkingDir . "\Assets\Secret_Key.ico"  ; Set the tray icon file path.
    TraySetIcon iconFile  ; Apply the new tray icon.
}


defineHotKeys() {
    HotKey START_MACRO, startMacro  ; Bind pause macro hotkey.
    HotKey PAUSE_MACRO, pauseMacro  ; Bind pause macro hotkey.
    HotKey EXIT_MACRO, exitMacro  ; Bind exit macro hotkey.
}

downloadRapJson() {
    Download URL_RAP_API, RAP_JSON  ; Download the RAP JSON data from the specified URL and save it to the file specified by RAP_JSON.
}

updateRap() {
    global

    jsonObject := loadJsonFromFile(RAP_JSON)  ; Load the JSON data from the specified RAP JSON file.

    ; Iterate through each item in the JSON data.
    for _, jsonData in jsonObject["data"] {
        ; Iterate through each item in the ITEM_MAP.
        for itemName, itemDetails in ITEM_MAP {
            ; Check if the categories match.
            if (itemDetails.category == jsonData["category"]) {
                ; Check if the tn value is not "NA".
                if itemDetails.tn != "NA" {
                    ; Update the value if both id and tn match.
                    if (itemDetails.id == jsonData["configData"]["id"] && itemDetails.tn == jsonData["configData"]["tn"]) {
                        itemDetails.value := jsonData["value"]
                    }
                }
                else {
                    ; Update the value if only id matches.
                    if (itemDetails.id == jsonData["configData"]["id"]) {
                        itemDetails.value := jsonData["value"]
                    }
                }
            }
        }

        ; Check if the current item is the "Secret Key" and update the SECRET_KEY_RAP value.
        if jsonData["configData"]["id"] == "Secret Key"
            SECRET_KEY_RAP := jsonData["value"]
    }
    
    return SECRET_KEY_RAP  ; Return the RAP value for the "Secret Key".
}


updatePriority() {
    priorityArray := readPrioritiesFromFile(PRIORITY_TXT)  ; Read the priorities from the specified text file.

    ; Iterate through each item in the priority array.
    for index, item in priorityArray {
        strippedContent := StrReplace(item, "`r", "")  ; Remove carriage return characters from the item string.
        strippedContent := StrReplace(strippedContent, "`n", "")  ; Remove newline characters from the item string.
        
        ; Check if the ITEM_MAP contains the stripped item string.
        if ITEM_MAP.Has(strippedContent)
            ITEM_MAP[strippedContent].priority := index  ; Update the priority of the item in ITEM_MAP.
    }
}


readPrioritiesFromFile(filePath) {
    array := []  ; Initialize an empty array to store the priorities.
    content := FileRead(filePath)  ; Read the content of the specified file.

    ; Split the file content by line breaks into an array.
    for line in StrSplit(content, "`n") {
        line := Trim(line)  ; Trim any leading or trailing whitespace.
        if (line != "") {  ; Check if the line is not empty.
            array.Push(line)  ; Push the non-empty line into the array.
        }
    }

    return array  ; Return the array of priorities.
}


loadJsonFromFile(filePath) {
    jsonString := FileRead(filePath)  ; Read the content of the specified JSON file into a string.
    return Jxon_Load(&jsonString)  ; Parse the JSON string into a JSON object using the Jxon library and return it.
}


; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
; ROBLOX CLIENT FUNCTIONS
; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰


resizeRobloxWindow() {
    WinActivate "ahk_exe RobloxPlayerBeta.exe"  ; Activate the Roblox window.
    WinRestore "ahk_exe RobloxPlayerBeta.exe"   ; Restore the Roblox window if it is minimized.
    
    ; Resize the window twice to fix any scaling issues with the Supercomputer.
    WinMove , , A_ScreenWidth, 600, "ahk_exe RobloxPlayerBeta.exe"  ; Resize the window to screen width by 600 pixels height.
    WinMove , , 800, 600, "ahk_exe RobloxPlayerBeta.exe"  ; Resize the window to 800x600 pixels dimensions.
}


activateRoblox() {
    try {
        WinActivate "ahk_exe RobloxPlayerBeta.exe"  ; Try to activate the Roblox game window.
    } catch {
        MsgBox "Roblox window not found."  ; Display an error message if the window is not found.
        ExitApp  ; Exit the application.
    }
    Sleep 100  ; Pause briefly to ensure the window is activated.
}


; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
; PIXEL SEARCHES
; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰


isSecretKeyNotConsumed() {
    return PixelSearch(&foundX, &foundY, 448, 428, 448, 428, "0x00FFFF", 2)  ; Search for the specific color at the given coordinate.
}


isMerchantWindowOpen() {
    return PixelSearch(&foundX, &foundY, 52, 101, 52, 101, "0xDC4000", 2)  ; Search for the specific color at the given coordinate.
}

isTransitionScreen() {
    return PixelSearch(&foundX, &foundY, 43, 63, 43, 63, "0x070711", 2)  ; Search for the specific color at the given coordinate.
}


isUseKeyWindowOpen() {
    return PixelSearch(&foundX, &foundY, 406, 314, 406, 314, "0xC34CE1", 2)  ; Search for the specific color at the given coordinates.
}


; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
; AUTO-RECONNECT FUNCTIONS
; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰


checkForDisconnection() {
    ;setCurrentAction("Checking Connection")  ; Indicate checking connection status.

    isDisconnected := checkForDisconnect()  ; Check for any disconnection.
    if (isDisconnected == true) {
        reconnectClient()  ; Reconnect if disconnected.
        Reload  ; Reload the script to refresh all settings and start fresh.
    }

    ;setCurrentAction("-")  ; Reset action status.
}

reconnectClient(*) {
    writeToActivityLog("*** RECONNECTING ***")
    reconnectTime := getSetting("ReconnectTimeSeconds")  ; Get the reconnect duration.

    privateServerLinkCode := getSetting("PrivateServerLinkCode")  ; Get the private server code.
    if (privateServerLinkCode == "") {
        try Run "roblox://placeID=8737899170"  ; Default reconnect without private server.
    }
    else {
        try Run "roblox://placeID=8737899170&linkCode=" privateServerLinkCode  ; Reconnect using private server link.
    }

    button := TELEPORT_COORDS["SKIP_BUTTON"]
    maxLoops := 200
    loop maxLoops {
        updateStatus("Waiting to reconnect (" A_Index "/" maxLoops ")")

        if isTeleportControlVisible()
            break
        if isSkipButtonShown()
            SendEvent "{Click, " button[1] ", " button[2] ", 1}"
        Sleep 100
    continue
    }

}

checkForDisconnect() {
    disconnectedWindowStart := [201, 175]  ; Define the start coordinates for the disconnection window.
    disconnectedWindowSize := [398, 248]   ; Define the size of the disconnection window.

    activateRoblox()  ; Focus the Roblox window.
    
    ; Perform OCR on the specified window area with a scaling factor of 20.
    ocrTextResult := getOcrResult(disconnectedWindowStart, disconnectedWindowSize, 20)
    
    ; Check for disconnection phrases in the OCR result.
    return (regexMatch(ocrTextResult, "Disconnected|Reconnect|Leave"))
}

; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
; MOVEMENT FUNCTIONS
; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

moveToTree() {
    updateStatus("Moving to the tree house")
    Sleep 500  ; Pause briefly before starting the movement.
    
    equipHoverboard("d")  ; Equip the hoverboard and start stabilizing it by moving right.
    moveDirection("d", 260)  ; Move right for 260 milliseconds to position the character.
    
    Sleep 200  ; Brief pause before the next movement.
    
    moveDirection("w", 1300)  ; Move forward for 1300 milliseconds to reach the tree.
    unequipHoverboard()  ; Unequip the hoverboard.
}

travelToTree() {
    updateStatus("Travelling to tree")
    travelToWorld1()  ; Ensure the character is in World 1.
    closeLeaderboard()  ; Close the leaderboard.
    travelToZone15()  ; Travel to Zone 15.
    moveToTree()  ; Move to the tree.
}

travelToWorld1() {
    if getWorld() != 1
        teleportToWorld(1)  ; Teleport to World 1 if not already there.
}

travelToZone15() {
    updateStatus("Travelling to zone: 15")
    ;teleportToZone(14)
    teleportToZone(15)
}

moveDirection(key, milliseconds) {
    Send "{" key " down}"  ; Send the key down event to initiate movement.
    Sleep milliseconds  ; Wait for the specified duration to continue movement.
    Send "{" key " up}"  ; Send the key up event to stop movement.
}

; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
; HOVERBOARD FUNCTIONS
; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

equipHoverboard(direction) {
    SendEvent "{q}"  ; Simulate pressing the 'q' key to toggle the hoverboard.
    Sleep 2000  ; Wait for 2000 milliseconds to ensure the hoverboard is activated.

    ; Stabilize the hoverboard by moving in the specified direction in small increments.
    loop 3 {
        moveDirection(direction, 1)  ; Move in the specified direction for 10 milliseconds.
        Sleep 10  ; Brief pause before the next movement.
    }

    Sleep 2000  ; Wait for 2000 milliseconds to allow the hoverboard to stabilize.
}

unequipHoverboard() {
    SendEvent "{q}"  ; Simulate pressing the 'q' key to toggle the hoverboard off.
}


; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
; WINDOW FUNCTIONS
; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

closeChatLog() {
    pixel := MENU_PIXEL["LEADERBOARD_RANK_STAR"]     
    if PixelSearch(&foundX, &foundY,  ; Perform a pixel search.
        pixel["START"][1], pixel["START"][2],  ; Starting coordinates for the search area.
        pixel["END"][1], pixel["END"][2],  ; Ending coordinates for the search area.
        pixel["COLOUR"], pixel["TOLERANCE"])  ; Color and tolerance for the search. 
        SendEvent "{Click, " foundX ", " foundY ", 1}"  ; Click on the found coordinates to close the chat log.
}

scrollMouseWheel(scrollDirection, timesToScroll := 1) {
    loop timesToScroll {  ; Repeat scroll for the number of specified increments.
        Send scrollDirection  ; Send scroll command in the specified direction.
        Sleep 50  ; Short pause to mimic natural scrolling behavior.
    }
}

getLogFolder() {
    global

    try {
        processPath := WinGetProcessPath("ahk_exe Psycho Hatcher.exe")
    } catch {
        processPath := ""  ; Set to empty if the process is not found
    }

    if processPath
        LOG_FOLDER := StrReplace(processPath, "Psycho Hatcher.exe", "") "Logs\TreeHouse\"
    else
        LOG_FOLDER := A_ScriptDir "\Logs\"

    CSS_DESTINATION := "" LOG_FOLDER "\style.css"
    HTML_LOG_FILE := "" LOG_FOLDER "\TreeHouse.html"        
}

updateStatus(message := "") {
    defaultTitle := (message = "") ? "Roblox" : "Roblox: "
    try WinSetTitle(defaultTitle message, "ahk_exe RobloxPlayerBeta.exe")
}