#Requires AutoHotkey v2.0

ITEM_IMAGE_FOLDER := A_ScriptDir "/Assets/Images/Items/"
CSS_DESTINATION := ""
HTML_LOG_FILE := ""
CSS_SOURCE := A_ScriptDir "/Assets/css/style.css"

initialiseHtmlLogFile() {
    global HTML_LOG_FILE, ITEM_IMAGE_FOLDER, STATS_MAP

    FileCopy CSS_SOURCE, CSS_DESTINATION, true

    currentDateTime := FormatTime(A_Now, "d MMMM yyyy - h:mm tt")

    ; Build statistics HTML dynamically
    statsHtml := ""
    for id, properties in STATS_MAP {
        statsHtml .= "            <p><span class='stat-label'>" . properties.name . ":</span> <span id='" . id . "' class='stat-value'>0</span></p>`n"
    }

    ; Session HTML block (only inserted once per session)
    sessionHtml := ""
        . "    <h3 class='session-time'>" . currentDateTime . "</h3>`n"
        . "    <div class='session-container'>`n"
        . "        <div class='statistics-container'>`n"
        .              statsHtml
        . "        </div>`n"
        . "        <div class='key-use-container'>`n"
        . "            <!-- KEY-USE-INSERT -->`n"
        . "        </div>`n"
        . "    </div>`n"

    if !FileExist(HTML_LOG_FILE) {
        ; Create new file with full HTML structure
        pageHtml := ""
            . "<!DOCTYPE html>`n"
            . "<html lang='en'>`n"
            . "<head>`n"
            . "    <meta charset='UTF-8'>`n"
            . "    <meta name='viewport' content='width=device-width, initial-scale=1.0'>`n"
            . "    <meta http-equiv='refresh' content='2'>`n"
            . "    <title>Tree House</title>`n"
            . "    <link rel='stylesheet' href='style.css'>`n"
            . "    <script>`n"
            . "        function updateStats(statId, value) {`n"
            . "            let el = document.getElementById(statId);`n"
            . "            if (el) el.textContent = value;`n"
            . "        }`n"
            . "    </script>`n"
            . "</head>`n"
            . "<body>`n"
            . "    <h1 class='page-title'>`n"
            . "        <img src='" . ITEM_IMAGE_FOLDER . "Merchant.webp' alt='Merchant'>`n"
            . "        Tree House`n"
            . "    </h1>`n"
            .              sessionHtml  ; Insert session content here
            . "</body>`n"
            . "</html>`n"

        FileAppend pageHtml, HTML_LOG_FILE
    } else {
        ; Read existing log to check if session already exists
        logText := FileRead(HTML_LOG_FILE)

        ; If the session container doesn't exist, insert it after </h1>
        logText := StrReplace(logText, "</h1>`n", "</h1>`n" . sessionHtml)
        try FileDelete HTML_LOG_FILE
        FileAppend logText, HTML_LOG_FILE
    }
}


updateHtmlLog(itemImages := "", keyCount := 0) {
    global HTML_LOG_FILE, ITEM_IMAGE_FOLDER, STATS_MAP

    if !FileExist(HTML_LOG_FILE)  ; Prevent errors if file is deleted
        return

    logText := FileRead(HTML_LOG_FILE)  ; Read current file content

    ; Ensure the key count is formatted as a four-digit number (####)
    formattedKeyCount := Format("{:04}", keyCount)

    ; Define SecretKey image and key count text
    keyImage := "<img src='" . ITEM_IMAGE_FOLDER . "Secret_Key.webp' class='key-icon'>"
    keyText := "<span class='key-count'>" . formattedKeyCount . "</span>"

    ; Format date
    logDate := "<div class='log-date'>" . FormatTime(A_Now, "yyyy-MM-dd HH:mm:ss") . "</div>"

    ; Ensure itemImages appear inside `.log-items`
    logItems := "<div class='log-items'>" . itemImages . "</div>"

    ; Properly formatted log entry
    newEntry := ""
        . "`n            <div class='key-use'>`n"
        . "                <div class='key-section'>" . keyImage . " " . keyText . "</div>`n"
        . "                " . logDate . "`n"
        . "                " . logItems . "`n"
        . "            </div>`n"

    ; Find the first occurrence of the marker
    firstKeyUsePos := InStr(logText, "<!-- KEY-USE-INSERT -->")

    if firstKeyUsePos {
        ; Replace only the first instance of `<!-- KEY-USE-INSERT -->`
        updatedLogText := SubStr(logText, 1, firstKeyUsePos - 1)  ; Everything before the marker
            . "<!-- KEY-USE-INSERT -->`n" . newEntry  ; Insert the new entry after the marker
            . SubStr(logText, firstKeyUsePos + StrLen("<!-- KEY-USE-INSERT -->"))  ; Everything after the marker
    } else {
        updatedLogText := logText  ; If no marker is found, keep log unchanged
    }

    ; **Update Statistics Dynamically**
    firstSessionPos := InStr(updatedLogText, "<div class='statistics-container'>")  ; Find the first occurrence

    if firstSessionPos {
        endSessionPos := InStr(updatedLogText, "</div>", , firstSessionPos)  ; Corrected position
        if endSessionPos
            endSessionPos += StrLen("</div>")  ; Adjust position to include the closing tag

        firstSessionText := SubStr(updatedLogText, firstSessionPos, endSessionPos - firstSessionPos)

        ; Update only the first session statistics
        for id, properties in STATS_MAP {
            newValue := properties.value  ; Get updated value
            firstSessionText := RegExReplace(firstSessionText, "(<span id='" . id . "' class='stat-value'>).*?(</span>)", "$1" . newValue . "$2")
        }

        ; Replace only the first session in the full text
        updatedLogText := SubStr(updatedLogText, 1, firstSessionPos - 1) . firstSessionText . SubStr(updatedLogText, endSessionPos)
    }


    try FileDelete HTML_LOG_FILE  ; Remove the old file
    FileAppend updatedLogText, HTML_LOG_FILE
}

openHtmlLogFile() {
    Run HTML_LOG_FILE  ; Open log file in default browser
}