﻿#Requires AutoHotkey v2.0

TELEPORT_COORDS := Map(
    "CONTROL", [107, 167],
    "MENU_ICON", [66, 108],
    "SEARCH_BOX", [600, 107],
    "SEARCH_ZONE", [398, 193],
    "CLOSE", [746, 109],
    "WORLD_1", [22, 238],
    "WORLD_2", [22, 284],
    "WORLD_3", [22, 328],
    "CONFIRM_TELEPORT", [291, 422],
    "SKIP_BUTTON", [397, 557 ]
)


; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
; TELEPORT FUNCTIONS
; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
CheckForBGFup(){
    loop{
        pixel := [484, 392 ]
    colour := "0xB8F0FF"
    SendEvent "{click 371, 376}"
    return PixelSearch(&X, &Y, pixel[1], pixel[2], pixel[1], pixel[2], colour, 2)
    }
}
teleportToZone(zoneNumber) {
    closeTeleportMenu()
    openTeleportMenu()
    closeLeaderboard()
    clickTeleportSearchBox()
    enterTeleportSearchTerm(zoneNumber)
    
    if isDestinationBlue() {
        closeTeleportMenu()
        return true
    }

    clickTeleportButton(zoneNumber)
    Sleep 1000
    return false
}

openTeleportMenu() {
    if isTeleportMenuOpen()
        return

    button := [100, 148]

    Loop 100 {
        SendEvent "{Click, " button[1] ", " button[2] ", 1}"
        Loop 25 {
            Sleep 10
            if isTeleportMenuOpen()
                return
        }
    }
}

clickTeleportMenuIcon() {
    button := [66, 108]

    Loop 100 {
        SendEvent "{Click, " button[1] ", " button[2] ", 1}"
        Loop 25 {
            Sleep 10
            if isTeleportMenuOpen()
                return
        }
    }
}

clickTeleportSearchBox() {
    button := [600, 107]

    Loop 100 {
        SendEvent "{Click, " button[1] ", " button[2] ", 1}"
        Loop 25 {
            Sleep 10
            if isTeleportSearchBoxSelected()
                return
        }
    }
}

enterTeleportSearchTerm(zoneNumber) {
    SendText ZONE_MAP.Get(zoneNumber)

    Loop 100 {
        if isTeleportSearchTermEntered() 
            return
        Sleep 100
    }
}

clickTeleportButton(zoneNumber) {
    button := [392,196]

    Loop 10 {
        SendEvent "{Click, " button[1] + Random(-2, -2) ", " button[2] + Random(2, 2) ", 1}"
        if !isTeleportMenuOpen()
            break
        Sleep 1000
    }

    openTeleportMenu()
    clickTeleportSearchBox()
    enterTeleportSearchTerm(zoneNumber)
    
    Loop 30 {
        if isDestinationBlue()
            break
        Sleep 1000
    }

    closeTeleportMenu()
    Sleep 1000
}

closeTeleportMenu() {
    if isTeleportMenuOpen() {
        button := [752, 107]
        SendEvent "{Click, " button[1] ", " button[2] ", 1}"
        Loop 100 {
            if !isTeleportMenuOpen()
                break
            Sleep 10
        }
    }
}

; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
; PIXEL CHECKS
; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

isTeleportMenuOpen() {
    pixel := [66, 108]
    colour := "0xd81140"
    return PixelSearch(&X, &Y, pixel[1], pixel[2], pixel[1], pixel[2], colour, 2)
}

isTeleportSearchBoxSelected() {
    pixel := [498, 105, 694, 116]
    colour := "0xafafaf"
    return PixelSearch(&X, &Y, pixel[1], pixel[2], pixel[3], pixel[4], colour, 2)
}

isTeleportSearchTermEntered() {
    pixel := [676, 100, 685, 115]
    colour := "0x1e1e1e"
    return PixelSearch(&X, &Y, pixel[1], pixel[2], pixel[3], pixel[4], colour, 2)    
}

isDestinationBlue() {
    pixel := [427, 271]
    colour := "0x5edefe"
    return PixelSearch(&X, &Y, pixel[1], pixel[2], pixel[1], pixel[2], colour, 2)
}

isDestinationGreen() {
    pixel := [353, 236]
    colour := "0x67f104"
    return PixelSearch(&X, &Y, pixel[1], pixel[2], pixel[1], pixel[2], colour, 2)
}

isDestinationWhite() {
    pixel := [353, 236]
    colour := "0xfefefe"
    return PixelSearch(&X, &Y, pixel[1], pixel[2], pixel[1], pixel[2], colour, 2)
}

isTeleportWorldConfirmationOpen() {
    pixel := [187, 126]
    colour := "0x53e3ff"
    return PixelSearch(&X, &Y, pixel[1], pixel[2], pixel[1], pixel[2], colour, 2)    
}

isTeleportControlVisible() {
    pixel := [109, 190]
    colour := "0xc80a2f"
    return PixelSearch(&X, &Y, pixel[1], pixel[2], pixel[1], pixel[2], colour, 2)  
}

isSkipButtonShown() {
    pixel := [397, 557]
    colour := "0xfd9e42"
    return PixelSearch(&X, &Y, pixel[1], pixel[2], pixel[1], pixel[2], colour, 2)  
}


; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
; WORLD FUNCTIONS
; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

getWorld() {
    worldSpawns := [15, 100, 200]
    world := -1

    maxLoops := 10
    loop maxLoops {
        updateStatus("Identifying world (" A_Index "/" maxLoops ")")  
        openTeleportMenu() 
        loop 3 {
            clickTeleportMenuIcon()
            clickTeleportSearchBox()
            enterTeleportSearchTerm(worldSpawns[A_Index])
            if !isDestinationWhite() {
                world := A_Index
                break
            }
        }
        
        if world != -1 {
            closeTeleportMenu()
            return world
        }
            
    }    

}

teleportToWorld(worldNumber) {
    openTeleportMenu()

    updateStatus("Teleporting to world: " worldNumber)

    button := TELEPORT_COORDS["WORLD_" worldNumber]
    SendEvent "{Click, " button[1] ", " button[2] ", 1}"
    Sleep 500

    button := TELEPORT_COORDS["CONFIRM_TELEPORT"]
    SendEvent "{Click, " button[1] ", " button[2] ", 1}"
    Sleep 500

    ; Wait until the teleport icon is visible (i.e., teleport complete).
    ; Click the skip button if it appears.
    button := TELEPORT_COORDS["SKIP_BUTTON"]
    maxLoops := 500
    loop maxLoops {
        updateStatus("Waiting to arrive at world: " worldNumber " (" A_Index "/" maxLoops ")")    

        if isTeleportControlVisible()
            break
        if isSkipButtonShown()
            SendEvent "{Click, " button[1] ", " button[2] ", 1}"
        Sleep 100
    }

}