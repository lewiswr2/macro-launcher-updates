#NoTrayIcon
#Requires AutoHotkey v2.0

; --------------------------
; Global Variable Definitions
; --------------------------

global clients := []
global MyGui := {}
global logFile := A_ScriptDir "\Logs\log_" A_Now ".log"
global iconPath := A_ScriptDir "\Icon.png"
global Paused := false
global AutoReconnect := true
global CurrentPoint := [0, 0]
global appName := "PS99 Fishing Master"
global singleWindowMode := false
SetMouseDelay(-1)

; Set tray icon
if FileExist(iconPath)
    TraySetIcon(iconPath)

; --------------------------
; Settings Management
; --------------------------

saveSettings() {
    IniWrite(singleWindowMode ? 1 : 0, A_ScriptDir "\settings.ini", "Settings", "SingleWindowMode")
    WriteLog("Settings saved")
}

loadSettings() {
    global singleWindowMode := IniRead(A_ScriptDir "\settings.ini", "Settings", "SingleWindowMode", 0)
    WriteLog("Settings loaded")
}

applySettingsToGui() {
    if (MyGui.HasOwnProp("__Handle")) {
        MyGui["SingleWindowMode"].Value := singleWindowMode
        WriteLog("Settings applied to GUI")
    }
}

; --------------------------
; Function Definitions
; --------------------------

WriteLog(message) {
    try FileAppend(A_Now " - " message "`n", logFile)
    catch as err
        MsgBox("Failed to write log: " . err.Message)
}

ActivateWindow(windowHandle) {
    if (windowHandle) {
        WriteLog("Activating window: " windowHandle)
        WinActivate("ahk_id " windowHandle)
        Sleep 10
    }
}

CreateButtonHandler(handle) {
    return (*) => ActivateWindow(handle)
}

closeChatLog() {
    CHAT_ICON_WHITE := Map("Start", [81, 24], "End", [81, 24], "Colour", "0xFFFFFF", "Tolerance", 2)
    if PixelSearch(&foundX, &foundY, CHAT_ICON_WHITE["Start"][1], CHAT_ICON_WHITE["Start"][2], CHAT_ICON_WHITE["End"][1], CHAT_ICON_WHITE["End"][2], CHAT_ICON_WHITE["Colour"], CHAT_ICON_WHITE["Tolerance"]) 
        leftClickMouse([foundX, foundY])  
}

leftClickMouse(coords) {
    MouseClick("left", coords[1], coords[2])
}

initialiseClient() {
    resizeRobloxWindow()
    closeLeaderboard() 
    closeChatLog()
    Sleep(100)
    Send("{Space}")
}

reconnectInNeed() {
    if checkForDisconnection() {
        reconnectClient()
        Sleep(60000)
        initialiseClient()
    } 
}

checkForDisconnection() {
    return false
}

reconnectClient() {
    WriteLog("*** RECONNECTING ***")
    try Run "roblox://placeID=8737899170"
    Sleep(30000)
}

resizeRobloxWindow() {
    WinActivate "ahk_exe RobloxPlayerBeta.exe"  
    WinRestore "ahk_exe RobloxPlayerBeta.exe"   
    WinMove , , A_ScreenWidth, 600, "ahk_exe RobloxPlayerBeta.exe"  
    WinMove , , 800, 600, "ahk_exe RobloxPlayerBeta.exe"  
}

closeLeaderboard() {
    LEADERBOARD_RANK_STAR := Map("Start", [652, 43], "End", [678, 59], "Colour", "0xB98335", "Tolerance", 50)
    if PixelSearch(&foundX, &foundY,  
        LEADERBOARD_RANK_STAR["Start"][1], LEADERBOARD_RANK_STAR["Start"][2], 
        LEADERBOARD_RANK_STAR["End"][1], LEADERBOARD_RANK_STAR["End"][2],  
        LEADERBOARD_RANK_STAR["Colour"], LEADERBOARD_RANK_STAR["Tolerance"]) 
        SendEvent "{Tab}"
}

ManageWindows() {
    global MyGui, iconPath, clients, COLORS
    
    COLORS := {
        headerBg: "0xd29922",
        headerText: "0x13171d",
        bg: "0x0a0e14",
        cardBg: "0x161b22",
        text: "0xFFFFFF",
        textDim: "0xB0B0B0",
        border: "0x3A3A3A"
    }

    robloxWindows := WinGetList("ahk_exe RobloxPlayerBeta.exe")
    maxWindows := robloxWindows.Length

    if (maxWindows == 0) {
        MsgBox("No Roblox windows found. Please open Roblox and try again.")
        WriteLog("No Roblox windows found.")
        ExitApp()
    }

    MyGui := Gui("+AlwaysOnTop -MaximizeBox")
    MyGui.MarginX := 0
    MyGui.MarginY := 0
    MyGui.BackColor := COLORS.bg
    MyGui.Title := appName

    guiWidth := 350
    
    ; Header with progress bar background
    MyGui.Add("Progress", "x0 y0 w" guiWidth " h100 Background" SubStr(COLORS.headerBg, 3))
    
    MyGui.SetFont("s20 bold c" SubStr(COLORS.headerText, 3), "Segoe UI")
    MyGui.Add("Text", "x0 y25 w" guiWidth " Center BackgroundTrans", "🎣 PS99 Fishing Master")
    MyGui.SetFont("s10 c" SubStr(COLORS.headerText, 3))
    MyGui.Add("Text", "x0 y60 w" guiWidth " Center BackgroundTrans", "Automate fishing across windows")

    ; Status Section
    MyGui.SetFont("s9 bold c" COLORS.text, "Segoe UI")
    MyGui.AddGroupBox("x8 y110 w" guiWidth-16 " h80 Background" COLORS.cardBg " c" COLORS.textDim, "✅ Status")
    MyGui.SetFont("s9 norm c" COLORS.text, "Segoe UI")
    MyGui.Add("Text", "vStatusText x20 y135 w" guiWidth-40 " Background" COLORS.cardBg " c" COLORS.text, "Status: Idle - Ready to start")

    ; Settings Section
    MyGui.SetFont("s9 bold c" COLORS.text, "Segoe UI")
    MyGui.AddGroupBox("x8 y200 w" guiWidth-16 " h60 Background" COLORS.cardBg " c" COLORS.textDim, "⚙️ Settings")
    MyGui.SetFont("s9 norm c" COLORS.text, "Segoe UI")
    MyGui.Add("CheckBox", "vSingleWindowMode x20 y225 c" COLORS.text, "Single Window Mode").OnEvent("Click", ToggleSingleWindowMode)

    ; Windows Section
    MyGui.SetFont("s9 bold c" COLORS.text, "Segoe UI")
    MyGui.AddGroupBox("x8 y270 w" guiWidth-16 " h" (maxWindows * 40 + 20) " Background" COLORS.cardBg " c" COLORS.textDim, "🪟 Roblox Windows")
    MyGui.SetFont("s9 norm c" COLORS.text, "Segoe UI")

    yPos := 295
    for i, handle in robloxWindows {
        if (i > maxWindows)
            break
        clients.Push({handle: handle, task: "Idle", timer: 0, state: "idle", loopCounter: 0})
        MyGui.Add("Button", "w" guiWidth-40 " h30 x20 y" yPos, "🎮 Activate Window " i).OnEvent("Click", CreateButtonHandler(handle))
        WriteLog("Added Roblox Window " . i . " to GUI.")
        yPos += 40
    }

    ; Buttons
    yPos += 20
    MyGui.SetFont("s9 norm c" COLORS.text, "Segoe UI")
    btnStart := MyGui.Add("Button", "x13 y" yPos " w78 h45", "▶️ Start`n(F1)")
    btnPause := MyGui.Add("Button", "x95 y" yPos " w78 h45", "⏸️ Pause`n(F2)")
    btnReload := MyGui.Add("Button", "x177 y" yPos " w78 h45", "🔄 Reload`n(F5)")
    btnStop := MyGui.Add("Button", "x259 y" yPos " w78 h45", "⏹️ Stop`n(F3)")
    
    btnStart.OnEvent("Click", StartButtonHandler)
    btnPause.OnEvent("Click", TogglePause)
    btnReload.OnEvent("Click", (*) => Reload())
    btnStop.OnEvent("Click", (*) => ExitApp())

    guiHeight := yPos + 60
    
    screenWidth := A_ScreenWidth
    xPos := screenWidth - guiWidth - 20
    yPos := 20

    MyGui.Show("w" guiWidth " h" guiHeight " x" xPos " y20")
    WriteLog("GUI shown with modern Key Master styling.")

    MyGui.OnEvent("Close", (*) => ExitApp())
    
    ; Apply saved settings to GUI
    applySettingsToGui()
}

ToggleSingleWindowMode(*) {
    global MyGui, singleWindowMode
    singleWindowMode := MyGui["SingleWindowMode"].Value
    if (singleWindowMode) {
        MyGui["StatusText"].Text := "Status: Single Window Mode Active"
        WriteLog("Single Window Mode enabled")
    } else {
        MyGui["StatusText"].Text := "Status: Multi Window Mode Active"
        WriteLog("Single Window Mode disabled")
    }
    saveSettings()
}

TogglePause(*) {
    Pause -1
    global Paused, singleWindowMode
    Paused := !Paused
    if (Paused) {
        MyGui["StatusText"].Text := "Status: Paused"
        WriteLog("Script paused")
    } else {
        if (singleWindowMode) {
            MyGui["StatusText"].Text := "Status: Single Window Mode Active"
        } else {
            MyGui["StatusText"].Text := "Status: Running"
        }
        WriteLog("Script resumed")
    }
}

; --------------------------
; Main Detection and Clicking Logic
; --------------------------

StartButtonHandler(*) {
    WriteLog("Start button clicked")
    Paused := false
    MyGui["StatusText"].Text := "Status: Running..."
    
    Loop {
        if Paused {
            Sleep(10)
            Continue
        }

        clientsToProcess := clients

        if (singleWindowMode) {
            clientsToProcess := [clients[1]]
        }

        for client in clientsToProcess {
            ActivateWindow(client.handle)
            initialiseClient()

            WinWaitActive("ahk_exe RobloxPlayerBeta.exe", , 2)
            if !WinActive("ahk_exe RobloxPlayerBeta.exe") {
                Continue
            }

            startTime := A_TickCount
            defaultClickPoint := [400, 300]

            Loop {
                if (A_TickCount - startTime >= 120000) {
                    break
                }

                if !WinActive("ahk_exe RobloxPlayerBeta.exe") {
                    Continue
                }

                if PixelSearch(&u, &u2, 0, 0, 800, 600, 0x77DAFF, 0) {
                    CurrentPoint := [u, u2]
                    Loop 160 {
                        if !WinActive("ahk_exe RobloxPlayerBeta.exe") {
                            Continue
                        }
                        Click(CurrentPoint[1], CurrentPoint[2])
                        Sleep(50)
                    }
                } else {
                    Loop 20 {
                        if !WinActive("ahk_exe RobloxPlayerBeta.exe") {
                            Continue
                        }
                        Click(defaultClickPoint[1], defaultClickPoint[2])
                        Sleep(10)
                    }
                    Sleep(100)
                }

                reconnectInNeed()
            }

            if (singleWindowMode) {
                break
            }
        }
    }
}

; --------------------------
; Hotkey Definitions
; --------------------------

F1::StartButtonHandler()
F2::TogglePause()
F3::ExitApp()
F5::Reload

; --------------------------
; Main Script Execution
; --------------------------

; Add OnExit handler to save settings
OnExit((*) => saveSettings())

if !FileExist(A_ScriptDir "\Logs")
    DirCreate(A_ScriptDir "\Logs")

loadSettings()
ManageWindows()

; --------------------------
; End of Script
; --------------------------