#Requires AutoHotkey v2.0
#SingleInstance Force
#NoTrayIcon

global Toggle := false
global MacroRunning := false
global StartTime := 0
global TotalSpins := 0
global StatsFile := "macro_stats.ini"

global COLORS := {
    headerBg: "0xd29922",
    headerText: "0x13171d",
    bg: "0x0a0e14",
    cardBg: "0x161b22",
    cardHover: "0x1c2128",
    text: "0xFFFFFF",
    textDim: "0xB0B0B0",
    border: "0x3A3A3A",
    success: "0x4CAF50",
    warning: "0xFFC107",
    danger: "0xF44336",
    buttonBg: "0xF5E6D3",
    buttonText: "0x000000"
}

try {
    TraySetIcon("icon.png")
} catch {
    ; Icon file not found, will use default
}

; Load saved statistics on startup
LoadStats()

; Create the GUI
MyGui := Gui("+AlwaysOnTop", "PS99 Spinny Wheel Macro")
MyGui.BackColor := COLORS.bg
MyGui.MarginX := 0
MyGui.MarginY := 0

; Header
MyGui.Add("Progress", "x0 y0 w400 h100 Background" SubStr(COLORS.headerBg, 3))
MyGui.SetFont("s20 bold c" SubStr(COLORS.headerText, 3), "Segoe UI")
MyGui.Add("Text", "x0 y25 w400 Center BackgroundTrans", "🎡 Spinny Wheel")
MyGui.SetFont("s10 c" SubStr(COLORS.headerText, 3))
MyGui.Add("Text", "x0 y60 w400 Center BackgroundTrans", "Automated Wheel Spinning for PS99")

; Instructions
MyGui.SetFont("s9 c" COLORS.warning, "Segoe UI")
MyGui.Add("Text", "x20 y120 w360 Center c" SubStr(COLORS.warning, 3), "📌 Position Roblox window to show the spin wheel before starting")

; Status Section
MyGui.SetFont("s10 c" COLORS.text, "Segoe UI")
MyGui.Add("Progress", "x20 y150 w360 h2 Background" SubStr(COLORS.border, 3))
MyGui.Add("Text", "x20 y162 c" COLORS.text, "Status:")
StatusText := MyGui.Add("Text", "x80 y162 w300 c" SubStr(COLORS.danger, 3), "⚫ Stopped")

MyGui.Add("Text", "x20 y192 c" COLORS.text, "Mode:")
ModeText := MyGui.Add("Text", "x80 y192 w300 c" SubStr(COLORS.warning, 3), "⏸ Paused")

; Statistics Section
MyGui.Add("Progress", "x20 y222 w360 h2 Background" SubStr(COLORS.border, 3))
MyGui.SetFont("s9 bold c" COLORS.text, "Segoe UI")
MyGui.Add("Text", "x20 y234", "📊 Statistics:")

MyGui.SetFont("s9 c" COLORS.text, "Segoe UI")
MyGui.Add("Text", "x20 y259", "Total Spins:")
TotalSpinsText := MyGui.Add("Text", "x120 y259 w240 c" SubStr(COLORS.info := "0x58a6ff", 3), "0")

MyGui.Add("Text", "x20 y284 c" COLORS.text, "Runtime:")
TimeText := MyGui.Add("Text", "x120 y284 w240 c" SubStr(COLORS.info, 3), "00:00:00")

MyGui.Add("Text", "x20 y309 c" COLORS.text, "Spins/Min:")
SpeedText := MyGui.Add("Text", "x120 y309 w240 c" SubStr(COLORS.info, 3), "0")

; Separator
MyGui.Add("Progress", "x20 y334 w360 h2 Background" SubStr(COLORS.border, 3))

; Control Buttons
MyGui.SetFont("s11 bold c" COLORS.buttonText, "Segoe UI")
StartBtn := MyGui.Add("Button", "x20 y349 w170 h50 Background" SubStr(COLORS.success, 3), "▶ Start (F1)")
StartBtn.OnEvent("Click", StartMacro)

StopBtn := MyGui.Add("Button", "x210 y349 w170 h50 Background" SubStr(COLORS.danger, 3) " Disabled", "⏹ Stop (F3)")
StopBtn.OnEvent("Click", StopMacro)

PauseBtn := MyGui.Add("Button", "x20 y409 w170 h50 Background" SubStr(COLORS.warning, 3) " Disabled", "⏸ Pause (F2)")
PauseBtn.OnEvent("Click", TogglePauseUI)

ResumeBtn := MyGui.Add("Button", "x210 y409 w170 h50 Background" SubStr(COLORS.info, 3) " Disabled", "▶ Resume (F2)")
ResumeBtn.OnEvent("Click", TogglePauseUI)

; Reset Stats Button
MyGui.SetFont("s10 c" COLORS.text, "Segoe UI")
ResetBtn := MyGui.Add("Button", "x20 y469 w360 h35 Background" SubStr(COLORS.cardBg, 3), "🔄 Reset Statistics")
ResetBtn.OnEvent("Click", ResetStats)

; Separator
MyGui.Add("Progress", "x20 y514 w360 h2 Background" SubStr(COLORS.border, 3))

; Settings Section
MyGui.SetFont("s9 bold c" COLORS.text, "Segoe UI")
MyGui.Add("Text", "x20 y526", "⚙️ Settings:")

MyGui.SetFont("s9 c" COLORS.text, "Segoe UI")
MyGui.Add("Text", "x20 y551", "Spin Delay (ms):")
DelaySlider := MyGui.Add("Slider", "x120 y551 w200 Range100-1000 ToolTip", 100)
DelayText := MyGui.Add("Text", "x330 y551 w50 c" SubStr(COLORS.info, 3), "100")
DelaySlider.OnEvent("Change", (*) => DelayText.Value := DelaySlider.Value)

; Separator
MyGui.Add("Progress", "x20 y581 w360 h2 Background" SubStr(COLORS.border, 3))

; Hotkeys Info
MyGui.SetFont("s9 c" COLORS.text, "Segoe UI")
MyGui.Add("Text", "x20 y593", "Hotkeys:")
MyGui.SetFont("s9 c" COLORS.textDim, "Segoe UI")
MyGui.Add("Text", "x20 y613", "F1 - Start  |  F2 - Pause/Resume  |  F3 - Stop  |  F5 - Reload")

; Position Map
PositionMap := Map(
    "SpinnButton", [171, 423],
    "CloseButton", [749, 111],
    "OkButton", [401, 420]
)

MyGui.Show("w400 h650")

; Set timer for updating runtime and stats
SetTimer(UpdateStats, 1000)

; Hotkeys
F1::StartMacro()
F2::TogglePauseUI()
F3::StopMacro()
F5::Reload

; Functions
StartMacro(*) {
    global MacroRunning, Toggle, StartTime
    
    if !WinExist("ahk_exe RobloxPlayerBeta.exe") {
        MsgBox("❌ Roblox window not found!`n`nPlease launch Roblox and make sure the spin wheel is visible.", "Error", "Icon! T5")
        return
    }
    
    if MacroRunning {
        return
    }
    
    MacroRunning := true
    Toggle := true
    StartTime := A_TickCount
    
    StatusText.Value := "🟢 Running"
    StatusText.SetFont("cLime")
    ModeText.Value := "▶ Active"
    ModeText.SetFont("cLime")
    
    StartBtn.Enabled := false
    StopBtn.Enabled := true
    PauseBtn.Enabled := true
    ResumeBtn.Enabled := false
    
    ; Activate and resize Roblox window
    WinActivate("ahk_exe RobloxPlayerBeta.exe")
    Sleep(300)
    WinMove(0, 0, 800, 600, "ahk_exe RobloxPlayerBeta.exe")
    Sleep(500)
    
    SetTimer(MacroCode, 50)
}

StopMacro(*) {
    global MacroRunning, Toggle
    
    if !MacroRunning {
        return
    }
    
    MacroRunning := false
    Toggle := false
    
    StatusText.Value := "⚫ Stopped"
    StatusText.SetFont("cRed")
    ModeText.Value := "⏸ Paused"
    ModeText.SetFont("c0xFFAA00")
    
    StartBtn.Enabled := true
    StopBtn.Enabled := false
    PauseBtn.Enabled := false
    ResumeBtn.Enabled := false
    
    SetTimer(MacroCode, 0)
}

TogglePauseUI(*) {
    global Toggle, MacroRunning
    
    if !MacroRunning {
        return
    }
    
    Toggle := !Toggle
    
    if Toggle {
        ModeText.Value := "▶ Active"
        ModeText.SetFont("cLime")
        PauseBtn.Enabled := true
        ResumeBtn.Enabled := false
    } else {
        ModeText.Value := "⏸ Paused"
        ModeText.SetFont("c0xFFAA00")
        PauseBtn.Enabled := false
        ResumeBtn.Enabled := true
    }
}

ResetStats(*) {
    global TotalSpins
    
    result := MsgBox("Are you sure you want to reset all statistics?", "Reset Statistics", "YesNo Icon?")
    if result = "Yes" {
        TotalSpins := 0
        UpdateStatsDisplay()
        SaveStats()
    }
}

LoadStats() {
    global TotalSpins, StatsFile
    
    try {
        TotalSpins := IniRead(StatsFile, "Statistics", "TotalSpins", 0)
    } catch {
        TotalSpins := 0
    }
}

SaveStats() {
    global TotalSpins, StatsFile
    
    try {
        IniWrite(TotalSpins, StatsFile, "Statistics", "TotalSpins")
        IniWrite(FormatTime(A_Now, "yyyy-MM-dd HH:mm:ss"), StatsFile, "Statistics", "LastUpdated")
    }
}

UpdateStats(*) {
    global MacroRunning, StartTime, Toggle
    
    if MacroRunning && Toggle {
        UpdateStatsDisplay()
    }
}

UpdateStatsDisplay() {
    global TotalSpins, StartTime, MacroRunning, Toggle
    
    ; Update runtime
    if MacroRunning && Toggle {
        elapsed := (A_TickCount - StartTime) // 1000
        hours := Format("{:02}", elapsed // 3600)
        minutes := Format("{:02}", (elapsed // 60) - (hours * 60))
        seconds := Format("{:02}", Mod(elapsed, 60))
        TimeText.Value := hours ":" minutes ":" seconds
        
        ; Calculate spins per minute
        if elapsed > 0 {
            spinsPerMin := Round((TotalSpins * 60) / elapsed, 1)
            SpeedText.Value := spinsPerMin
        }
    }
    
    ; Update statistics
    TotalSpinsText.Value := TotalSpins
    
    ; Save stats to file
    SaveStats()
}

MacroCode(*) {
    global Toggle, TotalSpins, MacroRunning
    
    if !Toggle || !MacroRunning {
        return
    }
    
    SB := PositionMap["SpinnButton"]
    CB := PositionMap["CloseButton"]
    OB := PositionMap["OkButton"]
    
    customDelay := DelaySlider.Value
    
    TotalSpins++
    
    ; Click spin button
    SendEvent("{Click " SB[1] " " SB[2] "}")
    Sleep(customDelay)
    
    ; Click close button
    SendEvent("{Click " CB[1] " " CB[2] "}")
    Sleep(customDelay)
    
    ; Click OK button
    SendEvent("{Click " OB[1] " " OB[2] "}")
    Sleep(customDelay)
    
    UpdateStatsDisplay()
}