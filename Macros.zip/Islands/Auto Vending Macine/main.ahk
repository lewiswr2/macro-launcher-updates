#Requires AutoHotkey v2.0
#SingleInstance Force
#Hotstring NoMouse
#NoTrayIcon

; ========== COLOR SCHEME (MATCHING AUTO CLICKER) ==========
global COLORS := {
    bg: "0x0a0e14",
    bgLight: "0x13171d",
    card: "0x161b22",
    cardHover: "0x1c2128",
    accent: "0xd29922",
    accentHover: "0x2ea043",
    accentAlt: "0x1f6feb",
    text: "0xe6edf3",
    textDim: "0x7d8590",
    border: "0x21262d",
    success: "0x238636",
    warning: "0xd29922",
    danger: "0xda3633"
}

; Configuration file paths
configFile := A_ScriptDir "\vending_config.ini"
statsFile := A_ScriptDir "\vending_stats.ini"
presetsFile := A_ScriptDir "\vending_presets.ini"

; Slot coordinates (buy position, sell position)
slotCoords := [
    {buy: {x: 40, y: 322}, sell: {x: 13, y: 461}},    ; Slot 1
    {buy: {x: 175, y: 320}, sell: {x: 144, y: 471}},  ; Slot 2
    {buy: {x: 338, y: 312}, sell: {x: 309, y: 472}},  ; Slot 3
    {buy: {x: 469, y: 304}, sell: {x: 469, y: 470}},  ; Slot 4
    {buy: {x: 593, y: 321}, sell: {x: 632, y: 475}},  ; Slot 5
    {buy: {x: 732, y: 300}, sell: {x: 765, y: 478}}   ; Slot 6
]

; Inventory slot clicks (1-6) when in F menu
inventorySlots := [
    {x: 168, y: 484},
    {x: 202, y: 484},
    {x: 237, y: 483},
    {x: 275, y: 488},
    {x: 311, y: 484},
    {x: 336, y: 486}
]

; Special click for buy-to-sell transition
extraBuyClick := {x: 626, y: 340}

; Store slot configurations
slotConfigs := []

; Undo/Redo stacks
undoStack := []
redoStack := []
maxUndoSteps := 20

; Stats tracking
global totalCycles := 0
global sessionStartTime := A_TickCount
global totalRuntime := 0
global estimatedProfit := 0

; ===================================
; HELPER FUNCTIONS
; ===================================
ConvertShorthand(input) {
    input := Trim(input)
    input := StrLower(input)
    
    if IsNumber(input)
        return input
    
    if RegExMatch(input, "^([\d.]+)\s*([kmbt]?)$", &match) {
        numPart := match[1]
        suffix := match[2]
        
        multiplier := 1
        switch suffix {
            case "k": multiplier := 1000
            case "m": multiplier := 1000000
            case "b": multiplier := 1000000000
            case "t": multiplier := 1000000000000
        }
        
        result := Round(Float(numPart) * multiplier)
        return String(result)
    }
    
    return input
}

FormatNumber(num) {
    numStr := String(num)
    result := ""
    len := StrLen(numStr)
    loop len {
        idx := len - A_Index + 1
        char := SubStr(numStr, idx, 1)
        result := char result
        if (Mod(len - idx, 3) = 0 and idx > 1)
            result := "," result
    }
    return result
}

NumberToShorthand(num) {
    try {
        numVal := Float(num)
        if (numVal >= 1000000000000)
            return Format("{:.1f}t", numVal / 1000000000000)
        if (numVal >= 1000000000)
            return Format("{:.1f}b", numVal / 1000000000)
        if (numVal >= 1000000)
            return Format("{:.1f}m", numVal / 1000000)
        if (numVal >= 1000)
            return Format("{:.1f}k", numVal / 1000)
        return String(num)
    }
    return num
}

IsNumber(str) {
    try {
        Float(str)
        return true
    }
    return false
}

FormatTime(milliseconds) {
    totalSeconds := milliseconds // 1000
    hours := totalSeconds // 3600
    minutes := Mod(totalSeconds // 60, 60)
    seconds := Mod(totalSeconds, 60)
    
    if (hours > 0)
        return Format("{:02d}:{:02d}:{:02d}", hours, minutes, seconds)
    else
        return Format("{:02d}:{:02d}", minutes, seconds)
}

; ===================================
; UNDO/REDO SYSTEM
; ===================================
SaveStateForUndo() {
    global undoStack, redoStack, slotConfigs
    
    ; Capture current state
    state := []
    for config in slotConfigs {
        state.Push({
            action: config.action.Value,
            buyPrice: config.buyPrice.Value,
            sellPrice: config.sellPrice.Value,
            enabled: config.enabled.Value
        })
    }
    
    ; Add to undo stack
    undoStack.Push(state)
    
    ; Limit stack size
    if (undoStack.Length > maxUndoSteps)
        undoStack.RemoveAt(1)
    
    ; Clear redo stack when new action is performed
    redoStack := []
}

PerformUndo() {
    global undoStack, redoStack, slotConfigs
    
    if (undoStack.Length = 0) {
        ToolTip("Nothing to undo")
        SetTimer () => ToolTip(), -1000
        return
    }
    
    ; Save current state to redo stack
    currentState := []
    for config in slotConfigs {
        currentState.Push({
            action: config.action.Value,
            buyPrice: config.buyPrice.Value,
            sellPrice: config.sellPrice.Value,
            enabled: config.enabled.Value
        })
    }
    redoStack.Push(currentState)
    
    ; Restore previous state
    state := undoStack.Pop()
    for i, config in slotConfigs {
        config.action.Choose(state[i].action)
        config.buyPrice.Value := state[i].buyPrice
        config.sellPrice.Value := state[i].sellPrice
        config.enabled.Value := state[i].enabled
        UpdateStatusIndicator(i)
    }
    
    ToolTip("✓ Undo successful")
    SetTimer () => ToolTip(), -1000
}

SetTrayIcon() {
    logoPath := A_ScriptDir "\logo.png"
    if FileExist(logoPath) {
        try {
            TraySetIcon(logoPath)
        }
    }
}

PerformRedo() {
    global undoStack, redoStack, slotConfigs
    
    if (redoStack.Length = 0) {
        ToolTip("Nothing to redo")
        SetTimer () => ToolTip(), -1000
        return
    }
    
    ; Save current state to undo stack
    currentState := []
    for config in slotConfigs {
        currentState.Push({
            action: config.action.Value,
            buyPrice: config.buyPrice.Value,
            sellPrice: config.sellPrice.Value,
            enabled: config.enabled.Value
        })
    }
    undoStack.Push(currentState)
    
    ; Restore redo state
    state := redoStack.Pop()
    for i, config in slotConfigs {
        config.action.Choose(state[i].action)
        config.buyPrice.Value := state[i].buyPrice
        config.sellPrice.Value := state[i].sellPrice
        config.enabled.Value := state[i].enabled
        UpdateStatusIndicator(i)
    }
    
    ToolTip("✓ Redo successful")
    SetTimer () => ToolTip(), -1000
}

; ===================================
; STATS FUNCTIONS
; ===================================
LoadStats() {
    global totalCycles, totalRuntime, estimatedProfit, statsFile
    
    if FileExist(statsFile) {
        totalCycles := IniRead(statsFile, "Stats", "TotalCycles", 0)
        totalRuntime := IniRead(statsFile, "Stats", "TotalRuntime", 0)
        estimatedProfit := IniRead(statsFile, "Stats", "EstimatedProfit", 0)
    }
}

SaveStats() {
    global totalCycles, totalRuntime, estimatedProfit, statsFile
    
    IniWrite(totalCycles, statsFile, "Stats", "TotalCycles")
    IniWrite(totalRuntime, statsFile, "Stats", "TotalRuntime")
    IniWrite(estimatedProfit, statsFile, "Stats", "EstimatedProfit")
}

ResetStats() {
    global totalCycles, totalRuntime, estimatedProfit, sessionStartTime
    
    result := MsgBox("Are you sure you want to reset all stats?", "Reset Statistics", "YesNo Icon!")
    if (result = "Yes") {
        totalCycles := 0
        totalRuntime := 0
        estimatedProfit := 0
        sessionStartTime := A_TickCount
        SaveStats()
        UpdateStatsDisplay()
        ToolTip("✓ Stats reset")
        SetTimer () => ToolTip(), -1500
    }
}

UpdateStatsDisplay() {
    global statsText, totalCycles, totalRuntime, estimatedProfit, sessionStartTime
    
    ; Calculate session time
    sessionTime := A_TickCount - sessionStartTime
    
    statsText.Value := Format("Cycles: {} | Runtime: {} | Session: {} | Est. Profit: {}",
        totalCycles,
        FormatTime(totalRuntime),
        FormatTime(sessionTime),
        FormatNumber(estimatedProfit))
}

CalculateProfit() {
    global slotConfigs, estimatedProfit
    
    profit := 0
    for config in slotConfigs {
        if !config.enabled.Value
            continue
        
        buyPrice := Float(ConvertShorthand(config.buyPrice.Value))
        sellPrice := Float(ConvertShorthand(config.sellPrice.Value))
        
        ; Calculate profit based on action type
        actionVal := config.action.Value
        if (actionVal = 2) { ; Sell only
            profit += sellPrice
        } else if (actionVal = 3) { ; Both
            profit += (sellPrice - buyPrice)
        }
    }
    
    estimatedProfit += profit
    SaveStats()
}

; ===================================
; PRESET SYSTEM
; ===================================
SavePreset() {
    global slotConfigs, presetsFile
    
    ; Ask for preset name
    ib := InputBox("Enter a name for this preset:", "Save Preset")
    if (ib.Result = "Cancel")
        return
    
    presetName := ib.Value
    if (presetName = "")
        return
    
    ; Save each slot configuration
    for config in slotConfigs {
        slotNum := config.slotNum
        actionText := config.action.Text
        
        if InStr(actionText, "💰")
            actionText := "Buy"
        else if InStr(actionText, "💸")
            actionText := "Sell"
        else if InStr(actionText, "🔄")
            actionText := "Both"
        
        IniWrite(actionText, presetsFile, presetName, "Slot" slotNum "Action")
        IniWrite(config.buyPrice.Value, presetsFile, presetName, "Slot" slotNum "BuyPrice")
        IniWrite(config.sellPrice.Value, presetsFile, presetName, "Slot" slotNum "SellPrice")
        IniWrite(config.enabled.Value, presetsFile, presetName, "Slot" slotNum "Enabled")
    }
    
    ToolTip("✓ Preset '" presetName "' saved!")
    SetTimer () => ToolTip(), -2000
    
    ; Refresh preset list
    UpdatePresetList()
}

LoadPreset() {
    global slotConfigs, presetsFile, presetDropdown
    
    if !presetDropdown.Value {
        ToolTip("Please select a preset first")
        SetTimer () => ToolTip(), -1500
        return
    }
    
    presetName := presetDropdown.Text
    
    ; Save current state for undo
    SaveStateForUndo()
    
    ; Load preset
    for config in slotConfigs {
        slotNum := config.slotNum
        
        action := IniRead(presetsFile, presetName, "Slot" slotNum "Action", "")
        if (action = "")
            continue
            
        switch action {
            case "Buy": config.action.Choose(1)
            case "Sell": config.action.Choose(2)
            case "Both": config.action.Choose(3)
        }
        
        config.buyPrice.Value := IniRead(presetsFile, presetName, "Slot" slotNum "BuyPrice", "10m")
        config.sellPrice.Value := IniRead(presetsFile, presetName, "Slot" slotNum "SellPrice", "22.5m")
        config.enabled.Value := IniRead(presetsFile, presetName, "Slot" slotNum "Enabled", 1)
        
        UpdateStatusIndicator(slotNum)
    }
    
    ToolTip("✓ Preset '" presetName "' loaded!")
    SetTimer () => ToolTip(), -2000
}

DeletePreset() {
    global presetsFile, presetDropdown
    
    if !presetDropdown.Value {
        ToolTip("Please select a preset first")
        SetTimer () => ToolTip(), -1500
        return
    }
    
    presetName := presetDropdown.Text
    
    result := MsgBox("Delete preset '" presetName "'?", "Delete Preset", "YesNo Icon!")
    if (result = "Yes") {
        ; Delete section from INI
        IniDelete(presetsFile, presetName)
        
        ToolTip("✓ Preset deleted")
        SetTimer () => ToolTip(), -1500
        
        UpdatePresetList()
    }
}

UpdatePresetList() {
    global presetsFile, presetDropdown
    
    ; Read all sections from presets file
    presets := []
    if FileExist(presetsFile) {
        content := FileRead(presetsFile)
        Loop Parse, content, "`n", "`r" {
            if RegExMatch(A_LoopField, "^\[(.*)\]$", &match) {
                presets.Push(match[1])
            }
        }
    }
    
    ; Update dropdown
    if (presets.Length > 0) {
        presetDropdown.Delete()
        for preset in presets {
            presetDropdown.Add([preset])
        }
        presetDropdown.Choose(1)
    } else {
        presetDropdown.Delete()
        presetDropdown.Add(["No presets saved"])
        presetDropdown.Choose(1)
    }
}

; ===================================
; COPY SLOT FUNCTION
; ===================================
CopySlot() {
    global slotConfigs
    
    ; Ask which slot to copy from
    ib := InputBox("Copy FROM which slot? (1-6)", "Copy Slot")
    if (ib.Result = "Cancel")
        return
    
    fromSlot := Integer(ib.Value)
    if (fromSlot < 1 or fromSlot > 6) {
        MsgBox("Invalid slot number. Must be 1-6.", "Error", "Icon!")
        return
    }
    
    ; Ask which slot to copy to
    ib2 := InputBox("Copy TO which slot? (1-6, or 'all' for all slots)", "Copy Slot")
    if (ib2.Result = "Cancel")
        return
    
    ; Save state for undo
    SaveStateForUndo()
    
    sourceConfig := slotConfigs[fromSlot]
    
    if (ib2.Value = "all") {
        ; Copy to all slots
        for i, config in slotConfigs {
            if (i = fromSlot)
                continue
            config.action.Choose(sourceConfig.action.Value)
            config.buyPrice.Value := sourceConfig.buyPrice.Value
            config.sellPrice.Value := sourceConfig.sellPrice.Value
            config.enabled.Value := sourceConfig.enabled.Value
            UpdateStatusIndicator(i)
        }
        ToolTip("✓ Slot " fromSlot " copied to all slots")
    } else {
        toSlot := Integer(ib2.Value)
        if (toSlot < 1 or toSlot > 6) {
            MsgBox("Invalid slot number. Must be 1-6 or 'all'.", "Error", "Icon!")
            return
        }
        
        targetConfig := slotConfigs[toSlot]
        targetConfig.action.Choose(sourceConfig.action.Value)
        targetConfig.buyPrice.Value := sourceConfig.buyPrice.Value
        targetConfig.sellPrice.Value := sourceConfig.sellPrice.Value
        targetConfig.enabled.Value := sourceConfig.enabled.Value
        UpdateStatusIndicator(toSlot)
        
        ToolTip("✓ Slot " fromSlot " copied to slot " toSlot)
    }
    
    SetTimer () => ToolTip(), -2000
}

; ===================================
; CREATE GUI
; ===================================
mainGui := Gui("+AlwaysOnTop -DPIScale", "AHK Vault - Islands Vending Macro")
mainGui.BackColor := COLORS.bg
mainGui.SetFont("s9 c" COLORS.text, "Segoe UI")
mainGui.OnEvent("Close", (*) => SaveAndExit())

; ========== HEADER ==========
mainGui.Add("Text", "x0 y0 w800 h60 Background" COLORS.accent)

; Add logo if it exists
logoPath := A_ScriptDir "\logo.png"
if FileExist(logoPath) {
    try {
        logoPic := mainGui.Add("Picture", "x15 y12 w36 h36 BackgroundTrans", logoPath)
        headerText := mainGui.Add("Text", "x60 y15 w700 h100 c" COLORS.text " BackgroundTrans", "Islands Vending Macro")
        headerText.SetFont("s16 bold")
        statusText := mainGui.Add("Text", "x60 y40 w700 c" COLORS.text " BackgroundTrans", "Status: Stopped")
        statusText.SetFont("s9")
    } catch {
        ; If logo fails to load, fall back to text only
        headerText := mainGui.Add("Text", "x20 y15 w760 h100 c" COLORS.text " BackgroundTrans", "Islands Vending Macro")
        headerText.SetFont("s16 bold")
        statusText := mainGui.Add("Text", "x20 y40 w760 c" COLORS.text " BackgroundTrans", "Status: Stopped")
        statusText.SetFont("s9")
    }
} else {
    headerText := mainGui.Add("Text", "x20 y15 w760 h100 c" COLORS.text " BackgroundTrans", "Islands Vending Macro")
    headerText.SetFont("s16 bold")
    statusText := mainGui.Add("Text", "x20 y40 w760 c" COLORS.text " BackgroundTrans", "Status: Stopped")
    statusText.SetFont("s9")
}

; === STATS BAR ===
yPos := 75
mainGui.Add("Text", "x20 y" yPos " w760 c" COLORS.text, "Statistics").SetFont("s10 bold")
mainGui.Add("Text", "x20 y" (yPos + 22) " w760 h1 Background" COLORS.border)

yPos += 35
statsText := mainGui.Add("Text", "x30 y" yPos " w650 h26 Border c" COLORS.text " Background" COLORS.bgLight " Center", "Cycles: 0 | Runtime: 00:00 | Session: 00:00 | Est. Profit: 0")
mainGui.Add("Button", "x690 y" yPos " w90 h26 Background" COLORS.danger, "Reset Stats").OnEvent("Click", (*) => ResetStats())

; === PRESET MANAGER ===
yPos += 45
mainGui.Add("Text", "x20 y" yPos " w760 c" COLORS.text, "Preset Manager").SetFont("s10 bold")
mainGui.Add("Text", "x20 y" (yPos + 22) " w760 h1 Background" COLORS.border)

yPos += 35
mainGui.Add("Text", "x30 y" (yPos + 5) " w60 c" COLORS.textDim, "Preset:")
presetDropdown := mainGui.Add("DropDownList", "x95 y" yPos " w230 h26 Background" COLORS.bgLight " c" COLORS.text, ["No presets saved"])
mainGui.Add("Button", "x335 y" yPos " w80 h26 Background" COLORS.success, "Load").OnEvent("Click", (*) => LoadPreset())
mainGui.Add("Button", "x420 y" yPos " w80 h26 Background" COLORS.accentAlt, "Save").OnEvent("Click", (*) => SavePreset())
mainGui.Add("Button", "x505 y" yPos " w80 h26 Background" COLORS.danger, "Delete").OnEvent("Click", (*) => DeletePreset())

; Undo/Redo and Copy
mainGui.Add("Button", "x600 y" yPos " w80 h26 Background" COLORS.warning, "↶ Undo").OnEvent("Click", (*) => PerformUndo())
mainGui.Add("Button", "x685 y" yPos " w95 h26 Background" COLORS.warning, "↷ Redo").OnEvent("Click", (*) => PerformRedo())

yPos += 32
mainGui.Add("Button", "x30 y" yPos " w100 h26 Background0xbc4c00", "📋 Copy Slot").OnEvent("Click", (*) => CopySlot())

; === TWO COLUMN LAYOUT ===
; LEFT COLUMN - Setup Guide
yPos += 45
mainGui.Add("Text", "x20 y" yPos " w360 c" COLORS.text, "Quick Setup").SetFont("s10 bold")
yPos += 22
mainGui.Add("Text", "x20 y" yPos " w360 h1 Background" COLORS.border)

yPos += 15
setupSteps := [
    "1. Place items in inventory slots 1-6",
    "2. Align colored dots with vending machines",
    "3. Configure prices using shorthand",
    "4. Press F1 to start automation"
]

for step in setupSteps {
    mainGui.Add("Text", "x30 y" yPos " w340 c" COLORS.text, step)
    yPos += 22
}

; RIGHT COLUMN - Shorthand + Bulk Setter
tempYPos := yPos - 88
mainGui.Add("Text", "x420 y" tempYPos " w360 c" COLORS.text, "Shorthand & Bulk Setter").SetFont("s10 bold")
mainGui.SetFont("s9", "Segoe UI")
tempYPos += 22
mainGui.Add("Text", "x420 y" tempYPos " w360 h1 Background" COLORS.border)

tempYPos += 15
mainGui.Add("Text", "x430 y" tempYPos " w175 c" COLORS.text, "• 1k = 1,000")
mainGui.Add("Text", "x430 y" (tempYPos + 22) " w175 c" COLORS.text, "• 1m = 1,000,000")
mainGui.Add("Text", "x630 y" tempYPos " w145 c" COLORS.text, "• 1b = 1,000,000,000")
mainGui.Add("Text", "x630 y" (tempYPos + 22) " w145 c" COLORS.text, "• 1t = 1,000,000,000,000")

tempYPos += 50
mainGui.Add("Text", "x430 y" (tempYPos + 3) " w60 c" COLORS.textDim, "Buy:")
bulkBuyEdit := mainGui.Add("Edit", "x490 y" tempYPos " w120 h26 Center Background" COLORS.bgLight " c" COLORS.text, "10m")
mainGui.Add("Button", "x620 y" tempYPos " w75 h26 Background" COLORS.success, "Apply").OnEvent("Click", (*) => ApplyBulkPrice("buy"))

tempYPos += 30
mainGui.Add("Text", "x430 y" (tempYPos + 3) " w60 c" COLORS.textDim, "Sell:")
bulkSellEdit := mainGui.Add("Edit", "x490 y" tempYPos " w120 h26 Center Background" COLORS.bgLight " c" COLORS.text, "22.5m")
mainGui.Add("Button", "x620 y" tempYPos " w75 h26 Background" COLORS.warning, "Apply").OnEvent("Click", (*) => ApplyBulkPrice("sell"))

; Apply bulk price function
ApplyBulkPrice(priceType) {
    global slotConfigs, bulkBuyEdit, bulkSellEdit
    
    SaveStateForUndo()
    
    if (priceType = "buy") {
        value := bulkBuyEdit.Value
        converted := ConvertShorthand(value)
        for config in slotConfigs {
            config.buyPrice.Value := converted
        }
        ToolTip("✓ Applied " FormatNumber(converted) " to all Buy prices")
        SetTimer () => ToolTip(), -2000
    } else {
        value := bulkSellEdit.Value
        converted := ConvertShorthand(value)
        for config in slotConfigs {
            config.sellPrice.Value := converted
        }
        ToolTip("✓ Applied " FormatNumber(converted) " to all Sell prices")
        SetTimer () => ToolTip(), -2000
    }
}

; === QUICK ACTIONS ===
yPos += 45
mainGui.Add("Text", "x20 y" yPos " w760 c" COLORS.text, "Quick Actions").SetFont("s10 bold")
mainGui.Add("Text", "x20 y" (yPos + 22) " w760 h1 Background" COLORS.border)
mainGui.SetFont("s9", "Segoe UI")

yPos += 35
mainGui.Add("Button", "x20 y" yPos " w120 h32 Background" COLORS.success, "✓ Enable All").OnEvent("Click", (*) => (SaveStateForUndo(), EnableAllSlots(true)))
mainGui.Add("Button", "x145 y" yPos " w120 h32 Background" COLORS.textDim, "✗ Disable All").OnEvent("Click", (*) => (SaveStateForUndo(), EnableAllSlots(false)))
mainGui.Add("Button", "x270 y" yPos " w120 h32 Background" COLORS.accentAlt, "💰 All Buy").OnEvent("Click", (*) => (SaveStateForUndo(), SetAllActions(1)))
mainGui.Add("Button", "x395 y" yPos " w120 h32 Background" COLORS.warning, "💸 All Sell").OnEvent("Click", (*) => (SaveStateForUndo(), SetAllActions(2)))
mainGui.Add("Button", "x520 y" yPos " w120 h32 Background0xa371f7", "🔄 All Both").OnEvent("Click", (*) => (SaveStateForUndo(), SetAllActions(3)))
mainGui.Add("Button", "x645 y" yPos " w135 h32 Background0xbc4c00", "🔢 Format All").OnEvent("Click", (*) => FormatAllPrices())

; Format all prices
FormatAllPrices() {
    global slotConfigs
    for config in slotConfigs {
        buyVal := config.buyPrice.Value
        sellVal := config.sellPrice.Value
        config.buyPrice.Value := NumberToShorthand(ConvertShorthand(buyVal))
        config.sellPrice.Value := NumberToShorthand(ConvertShorthand(sellVal))
    }
    ToolTip("✓ All prices formatted to shorthand")
    SetTimer () => ToolTip(), -2000
}

; === SLOT CONFIGURATION ===
yPos += 45
mainGui.Add("Text", "x20 y" yPos " w760 c" COLORS.text, "Slot Configuration").SetFont("s10 bold")
mainGui.Add("Text", "x20 y" (yPos + 22) " w760 h1 Background" COLORS.border)

; Headers
yPos += 35
mainGui.SetFont("s8 bold", "Segoe UI")
mainGui.Add("Text", "x30 y" yPos " w50 Center c" COLORS.textDim " Background" COLORS.card, "SLOT")
mainGui.Add("Text", "x90 y" yPos " w110 Center c" COLORS.textDim " Background" COLORS.card, "ACTION")
mainGui.Add("Text", "x210 y" yPos " w200 Center c" COLORS.textDim " Background" COLORS.card, "BUY PRICE")
mainGui.Add("Text", "x420 y" yPos " w200 Center c" COLORS.textDim " Background" COLORS.card, "SELL PRICE")
mainGui.Add("Text", "x630 y" yPos " w70 Center c" COLORS.textDim " Background" COLORS.card, "ENABLE")
mainGui.Add("Text", "x710 y" yPos " w70 Center c" COLORS.textDim " Background" COLORS.card, "STATUS")

; Slot rows
mainGui.SetFont("s9", "Segoe UI")
yPos += 27

slotColors := ["0x1f6feb", "0x238636", "0x9e6a03", "0xbc4c00", "0xa371f7", "0xd2a8ff"]

for i, slot in slotCoords {
    slotIndex := i
    
    bgColor := (Mod(i, 2) = 0) ? COLORS.bg : COLORS.card
    
    rowBg := mainGui.Add("Text", "x20 y" (yPos - 5) " w760 h40 Background" bgColor)
    
    mainGui.SetFont("s11 bold", "Segoe UI")
    mainGui.Add("Text", "x30 y" yPos " w50 h30 Center Border c" slotColors[i], i)
    
    mainGui.SetFont("s9", "Segoe UI")
    actionDD := mainGui.Add("DropDownList", "x90 y" yPos " w110 Background" COLORS.bgLight " c" COLORS.text, ["Buy", "Sell", "Both"])
    actionDD.Choose(1)
    actionDD.OnEvent("Change", ((idx) => (*) => SaveStateForUndo())(slotIndex))
    
    buyPriceEdit := mainGui.Add("Edit", "x210 y" yPos " w165 h30 Center Background" COLORS.bgLight " c" COLORS.text, "10m")
    
    buyFormatBtn := mainGui.Add("Button", "x380 y" yPos " w25 h30 Background" COLORS.accentAlt, ">")
    buyFormatBtn.OnEvent("Click", ((idx) => (*) => FormatSlotPrice(idx, "buy"))(slotIndex))
    buyFormatBtn.ToolTip := "Convert to shorthand"
    
    sellPriceEdit := mainGui.Add("Edit", "x420 y" yPos " w165 h30 Center Background" COLORS.bgLight " c" COLORS.text, "22.5m")
    
    sellFormatBtn := mainGui.Add("Button", "x590 y" yPos " w25 h30 Background" COLORS.warning, ">")
    sellFormatBtn.OnEvent("Click", ((idx) => (*) => FormatSlotPrice(idx, "sell"))(slotIndex))
    sellFormatBtn.ToolTip := "Convert to shorthand"
    
    enableCheck := mainGui.Add("CheckBox", "x630 y" yPos " w70 h30 Center Checked Background" bgColor)
    
    statusIndicator := mainGui.Add("Text", "x710 y" yPos " w70 h30 Center c" COLORS.success, "●")
    statusIndicator.SetFont("s11 bold")
    
    slotConfigs.Push({
        action: actionDD,
        buyPrice: buyPriceEdit,
        sellPrice: sellPriceEdit,
        enabled: enableCheck,
        statusIndicator: statusIndicator,
        slotNum: i,
        rowBg: rowBg
    })
    
    enableCheck.OnEvent("Click", ((idx) => (*) => (SaveStateForUndo(), UpdateStatusIndicator(idx)))(slotIndex))
    buyPriceEdit.OnEvent("LoseFocus", ((idx) => (*) => ConvertInputToNumber(idx, "buy"))(slotIndex))
    sellPriceEdit.OnEvent("LoseFocus", ((idx) => (*) => ConvertInputToNumber(idx, "sell"))(slotIndex))
    
    yPos += 40
}

; Format individual slot price
FormatSlotPrice(slotNum, priceType) {
    global slotConfigs
    config := slotConfigs[slotNum]
    
    if (priceType = "buy") {
        value := config.buyPrice.Value
        converted := ConvertShorthand(value)
        shorthand := NumberToShorthand(converted)
        config.buyPrice.Value := shorthand
        ToolTip("Slot " slotNum " buy: " FormatNumber(converted) " → " shorthand)
    } else {
        value := config.sellPrice.Value
        converted := ConvertShorthand(value)
        shorthand := NumberToShorthand(converted)
        config.sellPrice.Value := shorthand
        ToolTip("Slot " slotNum " sell: " FormatNumber(converted) " → " shorthand)
    }
    SetTimer () => ToolTip(), -1500
}

; Auto-convert on focus loss
ConvertInputToNumber(slotNum, priceType) {
    global slotConfigs
    config := slotConfigs[slotNum]
    
    if (priceType = "buy") {
        input := config.buyPrice.Value
        converted := ConvertShorthand(input)
        if (converted != input)
            config.buyPrice.Value := converted
    } else {
        input := config.sellPrice.Value
        converted := ConvertShorthand(input)
        if (converted != input)
            config.sellPrice.Value := converted
    }
}

; === CONTROLS ===
yPos += 45
mainGui.Add("Text", "x20 y" yPos " w760 c" COLORS.text, "Controls").SetFont("s10 bold")
mainGui.Add("Text", "x20 y" (yPos + 22) " w760 h1 Background" COLORS.border)
yPos += 35

; Control buttons
mainGui.SetFont("s11 bold", "Segoe UI")
btnY := yPos
mainGui.Add("Button", "x20 y" btnY " w185 h50 Background" COLORS.success, "▶ START`n(F1)").OnEvent("Click", (*) => StartMacro())
mainGui.Add("Button", "x210 y" btnY " w185 h50 Background" COLORS.warning, "⏸ PAUSE`n(F2)").OnEvent("Click", (*) => PauseMacro())
mainGui.Add("Button", "x400 y" btnY " w185 h50 Background" COLORS.danger, "⏹ EXIT`n(F3)").OnEvent("Click", (*) => SaveAndExit())
mainGui.Add("Button", "x590 y" btnY " w190 h50 Background" COLORS.accentAlt, "🔄 RELOAD`n(F5)").OnEvent("Click", (*) => SaveAndReload())

; Footer info
yPos := btnY + 60
mainGui.SetFont("s8", "Segoe UI")
mainGui.Add("Text", "x20 y" yPos " w760 Center c" COLORS.textDim, "🟢 Green (B1-B6) = Buy  |  🔴 Red (S1-S6) = Sell  |  Ctrl+Z = Undo  |  Ctrl+Y = Redo")
yPos += 16
mainGui.Add("Text", "x20 y" yPos " w760 Center c" COLORS.textDim, "Stats auto-save • Presets persist across sessions • All changes tracked for undo")

; Load data
LoadStats()
LoadConfig()
UpdatePresetList()
UpdateStatsDisplay()
SetTrayIcon()

; Setup stats update timer
SetTimer(UpdateStatsDisplay, 1000)

mainGui.Show("w800 h" (yPos + 30))

global robloxHandle := 0
try {
    statusText.Value := "Status: Searching for Roblox..."
    WinActivate "ahk_exe RobloxPlayerBeta.exe"
    Sleep 500
    
    statusText.Value := "Status: Resizing window..."
    try {
        robloxHandle := WinGetID("ahk_exe RobloxPlayerBeta.exe")
        WinRestore robloxHandle
        WinMove 0, 0, 800, 600, robloxHandle
    } catch {
        statusText.Value := "Status: Error - Couldn't resize window"
    }
    
    Sleep 1000
    WinActivate "ahk_exe RobloxPlayerBeta.exe"
    Sleep 500
    statusText.Value := "Status: Ready - Press F1 to Start"
} catch {
    statusText.Value := "Status: Warning - Roblox not found (will retry on F1)"
}

InitializeRoblox() {
    global robloxHandle := 0
try {
    statusText.Value := "Status: Searching for Roblox..."
    WinActivate "ahk_exe RobloxPlayerBeta.exe"
    Sleep 500
    
    statusText.Value := "Status: Resizing window..."
    try {
        robloxHandle := WinGetID("ahk_exe RobloxPlayerBeta.exe")
        WinRestore robloxHandle
        WinMove 0, 0, 800, 600, robloxHandle
    } catch {
        statusText.Value := "Status: Error - Couldn't resize window"
    }
    
    Sleep 1000
    WinActivate "ahk_exe RobloxPlayerBeta.exe"
    Sleep 500
    statusText.Value := "Status: Ready - Press F1 to Start"
} catch {
    statusText.Value := "Status: Warning - Roblox not found (will retry on F1)"
}
}
; Create visual indicators
redDots := Map()
dotLabels := Map()

for i, slot in slotCoords {
    ; Sell dot (red)
    sellDot := Gui("+AlwaysOnTop -Caption +ToolWindow")
    sellDot.BackColor := "Red"
    sellDot.Show("x" (slot.sell.x - 12) " y" (slot.sell.y - 12) " w24 h24 NoActivate")
    WinSetTransparent(220, sellDot)
    redDots["sell" i] := sellDot
    
    sellLabel := Gui("+AlwaysOnTop -Caption +ToolWindow")
    sellLabel.SetFont("s9 Bold", "Arial")
    sellLabel.BackColor := "Black"
    sellLabel.Add("Text", "cRed Center w28", "S" i)
    sellLabel.Show("x" (slot.sell.x - 14) " y" (slot.sell.y - 32) " w28 h20 NoActivate")
    WinSetTransparent(220, sellLabel)
    dotLabels["sell" i] := sellLabel
    
    ; Buy dot (green)
    buyDot := Gui("+AlwaysOnTop -Caption +ToolWindow")
    buyDot.BackColor := "Lime"
    buyDot.Show("x" (slot.buy.x - 12) " y" (slot.buy.y - 12) " w24 h24 NoActivate")
    WinSetTransparent(220, buyDot)
    redDots["buy" i] := buyDot
    
    buyLabel := Gui("+AlwaysOnTop -Caption +ToolWindow")
    buyLabel.SetFont("s9 Bold", "Arial")
    buyLabel.BackColor := "Black"
    buyLabel.Add("Text", "cLime Center w28", "B" i)
    buyLabel.Show("x" (slot.buy.x - 14) " y" (slot.buy.y - 32) " w28 h20 NoActivate")
    WinSetTransparent(220, buyLabel)
    dotLabels["buy" i] := buyLabel
}

; Global state
global isRunning := false
global isPaused := false
global currentSlot := 0

; Update status indicator
UpdateStatusIndicator(slotNum) {
    global slotConfigs, COLORS
    config := slotConfigs[slotNum]
    if config.enabled.Value {
        config.statusIndicator.SetFont("c" COLORS.success)
        config.statusIndicator.Value := "●"
    } else {
        config.statusIndicator.SetFont("c" COLORS.textDim)
        config.statusIndicator.Value := "○"
    }
}

; Highlight current processing slot
HighlightCurrentSlot(slotNum) {
    global slotConfigs, COLORS
    
    ; Reset all rows
    for config in slotConfigs {
        bgColor := (Mod(config.slotNum, 2) = 0) ? COLORS.bg : COLORS.card
        config.rowBg.Opt("Background" bgColor)
    }
    
    ; Highlight current slot
    if (slotNum > 0 and slotNum <= slotConfigs.Length) {
        slotConfigs[slotNum].rowBg.Opt("Background" COLORS.cardHover)
    }
}

; Enable/disable all slots
EnableAllSlots(enable) {
    global slotConfigs
    for config in slotConfigs {
        config.enabled.Value := enable
        UpdateStatusIndicator(config.slotNum)
    }
}

; Set all actions
SetAllActions(action) {
    global slotConfigs
    for config in slotConfigs {
        config.action.Choose(action)
    }
}

; Save configuration
SaveConfig() {
    global slotConfigs, configFile
    
    if FileExist(configFile)
        FileDelete(configFile)
    
    for config in slotConfigs {
        slotNum := config.slotNum
        actionText := config.action.Text
        
        if InStr(actionText, "💰")
            actionText := "Buy"
        else if InStr(actionText, "💸")
            actionText := "Sell"
        else if InStr(actionText, "🔄")
            actionText := "Both"
        
        IniWrite(actionText, configFile, "Slot" slotNum, "Action")
        
        buyPrice := ConvertShorthand(config.buyPrice.Value)
        sellPrice := ConvertShorthand(config.sellPrice.Value)
        
        IniWrite(buyPrice, configFile, "Slot" slotNum, "BuyPrice")
        IniWrite(sellPrice, configFile, "Slot" slotNum, "SellPrice")
        IniWrite(config.enabled.Value, configFile, "Slot" slotNum, "Enabled")
    }
}

; Load configuration
LoadConfig() {
    global slotConfigs, configFile
    
    if !FileExist(configFile)
        return
    
    for config in slotConfigs {
        slotNum := config.slotNum
        
        try {
            action := IniRead(configFile, "Slot" slotNum, "Action", "Buy")
            switch action {
                case "Buy": config.action.Choose(1)
                case "Sell": config.action.Choose(2)
                case "Both": config.action.Choose(3)
            }
            
            buyPrice := IniRead(configFile, "Slot" slotNum, "BuyPrice", "10m")
            config.buyPrice.Value := buyPrice
            
            sellPrice := IniRead(configFile, "Slot" slotNum, "SellPrice", "22.5m")
            config.sellPrice.Value := sellPrice
            
            enabled := IniRead(configFile, "Slot" slotNum, "Enabled", "1")
            config.enabled.Value := (enabled = "1")
            
            UpdateStatusIndicator(slotNum)
        }
    }
}

SaveAndExit() {
    SaveConfig()
    SaveStats()
    ExitApp()
}

SaveAndReload() {
    SaveConfig()
    SaveStats()
    Reload()
}

StartMacro() {
    global isRunning, isPaused, statusText, sessionStartTime, COLORS
    isRunning := true
    isPaused := false
    sessionStartTime := A_TickCount
    statusText.SetFont("c" COLORS.success)
    statusText.Value := "Status: Running - Processing Slots..."
    InitializeRoblox()
    SetTimer(RunMacroLoop, 100)
}

PauseMacro() {
    global isPaused, statusText, totalRuntime, sessionStartTime, COLORS
    isPaused := !isPaused
    if isPaused {
        ; Add session time to total runtime
        totalRuntime += (A_TickCount - sessionStartTime)
        SaveStats()
        
        statusText.SetFont("c" COLORS.warning)
        statusText.Value := "Status: Paused - Press F2 to Resume"
    } else {
        ; Reset session start time
        sessionStartTime := A_TickCount
        
        statusText.SetFont("c" COLORS.success)
        statusText.Value := "Status: Running - Processing Slots..."
    }
}

HighlightDot(dotKey, coord) {
    global redDots
    if redDots.Has(dotKey) {
        redDots[dotKey].Show("x" (coord.x - 18) " y" (coord.y - 18) " w36 h36 NoActivate")
        WinSetTransparent(255, redDots[dotKey])
    }
}

ResetDot(dotKey, coord, size := 24) {
    global redDots
    if redDots.Has(dotKey) {
        redDots[dotKey].Show("x" (coord.x - size//2) " y" (coord.y - size//2) " w" size " h" size " NoActivate")
        WinSetTransparent(220, redDots[dotKey])
    }
}

RunMacroLoop() {
    global isRunning, isPaused, statusText, slotConfigs, currentSlot, totalCycles
    
    if !isRunning
        return
    
    if isPaused {
        SetTimer(RunMacroLoop, 100)
        return
    }
    
    SetTimer(RunMacroLoop, 0)
    
    for config in slotConfigs {
        while isPaused and isRunning {
            Sleep 100
        }
        
        if !isRunning
            return
            
        if !config.enabled.Value
            continue
            
        slotNum := config.slotNum
        currentSlot := slotNum
        
        ; Highlight current slot
        HighlightCurrentSlot(slotNum)
        
        actionText := config.action.Text
        
        action := "Buy"
        if InStr(actionText, "💸")
            action := "Sell"
        else if InStr(actionText, "🔄")
            action := "Both"
        
        buyPrice := ConvertShorthand(config.buyPrice.Value)
        sellPrice := ConvertShorthand(config.sellPrice.Value)
        
        statusText.SetFont("c" COLORS.accentAlt)
        statusText.Value := "Status: Processing Slot " slotNum " (" action ")..."
        
        doBuy := (action = "Buy" or action = "Both")
        doSell := (action = "Sell" or action = "Both")
        
        if doBuy {
            ProcessAction(slotNum, "Buy", buyPrice, doSell)
            Sleep 300
        }
        
        if doSell {
            ProcessAction(slotNum, "Sell", sellPrice, false)
            Sleep 300
        }
    }
    
    ; Cycle complete
    totalCycles++
    totalRuntime += (A_TickCount - sessionStartTime)
    sessionStartTime := A_TickCount
    
    ; Calculate profit
    CalculateProfit()
    
    ; Reset highlight
    HighlightCurrentSlot(0)
    
    statusText.SetFont("c" COLORS.success)
    statusText.Value := "Status: Cycle Complete - Restarting..."
    Sleep 1000
    
    if isRunning and !isPaused
        SetTimer(RunMacroLoop, 100)
}

ProcessAction(slotNum, actionType, price, willDoSell := false) {
    global slotCoords, inventorySlots, redDots, extraBuyClick
    
    coord := (actionType = "Buy") ? slotCoords[slotNum].buy : slotCoords[slotNum].sell
    dotKey := (actionType = "Buy") ? "buy" slotNum : "sell" slotNum
    
    HighlightDot(dotKey, coord)
    SendEvent "{Click " coord.x ", " coord.y "}"
    Sleep 300
    ResetDot(dotKey, coord)
    
    Send "f"
    Sleep 1500
    
    SendEvent "{Click 320, 86}"
    Sleep 300
    
    invSlot := inventorySlots[slotNum]
    SendEvent "{Click " invSlot.x ", " invSlot.y "}"
    Sleep 300
    
    if (actionType = "Buy") {
        SendEvent "{Click 511, 293}"
    } else {
        SendEvent "{Click 569, 291}"
    }
    Sleep 300
    
    SendEvent "{Click 626, 322}"
    Sleep 300
    
    SendEvent "{Click 616, 354}"
    Sleep 300
    
    A_Clipboard := price
    Send "^v"
    Sleep 300
    
    SendEvent "{Click 722, 354}"
    Sleep 300
    
    if (actionType = "Sell") {
        SendEvent "{Click " extraBuyClick.x ", " extraBuyClick.y "}"
    }
    Sleep 300
    
    SendEvent "{Click 777, 59}"
    Sleep 300
}

; Hotkeys
F1:: {
    global isRunning
    if !isRunning {
        StartMacro()
    }
}

F2::PauseMacro()
F3::SaveAndExit()
F5::SaveAndReload()

; Undo/Redo hotkeys
^z::PerformUndo()
^y::PerformRedo()
