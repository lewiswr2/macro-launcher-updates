#Requires AutoHotkey v2.0

completeNeed(need) {

    differenceInSeconds := 0
    startTimer := A_Now
    needTimer := DateAdd(A_Now, need.Timer, "s")

    Loop {        

        switch need.Name {
            case "Catch!":
                SendEvent "{Click " 6 ", " 8 ", 1}"
            case "Pet Me!":
                SendMode "Event"
                activateRoblox()
                MouseMove 400, 300
                SendEvent "{LButton Down}"
                Sleep 100
                MouseMove 400, 400, 100
                SendEvent "{LButton Up}"                
                Sleep 100
                SendMode "Input"
            case "Walk!":
                ; Start moving left and swap directions every 10 loops.
                if A_Index = 1 {
                    moveLeft := true
                    direction := "a"
                    Loop 3
                        Send "{" direction " down}"
                }
                else if Mod(A_Index, 10) = 0 {
                    moveLeft := !moveLeft
                    direction := moveLeft ? "a" : "d"
                    Loop 3
                        Send "{a up}{d up}"                  
                    Loop 3
                        Send "{" direction " down}"                    
                }
        }

        ; Determine if the need is complete.
        if isNeedComplete() {
            elapsedSeconds := DateDiff(A_Now, startTimer, "S")
            updateStatus("INFO | Need completed (" elapsedSeconds " seconds)")
            break
        }
            
        Sleep 50

        ; Determine if the need has taken too long to complete.
        if A_Now > needTimer {
            elapsedSeconds := DateDiff(A_Now, startTimer, "S")
            updateStatus("ERROR | Need not completed in time (" elapsedSeconds " seconds)")
            break
        }
        
        ; Determine if the scheduled reconnect time is due.
        if A_Now > SCHEDULED_RECONNECT_TIME {
            reconnectClient()
            setReconnectTimer()            
            break
        } 

        ; Determine if the client has been disconnected.
        if reconnectIdle()
            break

        closePopups()

        differenceInSeconds := DateDiff(needTimer, A_Now, "S")
        updateStatus("Doing need | " need.name " (" differenceInSeconds " seconds)", false)           
     
    }
    
    updateStatus("")    
}

doBoredNeed(need) {
    updateStatus("Completing need | " need.name)

    closeNeedWindow()

    ; Move to and play piano.
    moveDirection("a", 1000)
    Send "{e}"
    Send "{2}"

    maxMinutes := 2
    completeNeed(need)
}

doRideNeed(need) {
    updateStatus("Completing need | " need.name)

    closeNeedWindow()

    ; Go outside.
    updateStatus(need.name ": Exiting home")

    exitHome()
    Sleep 2000

    ; Mount the vehicle.
    openBackpack()
    selectVehiclesTab() 
    selectVehicle()
    closeBackpack()
    closePopups()

    updateStatus(need.name ": Completing need")

    Send "{d down}{w down}"

    completeNeed(need)

    ; Dismount the vehicle.
    Send "{space down}"
    Sleep 100
    Send "{space up}"
    Send "{d up}{w up}"
    
}

doHouseNeed(need) {
    updateStatus("Completing need | " need.name)

    SendEvent "{Click " need.position.x ", " need.position.y ", 1}"
    Sleep 250

    ; Search for nearest text.
    area := NEAREST_SEARCH_AREA
    ocrObject := getOcrResult(area.x1, area.y1, area.x2, area.y2, 20, true)

    if !RegExMatch(ocrObject.Text, "i)nearest")
        return

    nearText := ocrObject.FindString("Nearest")
    click := {x: area.x1 + nearText.X, y: area.y1 + nearText.Y}

    SendEvent "{Click " click.x ", " click.y ", 1}"
    Sleep 250
    moveDirection("w", 750)

    ; Move back to the door, and back to the wall to mitigate when a pet becomes "stuck".
    moveDirection("s", 1000)
    moveDirection("w", 1000)

    completeNeed(need)

}

doCatchNeed(need) {
    updateStatus("Completing need | " need.name)

    closeNeedWindow()

    ; Equip toy.
    Send "{1}"

    completeNeed(need)

    ; Unequip toy.
    Send "{1}"

}

doNothing(need, position := "") {

}


