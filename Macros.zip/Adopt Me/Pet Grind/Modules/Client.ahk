#Requires AutoHotkey v2.0

activateRoblox() {
    try {
        WinActivate "ahk_exe RobloxPlayerBeta.exe"
    } catch {
        MsgBox "Roblox window not found.", MACRO_TITLE, 16
        ExitApp
    }
    Sleep 100
}

resizeRobloxWindow() {
    updateStatus("Resizing the Roblox window")

    try {
        windowHandle := WinGetID("ahk_exe RobloxPlayerBeta.exe")
    } catch {
        MsgBox "Roblox window not found.", MACRO_TITLE, 16
        ExitApp
    }

    WinActivate windowHandle
    WinRestore windowHandle
    WinMove , , A_ScreenWidth, 600, windowHandle
    WinMove , , 800, 600, windowHandle 
    
    updateStatus("")
}

disableResizing() {
    updateStatus("Disabling resizing of the Roblox window")

    ; Get the window handle for the specified title
    hWnd := WinExist("ahk_exe RobloxPlayerBeta.exe")
    if !hWnd {
        MsgBox "Roblox window not found!"
        return
    }

    ; Get the current window style
    style := DllCall("GetWindowLongPtr", "Ptr", hWnd, "Int", -16, "Int64")
    
    ; Remove the WS_SIZEBOX, WS_MAXIMIZEBOX, and WS_MINIMIZEBOX styles
    newStyle := style & ~0x00040000  ; WS_SIZEBOX (resizing border)
    newStyle := newStyle & ~0x00010000  ; WS_MAXIMIZEBOX (maximize button)
    newStyle := newStyle & ~0x00020000  ; WS_MINIMIZEBOX (minimize button)

    ; Apply the new style to the window
    DllCall("SetWindowLongPtr", "Ptr", hWnd, "Int", -16, "Int64", newStyle)

    ; Force the window to update and redraw
    DllCall("SetWindowPos", "Ptr", hWnd, "Ptr", 0, "Int", 0, "Int", 0, "Int", 0, "Int", 0, "UInt", 0x27)

    updateStatus("")
}