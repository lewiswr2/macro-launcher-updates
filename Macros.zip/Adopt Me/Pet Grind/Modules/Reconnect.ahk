#Requires AutoHotkey v2.0

; Interface searches.
ROBLOX_MENU_ICON := {x: 35, y: 48, colour: "0x000000"}
WELCOME_MENU_ADOPT_ME_TEXT := {x: 445, y: 446, colour: "0x4AC655"}
REWARDS_MENU_CLOSE_BUTTON := {x: 370, y: 382, colour: "0xd82a3f"}
REWARDS_MENU_BINDER := {x: 135, y: 158, colour: "0xc5c4c4"}

DISCONNECTED_WINDOW := {x1: 201, y1: 175, x2: 599, y2: 424}

; Screen clickables.
WELCOME_MENU_PLAY_BUTTON := {x: 395, y: 449}

; Variables.
SCHEDULED_RECONNECT_TIME := 0
SCHEDULED_RECONNECT_MINUTES := 20
DISCONNECTED_WINDOW_TEXT := Object()

reconnectClient(*) {

    global

    deeplink := "roblox://placeID=920587237"
    if usePrivateCheckbox.Value
        deeplink .= "&linkCode=" privateServerLinkCode.Value
    try 
        Run deeplink
    catch
        return
    
    updateStatus("Reconnecting client")

    activateRoblox()

    waitUntilRobloxMenuIsNotDisplayed()
    ;waitUntilRobloxMenuIsDisplayed()

    waitUntilWelcomeMenuIsDisplayed()
    clickWelcomeMenuPlayButton()
    waitUntilWelcomeMenuIsNotDisplayed()

    waitUntilRewardsMenuIsDisplayed()
    clickRewardMenuCloseButton()
    waitUntilRewardsMenuIsNotDisplayed()
    resetCharacter()
    Checkhome()

    updateStatus("")
}

; Checks for the Roblox Menu icon.
isRobloxMenuDisplayed() {
    activateRoblox()
    search := ROBLOX_MENU_ICON
    return PixelSearch(&x, &y, search.x, search.y, search.x, search.y, search.colour, 2)       
}

; Waits until the Roblox Menu icon is not displayed.
waitUntilRobloxMenuIsNotDisplayed() {
    activateRoblox()

    updateStatus("Reconnecting client | Waiting to reconnect")
    maxLoops := 200
    Loop maxLoops {
        updateStatus("Reconnecting client | Waiting to reconnect (" A_Index "/" maxLoops ")")
        if !isRobloxMenuDisplayed()
            break
        Sleep 100
    }

    updateStatus("")
}

; Waits until the Roblox Menu icon is displayed.
waitUntilRobloxMenuIsDisplayed() {
    activateRoblox()

    updateStatus("Reconnecting client | Waiting to connect")

    maxLoops := 200
    Loop maxLoops {
        updateStatus("Reconnecting client | Waiting to connect (" A_Index "/" maxLoops ")")
        if isRobloxMenuDisplayed()
            break
        Sleep 100
    }

    updateStatus("")
}

; Checks for the Welcome menu "Adopt Me" text.
isWelcomeMenuDisplayed() {
    activateRoblox()
    search := WELCOME_MENU_ADOPT_ME_TEXT
    return PixelSearch(&x, &y, search.x, search.y, search.x, search.y, search.colour, 2)
}

; Waits until the Welcome menu is displayed.
waitUntilWelcomeMenuIsDisplayed() {
    
    updateStatus("Reconnecting client | Waiting for Welcome menu to open")

    maxLoops := 200
    Loop maxLoops {
        updateStatus("Reconnecting client |  Waiting for Welcome menu to open (" A_Index "/" maxLoops ")")
        if isWelcomeMenuDisplayed()
            break
        Sleep sleeptimeslider.Value
    }

    updateStatus("")
}

; Waits until the Welcome menu is not displayed.
waitUntilWelcomeMenuIsNotDisplayed() {
    updateStatus("Reconnecting client | Waiting for Welcome menu to close")

    maxLoops := 200
    Loop maxLoops {
        updateStatus("Reconnecting client |  Waiting for Welcome menu to close (" A_Index "/" maxLoops ")")
        if !isWelcomeMenuDisplayed()
            break
        Sleep 100
    }

    updateStatus("")    
}

; Clicks the play button on the Welcome menu.
clickWelcomeMenuPlayButton() {
    button := WELCOME_MENU_PLAY_BUTTON
    SendEvent "{Click " button.x ", " button.y ", 1}" 
}

; Waits until the Rewards menu is displayed.
waitUntilRewardsMenuIsDisplayed() {
    updateStatus("Reconnecting client | Waiting for Rewards menu to open")

    maxLoops := 20
    Loop maxLoops {
        updateStatus("Reconnecting client |  Waiting for Rewards menu to open (" A_Index "/" maxLoops ")")
        if isRewardsWindowDisplayed()
            break
        Sleep 100
    }

    updateStatus("")       
}

; Waits until the Rewards menu is not displayed.
waitUntilRewardsMenuIsNotDisplayed() {
    updateStatus("Reconnecting client | Waiting for Rewards menu to close")

    maxLoops := 200
    Loop maxLoops {
        updateStatus("Reconnecting client |  Waiting for Rewards menu to close (" A_Index "/" maxLoops ")")
        if !isRewardsWindowDisplayed()
            break
        Sleep 100
    }

    updateStatus("")        
}

; Checks for the Rewards menu help icon.
isRewardsWindowDisplayed() {
    activateRoblox()
    search := REWARDS_MENU_BINDER
    return PixelSearch(&x, &y, search.x, search.y, search.x, search.y, search.colour, 2)    
}

; Clicks the close button on the Rewards menu.
clickRewardMenuCloseButton() {
    button := REWARDS_MENU_CLOSE_BUTTON
    SendEvent "{Click " button.x ", " button.y ", 1}" 
}

setReconnectTimer() {
    global

    SCHEDULED_RECONNECT_TIME := DateAdd(A_Now, SCHEDULED_RECONNECT_MINUTES, "m")
    formattedTime := FormatTime(SCHEDULED_RECONNECT_TIME, "HH:mm:ss")
    reconnectTime.Text := formattedTime
}

reconnectIdle() {
    if !checkForIdleDisconnection()
        return false

    clickReconnectButton()

    waitUntilWelcomeMenuIsDisplayed()
    clickWelcomeMenuPlayButton()
    waitUntilWelcomeMenuIsNotDisplayed()

    waitUntilRewardsMenuIsDisplayed()
    clickRewardMenuCloseButton()
    waitUntilRewardsMenuIsNotDisplayed()

    updateStatus("")

    return true
}

checkForIdleDisconnection() {
    if !isDisconnectedWindowDisplayed()
        return false
    
    if !isIdle20MinutesDisplayed()
        return false

    return true
}

clickReconnectButton() {
    area := DISCONNECTED_WINDOW
    nearText := DISCONNECTED_WINDOW_TEXT.FindString("Reconnect")
    click := {x: area.x1 + nearText.X, y: area.y1 + nearText.Y}

    SendEvent "{Click " click.x ", " click.y ", 1}"
    Sleep 250
}

isIdle20MinutesDisplayed() {
    global
    area := DISCONNECTED_WINDOW
    DISCONNECTED_WINDOW_TEXT := getOcrResult(area.x1, area.y1, area.x2, area.y2, 20, true)
    return RegExMatch(DISCONNECTED_WINDOW_TEXT.Text, "i)idle")
}

isDisconnectedWindowDisplayed() {
    activateRoblox()
    disconnectedPixelCheck := {x: 204, y: 180, colour: "0x393b3d"}
    search := disconnectedPixelCheck
    return PixelSearch(&x, &y, search.x, search.y, search.x, search.y, search.colour, 2)       
}

closeRewardsMenu() {
    if isRewardsWindowDisplayed()
        clickRewardMenuCloseButton()
}
Checkhome(){
        SendEvent "{Click 439, 39}"
        Sleep 500
        area := House_search_area
    ocrObject := getOcrResult(area.x1, area.y1, area.x2, area.y2, 20, true)

     if !RegExMatch(ocrObject.Text, "i)macro")
        return

    goText := ocrObject.FindString("macro")
    click := {x: area.x1 + goText.X, y: area.y1 + goText.Y}

    SendEvent "{Click " click.x ", " click.y ", 1}"
    Sleep 250
    SendEvent "{click 620, 425}"
    Sleep 500 
    SendEvent "{click 624, 165}"
    Sleep 500
}