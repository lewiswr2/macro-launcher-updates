#Requires AutoHotkey v2.0

doPetMeNeed(need) {
    action := "Doing " need.name
    updateStatus(action)

    SendEvent "{Click " need.position.x ", " need.position.y ", 1}"
    Sleep 250

    closePopups()
    Sleep 250
    
    ;SendEvent "{LButton Down}"
    completeNeed(need)
    ;SendEvent "{LButton Up}"

}

doBeachPartyNeed(need) {
    action := "Doing " need.name
    updateStatus(action)
    
    closeNeedWindow()
    teleportToGiftsDisplay(action)

    ; Travel to the beach.
    updateStatus(action ": Walking to area")
    moveDirection("as", 300)
    moveDirection("s", 4400)
    moveDirection("a", 20000)        

    completeNeed(need)
}

doCampingNeed(need) {
    action := "Doing " need.name
    updateStatus(action)
    
    SendEvent "{Click " need.position.x ", " need.position.y ", 1}"
    Sleep 250

    ; Search for nearest text.
    area := NEAREST_SEARCH_AREA
    ocrObject := getOcrResult(area.x1, area.y1, area.x2, area.y2, 20, true)

    if !RegExMatch(ocrObject.Text, "i)campsite")
        return

    goText := ocrObject.FindString("campsite")
    click := {x: area.x1 + goText.X, y: area.y1 + goText.Y}

    SendEvent "{Click " click.x ", " click.y ", 1}"
    Sleep 250

    closePopups()

    ;closeNeedWindow()
    teleportToGiftsDisplay(action)

    ; Travel to the camping ground.
    updateStatus(action ": Walking to area")
SendEvent "{s down}"
Sleep(2344)
SendEvent "{s up}"
Sleep(500)
SendEvent "{a down}"
Sleep(891)
SendEvent "{a up}"
Sleep(500)
SendEvent "{s down}"
Sleep(5344)
SendEvent "{s up}"
Sleep(500)
SendEvent "{d down}"
Sleep(2203)
SendEvent "{d up}"
Sleep(500)
SendEvent "{s down}"
Sleep(12719)
SendEvent "{s up}"
Sleep(500)
SendEvent "{d down}"
Sleep(4907)
SendEvent "{d up}"
Sleep(500)
SendEvent "{w down}"
Sleep(1140)
SendEvent "{w up}"
Sleep(500)
SendEvent "{d down}"
Sleep(5109)
SendEvent "{d up}"
Sleep(500)
SendEvent "{s down}"
Sleep(4547)
SendEvent "{s up}"
Sleep(500)
SendEvent "{w down}"
Sleep(2235)
SendEvent "{w up}"
Sleep(500)
SendEvent "{d down}"
Sleep(2719)
SendEvent "{d up}"
Sleep(500)
SendEvent "{s down}"
Sleep(1765)
SendEvent "{s up}"
Sleep(531)
SendEvent "{d down}"
Sleep(531)
SendEvent "{d up}"
Sleep(500)
SendEvent "{d down}"
Sleep(547)
SendEvent "{d up}"
Sleep(500)
SendEvent "{d down}"
Sleep(265)
SendEvent "{d up}"
Sleep(500)
SendEvent "{d down}"
Sleep(250)
SendEvent "{d up}"
Sleep(282)
SendEvent "{s down}"
Sleep(3235)
SendEvent "{s up}"
Sleep(500)
SendEvent "{s down}"
Sleep(266)
SendEvent "{s up}"
Sleep(500)
SendEvent "{s down}"
Sleep(5000)
SendEvent "{s up}"
    ; Finish the need.
    completeNeed(need)

}

doPizzaPartyNeed(need) {
    action := "Doing " need.name
    updateStatus(action)
    
    SendEvent "{Click " need.position.x ", " need.position.y ", 1}"
    Sleep 250

    ; Search for nearest text.
    area := NEAREST_SEARCH_AREA
    ocrObject := getOcrResult(area.x1, area.y1, area.x2, area.y2, 20, true)

    if !RegExMatch(ocrObject.Text, "i)pizza")
        return

    goText := ocrObject.FindString("pizza")
    click := {x: area.x1 + goText.X, y: area.y1 + goText.Y}

    SendEvent "{Click " click.x ", " click.y ", 1}"
    Sleep 250

    closePopups()

    ;closeNeedWindow()
    teleportToGiftsDisplay(action)

    ; Travel to the pizza party.
    updateStatus(action ": Walking to area")
    moveDirection("wd", 2500)
    moveDirection("w", 10000)
    moveDirection("d", 3000)
    moveDirection("sd", 6200)
    moveDirection("d", 2000)

    ; Finish the need.
    completeNeed(need)

}

doSchoolNeed(need) {
    action := "Doing " need.name
    updateStatus(action)
    
    SendEvent "{Click " need.position.x ", " need.position.y ", 1}"
    Sleep 250

    ; Search for nearest text.
    area := NEAREST_SEARCH_AREA
    ocrObject := getOcrResult(area.x1, area.y1, area.x2, area.y2, 20, true)

    if !RegExMatch(ocrObject.Text, "i)school")
        return

    goText := ocrObject.FindString("school")
    click := {x: area.x1 + goText.X, y: area.y1 + goText.Y}

    SendEvent "{Click " click.x ", " click.y ", 1}"
    Sleep 250

    closePopups()

    ;closeNeedWindow()
    teleportToGiftsDisplay(action)

    ; Travel to the school.
    updateStatus(action ": Walking to area")
    moveDirection("as", 300)
    moveDirection("s", 2400)
    moveDirection("a", 3000)

    ; Finish the need.
    completeNeed(need)

}

doWalkNeed(need) {
    action := "Doing " need.name

    closeNeedWindow()

    button := EXIT_HOME_BUTTON
    SendEvent "{Click " button.x ", " button.y ", 1}"

    waitForWhiteScreen(action)
    waitForNonWhiteScreen(action)

    moveDirection("w", 500)

    ; Finish the need.
    completeNeed(need)

    Send "{a up}{d up}"

}


; ========================================================================
; WORK IN PROGRESS
; ========================================================================



doSalonNeed(need) {
    action := "Doing " need.name
    updateStatus(action)
    
    SendEvent "{Click " need.position.x ", " need.position.y ", 1}"
    Sleep 250

    ; Search for nearest text.
    area := NEAREST_SEARCH_AREA
    ocrObject := getOcrResult(area.x1, area.y1, area.x2, area.y2, 20, true)

    if !RegExMatch(ocrObject.Text, "i)salon")
        return

    goText := ocrObject.FindString("salon")
    click := {x: area.x1 + goText.X, y: area.y1 + goText.Y}

    SendEvent "{Click " click.x ", " click.y ", 1}"
    Sleep 250

    closePopups()

    ;closeNeedWindow()
    teleportToGiftsDisplay(action)

    ; Travel to the salon.
    updateStatus(action ": Walking to area")
    moveDirection("wd", 2500)
    moveDirection("w", 10000)
    moveDirection("d", 7300)    
    moveDirection("w", 3000)    

    ; Finish the need.
    completeNeed(need)

}

doSickNeed(need) {
    action := "Doing " need.name
    updateStatus(action)

    teleportToGiftsDisplay(action)

    ; Travel to the hospital.
    updateStatus(action ": Walking to area")
SendEvent "{s down}"
Sleep(5609)
SendEvent "{s up}"
Sleep(125)
SendEvent "{a down}"
Sleep(1062)
SendEvent "{a up}"
Sleep(220)
SendEvent "{s down}"
Sleep(1937)
SendEvent "{s up}"
Sleep(657)
SendEvent "{d down}"
Sleep(532)
SendEvent "{d up}"
Sleep(253)
SendEvent "{s down}"
Sleep(828)
SendEvent "{s up}"
Sleep(269)
SendEvent "{s down}"
Sleep(719)
SendEvent "{s up}"

    waitForWhiteScreen(action)
    waitForNonWhiteScreen(action)
    Sleep sleeptimeslider.Value

    updateStatus(action ": Walking to nurse")
    moveDirection("w", 1300)

    Send "{e}"
    Sleep 2000
    Loop 5 {
        SendEvent "{Click " 488 ", " 405 ", 1}"
        Sleep 50
    }

    ; Finish the need.
    completeNeed(need)

}

doBoredNeed(need) {
    updateStatus("Completing need | " need.name)

    closeNeedWindow()

    ; Move to and play piano.
    moveDirection("a", 1000)
    Send "{e}"
    Send "{2}"

    maxMinutes := 2
    completeNeed(need)
}

doRideNeed(need) {
    updateStatus("Completing need | " need.name)

    closeNeedWindow()

    ; Go outside.
    updateStatus(need.name ": Exiting home")

    exitHome()
    Sleep 5000

  ; Mount the vehicle.
    openBackpack()
    selectVehiclesTab() 
    selectVehicle()
    closeBackpack()
    closePopups()

    updateStatus(need.name ": Completing need")

    Send "{d down}{w down}"

    completeNeed(need)

    ; Dismount the vehicle.
    Send "{space down}"
    Sleep 100
    Send "{space up}"
    Send "{d up}{w up}"
    
}

doHouseNeed(need) {
    updateStatus("Completing need | " need.name)

    SendEvent "{Click " need.position.x ", " need.position.y ", 1}"
    Sleep 250

    ; Search for nearest text.
    area := NEAREST_SEARCH_AREA
    ocrObject := getOcrResult(area.x1, area.y1, area.x2, area.y2, 20, true)

    if !RegExMatch(ocrObject.Text, "i)nearest")
        return

    nearText := ocrObject.FindString("Nearest")
    click := {x: area.x1 + nearText.X, y: area.y1 + nearText.Y}

    SendEvent "{Click " click.x ", " click.y ", 1}"
    Sleep 250
    moveDirection("w", 750)

    ; Move back to the door, and back to the wall to mitigate when a pet becomes "stuck".
    moveDirection("s", 1000)
    moveDirection("w", 1000)

    completeNeed(need)

}

doCatchNeed(need) {
    updateStatus("Completing need | " need.name)

    closeNeedWindow()

    ; Equip toy.
    Send "{1}"

    completeNeed(need)

    ; Unequip toy.
    Send "{1}"

}
doIceskatingneed(need) {
    action := "Doing " need.name
    updateStatus(action)
    
    SendEvent "{Click " need.position.x ", " need.position.y ", 1}"
    Sleep 250

    ; Search for nearest text.
    area := NEAREST_SEARCH_AREA
    ocrObject := getOcrResult(area.x1, area.y1, area.x2, area.y2, 20, true)

    if !RegExMatch(ocrObject.Text, "i)Go to the Disco Dome!")
        return

    goText := ocrObject.FindString("Disco")
    click := {x: area.x1 + goText.X, y: area.y1 + goText.Y}

    SendEvent "{Click " click.x ", " click.y ", 1}"
    Sleep 250

    closePopups()

    ;closeNeedWindow()
    teleportToGiftsDisplay(action)

    ; Travel to the camping ground.
    updateStatus(action ": Walking to area")
     closePopups()
SendEvent "{s down}"
Sleep(5312)
SendEvent "{s up}"
Sleep(500)

SendEvent "{a down}"
Sleep(297)
SendEvent "{a up}"
Sleep(500)

SendEvent "{s down}"
Sleep(2875)
SendEvent "{s up}"
Sleep(500)

SendEvent "{d down}"
Sleep(2047)
SendEvent "{d up}"
Sleep(500)

SendEvent "{s down}"
Sleep(11687)
SendEvent "{s up}"
Sleep(500)

SendEvent "{d down}"
Sleep(9344)
SendEvent "{d up}"
Sleep(500)

SendEvent "{s down}"
Sleep(922)
SendEvent "{s up}"
Sleep(500)

SendEvent "{d down}"
Sleep(3469)
SendEvent "{d up}"
Sleep(500)

SendEvent "{s down}"
Sleep(8812)
SendEvent "{s up}"
Sleep(500)

SendEvent "{a down}"
Sleep(360)
SendEvent "{a up}"
Sleep(500)

SendEvent "{s down}"
Sleep(1563)
SendEvent "{s up}"

 closePopups()
 ; Finish the need.
completeNeed(need)
}
doDiscoNeed(need) {
    action := "Doing " need.name
    updateStatus(action)
    
    SendEvent "{Click " need.position.x ", " need.position.y ", 1}"
    Sleep 250

    ; Search for nearest text.
    area := NEAREST_SEARCH_AREA
    ocrObject := getOcrResult(area.x1, area.y1, area.x2, area.y2, 20, true)

     if !RegExMatch(ocrObject.Text, "i)Ice Skating!")
        return

    goText := ocrObject.FindString("Ice")
    click := {x: area.x1 + goText.X, y: area.y1 + goText.Y}

    SendEvent "{Click " click.x ", " click.y ", 1}"
    Sleep 250

    closePopups()

    ;closeNeedWindow()
    teleportToGiftsDisplay(action)

    ; Travel to the camping ground.
    updateStatus(action ": Walking to area")
     closePopups()
    SendEvent "{w down}"
Sleep 6700
SendEvent "{w up}"
 closePopups()
completeNeed(need)
}

completeNeed(need) {

    differenceInSeconds := 0
    startTimer := A_Now
    needTimer := DateAdd(A_Now, need.Timer, "s")

    Loop {        

        switch need.Name {
            case "Catch!":
                SendEvent "{Click " 6 ", " 8 ", 1}"
            case "Pet Me!":
                SendMode "Event"
                activateRoblox()
                MouseMove 400, 350
                SendEvent "{LButton Down}"
                Sleep 100
                MouseMove 400, 400, 100
                SendEvent "{LButton Up}"                
                Sleep 100
                SendMode "Input"
            case "Walk!":
                ; Start moving left and swap directions every 10 loops.
                if A_Index = 1 {
                    moveLeft := true
                    direction := "a"
                    Loop 3
                        Send "{" direction " down}"
                }
                else if Mod(A_Index, 10) = 0 {
                    moveLeft := !moveLeft
                    direction := moveLeft ? "a" : "d"
                    Loop 3
                        Send "{a up}{d up}"                  
                    Loop 3
                        Send "{" direction " down}"                    
                }
        }
                
        ; Determine if the need is complete.
        if isNeedComplete() {
            elapsedSeconds := DateDiff(A_Now, startTimer, "S")
            updateStatus("INFO | Need completed (" elapsedSeconds " seconds)")
            break
        }
            
        Sleep 50
        
        ; Determine if the need has taken too long to complete.
        if A_Now > needTimer {
            elapsedSeconds := DateDiff(A_Now, startTimer, "S")
            updateStatus("ERROR | Need not completed in time (" elapsedSeconds " seconds)")
            break
        }
        
        ; Determine if the scheduled reconnect time is due.
        if A_Now > SCHEDULED_RECONNECT_TIME {
            reconnectClient()
            setReconnectTimer()            
            break
        } 

        ; Determine if the client has been disconnected.
        if reconnectIdle()
            break

        closePopups()

        differenceInSeconds := DateDiff(needTimer, A_Now, "S")
        updateStatus("Doing need | " need.name " (" differenceInSeconds " seconds)", false)           
     
    }
    
    updateStatus("")    
}