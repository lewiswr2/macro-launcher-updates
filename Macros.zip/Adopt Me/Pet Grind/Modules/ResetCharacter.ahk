#Requires AutoHotkey v2.0

WHITE_TRANSITION_SCREEN := {x: 374, y: 120, colour: "0xffffff"}
ROBLOX_MENU_BUTTON := {x: 6, y: 67, colour: "0x000000"}
RESET_BUTTON := {x: 231, y: 369, colour: "0x38393b"}

PLAY_BUTTON := {x: 345, y: 442, colour: "0x4ac655"}

resetCharacter() {
    activateRoblox()

    action := "Resetting character"
    updateStatus(action)
    closeAdoptMePlayWindow()
    openRobloxMenu(action)
    selectRespawnOption(action)
    selectResetCharacter(action)
    waitForWhiteScreen(action)
    waitForNonWhiteScreen(action)
    moveToMiddleOfHome(action)

    
    
    updateStatus("")
}

moveToMiddleOfHome(action) {
    updateStatus(action ": Moving to middle of home")
    moveDirection("w", 250)
}

openRobloxMenu(action) {
    updateStatus(action ": Open Roblox menu")
    if isEscapeMenuDisplayed()
        return true

    loop 100 {
        Send "{Esc}"
        Sleep 50
        loop 10 {
            if isEscapeMenuDisplayed()
                return true
            Sleep 50
        }
    }
    return false
}

selectRespawnOption(action) {
    updateStatus(action ": Selecting respawn option")
    if isResetButtonDisplayed()
        return true

    loop 100 {
        Send "{r}"
        Sleep 50
        loop 10 {
            if isResetButtonDisplayed()
                return true
            Sleep 50
        }
    }    
    return false
}

selectResetCharacter(action) {
    updateStatus(action ": Selecting reset option")
    loop 100 {
        Send "{Enter}"
        Sleep 50
        loop 10 {
            if !isResetButtonDisplayed()
                return true
            Sleep 50            
        }
    }
    return false
}




isScreenWhite() {
    search := WHITE_TRANSITION_SCREEN
    return PixelSearch(&x, &y, search.x, search.y, search.x, search.y, search.colour, 2)
}

isEscapeMenuDisplayed() {
    search := ROBLOX_MENU_BUTTON
    return PixelSearch(&x, &y, search.x, search.y, search.x, search.y, search.colour, 2)
}

isResetButtonDisplayed() {
    search := RESET_BUTTON
    return PixelSearch(&x, &y, search.x, search.y, search.x, search.y, search.colour, 2)    
}



exitHome() {
    EXIT_HOME_BUTTON := {x: 20, y: 543, colour: "0xd82a3f"}

    ; Wait until exit home button is not displayed.
    search := EXIT_HOME_BUTTON
    loop {
        SendEvent "{Click " search.x ", " search.y ", 1}"
        Sleep 50
        if !PixelSearch(&x, &y, search.x, search.y, search.x, search.y, search.colour, 2)   
            break
        Sleep 50
    }
}

waitForWhiteScreen(action) {
    updateStatus(action ": Waiting for white screen")
    maxLoops := 100
    loop maxLoops {
        updateStatus(action ": Waiting for white screen (" A_Index "/" maxLoops ")")
        if isScreenWhite()
            return true
        Sleep 1000
    }
    return false
}

waitForNonWhiteScreen(action) {
    updateStatus(action ": Waiting for non-white screen")
    maxLoops := 100
    loop maxLoops {
        updateStatus(action ": Waiting for non-white screen (" A_Index "/" maxLoops ")")
        if !isScreenWhite()
            return true
        Sleep sleeptimeslider.Value
    }
    return false
}

closeAdoptMePlayWindow() {
    if isAdoptMePlayWindowDisplayed() {
        button := PLAY_BUTTON
        SendEvent "{Click " button.x ", " button.y ", 1}"
    }
}

isAdoptMePlayWindowDisplayed() {
    search := PLAY_BUTTON
    return PixelSearch(&x, &y, search.x, search.y, search.x, search.y, search.colour, 2)   
}