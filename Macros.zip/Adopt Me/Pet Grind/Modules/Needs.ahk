#Requires AutoHotkey v2.0

NEEDS_MAP := Map(
    "Choose!", {Priority: 2, Bucks: 0, Timer: 30},
    "Pet Me!", {Priority: 2, Bucks: 10, Timer: 30},
    "Dirty!", {Priority: 3, Bucks: 12, Timer: 30},
    "Catch!", {Priority: 4, Bucks: 10, Timer: 30},
    "Potty!", {Priority: 4, Bucks: 10, Timer: 30},
    "Hungry!", {Priority: 4, Bucks: 10, Timer: 30},
    "Thirsty!", {Priority: 4, Bucks: 10, Timer: 30},
    "Sleepy!", {Priority: 5, Bucks: 8, Timer: 30},
    "Bored!", {Priority: 6, Bucks: 0, Timer: 30},
    "Ride!", {Priority: 8, Bucks: 10, Timer: 45},
    "Walk!", {Priority: 8, Bucks: 10, Timer: 60},
    "Camping!", {Priority: 1, Bucks: 15, Timer: 60},
    "Sick!", {Priority: 1, Bucks: 15, Timer: 30},
    "Beach Party!", {Priority: 1, Bucks: 18, Timer: 60},
    "School!", {Priority: 1, Bucks: 18, Timer: 60},
    "Pizza Party!", {Priority: 1, Bucks: 18, Timer: 60},
    "Salon!", {Priority: 1, Bucks: 18, Timer: 60},
    "Moon!", {Priority: 0, Bucks: 20, Timer: 60},
    "New Year Disco!!", {Priority: 0, Bucks: 20, Timer: 99},
    "Ice Skating!", {Priority: 0, Bucks: 15, Timer: 99}

)


NEED_COMPLETE_SEARCH := {x1: 200, y1: 350, x2: 600, y2: 460, colour: "0x9dff73"}

MIDDLE_SCREEN := {x: 400, y: 300}

;BACKPACK_MENU_ICON := {x: 175, y: 155, colour: "0xfc18fb"}
BACKPACK_MENU_ICON := {x: 175, y: 155, colour: "0x8F4AFF"}

BACKPACK_ITEM_1 := {x: 423, y: 219}
BACKPACK_ITEM_EQUIP_BUTTON := {x: 554, y: 309}
BACKPACK_X_BUTTON := {x: 628, y: 157}
BACKPACK_GET_MORE_BUTTON := {x: 334, y: 225}

TELEPORT_TO_GIFTS_YES_BUTTON := {x: 485, y: 404}

VEHICLES_BUTTON := {x: 278, y: 312, colour: "0xf7931e"}
GIFTS_BUTTON := {x: 275, y: 365, colour: "0xf7931e"}

UNEQUIP_BUTTON := {x: 486, y: 497, colour: "0xe0414c"}

EVENT_MESSAGE_NO_BUTTON := {x: 264, y: 397, colour: "0xd82a3f"}
AGE_UP_POTION_MESSAGE_OKAY_BUTTON := {x: 460, y: 408, colour: "0x4ac655"}

EXIT_HOME_BUTTON := {x: 94, y: 557}

NEAREST_SEARCH_AREA := {x1: 270, y1: 200, x2: 525, y2: 400}
House_search_area := {x1: 156, y1: 144, x2: 360, y2: 445}

;NEED_COLOURS := ["0x00a0ff", "0xfa8811", "0xa703ff"]
NEED_COLOURS := ["0x00d2ff", "0xffbf26", "0xfc18fb"]

NEED_PIXELS := Map(
    1, {x: 396, y: 50},
    2, {x: 214, y: 152},
    3, {x: 578, y: 152},
    4, {x: 214, y: 360},
    5, {x: 578, y: 360}
)

CHOOSE_NEED_PIXELS := Map(
    1, {x1: 152, y1: 248, x2: 290, y2: 272},
    2, {x1: 332, y1: 248, x2: 470, y2: 272},
    3, {x1: 510, y1: 248, x2: 648, y2: 272}
)


getNeeds() {
    
    NEEDS_ARRAY := []

    openNeedsMenu()
    Sleep 500

    maxLoops := 10
    loop maxLoops {
        activateRoblox()
        loopNumber := A_Index
        closePopups()
        closeJournal()

        for key, position in NEED_PIXELS {
            updateStatus("Checking needs | Loop: " loopNumber "/" maxLoops " | Slot: " A_Index "/" NEED_PIXELS.Count, false)
            activateRoblox()
            MouseMove 1, 1

            found := false

            for colour in NEED_COLOURS {
                if PixelSearch(&x, &y, position.x, position.y, position.x, position.y, colour, 10) {
                    found := true
                    break
                }
            }

            if found {
                activateRoblox()
                MouseMove position.x, position.y, 50
                activateMouseHover()
                Sleep 250
                need := getOcrResult(334, 248, 466, 272, 25)
                activateRoblox()
                MouseMove 1, 1, 50
                if NEEDS_MAP.Has(need) {
                    if NEEDS_MAP[need].Priority > 0
                        NEEDS_ARRAY.Push({Name: need, 
                            Priority: NEEDS_MAP[need].Priority, 
                            Bucks: NEEDS_MAP[need].Bucks,
                            Timer: NEEDS_MAP[need].Timer,
                            Position: {x: position.x, y: position.y}})
                }



            }
        }

        if NEEDS_ARRAY.Length > 0 {
            SortArrayByPriority(NEEDS_ARRAY)
            doNeed(NEEDS_ARRAY[1])
            break
        }

        if A_Index = maxLoops {
            totalChecks := maxLoops * NEED_PIXELS.Count
            updateStatus("ERROR | No needs (" totalChecks " checks)")
        }

    }

    updateStatus("")
}


SortArrayByPriority(arr) {
    loop arr.Length - 1 {
        swapped := false
        loop arr.Length - A_Index {
            if arr[A_Index].Priority > arr[A_Index + 1].Priority {
                temp := arr[A_Index]
                arr[A_Index] := arr[A_Index + 1]
                arr[A_Index + 1] := temp
                swapped := true
            }
        }
        if !swapped  ; Stop if already sorted
            break
    }
}


openNeedsMenu() {
    activateRoblox()
closePopups()
  Loop 10 {

        Send "{r}"

   
yOffset := 45
XOffset := 0
imagePath := "*20 " . A_ScriptDir . "\3333333.png"

try {
    ImageSearch(&x, &y, 0, 0, A_ScreenWidth, A_ScreenHeight, imagePath)
 Click x + XOffset, y + yOffset

}
catch {
    ; image not found
}
    }

Loop 25 {
yOffset := 40
    imagePath := "*10 " . A_ScriptDir . "\Screenshot 2025-12-28 100752 yellow.png"

    try {
        ImageSearch(&x, &y, 0, 0, A_ScreenWidth, A_ScreenHeight, imagePath)
        Click x, y + yOffset
    }
    catch {
        ; image not found
    }
}




        Loop 10 {
            if isNeedsMenuDisplayed()
                return true
            Sleep 50
        }
              return false
    }






goToSchool() {

}

isNeedsMenuDisplayed() {
    NEEDS_BACK_BUTTON := {x: 151, y: 78, colour: "0xed2c79"}
    pixel := NEEDS_BACK_BUTTON
    return PixelSearch(&x, &y, pixel.x, pixel.y, pixel.x, pixel.y, pixel.colour, 2)   
}


isNeedIconDisplayed(position) {
    activateRoblox()
    ; Calculate a search area.
    offset := 20
    area := {
        x1: position.x - offset,
        y1: position.y - offset,
        x2: position.x + offset,
        y2: position.y + offset
    }
    ; Determine if there is a white logo displayed.
    return PixelSearch(&x, &y, area.x1, area.y1, area.x2, area.y2, "0xffffff", 2)
}

closeNeedWindow() {
    Loop {
        Send "{e}"
        Send "{r}"
        Sleep 50
        Loop 10 {
            if !isNeedsMenuDisplayed()
                break 2
            Sleep 10
        }
    }
}

doChooseNeed(need) {
    updateStatus("Completing need | " need.Name)

    SendEvent "{Click " need.position.x ", " need.position.y ", 1}"
    Sleep 250

    for key, position in CHOOSE_NEED_PIXELS {
        Sleep 100
        needOcr := getOcrResult(position.x1, position.y1, position.x2, position.y2, 25)
        switch needOcr {  
            case "Dirty!", "Hungry!", "Potty!", "Sleepy!", "Thirsty!", "Catch!", "Walk!", "Ride!", "Bored!":
                updateStatus("Selected need | " need.Name)
                SendEvent "{Click " position.x1 ", " position.y1 ", 1}"
                return true
            default:
        }
    }

    ; Select the first need if no other automated need is available.
    SendEvent "{Click " CHOOSE_NEED_PIXELS[1].x1 ", " CHOOSE_NEED_PIXELS[1].y1 ", 1}"
    return false

}

closePopups() {
    closeMinigameMessage()
    closeAgeUpPotionMessage()
    closeRewardsMenu()
    closeBackpack()
    closeOtherMessages()
    closetree()

}

closeOtherMessages() {
    loop 50 {
        if !PixelSearch(&x, &y, 141, 265, 668, 442, "0x4AC655", 2) 
            break
        SendEvent "{Click " x ", " y ", 1}"
        Sleep 500
    
    }
}
closetree(){
        loop 100 {
        if !PixelSearch(&x, &y, 225, 383, 584, 419, "0x4AC655", 2) 
            break
        SendEvent "{Click " x ", " y ", 1}"
        Sleep 500
    
    }
}
openBackpack(need := "") {
    updateStatus(need ": Opening backpack")
    maxAttempts := 100
    maxChecks := 10
    loop maxAttempts {
        attemptCount := A_Index
        updateStatus(need ": Opening backpack | (" attemptCount "/" maxAttempts ")")
        Send "{b}"
        Sleep 500
        
        loop maxChecks {
            checkCount := A_Index
            updateStatus(need ": Opening backpack | (" attemptCount "/" maxAttempts ") (" checkCount "/" maxChecks ")")
            if isBackPackOpen()
                return
            Sleep 50
        }
        closePopups()
    }
}

closeBackpack(need := "") {
    button := BACKPACK_X_BUTTON

    if !isBackPackOpen()
        return

    loop {
        SendEvent "{Click " button.x ", " button.y ", 1}"
        Sleep 50
        loop 10 {
            if !isBackPackOpen()
                break 2
            Sleep 10
            closePopups()
        }
    }
}

selectVehicle(need := "") {
    updateStatus(need ": Selecting vehicle")
    SendEvent "{Click " BACKPACK_ITEM_1.x ", " BACKPACK_ITEM_1.y ", 1}"
    Sleep 250
    SendEvent "{Click " BACKPACK_ITEM_EQUIP_BUTTON.x ", " BACKPACK_ITEM_EQUIP_BUTTON.y ", 1}"
    Sleep 250
}

selectVehiclesTab(need := "") {
    updateStatus(need ": Selecting vehicles tab")
    button := VEHICLES_BUTTON
    Loop {
        Sleep 100
        if isVehiclesTabSelected()
            break
        SendEvent "{Click " button.x ", " button.y + 10 ", 1}"
    }
}

isVehiclesTabSelected() {
    pixel := VEHICLES_BUTTON
    return PixelSearch(&x, &y, pixel.x, pixel.y, pixel.x, pixel.y, pixel.colour, 2)    
}

isBackPackOpen() {
    pixel := BACKPACK_MENU_ICON
    return PixelSearch(&x, &y, pixel.x, pixel.y, pixel.x, pixel.y, pixel.colour, 2)        
}



isNeedComplete() {
    area := NEED_COMPLETE_SEARCH
    return PixelSearch(&x, &y, area.x1, area.y1, area.x2, area.y2, area.colour, 2)
}

activateMouseHover() {
    MouseMove 0, 1, , "R"
    Sleep 10
}

closeMinigameMessage() {
    if isMiniGameMessageDisplayed()
        SendEvent "{Click " EVENT_MESSAGE_NO_BUTTON.x ", " EVENT_MESSAGE_NO_BUTTON.y ", 1}"
}

isMiniGameMessageDisplayed() {
    pixel := EVENT_MESSAGE_NO_BUTTON
    return PixelSearch(&x, &y, pixel.x, pixel.y, pixel.x, pixel.y, pixel.colour, 2)    
}

closeAgeUpPotionMessage() {
    if isAgeUpPotionMessageDisplayed() {
        SendEvent "{Click " AGE_UP_POTION_MESSAGE_OKAY_BUTTON.x ", " AGE_UP_POTION_MESSAGE_OKAY_BUTTON.y ", 1}"
        Sleep 250
        closeBackpack()
    }
        
}

isAgeUpPotionMessageDisplayed() {
    pixel := AGE_UP_POTION_MESSAGE_OKAY_BUTTON
    return PixelSearch(&x, &y, pixel.x, pixel.y, pixel.x, pixel.y, pixel.colour, 2)    
}

teleportToGiftsDisplay(action) {
    openBackpack()
    selectGiftsTab() 
    clickGetMoreGiftsButton()
    waitForWhiteScreen(action)
    waitForNonWhiteScreen(action)
    Sleep sleeptimeslider.Value
}

clickGetMoreGiftsButton() {
    SendEvent "{Click " BACKPACK_GET_MORE_BUTTON.x ", " BACKPACK_GET_MORE_BUTTON.y ", 1}"
    Sleep 250
    SendEvent "{Click " TELEPORT_TO_GIFTS_YES_BUTTON.x ", " TELEPORT_TO_GIFTS_YES_BUTTON.y ", 1}"
    Sleep 250    
}

selectGiftsTab() {
    button := GIFTS_BUTTON
    Loop {
        Sleep 10
        if isGiftsTabSelected()
            break
        SendEvent "{Click " button.x ", " button.y ", 1}"
    }
}

isGiftsTabSelected() {
    search := GIFTS_BUTTON
    return PixelSearch(&x, &y, search.x, search.y, search.x, search.y, search.colour, 2)    
}
Checkhomemacro(){
        SendEvent "{Click 439, 39}"
        Sleep 500
        area := NEAREST_SEARCH_AREA
    ocrObject := getOcrResult(area.x1, area.y1, area.x2, area.y2, 20, true)

     if !RegExMatch(ocrObject.Text, "i)macro")
        return

    goText := ocrObject.FindString("macro")
    click := {x: area.x1 + goText.X, y: area.y1 + goText.Y}

    SendEvent "{Click " click.x ", " click.y ", 1}"
    Sleep 250
    SendEvent "{click 620, 425}"
    Sleep 500 
    SendEvent "{click 624, 165}"
    Sleep 500
}

doNeed(need) {

    MouseMove 1, 1

    switch need.Name {
        case "Sick!":
            doSickNeed(need)
            return true  
        case "Salon!":
            doSalonNeed(need)
            return true  
        case "School!":
            doSchoolNeed(need)
            return true  
        case "Pet Me!":
            doPetMeNeed(need)
            return true            
        case "Dirty!":
            doHouseNeed(need)
            return true
        case "Hungry!":
            doHouseNeed(need)
            return true    
        case "Potty!":
            doHouseNeed(need)
            return true     
        case "Sleepy!":
            doHouseNeed(need)
            return true  
        case "Thirsty!":
            doHouseNeed(need)
            return true            
        case "Walk!":
            doWalkNeed(need)
            return true
        case "Choose!":
            doChooseNeed(need)
            getNeeds()
            return false
        case "Catch!":
            doCatchNeed(need)
            return true
        case "Ride!":
            doRideNeed(need)
            return true        
        case "Bored!":
            doBoredNeed(need)
            return true
        case "Beach Party!":
            doBeachPartyNeed(need)
            return true
        case "Pizza Party!":
            doPizzaPartyNeed(need)
            return true
        case "Camping!":
            doCampingNeed(need)
            return true 
        case "New Year Disco!!":
            doIceskatingneed(need)
            return true 
        case "Ice Skating!":
            doDiscoNeed(need)
            return true 
        default:
            updateStatus("")
            return false
    }
    updateStatus("")
}