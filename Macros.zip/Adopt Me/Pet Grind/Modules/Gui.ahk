#Requires AutoHotkey v2.0

FRUIT_DELAY_MINIMUM := 5
FRUIT_DELAY_MAXIMUM := 30
VENDING_DELAY_MINIMUM := 5
VENDING_DELAY_MAXIMUM := 30
RECONNECT_DELAY_MINIMUM := 30
RECONNECT_DELAY_MAXIMUM := 240

EXCLUSION_GUIS := []

ICON_FOLDER := A_ScriptDir "\Assets\Icons\"

ICON_MAP := Map(
    "Application", {icon: "Application.ico"},
    "AdoptMe", {icon: "AdoptMe.ico"},
    "Discord", {icon: "Discord.ico"},
    "Donate", {icon: "Donate.ico"},
    "PlayPause", {icon: "PlayPause.ico"},
    "PsychoHatcher", {icon: "AHKvault.ico"},
    "Roblox", {icon: "Roblox.ico"}
)

COLORS := {
    headerBg: "0xd29922",
    headerText: "0x13171d",
    bg: "0x0a0e14",
    cardBg: "0x161b22",
    cardHover: "0x1c2128",
    text: "0xFFFFFF",
    textDim: "0xB0B0B0",
    border: "0x3A3A3A",
    success: "0x4CAF50",
    warning: "0xFFC107",
    danger: "0xF44336",
    buttonBg: "0xF5E6D3",
    buttonText: "0x000000"
}

displayMainGui() {
    global

    mainGui := Gui("+AlwaysOnTop")
    mainGui.Title := MACRO_TITLE
    mainGui.BackColor := SubStr(COLORS.bg, 3)
    mainGui.SetFont("s8 c" SubStr(COLORS.text, 3), "Segoe UI")

    fileMenu := Menu()
    startText := "Start Macro`t" START_MACRO
    pauseText := "Pause Macro`t" PAUSE_MACRO
    exitText := "Exit Macro`t" EXIT_MACRO
    fileMenu.Add(startText, (*) => startMacro())
    fileMenu.Add()
    fileMenu.Add(pauseText, (*) => pauseMacro())
    fileMenu.Add("Reload Macro", (*) => reloadMacro())
    fileMenu.Add()
    fileMenu.Add(exitText, exitMacro)
    fileMenu.SetIcon(startText, "imageres.dll", 282)
    fileMenu.SetIcon(pauseText, ICON_FOLDER ICON_MAP["PlayPause"].icon)
    fileMenu.SetIcon("Reload Macro", "imageres.dll", 230)
    fileMenu.SetIcon(exitText, "imageres.dll", 94)

    toolsMenu := Menu()
    toolsMenu.Add("Reconnect", (*) => reconnectClient())
    toolsMenu.SetIcon("Reconnect", ICON_FOLDER ICON_MAP["Roblox"].icon)

    helpMenu := Menu()
    helpMenu.Add("How To", (*) => openHowTo())
    helpMenu.Add()
    helpMenu.Add("Discord", (*) => openDiscord())
    helpMenu.Add("Website", (*) => openWebsite())
    helpMenu.Add()
    helpMenu.Add("Donate", (*) => openDonate())
    helpMenu.SetIcon("How To", "imageres.dll", 95)    
    helpMenu.SetIcon("Discord", ICON_FOLDER ICON_MAP["Discord"].icon)
    helpMenu.SetIcon("Website", ICON_FOLDER ICON_MAP["PsychoHatcher"].icon)
    helpMenu.SetIcon("Donate", ICON_FOLDER ICON_MAP["Donate"].icon)
       
    MyMenuBar := MenuBar()
    MyMenuBar.Add("&File", fileMenu)
    MyMenuBar.Add("&Tools", toolsMenu)
    MyMenuBar.Add("&Help", helpMenu)
    mainGui.MenuBar := MyMenuBar

    ; Header
    mainGui.Add("Progress", "x0 y0 w350 h100 Background" SubStr(COLORS.headerBg, 3))
    mainGui.SetFont("s20 bold c" SubStr(COLORS.headerText, 3), "Segoe UI")
    mainGui.Add("Text", "x0 y25 w350 Center BackgroundTrans", MACRO_TITLE " 🎮")
    mainGui.SetFont("s10 c" SubStr(COLORS.headerText, 3), "Segoe UI")
    mainGui.Add("Text", "x0 y60 w350 Center BackgroundTrans", "Version " MACRO_VERSION)

    ; Reset font and add spacing
    mainGui.SetFont("s9 c" SubStr(COLORS.text, 3), "Segoe UI")

    ; Card-style container for controls
    mainGui.Add("Progress", "x10 y115 w330 h165 Background" SubStr(COLORS.cardBg, 3))
    
    usePrivateCheckbox := mainGui.AddCheckbox("x25 y125 w300 c" SubStr(COLORS.text, 3) " Checked", "Use Private Server")
    mainGui.SetFont("s8 c" SubStr(COLORS.textDim, 3), "Segoe UI")
    mainGui.AddText("x25 yp+25 w300", "Private Server Link Code:")
    mainGui.SetFont("s9 c" SubStr(COLORS.text, 3), "Segoe UI")
    privateServerLinkCode := mainGui.AddEdit("x25 yp+18 w300 c" SubStr(COLORS.text, 3) " Background" SubStr(COLORS.bg, 3), "29898902912158637910372384065745")
    
    mainGui.SetFont("s8 c" SubStr(COLORS.textDim, 3), "Segoe UI")
    mainGui.AddText("x25 yp+30 w300", "Reconnect Delay (seconds):")
    mainGui.SetFont("s9 c" SubStr(COLORS.text, 3), "Segoe UI")
    sleeptimeslider := mainGui.AddSlider("x25 yp+18 w300 Range2500-30000 TickInterval5000", 5000)

    sleeptimeslider.OnEvent("Change", ShowSliderTooltip)

    ShowSliderTooltip(*) {
        ToolTip(Round(sleeptimeslider.Value / 1000) " seconds")
        SetTimer(RemoveToolTip, -2000)
    }

    RemoveToolTip() {
        ToolTip()
    }

    ; Status section
    mainGui.SetFont("s9 c" SubStr(COLORS.text, 3), "Segoe UI")
    mainGui.AddText("x25 y295 w140", "Next Reconnection:")
    reconnectTime := mainGui.AddText("yp x+5 w140 c" SubStr(COLORS.warning, 3), "-")

    statusBar := mainGui.AddStatusBar("Background" SubStr(COLORS.cardBg, 3) " c" SubStr(COLORS.textDim, 3), "Press F1 to start the macro.")

    mainGui.Show("w350 h360")
    mainGui.Move(-8, 0)
}

pauseMacro(*) { 
    if A_IsPaused {
        updateStatus("DEBUG | Mode unpaused")
        updateStatus("")
    }
    else {
        updateStatus("DEBUG | Mode paused")
        updateStatus("*MACRO PAUSED*", false)
    }
    Pause -1 
}

exitMacro(*) {
    updateStatus("DEBUG | Mode exited")
    ExitApp
}

openHowTo(*) {
    Run "https://docs.google.com/document/d/1Z3_9i0TE8WTX0J5o9iwnJ1ybOJ7LFtKeuhTpcumtHXk/edit?tab=t.0"
}

openDiscord(*) {
    Run "https://discord.gg/xVmSTVxQt9"
}

openWebsite(*) {
    Run ""
}

openDonate(*) {
    Run ""
}

reloadMacro(*) {
    Reload
}