#Requires AutoHotkey v2.0

LOG_FOLDER := ""

writeToLogFile(logMessage) {
    dateToday := FormatTime(A_Now, "yyyyMMdd")
    timeNow := FormatTime(A_Now, "yyyy-MM-dd HH:mm:ss")

    formattedMessage := "[" timeNow "]   " logMessage "`n"
    logFile := LOG_FOLDER dateToday ".log"
    
    try FileAppend formattedMessage, logFile
}

getLogFolder() {
    global

    try {
        processPath := WinGetProcessPath("ahk_exe Psycho Hatcher.exe")
    } catch {
        processPath := ""  ; Set to empty if the process is not found
    }

    if processPath
        LOG_FOLDER := StrReplace(processPath, "Psycho Hatcher.exe", "") "Logs\AdoptMePetGrind\"
    else
        LOG_FOLDER := A_ScriptDir "\Logs\"
}