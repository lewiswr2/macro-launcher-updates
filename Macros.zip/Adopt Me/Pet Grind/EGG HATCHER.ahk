﻿#Requires AutoHotkey v2.0



; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
; DIRECTIVES & CONFIGURATIONS
; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

#SingleInstance Force
CoordMode "Mouse", "Client"
CoordMode "Pixel", "Client"
SetMouseDelay 10
SendMode "Input"
#NoTrayIcon

; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
; TIMERS
; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰



; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
; LIBRARIES
; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

; Third-party Libraries:
#Include <OCR>
#Include <Pin>

; Macro Related Libraries:
#Include "%A_ScriptDir%\Modules"
#Include Client.ahk
#Include DoNeed.ahk
#Include Gui.ahk
#Include Log.ahk
#Include Needs.ahk
#Include OCR.ahk
#Include Movement.ahk
#Include ResetCharacter.ahk
#Include Reconnect.ahk

; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
; GLOBAL VARIABLES
; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

; Macro details.
MACRO_TITLE := "Adopt Me | Pet Grind"
MACRO_VERSION := "0.0.5"

START_MACRO := "F1"
PAUSE_MACRO := "F2"
EXIT_MACRO := "F3"

SETTINGS_GUI_VISIBLE := false

JOURNAL_CLOSE_BUTTON := {x: 611, y: 169, colour: "0xd82a3f"}

    
; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
; HOTKEYS
; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

F1::startMacro()
F2::pauseMacro()
F3::exitMacro()


; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
; MACRO
; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

runMacro()

runMacro() {
    getLogFolder()
    updateTrayIcon()
    displayMainGui()
    checkDisplayScaling()
    resizeRobloxWindow()
    disableResizing()
    updateTrayIcon()
    updateStatus("Press F1 to start the macro.", false) 
    activateRoblox()
    closeOtherMessages()
}

startMacro(*) {
    updateStatus("DEBUG | Starting mode") 
    setReconnectTimer()
    Loop {
        activateRoblox()
        resetCharacter()
        getBucksBalance()
        CheckIfHatched()
        getNeeds()
        
    }
}
updateTrayIcon() {
    TraySetIcon ICON_FOLDER ICON_MAP["AdoptMe"].icon
}

updateStatus(message, addToLog := true) {
    statusBar.SetText(message)
    defaultTitle := (message = "") ? "Roblox" : "Roblox: "

    try WinSetTitle(defaultTitle message, "ahk_exe RobloxPlayerBeta.exe")
    if message != "" && addToLog
        writeToLogFile(message)
}

checkDisplayScaling() {
    if A_ScreenDPI == 96
        return

    Msgbox "Display scaling must be 100%.`nUpdate in Windows display settings.", "Rank Quests", 0x30
    ExitApp
}


getBucksBalance() {
    balance := getOcrResult(619, 26, 757, 68, 30, false)
    updateStatus("INFO | Bucks: $" balance) 
}

closeJournal() {
    search := JOURNAL_CLOSE_BUTTON
    if PixelSearch(&x, &y, search.x, search.y, search.x, search.y, search.colour, 2)
        SendEvent "{Click " x ", " y ", 1}"
}


 CheckIfHatched(){



        Send "{r}"

   
yOffset := 45
XOffset := 0
imagePath := "*20 " . A_ScriptDir . "\unhatched.png"

try {
SendEvent "{b}"

}
catch {
    ; image not found
}
    }
 