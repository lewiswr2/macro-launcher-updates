﻿#Requires AutoHotkey v2.0

; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
; @region DIRECTIVES
; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

#SingleInstance Force
CoordMode "Mouse", "Client"
CoordMode "Pixel", "Client"
SetMouseDelay 10
SendMode "Input"
#NoTrayIcon

; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
; @region LIBRARIES
; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

#Include <DarkMode>
#Include <Gdip_all>
#Include <JXON>
#Include <Ocr>
#Include <Pin>
#Include "%A_ScriptDir%\Modules"
#Include _AllModules.ahk

; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
; @region HOTKEYS
; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

Hotkey("F1", (*) => startMacro())
Hotkey("F2", (*) => pauseMacro())
Hotkey("F3", (*) => exitMacro())
Hotkey("F4", (*) => stopMacro())


; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
; @region GLOBAL CONSTANTS & VARIABLES
; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

MACRO_TITLE := "Bubble Gum Simulator INFINITY"
MACRO_VERSION := "0.25.0"
CAN_START_MACRO := false
QUEUE := "Action"

_ := true

; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
; @region MACRO
; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

runMacro()

runMacro() {
    global

    Roblox.activate()

    completeInitialisationTasks()

    Roblox.setTitle("Initialising | Creating GUI")
    createmainGui()
    createSubGuis()

    Roblox.setTitle("Initialising | Loading Settings")
    Settings.initialiseMap()
    Settings.load()
    Settings.populateDropdowns()

    GuiModeQueue.show()
    GuiActionQueue.show()

    Timers.Action.init()
    Timers.Mode.init()

    ;updateVipOptions()
    ;updateShopsOptions()
    
    setKeyBindings()
    
    Roblox.setTitle("Initialising | Reticulating Splines")
    Shops.init()
    WheelSpins.init()
    Actions.setupActionList()
    CompetitiveTasks.setTasks()

    Roblox.activate()

    CAN_START_MACRO := true

    Roblox.setTitle()

    GuiTools.eggToHatchStart.Enabled := _
    GuiTools.enchantStart.Enabled := _
    GuiHatch.hatchAddButton.Enabled := _
}

setKeyBindings() {
    Hotkey(GuiSettings.startHotkey.Value, (*) => startMacro())
    Hotkey(GuiSettings.pauseHotkey.Value, (*) => pauseMacro())
    Hotkey(GuiSettings.exitHotkey.Value,  (*) => exitMacro())
}

; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
; @region START
; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

startMacro(*) {
    global

    Pause(0)

    if !CAN_START_MACRO
        return

    Movement.updateModifier(GuiSettings.buffsMasteryDropdown.Text)
    Settings.save()

    UI.HideTooltip()

    Roblox.setTitle("Starting | Adding Modes & Actions")
    Actions.populateFromSettings()

    Roblox.activate()
    Roblox.Respawn.resetCharacter()
    Windows.closeAllWindows()

    ;Camera.setOverhead()
    ;Camera.zoomOut(2000)

    Timers.Mode.start()
    Timers.Action.start()

    QUEUE := "Action"   

    Loop {

        UI.HideTooltip()

        Roblox.setTitle("Running | Checking Queues (" A_Index ")")
        
        Windows.closeAllWindows()

        if Actions.isActionReady()
            Actions.doNextAction()
        else {
            if A_Index != 1
                Roblox.Respawn.resetCharacter()
            doMode()
        }

        Sleep 1000
    }

}

doMode() {

    if GuiModeQueue.modeQueueList.GetCount() = 0 {
        ;MsgBox "No modes are currently in the Mode Queue. Please select at least one mode as a fallback to run when no other actions are being performed.", MACRO_TITLE, "Icon!"
        return
    }

    Windows.closeAllWindows()

    json := GuiModeQueue.modeQueueList.GetText(1, 4)  ; Column 4 = JSON string
    mode := Jxon_Load(&json)

    switch mode["type"] {
        case "Hatch":
            Hatching.runQueue(mode)
        case "Farm Tickets":
            Farming.Tickets.runQueue(mode)
        case "Farm Gems":
            Farming.Gems.runQueue(mode)         
        case "Farm Festival Coins":
            Farming.FestivalCoins.runQueue(mode)                    
        /*
        case "Farm Seashells":
            Farming.Seashells.runQueue(mode)
        */
        case "Season Challenges":
            GuiSeasonList.show()
            GuiSeasonList.pointsImage.Value := GUI_SEASON_IMAGE_FOLDER "Season_Points.png"
            Season.Challenges.run(mode)
            GuiSeasonList.gui.Hide()
        case "Event Challenges":
            GuiSeasonList.show()
            GuiSeasonList.pointsImage.Value := GUI_SEASON_IMAGE_FOLDER "Event_Points.png"
            Event.Challenges.run(mode)
            GuiSeasonList.gui.Hide()        
        default:
    }

    due := A_TickCount + (mode["duration"] * 60 * 1000)
    duration := formatTimeMs(due - A_TickCount)
    iconIndex := IL_Add(GuiModeQueue.modeImageList, mode["icon"])
    GuiModeQueue.modeQueueList.Add("Icon" iconIndex, mode["mode"], , duration, json)    
    GuiModeQueue.modeQueueList.Delete(1)

    Timers.Mode.stop()

}

pauseMacro(*) {
    Pause(-1)
}

exitMacro(*) {
    global
    Roblox.setTitle()
    SendEvent "{RButton up}"
    ExitApp
}

updateCounter(control, timer) {
    timeLeft := Max(0, timer - A_TickCount)
    secondsLeft := Round(timeLeft / 1000)
    minutes := Floor(secondsLeft / 60)
    seconds := Mod(secondsLeft, 60)
    control.Text := Format("{:2}m {:02}s", minutes, seconds)
}

STOP_MACRO := false

stopMacro() {
    global
    STOP_MACRO := true
}

formatTimeElapsed(ms) {
    seconds := Floor(ms / 1000)
    hours := Floor(seconds / 3600)
    minutes := Floor(Mod(seconds, 3600) / 60)
    seconds := Mod(seconds, 60)

    result := ""
    if (hours)
        result .= hours "h "
    if (minutes)
        result .= minutes "m "
    if (seconds || (!hours && !minutes))
        result .= seconds "s"

    return RTrim(result)
}



formatTimeMs(ms) {
    seconds := Floor(ms / 1000)
    minutes := Floor(seconds / 60)
    seconds := Mod(seconds, 60)
    return minutes ? Format("{}m {}s", minutes, seconds) : Format("{}s", seconds)
}

clamp(value, minLimit, maxLimit) {
    return Min(Max(value, minLimit), maxLimit)
}

isBubblegumIconDisplayed() {
    return PixelSearch(&x, &y, 25, 326, 44, 344, "0xff66c4", 5)
}