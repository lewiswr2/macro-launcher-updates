#Requires AutoHotkey v2.0

hasGiantChestsBuff() {
    return (GuiSettings.buffsMasteryDropdown.Text >= 15)
}