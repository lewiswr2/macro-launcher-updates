#Requires AutoHotkey v2.0

class Modes {

    static addHatchMode() {
        egg := GuiHatch.hatchingEggDropdown.Text

        mode := Map(
            "mode", "Hatch " GuiHatch.hatchingEggDropdown.Text " Egg",
            "type", "Hatch",
            "egg", egg,
            "duration", GuiHatch.hatchingCooldownDropdown.Text,
            "useLucky", GuiHatch.hatchingLuckyCheckbox.Value,
            "useSpeed", GuiHatch.hatchingSpeedCheckbox.Value,
            "useMythic", GuiHatch.hatchingMythicCheckbox.Value,
            "changeTeam", GuiHatch.hatchingChangeTeam.Value,
            "petTeam", GuiHatch.hatchingPetTeam.Text,
            "icon", GUI_MODE_ICON_FOLDER Hatching.EggProperties[egg].icon
        )
        this.add(mode)      
    }

    static addFarmTicketsMode() {
        mode := Map(
            "mode", "Farm Tickets",
            "type", "Farm Tickets",
            "duration", GuiFarm.farmTicketsCooldown.Text,
            "pathing", GuiFarm.farmTicketsPathing.Text,
            "useTicketsPotion", GuiFarm.farmTicketsTicketsPotionCheckbox.Value,
            "useGoldenOrb", GuiFarm.farmTicketsGoldenOrbCheckbox.Value,
            "blowBubbles", GuiFarm.farmTicketsBlowBubbles.Value,
            "icon", GUI_MODE_ICON_FOLDER "Ticket.ico"
        )
        this.add(mode)      
    }

    static addFarmGemsMode() {
        mode := Map(
            "mode", "Farm Gems",
            "type", "Farm Gems",
            "duration", GuiFarm.farmGemsCooldown.Text,
            "useCoinsPotion", GuiFarm.farmGemsCoinsPotionCheckbox.Value,
            "useGoldenOrb", GuiFarm.farmGemsGoldenOrbCheckbox.Value,
            "blowBubbles", GuiFarm.farmGemsBlowBubbles.Value,
            "icon", GUI_MODE_ICON_FOLDER "Gem.ico"
        )
        this.add(mode)
    }

    static addFarmFestivalCoinsMode() {
        mode := Map(
            "mode", "Farm Festival Coins",
            "type", "Farm Festival Coins",
            "duration", GuiFarm.farmFestivalCoinsCooldown.Text,
            "useCoinsPotion", GuiFarm.farmFestivalCoinsCoinsPotionCheckbox.Value,
            "useGoldenOrb", GuiFarm.farmFestivalCoinsGoldenOrbCheckbox.Value,
            "blowBubbles", GuiFarm.farmFestivalCoinsBlowBubbles.Value,
            "icon", GUI_MODE_ICON_FOLDER "Festival_Coins.ico"
        )
        this.add(mode)
    }

    /*
    static addfarmSeashellsMode() {
        mode := Map(
            "mode", "Farm Seashells",
            "type", "Farm Seashells",
            "duration", GuiFarm.farmSeashellsCooldown.Text,
            "location", GuiFarm.farmSeashellsLocation.Text,
            "icon", GUI_MODE_ICON_FOLDER "Seashell.ico"
        )
        this.add(mode)        
    }
    */

    static addSeasonMode() {
        mode := Map(
            "mode", "Season Challenges",
            "type", "Season Challenges",
            "duration", GuiSeason.seasonMinutes.Text,
            "hatchTime", GuiSeason.seasonHatchingMinutes.Text,
            "uniquePetEgg", GuiSeason.seasonUniqueEggDropdown.Text,
            "rarePetEgg", GuiSeason.seasonRareEggDropdown.Text,
            "commonPetEgg", GuiSeason.seasonCommonEggDropdown.Text,
            "epicPetEgg", GuiSeason.seasonEpicEggDropdown.Text,
            "legendaryPetEgg", GuiSeason.seasonLegendaryEggDropdown.Text,
            "shinyPetEgg", GuiSeason.seasonShinyEggDropdown.Text,
            "mythicPetEgg", GuiSeason.seasonMythicEggDropdown.Text,
            "useLucky", GuiSeason.seasonLuckyCheckbox.Value,
            "useSpeed", GuiSeason.seasonSpeedCheckbox.Value,
            "useMythic", GuiSeason.seasonMythicCheckbox.Value,
            "icon", GUI_MODE_ICON_FOLDER "Season_Icon.ico",
        )
        this.add(mode)
    }

    static addEventMode() {
        mode := Map(
            "mode", "Event Challenges",
            "type", "Event Challenges",
            "duration", GuiEventChallenges.eventMinutes.Text,
            "hatchTime", GuiEventChallenges.eventHatchingMinutes.Text,
            "useLucky", GuiEventChallenges.eventLuckyCheckbox.Value,
            "useSpeed", GuiEventChallenges.eventSpeedCheckbox.Value,
            "useMythic", GuiEventChallenges.eventMythicCheckbox.Value,            
            "icon", GUI_MODE_ICON_FOLDER "Festival_Mystery_Box.ico",
        )
        this.add(mode)
    }

    static add(mode) {
        due := A_TickCount + (mode["duration"] * 60 * 1000)
        duration := formatTimeMs(due - A_TickCount)
        json := Jxon_Dump(mode)
        iconIndex := IL_Add(GuiModeQueue.modeImageList, mode["icon"])
        index := GuiModeQueue.modeQueueList.GetCount() + 1
        GuiModeQueue.modeQueueList.Add("Icon" iconIndex, mode["mode"], , duration, json, index)
    }

}