#Requires AutoHotkey v2.0

class Playtime {
    
    
    static OPEN_BUTTON_COLOUR := "0x52ff33"

    static SAFE_CURSOR_LOCATION := {x: 519, y: 134}
    static MAX_CLAIM_SEARCHES := 25
    static MAX_WINDOW_CHECKS := 100
    static COOLDOWN := 10

    ; Buttons.
    static PLAYTIME_BUTTON := {x: 40, y: 233}
    static SKIP_BUTTON := {x: 397, y: 355}
    static CLOSE_BUTTON := {x: 633, y: 132}
    static CLAIM_ALL_BUTTON := {x: 193, y: 132}
    
    ; Pixel searches.
    static CLAIM_ALL_BUTTON_SEARCH := [143, 117, 246, 147, "0x60ef19"]
    static REWARDS_AVAILABLE_SEARCH := [12, 197, 35, 217, "0xff2929"]
    static WINDOW_OPEN_SEARCH := [318, 117, 321, 121, "0xffffff"]

    ; Search areas.
    static REWARDS_ROWS := [
        {x1: 171, y1: 243, x2: 461, y2: 262, step: 20},
        {x1: 195, y1: 330, x2: 435, y2: 351, step: 30},
        {x1: 184, y1: 448, x2: 436, y2: 472, step: 50}
    ]

    static areRewardsAvailable() {
        return PixelSearch(&x, &y, this.REWARDS_AVAILABLE_SEARCH*)
    }

    static isWindowOpen() {
        return PixelSearch(&x, &y, this.WINDOW_OPEN_SEARCH*)
    }

    static isClaimAllButtonDisplayed() {
        return PixelSearch(&x, &y, this.CLAIM_ALL_BUTTON_SEARCH*)
    }

    static claimRewards() {
        if !this.areRewardsAvailable()
            return

        Roblox.Leaderboard.close()
        clickButton(this.PLAYTIME_BUTTON, 50, 1)

        Loop this.MAX_WINDOW_CHECKS {
            Roblox.setTitle("Checking for window open (" A_Index "/" this.MAX_WINDOW_CHECKS ")")
            if this.isWindowOpen()
                break
            Sleep 50
        }

        Roblox.setTitle("Claiming playtime rewards")
        ; Delay necessary for the Claim All button to render correctly—skipping this causes it to fail.
        Sleep 500

        ; Claim either using Claim All button or by clicking the Open text.
        if this.isClaimAllButtonDisplayed()
            clickButton(this.CLAIM_ALL_BUTTON, 100, 1)
        else
            this.searchAndClickOpenText()

        clickButton(this.CLOSE_BUTTON, 500, 1)
        Roblox.setTitle()
    }

    static searchAndClickOpenText() {

        found := this.getAllOpenLocations()
        this.clickAllOpenLocations(found)

    }

    static clickAllOpenLocations(found) {
        for open in found {
            moveLocation(open, 50)
            clickButton(open, 50, 1)

            Loop this.MAX_WINDOW_CHECKS {
                if !this.isWindowOpen()
                    break
                Sleep 50
            }

            clickButton(this.SKIP_BUTTON, 50, 2)

            Loop this.MAX_WINDOW_CHECKS {
                if this.isWindowOpen()
                    break
                Sleep 50
            }
        }
    }

    static getAllOpenLocations() {
        found := []
        
        for area in this.REWARDS_ROWS {
            searchX := area.x1
            Loop this.MAX_CLAIM_SEARCHES {
                if !PixelSearch(&x, &y, searchX, area.y1, area.x2, area.y2, this.OPEN_BUTTON_COLOUR, 2)
                    break

                found.Push({x: x, y: y - 30})

                searchX := x + area.step
            }
        }
        return found
    }
}
