#Requires AutoHotkey v2.0

OnMessage(0x201, ObjBindMethod(GuiFarm, "handleMouseDown"))
OnMessage(0x0006, ObjBindMethod(GuiFarm, "handleDeactivate"))

class GuiFarm {

    static gui := ""

    static FIRST_COLUMN_X := 10
    static SECOND_COLUMN_X := 220
    static TOP_Y := 10

    static show() {
        this.gui.Show("AutoSize")
        mainGui.GetPos(&x, &y, &w, &h)
        this.gui.Move(x + 6, y + h - 8)  
    }

    static handleMouseDown(wParam, lParam, msg, hwnd) {
        if (this.gui && hwnd = this.gui.Hwnd && WinActive("ahk_id " hwnd)) {
            PostMessage 0xA1, 2,,, "ahk_id " hwnd  ; WM_NCLBUTTONDOWN, HTCAPTION
        }
    }

    static handleDeactivate(wParam, lParam, msg, hwnd) {
        if (wParam = 0 && this.gui && hwnd = this.gui.Hwnd) {
            this.gui.Hide()
        }
    }

    static create() {
        this.gui := Gui("-Caption +Border")
        this.gui.SetFont("s8 c" UI.UI_FONT_COLOUR, "Segoe UI Light")
        this.gui.BackColor := UI.UI_BACKCOLOUR

        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
        ; @region FARM GEMS
        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

        this.gui.AddGroupBox("x" GuiFarm.FIRST_COLUMN_X " y" GuiFarm.TOP_Y " Section w200 h145", "Farm Gems + Coins").SetFont("w700")

        randomImage := (Random(0, 1) = 0) ? "Gems.png" : "Coins.png"
        info := this.gui.AddPicture("xs+10 yp+20 w30 h30", GUI_RESOURCE_IMAGE_FOLDER randomImage )
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Farm Gems + Coins", text: "This section adds gem and coin farming to the Mode Queue. Gems and coins are collected on Zen island." }

        info := this.gui.AddText("x+10 w70", "Duration")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Duration", text: "Select how long the resource should be farmed for. A 20-minute duration is recommended when using automated boosts." }    
        this.farmGemsCooldown := this.gui.AddDropDownList("x+10 yp-3 w60 ", [5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60])
        this.farmGemsCooldown.Value := 4

        this.farmGemsBoostsSelectAllCheckbox := this.gui.AddCheckbox("xs+50 yp+25 w20 h20 Check3", "")
        info := this.gui.AddText("x+0 yp+3 w70", "Boosts")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Boosts", text: "Check or uncheck all options for using boosts." }
        info.SetFont("", "Segoe UI Semibold")

        this.gui.Add("Text", "xs+50 yp+20 w140 h1 BackgroundGray")

        this.farmGemsCoinsPotionCheckbox := this.gui.AddCheckbox("xs+50 yp+5 w20 h20", "")
        info := this.gui.AddText("x+0 yp+3 w100", "Use Coins V Potion")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Use Coins V Potion", text: "Automatically uses a Tickets Potion before beginning to farm." }

        this.farmGemsGoldenOrbCheckbox := this.gui.AddCheckbox("xs+50 yp+15 w20 h20", "")
        info := this.gui.AddText("x+0 yp+3 w100", "Use Golden Orb")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Use Golden Orb", text: "Automatically uses a Golden Orb before beginning to farm." }

        this.gui.Add("Text", "xs+50 yp+20 w140 h1 BackgroundGray")

        this.farmGemsBlowBubbles := this.gui.AddCheckbox("xs+50 yp+5 w20 h20", "")
        info := this.gui.AddText("x+0 yp+3 w100", "Blow Bubbles")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Blow Bubbles", text: "Blow bubbles while farming." }    

        ; Start button.
        this.farmGemsAddButton := this.gui.AddButton("xs+10 ys+55 w30", "➕")
        this.farmGemsAddButton.OnEvent("Click", (*) => Modes.addfarmGemsMode())

        ; Checkbox updates.
        gemsSelect := this.farmGemsBoostsSelectAllCheckbox
        gemsCheckboxes := [this.farmGemsCoinsPotionCheckbox, this.farmGemsGoldenOrbCheckbox]
        gemsSelect.OnEvent("Click", (*) => updateCheckboxes(gemsSelect, gemsCheckboxes))
        for checkbox in gemsCheckboxes
            checkbox.OnEvent("Click", (*) => updateSelectAllCheckbox(gemsSelect, gemsCheckboxes))


        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
        ; @region FARM FESTIVAL COINS
        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

        this.gui.AddGroupBox("xs Section w200 h145", "Farm Festival Coins").SetFont("w700")

        info := this.gui.AddPicture("xs+10 yp+20 w30 h30", GUI_RESOURCE_IMAGE_FOLDER "Festival_Coins.png")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Farm Festival Coins", text: "This section adds festival coin farming to the Mode Queue. Festival coins are collected from the Bubble Festival on The Overworld." }

        info := this.gui.AddText("x+10 w70", "Duration")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Duration", text: "Select how long the resource should be farmed for. A 20-minute duration is recommended when using automated boosts." }    
        this.farmFestivalCoinsCooldown := this.gui.AddDropDownList("x+10 yp-3 w60 ", [5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60])
        this.farmFestivalCoinsCooldown.Value := 4

        this.farmFestivalCoinsBoostsSelectAllCheckbox := this.gui.AddCheckbox("xs+50 yp+25 w20 h20 Check3", "")
        info := this.gui.AddText("x+0 yp+3 w70", "Boosts")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Boosts", text: "Check or uncheck all options for using boosts." }
        info.SetFont("", "Segoe UI Semibold")

        this.gui.Add("Text", "xs+50 yp+20 w140 h1 BackgroundGray")

        this.farmFestivalCoinsCoinsPotionCheckbox := this.gui.AddCheckbox("xs+50 yp+5 w20 h20", "")
        info := this.gui.AddText("x+0 yp+3 w100", "Use Coins V Potion")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Use Coins V Potion", text: "Automatically uses a Tickets Potion before beginning to farm." }

        this.farmFestivalCoinsGoldenOrbCheckbox := this.gui.AddCheckbox("xs+50 yp+15 w20 h20", "")
        info := this.gui.AddText("x+0 yp+3 w100", "Use Golden Orb")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Use Golden Orb", text: "Automatically uses a Golden Orb before beginning to farm." }

        this.gui.Add("Text", "xs+50 yp+20 w140 h1 BackgroundGray")

        this.farmFestivalCoinsBlowBubbles := this.gui.AddCheckbox("xs+50 yp+5 w20 h20", "")
        info := this.gui.AddText("x+0 yp+3 w100", "Blow Bubbles")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Blow Bubbles", text: "Blow bubbles while farming." }    

        ; Start button.
        this.farmFestivalCoinsAddButton := this.gui.AddButton("xs+10 ys+55 w30", "➕")
        this.farmFestivalCoinsAddButton.OnEvent("Click", (*) => Modes.addfarmFestivalCoinsMode())

        ; Checkbox updates.
        festivalCoinsSelect := this.farmFestivalCoinsBoostsSelectAllCheckbox
        festivalCoinsCheckboxes := [this.farmFestivalCoinsCoinsPotionCheckbox, this.farmFestivalCoinsGoldenOrbCheckbox]
        festivalCoinsSelect.OnEvent("Click", (*) => updateCheckboxes(festivalCoinsSelect, festivalCoinsCheckboxes))
        for checkbox in festivalCoinsCheckboxes
            checkbox.OnEvent("Click", (*) => updateSelectAllCheckbox(festivalCoinsSelect, festivalCoinsCheckboxes))

        /*
        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
        ; @region FARM SEASHELLS
        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

        this.gui.AddGroupBox("xs Section w200 h85", "Farm Seashells").SetFont("w700")

        info := this.gui.AddPicture("xs+10 yp+20 w30 h30", GUI_RESOURCE_IMAGE_FOLDER "Seashells.png")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Farm Seashells", text: "This section adds seashell farming to the Mode Queue. Seashells are collected in the Event area." }    

        info := this.gui.AddText("x+10 w50", "Duration")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Duration", text: "Select how long the resource should be farmed for." }
        this.farmSeashellsCooldown := this.gui.AddDropDownList("x+10 yp-3 w80 ", [5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60])
        this.farmSeashellsCooldown.Value := 4

        info := this.gui.AddText("xs+50 yp+25 w50", "Location")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Location", text: "Select which location should be farmed." }
        this.farmSeashellsLocation := this.gui.AddDropDownList("x+10 yp-3 w80 ", ["Beach", "Ancient Island"])
        this.farmSeashellsLocation.Value := 1

        ; Start button.
        this.farmSeashellsAddButton := this.gui.AddButton("xs+10 ys+55 w30", "➕")
        this.farmSeashellsAddButton.OnEvent("Click", (*) => Modes.addfarmSeashellsMode())
        */

        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
        ; @region FARM TICKETS
        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

        this.gui.AddGroupBox("x" GuiFarm.SECOND_COLUMN_X " y" GuiFarm.TOP_Y " Section w200 h165", "Farm Tickets").SetFont("w700")

        info := this.gui.AddPicture("xs+10 yp+20 w30 h30", GUI_RESOURCE_IMAGE_FOLDER "Tickets.png")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Farm Tickets", text: "This section adds ticket farming to the Mode Queue. Tickets are collected on Robot Factory island." }    

        info := this.gui.AddText("x+10 w70", "Duration")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Duration", text: "Select how long the resource should be farmed for. A 20-minute duration is recommended when using automated boosts." }    
        this.farmTicketsCooldown := this.gui.AddDropDownList("x+10 yp-3 w60 ", [5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60])
        this.farmTicketsCooldown.Value := 4

        info := this.gui.AddText("xs+50 yp+25 w70", "Pathing Mode")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Pathing Mode", text: "Select the pathing mode to use for farming tickets. Auto mode detects and collects tickets dynamically, while Manual mode follows a predefined route." }        
        this.farmTicketsPathing := this.gui.AddDropDownList("x+10 yp-3 w60", ["Auto", "Manual"])
        this.farmTicketsPathing.Value := 1

        this.farmTicketsBoostsSelectAllCheckbox := this.gui.AddCheckbox("xs+50 yp+25 w20 h20 Check3", "")
        info := this.gui.AddText("x+0 yp+3 w70", "Boosts")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Boosts", text: "Check or uncheck all options for using boosts." }
        info.SetFont("", "Segoe UI Semibold")

        this.gui.Add("Text", "xs+50 yp+20 w140 h1 BackgroundGray")

        this.farmTicketsTicketsPotionCheckbox := this.gui.AddCheckbox("xs+50 yp+5 w20 h20", "")
        info := this.gui.AddText("x+0 yp+3 w100", "Use Tickets V Potion")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Use Tickets V Potion", text: "Automatically uses a Tickets Potion before beginning to farm." }

        this.farmTicketsGoldenOrbCheckbox := this.gui.AddCheckbox("xs+50 yp+15 w20 h20", "")
        info := this.gui.AddText("x+0 yp+3 w100", "Use Golden Orb")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Use Golden Orb", text: "Automatically uses a Golden Orb before beginning to farm." }

        this.gui.Add("Text", "xs+50 yp+20 w140 h1 BackgroundGray")

        this.farmTicketsBlowBubbles := this.gui.AddCheckbox("xs+50 yp+5 w20 h20", "")
        info := this.gui.AddText("x+0 yp+3 w100", "Blow Bubbles")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Blow Bubbles", text: "Blow bubbles while farming." }    

        ; Start button.
        this.farmTicketsAddButton := this.gui.AddButton("xs+10 ys+55 w30", "➕")
        this.farmTicketsAddButton.OnEvent("Click", (*) => Modes.addFarmTicketsMode())

        ; Checkbox updates.
        ticketsSelect := this.farmTicketsBoostsSelectAllCheckbox
        ticketsCheckboxes := [this.farmTicketsTicketsPotionCheckbox, this.farmTicketsGoldenOrbCheckbox]
        ticketsSelect.OnEvent("Click", (*) => updateCheckboxes(ticketsSelect, ticketsCheckboxes))
        for checkbox in ticketsCheckboxes
            checkbox.OnEvent("Click", (*) => updateSelectAllCheckbox(ticketsSelect, ticketsCheckboxes))

        /*
        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
        ; @region FARM BUBBLES
        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

        this.gui.AddGroupBox("xs Section w200 h165", "Farm Bubbles").SetFont("w700")

        info := this.gui.AddPicture("xs+10 yp+20 w30 h30", GUI_RESOURCE_IMAGE_FOLDER "Bubbles.png")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Farm Bubbles", text: "This section adds bubble farming to the Mode Queue." }    

        info := this.gui.AddText("x+10 w70", "Duration")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Duration", text: "Select how long the resource should be farmed for. A 20-minute duration is recommended when using automated boosts." }    
        this.farmBubblesCooldown := this.gui.AddDropDownList("x+10 yp-3 w60 ", [5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60])
        this.farmBubblesCooldown.Value := 4

        info := this.gui.AddText("xs+50 yp+25 w70", "Currency")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Currency", text: "Select the currency bubbles should be sold for." }        
        this.farmBubblesCurrency := this.gui.AddDropDownList("x+10 yp-3 w60", ["Auto", "Manual"])
        this.farmBubblesCurrency.Value := 1
        */
    }

}