#Requires AutoHotkey v2.0

class Farming {
    static IS_CLICKING := false

    static selectTeam(world) {
        if world == 1 && GuiSettings.teamWorld1Checkbox
            this.switchTeam(GuiSettings.teamWorld1.Text)
        else if world == 2 && GuiSettings.teamWorld2Checkbox
            this.switchTeam(GuiSettings.teamWorld2.Text)
        ;else if world == "Event" && GuiSettings.teamEventWorldCheckbox
        ;    this.switchTeam(GuiSettings.teamEventWorld.Text)
    }

    static switchTeam(team) {
        Roblox.setTitle("Equipping Team: " team)
        if team == "Event"
            Items.PetsTab.equipBestTeam()
        else
            Items.PetsTab.selectTeam(team)
    }

    static teleportToIsland(resource, island) {
        Roblox.setTitle(resource " | Teleporting to Island")
        Teleport.teleportTo(island)
        Roblox.activate()
        Roblox.Leaderboard.close()            
    }

    static hasModeEnded() {
        return GuiModeQueue.modeQueueList.GetText(1, 3) = "Ended"
    }

    static completePath(path) {    
        for step in path
            Movement.move(step[1], step[2])
        Mouse.releaseLeftMouse()
        Sleep 50
        Roblox.Leaderboard.close()
        Bubble.closeBubbleFullWindow()
    }

    class Gems {
        static ISLAND := "1-5"
        static RESOURCE := "Gems"
        static PATH := [
            ; Bottom half.
            ["d", 275], ["as", 275], ["d", 275], ["as", 275],
            ["d", 450], ["as", 275], ["d", 450], ["as", 225],
            ["d", 1100], ["s", 450], ["aw", 275], ["s", 175],
            ["aw", 275], ["s", 375], ["aw", 375], ["s", 375],
            ["aw", 375], ["w", 275], ["as", 275], ["w", 275],
            ["as", 275], ["w", 275], ["as", 275], ["w", 450],
            ["as", 275], ["w", 450], ["as", 275], ["w", 450],
            ["as", 275],
            ; Top half.
            ["wd", 275], ["w", 2000], ["dw", 1000], ["w", 550], ["sd", 275],
            ["w", 450], ["sd", 375], ["w", 275], ["sd", 375],
            ["w", 275], ["sd", 375], ["w", 275], ["sd", 375],
            ["s", 425], ["aw", 275], ["as", 450], ["w", 275],
            ["as", 450], ["w", 275], ["as", 450], ["w", 275],
            ["as", 925], ["w", 650]
        ]

        static runQueue(mode) {

            Roblox.setTitle(mode["mode"] " | Teleporting to Island")
            Farming.teleportToIsland(mode["mode"], this.ISLAND)
            Farming.selectTeam(1)
            this.useBoosts(mode)

            end := A_TickCount + (mode["duration"] * 60 * 1000)
            GuiModeQueue.modeQueueList.Modify(1, , , end)
            Timers.Mode.start()

            Loop {
                Roblox.setTitle(mode["mode"] " | Running Path (" A_Index ")")
                Roblox.activate()
                Roblox.Leaderboard.close()

                Farming.completePath(this.PATH)

                if Farming.hasModeEnded()
                    break   

                Roblox.setTitle(mode["mode"] " | Teleporting to Island")
                Farming.teleportToIsland(mode["mode"], this.ISLAND)

                Roblox.setTitle()
            }            
        }

        static useBoosts(mode) {
            if !mode["useCoinsPotion"] && !mode["useGoldenOrb"]
                return false

            Roblox.setTitle(mode["mode"] " | Using Boosts")
            Items.open()
            Items.ItemsTab.open()
            Roblox.Leaderboard.close()
            if mode["useCoinsPotion"] {
                item := "Coins V"
                Roblox.setTitle(mode["mode"] " | Using " item)
                Items.ItemsTab.useItem(item)
            }
            if mode["useGoldenOrb"] {
                item := "Golden Orb"
                Roblox.setTitle(mode["mode"] " | Using " item)
                Items.ItemsTab.useItem(item)                        
            }
            Items.ItemsTab.close()
            Roblox.setTitle()                
        }

    }

    class Tickets {
        static MAX_AUTOMATED_FARMING_TIME := 5
        static ISLAND := "2-3"
        static RESOURCE := "Tickets"
        static TICKET_COLOURS := ["0x410cac", "0x220672", "0x3e0aa8", "0x7c48dc"]
        static PATH := [
            ["w", 300], ["a", 800], ["s", 300], ["d", 800], ["s", 300], ["a", 800],
            ["w", 600], ["d", 400], ["s", 600], ["d", 400], ["w", 600],
            ["a", 800], ["s", 300], ["d", 800], ["s", 300], ["a", 800],
            ["w", 600], ["d", 400], ["s", 600], ["d", 400], ["w", 600],
            ["a", 800], ["s", 300], ["d", 800], ["s", 300], ["a", 800],
            ["w", 600], ["d", 400], ["s", 600], ["d", 400], ["w", 600],
            ["a", 800], ["s", 300], ["d", 800], ["s", 300], ["a", 800],
            ["w", 600], ["d", 400]
        ]

        static runQueue(mode) {

            Roblox.setTitle(mode["mode"] " | Teleporting to Island")
            Farming.teleportToIsland(mode["mode"], this.ISLAND)
            Farming.selectTeam(2)
            this.useBoosts(mode)

            end := A_TickCount + (mode["duration"] * 60 * 1000)
            GuiModeQueue.modeQueueList.Modify(1, , , end)
            Timers.Mode.start()

            Loop {
                switch mode["pathing"] {
                    case "Manual":
                        this.manualFarm(mode)
                    case "Auto":
                        this.automaticFarm(mode)
                    default:
                }

                if Farming.hasModeEnded()
                    break   

                Roblox.setTitle(mode["mode"] " | Teleporting to Island")
                Farming.teleportToIsland(mode["mode"], this.ISLAND)

                Roblox.setTitle()
            }            
        }

        static useBoosts(mode) {
            if !mode["useTicketsPotion"] && !mode["useGoldenOrb"]
                return false

            Roblox.setTitle(mode["mode"] " | Using Boosts")
            Items.open()
            Items.ItemsTab.open()
            Roblox.Leaderboard.close()
            if mode["useTicketsPotion"] {
                item := "Tickets V"
                Roblox.setTitle(mode["mode"] " | Using " item)
                Items.ItemsTab.useItem(item)
            }
            if mode["useGoldenOrb"] {
                item := "Golden Orb"
                Roblox.setTitle(mode["mode"] " | Using " item)
                Items.ItemsTab.useItem(item)                        
            }
            Items.ItemsTab.close()
            Roblox.setTitle()                
        }

        static manualFarm(mode) {
            Loop {

                Roblox.setTitle(mode["mode"] " | Running Path (" A_Index ")")

                if mode["blowBubbles"]
                    Mouse.holdLeftMouse()                    
                Farming.completePath(this.PATH)
                Mouse.releaseLeftMouse()

                if Farming.hasModeEnded()
                    break

                Farming.teleportToIsland(this.RESOURCE, this.ISLAND)
            }
        }

        static automaticFarm(mode) {
            Camera.setOverhead()
            Camera.zoomOut(2000)

            if mode["blowBubbles"]
                Mouse.holdLeftMouse()

            exitTimer := A_TickCount + (this.MAX_AUTOMATED_FARMING_TIME * 60 * 1000)

            Loop {

                Roblox.setTitle(mode["mode"] " | Searching for Tickets (" A_Index ")")
                if PixelSearch(&x1, &y1, 280, 133, 365, 149, "0xffffff", 2)
                    Movement.move("w", 500)

                for colour in this.TICKET_COLOURS {
                    if PixelSearch(&x1, &y1, 200, 200, 600, 400, colour, 10) {
                        if PixelSearch(&x2, &y2, x1 - 20, y1 - 20, x1 + 20 , y1 + 20, "0x4792ac", 5) {
                            Movement.moveTowardScreenCoord(x1, y1, 300)
                            break
                        }
                    }
                }
                Sleep 50

                if Farming.hasModeEnded()
                    break

                if A_TickCount > exitTimer
                    break

                if Bubble.closeBubbleFullWindow()
                    Mouse.releaseLeftMouse()

            }
            Mouse.releaseLeftMouse()
            
        }

    }

    class Bubbles {
        
    }

    /*
    class Seashells {
        static ISLAND := "1-0"
        static RESOURCE := "Seashells"
        static MAX_LOOPS_BEFORE_TELEPORTING := 25
        static SAFE_MOUSE_LOCATION := {x: 780, y: 20}

        ; Pixel searches.
        static AUTO_SELL_ENABLED := [406, 426, 462, 481, "0x36e822", 5]

        static LOCATION := Map(
            "Beach", {
                PATH_TO: [["sd", 450], ["s", 2600], ["as", 900], ["", 2000], ["d", 2500]],
                FARM_PATH: [["w", 2000], ["s", 2000], ["s", 2100], ["w", 2100]],
            },
            "Ancient Island", {
                PATH_TO: [["sd", 450], ["s", 2600], ["as", 900], ["", 2000], ["d", 6400], ["", 2000], ["a", 5200]],
                FARM_PATH: [["s", 1000], ["a", 2000], ["w", 2000], ["d", 2000], ["s", 1000]],
            }
        )

        ; Buttons.
        static AUTO_SELL := {x: 433, y: 454}

        static moveToLocation(mode) {
            location := this.LOCATION[mode["location"]]
            Roblox.setTitle("Farming " this.RESOURCE " | Moving to " mode["location"])
            for step in location.PATH_TO
                Movement.move(step[1], step[2])
        }

        static runQueue(mode) {

            Roblox.setTitle(mode["mode"] " | Teleporting to Island")
            Farming.teleportToIsland(mode["mode"], this.ISLAND)
            this.moveToLocation(mode)
            Farming.selectTeam("Event")

            if !this.isAutoSellEnabled()
                clickButton(this.AUTO_SELL, 100)

            end := A_TickCount + (mode["duration"] * 60 * 1000)
            GuiModeQueue.modeQueueList.Modify(1, , , end)
            Timers.Mode.start()

            location := this.LOCATION[mode["location"]]

            Loop {
                Roblox.activate()
                Roblox.Leaderboard.close()

                Loop this.MAX_LOOPS_BEFORE_TELEPORTING {
                    Roblox.setTitle(mode["mode"] " | Running Path (" A_Index "/" this.MAX_LOOPS_BEFORE_TELEPORTING ")")

                    moveLocation(this.SAFE_MOUSE_LOCATION, 10)

                    Mouse.holdLeftMouse()        
                    Farming.completePath(location.FARM_PATH)
                    Mouse.releaseLeftMouse()

                    if Farming.hasModeEnded()
                        break 2                   
                        
                }

                Roblox.setTitle(mode["mode"] " | Teleporting to Island")
                Teleport.teleportTo(this.ISLAND)
                this.moveToLocation(mode)

            }

            Roblox.setTitle()
         
        }

        static isAutoSellEnabled() {
            return PixelSearch(&x, &y, this.AUTO_SELL_ENABLED*)
        }

    }
    */

    class FestivalCoins {
        static ISLAND := "1-0"
        static RESOURCE := "Festival Coins"
        static PATH_TO := [["as", 4000], ["s", 250], ["as", 4200]]
        static FARM_PATH := [
            ["sd", 800], ["as", 1600], ["aw", 1600], ["wd", 1600], ["sd", 800],
            ["s", 1600], ["a", 1600], ["w", 1600], ["d", 1600],
        ]
        static MAX_LOOPS_BEFORE_TELEPORTING := 10
        static SAFE_MOUSE_LOCATION := {x: 780, y: 20}

        static runQueue(mode) {

            Roblox.setTitle(mode["mode"] " | Teleporting to Island")
            Farming.teleportToIsland(mode["mode"], this.ISLAND)

            Roblox.setTitle("Farming " this.RESOURCE " | Moving to Bubble Festival")
            for step in this.PATH_TO
                Movement.move(step[1], step[2])            

            Farming.selectTeam(1)
            this.useBoosts(mode)

            end := A_TickCount + (mode["duration"] * 60 * 1000)
            GuiModeQueue.modeQueueList.Modify(1, , , end)
            Timers.Mode.start()

            Loop {
                Roblox.setTitle(mode["mode"] " | Running Path (" A_Index ")")
                Roblox.activate()
                Roblox.Leaderboard.close()

                Loop this.MAX_LOOPS_BEFORE_TELEPORTING {
                    Roblox.setTitle(mode["mode"] " | Running Path (" A_Index "/" this.MAX_LOOPS_BEFORE_TELEPORTING ")")

                    moveLocation(this.SAFE_MOUSE_LOCATION, 10)

                    if mode["blowBubbles"]
                        Mouse.holdLeftMouse()
                    Farming.completePath(this.FARM_PATH)
                    Mouse.releaseLeftMouse()

                    if Farming.hasModeEnded()
                        break 2                   
                        
                }
                
                Roblox.setTitle(mode["mode"] " | Teleporting to Island")
                Teleport.teleportTo(this.ISLAND)
                Roblox.setTitle("Farming " this.RESOURCE " | Moving to Bubble Festival")
                for step in this.PATH_TO
                    Movement.move(step[1], step[2])    

                Roblox.setTitle()
            }            
        }

        static useBoosts(mode) {
            if !mode["useCoinsPotion"] && !mode["useGoldenOrb"]
                return false

            Roblox.setTitle(mode["mode"] " | Using Boosts")
            Items.open()
            Items.ItemsTab.open()
            Roblox.Leaderboard.close()
            if mode["useCoinsPotion"] {
                item := "Coins V"
                Roblox.setTitle(mode["mode"] " | Using " item)
                Items.ItemsTab.useItem(item)
            }
            if mode["useGoldenOrb"] {
                item := "Golden Orb"
                Roblox.setTitle(mode["mode"] " | Using " item)
                Items.ItemsTab.useItem(item)                        
            }
            Items.ItemsTab.close()
            Roblox.setTitle()                
        }

    }   

}

spamClick() {
    Roblox.activate()
    SendEvent "{Click, " 400 ", " 300 "}"
}