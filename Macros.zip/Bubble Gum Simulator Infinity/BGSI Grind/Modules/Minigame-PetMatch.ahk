#Requires AutoHotkey v2.0

; #Requires AutoHotkey v2.0

class PetMatch {

    ; Minigame settings.
    static GAME_TITLE := "Pet Match"
    static GAME_ISLAND := "2-1"
    static PATH := [["as", 350], ["a", 300]]
    static GAME_TIMEOUT := 180000

    ; Matching settings.
    static PATCH_SIZE := 3
    static pToken := 0

    ; Pixel searches.
    ;static UNMATCHED_COLOUR := "0x00b7ff"   
    static UNMATCHED_COLOUR := "0x008eff"   
    static UNMATCHED_TOLERANCE := 50
    static CARDS_REVEALED_PIXEL := [137, 50, 137, 50, "0xffffff"]

    static play() {
        Minigame.teleportToMinigame(this.GAME_TITLE, this.GAME_ISLAND)
        Minigame.moveToMinigame(this.GAME_TITLE, this.PATH)
        Sleep 1000

        if !Minigame.isMinigameWindowOpen()
            return

        Minigame.useTicket(this.GAME_TITLE, GuiTools.minigamePetMatchDifficulty.Value)
        this.matchByPatches()
        Minigame.claimRewards(this.GAME_TITLE)
        Roblox.setTitle()
    }

    static playFromMenu() {
        Roblox.activate()

        if !Minigame.isInStartArea(this.GAME_TITLE)
            return
            
        Loop {
            Minigame.useTicket(this.GAME_TITLE)
            this.matchByPatches()
            Minigame.claimRewards(this.GAME_TITLE)
            Minigame.restartGame(this.GAME_TITLE)
        }
    }

    static matchByPatches() {
        this.startGdip()
        Minigame.moveCursorToSafePosition()

        Roblox.setTitle("Pet Match | Waiting for the Reveal")
        this.waitForReveal()

        endTime := A_TickCount + this.GAME_TIMEOUT

        result := this.captureRobloxWindow()
        bitmap := result.bitmap
        patches := ""

        ; Attempt patch extraction
        patches := this.extractPatches(bitmap, endTime)
        if !patches
            goto cleanup

        matchArray := this.comparePatches(patches, endTime)
        if !matchArray
            goto cleanup

        Sleep 1000

        this.clickMatchedPairs(matchArray, endTime)
        this.bruteForceUnmatchedCards(endTime)

    cleanup:
        if patches {
            for _, bmp in patches
                Gdip_DisposeImage(bmp)
        }

        if bitmap
            Gdip_DisposeImage(bitmap)

        this.stopGdip()
        Roblox.setTitle()
    }

    static extractPatches(bitmap, endTime) {
        patches := Map()
        for cardNum, data in this.CARD_COORDS {
            if (A_TickCount > endTime)
                return false
            cx := data.centre[1] - Floor(this.PATCH_SIZE / 2)
            cy := data.centre[2] - Floor(this.PATCH_SIZE / 2)
            bmp := Gdip_CloneBitmapArea(bitmap, cx, cy, this.PATCH_SIZE, this.PATCH_SIZE)
            patches[cardNum] := bmp
        }
        return patches
    }

    static comparePatches(patches, endTime) {
        matchArray := []
        matched := Map()

        Loop 24 {
            i := A_Index
            if matched.Has(i)
                continue
            if (A_TickCount > endTime)
                return false

            Loop 24 - i {
                j := i + A_Index
                if matched.Has(j)
                    continue
                if (A_TickCount > endTime)
                    return false

                if this.compareBitmaps(patches[i], patches[j], this.PATCH_SIZE) {
                    matchArray.Push([this.CARD_COORDS[i].centre, this.CARD_COORDS[j].centre, i, j])
                    matched[i] := true
                    matched[j] := true
                    break
                }
            }
        }
        return matchArray
    }

    static clickMatchedPairs(matchArray, endTime) {
        for idx, pair in matchArray {
            Roblox.setTitle("Pet Match | Clicking Matched Pairs (" A_Index "/" matchArray.Length ")")
            if (A_TickCount > endTime)
                return
            c1 := pair[1], c2 := pair[2]
            Sleep 250
            SendEvent "{Click, " c1[1] ", " c1[2] "}"
            Sleep 250
            SendEvent "{Click, " c2[1] ", " c2[2] "}"
            Sleep 500
        }
        Roblox.setTitle()
    }

    static bruteForceUnmatchedCards(endTime := 0) {
        unmatched := this.getUnmatchedCards()

        Roblox.setTitle("Pet Match | Finding Unmatched Cards")
        
        pairs := []
        Loop unmatched.Length {
            i := A_Index
            first := unmatched[i]
            Loop unmatched.Length - i {
                second := unmatched[i + A_Index]
                if second
                    pairs.Push([first, second])
            }
        }

        Roblox.setTitle("Pet Match | Brute Force Matching")

        ; Try each pair
        for _, pair in pairs {
            if (endTime && A_TickCount > endTime)
                return false

            first := pair[1]
            second := pair[2]

            c1 := this.CARD_COORDS[first].centre
            c2 := this.CARD_COORDS[second].centre

            Sleep 250
            SendEvent "{Click, " c1[1] ", " c1[2] "}"
            Sleep 250
            SendEvent "{Click, " c2[1] ", " c2[2] "}"
            Sleep 700

            ; Check both cards
            area1 := this.CARD_COORDS[first].card
            area2 := this.CARD_COORDS[second].card

            card1Unmatched := PixelSearch(&x1, &y1, area1[1], area1[2], area1[3], area1[4], this.UNMATCHED_COLOUR, 5)
            card2Unmatched := PixelSearch(&x2, &y2, area2[1], area2[2], area2[3], area2[4], this.UNMATCHED_COLOUR, 5)

            if (!card1Unmatched && !card2Unmatched) {
                unmatched := this.getUnmatchedCards()
                return this.bruteForceUnmatchedCards(endTime)
            }
        }

        ; If only 1 card remains at the end
        unmatched := this.getUnmatchedCards()
        if unmatched.Length = 1 {
            c := this.CARD_COORDS[unmatched[1]].centre
            Sleep 250
            SendEvent "{Click, " c[1] ", " c[2] "}"
            Sleep 500
        }

        Roblox.setTitle()
    }

    static getUnmatchedCards() {
        result := []

        for _, card in this.CARD_COORDS {
            area := card.card
            if PixelSearch(&x, &y, area[1], area[2] + 50, area[3], area[4], this.UNMATCHED_COLOUR, this.UNMATCHED_TOLERANCE)
                result.Push(_)
        }

        return result
    }

    static captureRobloxWindow() {
        this.startGdip()

        hwnd := WinExist("ahk_exe RobloxPlayerBeta.exe")
        if !hwnd
            throw Error("Roblox window not found")

        ; Get client size
        rect := Buffer(16, 0)
        DllCall("GetClientRect", "Ptr", hwnd, "Ptr", rect)
        w := NumGet(rect, 8, "Int")
        h := NumGet(rect, 12, "Int")

        ; Get client top-left in screen coordinates
        pt := Buffer(8, 0)
        DllCall("ClientToScreen", "Ptr", hwnd, "Ptr", pt)
        x := NumGet(pt, 0, "Int")
        y := NumGet(pt, 4, "Int")

        rectStr := Format("{}|{}|{}|{}", x, y, w, h)
        pBitmap := Gdip_BitmapFromScreen(rectStr)

        return {bitmap: pBitmap, offsetX: x, offsetY: y}
    }

    static compareBitmaps(bmpA, bmpB, size) {
        Loop size {
            y := A_Index - 1
            Loop size {
                x := A_Index - 1
                p1 := Gdip_GetPixel(bmpA, x, y) & 0xFFFFFF
                p2 := Gdip_GetPixel(bmpB, x, y) & 0xFFFFFF
                if (p1 != p2)
                    return false
            }
        }
        return true
    }

    static waitForReveal() {
        Loop {
            if PixelSearch(&X, &Y, this.CARDS_REVEALED_PIXEL*)
                break
            Sleep 50
        }
    }

    static startGdip() {
        if !this.pToken
            this.pToken := Gdip_Startup()
    }

    static stopGdip() {
        if this.pToken {
            Gdip_Shutdown(this.pToken)
            this.pToken := 0
        }
    }

    static CARD_COORDS := Map(
        1,  {card: [130,  42, 209, 161], image: [131,  63, 208, 140], centre: [169, 101]},
        2,  {card: [222,  42, 301, 161], image: [223,  63, 300, 140], centre: [261, 101]},
        3,  {card: [314,  42, 393, 161], image: [315,  63, 392, 140], centre: [353, 101]},
        4,  {card: [406,  42, 485, 161], image: [407,  63, 484, 140], centre: [445, 101]},
        5,  {card: [498,  42, 577, 161], image: [499,  63, 576, 140], centre: [537, 101]},
        6,  {card: [590,  42, 669, 161], image: [591,  63, 668, 140], centre: [629, 101]},
        7,  {card: [130, 174, 209, 293], image: [131, 195, 208, 272], centre: [169, 233]},
        8,  {card: [222, 174, 301, 293], image: [223, 195, 300, 272], centre: [261, 233]},
        9,  {card: [314, 174, 393, 293], image: [315, 195, 392, 272], centre: [353, 233]},
        10, {card: [406, 174, 485, 293], image: [407, 195, 484, 272], centre: [445, 233]},
        11, {card: [498, 174, 577, 293], image: [499, 195, 576, 272], centre: [537, 233]},
        12, {card: [590, 174, 669, 293], image: [591, 195, 668, 272], centre: [629, 233]},
        13, {card: [130, 305, 209, 424], image: [131, 326, 208, 403], centre: [169, 364]},
        14, {card: [222, 305, 301, 424], image: [223, 326, 300, 403], centre: [261, 364]},
        15, {card: [314, 305, 393, 424], image: [315, 326, 392, 403], centre: [353, 364]},
        16, {card: [406, 305, 485, 424], image: [407, 326, 484, 403], centre: [445, 364]},
        17, {card: [498, 305, 577, 424], image: [499, 326, 576, 403], centre: [537, 364]},
        18, {card: [590, 305, 669, 424], image: [591, 326, 668, 403], centre: [629, 364]},
        19, {card: [130, 437, 209, 556], image: [131, 458, 208, 535], centre: [169, 496]},
        20, {card: [222, 437, 301, 556], image: [223, 458, 300, 535], centre: [261, 496]},
        21, {card: [314, 437, 393, 556], image: [315, 458, 392, 535], centre: [353, 496]},
        22, {card: [406, 437, 485, 556], image: [407, 458, 484, 535], centre: [445, 496]},
        23, {card: [498, 437, 577, 556], image: [499, 458, 576, 535], centre: [537, 496]},
        24, {card: [590, 437, 669, 556], image: [591, 458, 668, 535], centre: [629, 496]}
    )
}

