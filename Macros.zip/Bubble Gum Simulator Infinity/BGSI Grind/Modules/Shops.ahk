#Requires AutoHotkey v2.0

; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
; @region SHOPS
; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

class Shops {
    static BUY_ONE_AREA := [225, 354, 579, 366, "0x9d47f7", 15]
    static BUY_ALL_AREA := [225, 412, 579, 416, "0xff8332", 15]
    static MOVE_LOCATION := {x: 392, y: 183}
    static CLOSE_BUTTON := {x: 602, y: 142}
    static REROLL_NOW_AREA := [416, 437, 489, 460, "0xffffff"]
    static REROLL_BUTTON := {x: 451, y: 449}
    static REFRESHES_IN_AREA := {x1: 512, y1: 444, x2: 584, y2: 462}
    static NUMBER_IMAGES_FOLDER := A_ScriptDir "\Assets\Numbers\"
    static MAX_TRIES := 500
    static NUMBER_IMAGES_MAP := Map(
        "0.bmp", 0, "1.bmp", 1, "2.bmp", 2, "3.bmp", 3, "4.bmp", 4,
        "5.bmp", 5, "6.bmp", 6, "7.bmp", 7, "8.bmp", 8, "9.bmp", 9
    )

    static SHOP_DATA := Map()

    static init() {
        Shops.SHOP_DATA := Map(
            "Alien Shop", Map(
                "Name", "Alien Shop",
                "Island", "1-5",
                "Path", [["w", 2000], ["wd", 1500], ["d", 2200], ["sd", 1050]],
                "Cooldown", 15,
                "Timer", 0,
                "Reroll", GuiActions.rerollAlienShop.Value,
                "Checkbox", GuiActions.alienShopCheckbox
            ),
            "Blackmarket", Map(
                "Name", "Blackmarket",
                "Island", "1-4",
                "Path", [["as", 650], ["s", 800]],
                "Cooldown", 300,
                "Timer", 0,
                "Reroll", GuiActions.rerollBlackmarket.Value,
                "Checkbox", GuiActions.blackmarketCheckbox
            ),
            "Dice Merchant", Map(
                "Name", "Dice Merchant",
                "Island", "2-0",
                "Path", [["w", 1800], ["aw", 1400], ["a", 600]],
                "Cooldown", 300,
                "Timer", 0,
                "Reroll", GuiActions.rerollDiceMerchant.Value,
                "Checkbox", GuiActions.diceMarketCheckbox
            ),
            "Traveling Merchant", Map(
                "Name", "Traveling Merchant",
                "Island", "1-0",
                "Path", [["sd", 450], ["s", 3250], ["as", 400]],
                "Cooldown", 400,
                "Timer", 0,
                "Reroll", GuiActions.rerollTravelingMerchant.Value,
                "Checkbox", GuiActions.travelingMerchantCheckbox
            ),
            "Festival Shop", Map(
                "Name", "Festival Shop",
                "Island", "1-0",
                "Path", [["as", 4000], ["s", 250], ["as", 4200], ["s", 750], ["sd", 550]],
                "Cooldown", 400,
                "Timer", 0,
                "Reroll", GuiActions.rerollFestivalShop.Value,
                "Checkbox", GuiActions.festivalShopCheckbox
            ),  
            "Fishing Shop", Map(
                "Name", "Fishing Shop",
                "Island", "3-0",
                "Path", [["a", 2400], ["as", 1400]],
                "Cooldown", 300,
                "Timer", 0,
                "Reroll", GuiActions.rerollFishingShop.Value,
                "Checkbox", GuiActions.fishingShopCheckbox
            ),          
            /*
            "Event Shop", Map(
                "Name", "Event Shop",
                "Island", "1-0",
                "Path", [["sd", 450], ["s", 2600], ["as", 900], ["", 2000], ["aw", 2000]],
                "Cooldown", 400,
                "Timer", 0,
                "Reroll", GuiActions.rerollEventShop.Value,
                "Checkbox", GuiActions.eventShopCheckbox
            ),
            */
        )
    }


    static isRerollAvailable() {
        return PixelSearch(&x, &y, this.REROLL_NOW_AREA*)
    }

    static readRefreshTime() {
        a := this.REFRESHES_IN_AREA
        digits := []
        result := ""
        Roblox.activate()

        for imageFile, number in this.NUMBER_IMAGES_MAP {
            imagePath := this.NUMBER_IMAGES_FOLDER imageFile
            if !FileExist(imagePath)
                continue

            searchX := a.x1
            while ImageSearch(&x, &y, searchX, a.y1, a.x2, a.y2, "*Transff00f0 *50 " imagePath) {
                digits.Push([number, x])
                searchX := x + 1
            }
        }

        while digits.Length > 0 {
            minIndex := 1
            for i, pair in digits {
                if pair[2] < digits[minIndex][2]
                    minIndex := i
            }
            result .= digits[minIndex][1]
            digits.RemoveAt(minIndex)
        }

        return IsInteger(result) ? result : -1
    }

    static moveToShop(path) {
        for _, step in path
            Movement.move(step[1], step[2])
    }

    static useShop(data) {
        shopName := data["Name"]
        Roblox.setTitle(shopName " | Teleporting to Island")
        Teleport.teleportTo(data["Island"])
        Roblox.Leaderboard.close()

        Roblox.setTitle(shopName " | Moving to Shop")
        this.moveToShop(data["Path"])
        Sleep 250
        this.sendWebhook(shopName)

        Loop {
            Roblox.setTitle(shopName " | Buying Items (" A_Index ")")
            this.buyItems(shopName)
            if this.shouldReroll(data) {
                clickButton(this.REROLL_BUTTON, 500)
                this.sendWebhook(shopName)
            }

            else
                break
        }
        Roblox.setTitle(shopName " | Reading Refresh Time")
        this.setRefreshTime(data)
        Roblox.setTitle(shopName " | Closing Window")
        clickButton(this.CLOSE_BUTTON, 1000)
        Roblox.setTitle()
        return data["Timer"]
    }

    static setRefreshTime(data) {
        refreshTime := this.readRefreshTime()
        if refreshTime > -1 {
            minutes := Time.convertToMinutes(refreshTime)
            data["Timer"] := minutes
        } else {
            data["Timer"] := data["Cooldown"]
        }
    }

    static shouldReroll(data) {
        return data["Reroll"] && this.isRerollAvailable()
    }

    static buyItems(shopName) {
        this.buyAllItems(this.BUY_ALL_AREA, shopName)
        this.buyAllItems(this.BUY_ONE_AREA, shopName)
    }

    static buyAllItems(area, shopName) {
        Loop this.MAX_TRIES {
            Roblox.setTitle(shopName " | Buying All Items (" A_Index ")")
            Roblox.activate()
            moveLocation(this.MOVE_LOCATION, 50)
            if !PixelSearch(&x, &y, area*)
                break
            found := {x: x + 20, y: y}
            moveLocation(found, 50)
            clickButton(found, 50)
            Sleep 100
        }
    }  

    static sendWebhook(shopName) {
        if GuiSettings.webhookShops.Value
            PersonalWebhook.shopsWebhook(shopName)
    }    

}

class Time {
    
    static convertToSeconds(timeStr) {
        len := StrLen(timeStr)
        if (len <= 2) {
            seconds := timeStr, minutes := 0, hours := 0
        } else if (len <= 4) {
            seconds := SubStr(timeStr, -2)
            minutes := SubStr(timeStr, 1, len - 2)
            hours := 0
        } else {
            seconds := SubStr(timeStr, -2)
            minutes := SubStr(timeStr, -4, 2)
            hours := SubStr(timeStr, 1, len - 4)
        }
        return hours * 3600 + minutes * 60 + seconds
    }
    
    static convertToMinutes(timeStr) {
        len := StrLen(timeStr)
        if (len <= 2) {
            seconds := timeStr, minutes := 0, hours := 0
        } else if (len <= 4) {
            seconds := SubStr(timeStr, -2)
            minutes := SubStr(timeStr, 1, len - 2)
            hours := 0
        } else {
            seconds := SubStr(timeStr, -2)
            minutes := SubStr(timeStr, -4, 2)
            hours := SubStr(timeStr, 1, len - 4)
        }

        ; Convert all to numbers
        seconds := seconds + 0
        minutes := minutes + 0
        hours := hours + 0

        ; Total minutes (with decimals)
        return (hours * 60) + minutes + (seconds / 60)
    }

}