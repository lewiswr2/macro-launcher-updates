#Requires AutoHotkey v2.0

class Genie {
    static ICON_AREA := [303, 52, 341, 69, "0x0a10c9"]
    static CHOOSE_BUTTON_AREA := [96, 464, 238, 506, "0x1e94e3"]
    static CHOOSE_BUTTON := {x: 170, y: 485}
    static CLOSE_BUTTON := {x: 720, y: 57}
    static NEXT_QUEST_BUTTON := {x: 506, y: 23}
    static OCR_SCALE := 5
    static TASK_OCR_AREA := {x: 284, y: 38, w: 300, h: 100}

    static GENIE_TASKS := Map(
        "Hatch 30 Rare Pets", {
            regex: "i)(?=.*rar)(?=.*pet)",
            run: (*) => Tasks.hatchRarePets()
        },
        "Hatch 190 Spotted Eggs", {
            regex: "i)(?=.*spot)(?=.*egg)",
            run: (*) => 
        },
        "Blow 1,500,000 Bubbles", {
            regex: "i)(?=.*blow)(?=.*bubb)",
            run: (*) => 
        }
    )

    static doTasks() {
        this.getTasks()
        firstRow := GuiGenie.genieTaskList.GetText(1, 1)  ; Row 1, Column 1 = Task name
        if Genie.GENIE_TASKS.Has(firstRow)
            Genie.GENIE_TASKS[firstRow].run.Call()
    }

    static chooseDestiny() {
        if this.isActive()
            return

        Teleport.teleportTo("1-3")
        Roblox.activate()
        Roblox.Leaderboard.close()
        Sleep 1000

        if this.isActive()
            return

        Movement.move("w", 1100)
        Movement.move("d", 1400)
        Sleep 1000

        if this.isChooseButtonVisible()
            clickButton(this.CHOOSE_BUTTON, 1000, 1)

        clickButton(this.CLOSE_BUTTON, 50, 1)
    }

    static getTasks() {
        Roblox.activate()
        GuiGenie.genieTaskList.Delete()
        area := this.TASK_OCR_AREA
        Loop 3 {
            text := getOcr(area.x, area.y, area.w, area.h, this.OCR_SCALE, , false)
            trimmed := Trim(text)
            for name, task in this.GENIE_TASKS {
                if RegExMatch(trimmed, task.regex)
                    GuiGenie.genieTaskList.Add(, name, "Genie")
            }
            clickButton(this.NEXT_QUEST_BUTTON, 500, 1)
        }
    }

    static isActive() {
        Roblox.activate()
        return PixelSearch(&x, &y, this.ICON_AREA*)
    }

    static isChooseButtonVisible() {
        return PixelSearch(&x, &y, this.CHOOSE_BUTTON_AREA*)
    }
}

class Tasks {
    static NUMBER_EGGS := 4

    static hatchRarePets() {
        Roblox.activate()
        Hatching.moveToEgg("Common")

        hatchTimes := 30
        Loop hatchTimes {
            Roblox.setTitle("Hatching (" A_Index "/" hatchTimes ")")
            Loop {
                if Teleport.isMainGameVisible() {
                    Hatching.startHatchingEgg()
                    break
                }
                Sleep 50
            }
            Sleep 500
        }
    }

    static hatchEggs() {
        Roblox.activate()
        Hatching.moveToEgg("Infinity")

        hatchTimes := 30
        Loop hatchTimes {
            Roblox.setTitle("Hatching (" A_Index "/" hatchTimes ")")
            Loop {
                if Teleport.isMainGameVisible() {
                    Hatching.startHatchingEgg()
                    break
                }
                Sleep 50
            }
            Sleep 500
        }
    }
}