#Requires AutoHotkey v2.0

class Webhook {
    static COLOUR_RED := 15548997
    static COLOUR_GREEN := 5763719
    static COLOUR_PURPLE := 10181046
    static ICON_URL := "https://i.imgur.com/7nM9jMC.png"
}

class PersonalWebhook {

    static rewardsWebhook(minigame) {
        if GuiSettings.webhookUrl.Value = ""
            return

        pToken := Gdip_Startup()
        WinGetClientPos(&cx, &cy, &cw, &ch, "ahk_exe RobloxPlayerBeta.exe")
        pBitmap := Gdip_BitmapFromScreen(cx "|" cy "|" cw "|" ch)
        this.sendWithImage(pBitmap, minigame " Rewards")
        Gdip_DisposeImage(pBitmap)
        Gdip_Shutdown(pToken)
    }

    static shopsWebhook(shop) {
        if GuiSettings.webhookUrl.Value = ""
            return

        pToken := Gdip_Startup()
        WinGetClientPos(&cx, &cy, &cw, &ch, "ahk_exe RobloxPlayerBeta.exe")
        pBitmap := Gdip_BitmapFromScreen(cx "|" cy "|" cw "|" ch)
        this.sendWithImage(pBitmap, shop " Items")
        Gdip_DisposeImage(pBitmap)
        Gdip_Shutdown(pToken)
    }

    static sendWithImage(pBitmap, title := "", message := "", embedColour := Webhook.COLOUR_GREEN) {
        ; -----------------------------------------------------------
        ; Sends a GDI+ bitmap (pBitmap) as a Discord embed image using IStream
        ; The image is kept in memory, encoded as PNG, and uploaded using a multipart/form-data payload.
        ; Discord requires a filename for the embedded image (even from memory).
        ; The same filename must be used in both:
        ;   1. The multipart form-data "filename" field
        ;   2. The embed's image URL as "attachment://filename"
        ; -----------------------------------------------------------

        boundary := "----------------------------" SubStr(A_TickCount, 1)

        ; Create a memory stream to build the full HTTP body
        hData := DllCall("GlobalAlloc", "UInt", 0x2, "UPtr", 0, "Ptr")
        DllCall("ole32\CreateStreamOnHGlobal", "Ptr", hData, "Int", false, "PtrP", &pStream := 0)

        dateTime := FormatTime(A_Now, "yyyy-MM-dd HH:mm:ss")


        ; Discord requires a filename for embedded images, even if the image is sent from memory (IStream).
        ; The same filename must be used in both the multipart form-data and the embed's attachment URL.
        filename := "screenshot_from_IStream.png"

        ; === Part 1: JSON payload ===
        postData :=
        (
        '
        ------------------------------' boundary '
        Content-Disposition: form-data; name="payload_json"
        Content-Type: application/json

        {
            "content": "' message '",
            "embeds": [
                {
                    "footer": {
                        "text": "' MACRO_TITLE ' ' MACRO_VERSION '  [' dateTime ']",
                        "icon_url": "' Webhook.ICON_URL '"
                    },            
                    "title": "' title '",
                    "description": "",
                    "color": ' embedColour ',
                    "image": { "url": "attachment://' filename '" }
                }
            ]
        }
        '
        )
        utf8 := Buffer(len := StrPut(postData, "UTF-8") - 1)
        StrPut(postData, utf8, len, "UTF-8")
        DllCall("shlwapi\IStream_Write", "Ptr", pStream, "Ptr", utf8.Ptr, "UInt", len, "UInt")

        ; === Part 2: Image file section ===
        part2 :=
        (
        '
        ------------------------------' boundary '
        Content-Disposition: form-data; name="file"; filename="' filename '"
        Content-Type: image/png

        '
        )
        utf8 := Buffer(len := StrPut(part2, "UTF-8") - 1)
        StrPut(part2, utf8, len, "UTF-8")
        DllCall("shlwapi\IStream_Write", "Ptr", pStream, "Ptr", utf8.Ptr, "UInt", len, "UInt")

        ; Save GDI+ bitmap to PNG format into a memory stream
        pFileStream := Gdip_SaveBitmapToStream(pBitmap)
        DllCall("shlwapi\IStream_Size", "Ptr", pFileStream, "UInt64P", &size := 0)
        DllCall("shlwapi\IStream_Reset", "Ptr", pFileStream)
        DllCall("shlwapi\IStream_Copy", "Ptr", pFileStream, "Ptr", pStream, "UInt", size)
        ObjRelease(pFileStream)

        ; === Part 3: Final boundary ===
        part3 :=
        (
        '
        ------------------------------' boundary '--
        '
        )
        utf8 := Buffer(len := StrPut(part3, "UTF-8") - 1)
        StrPut(part3, utf8, len, "UTF-8")
        DllCall("shlwapi\IStream_Write", "Ptr", pStream, "Ptr", utf8.Ptr, "UInt", len, "UInt")

        ; Finalise and extract the memory stream
        ObjRelease(pStream)
        pData := DllCall("GlobalLock", "Ptr", hData, "Ptr")
        size := DllCall("GlobalSize", "Ptr", hData, "UPtr")
        arr := ComObjArray(0x11, size)  ; VT_UI1 | VT_ARRAY
        pvData := NumGet(ComObjValue(arr), 8 + A_PtrSize, "Ptr")
        DllCall("RtlMoveMemory", "Ptr", pvData, "Ptr", pData, "UPtr", size)
        DllCall("GlobalUnlock", "Ptr", hData)
        DllCall("GlobalFree", "Ptr", hData)

        ; Send via WinHttp
        contentType := "multipart/form-data; boundary=----------------------------" boundary
        wr := ComObject("WinHttp.WinHttpRequest.5.1")
        wr.Open("POST", GuiSettings.webhookUrl.Value)
        wr.SetRequestHeader("Content-Type", contentType)
        wr.Send(arr)

        ; Uncomment to debug response
        ; MsgBox "Response:`n" wr.ResponseText
    }

    static post(title, description := "", thumbnail := "", content := "", embedColour := Webhook.COLOUR_GREEN, status := false) {
        dateTime := FormatTime(A_Now, "yyyy-MM-dd HH:mm:ss")

        postData :=
            (
            '
            {
                "content": "' content '",
                "embeds": [
                    {
                        "footer": {
                            "text": "' MACRO_TITLE ' ' MACRO_VERSION '  [' dateTime ']",
                            "icon_url": "' Webhook.ICON_URL '"
                        },
                        "title": "' title '",
                        "description": "' description '",
                        "color": ' embedColour ',
                        "thumbnail": {
                            "url": "' thumbnail '"
                        }
                    }
                ]
            }
            '
        )

        WebRequest := ComObject("WinHttp.WinHttpRequest.5.1")
        WebRequest.Open("POST", GuiSettings.webhookUrl.Value, false)
        WebRequest.SetRequestHeader("Content-Type", "application/json")
        WebRequest.Send(postData)

        if status {
            if (WebRequest.Status = 204) {
                MsgBox "Webhook sent successfully!", MACRO_TITLE, 0x40
            } else {
                MsgBox "Webhook error: " WebRequest.Status "`n`n" WebRequest.ResponseText, MACRO_TITLE, 0x10
            }
        }

    }    

    static test() {
        if GuiSettings.webhookUrl.Value = "" {
            MsgBox "Please complete the Webhook URL before sending a notification.", "Missing Info", 0x30
            return
        }
        title := "Test Notification"
        description := "This is a test notification."
        this.post(title, description, , , , true)
    }

    static MINIGAME_IMAGES := Map(
        "Pet Match", "https://i.imgur.com/DJCCerI.png",
        "Robot Claw", "https://i.imgur.com/eJHLE4s.png",
        "Hyper Darts", "https://i.imgur.com/qwrwCoB.png",
    )

    static minigameStartedWebhook(minigame) {
        title := minigame " Started"
        description := ""
        thumbnail := this.MINIGAME_IMAGES[minigame]
        this.post(title, description, thumbnail)
    }

}