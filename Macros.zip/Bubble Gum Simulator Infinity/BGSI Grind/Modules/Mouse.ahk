#Requires AutoHotkey v2.0

clickButton(button, delay, times := 1) {
    ; First click at the exact button position.
    SendEvent "{Click, " button.x ", " button.y ", 1}"

    ; If more clicks are needed, send them with small random offsets.
    if times > 1 {
        loop times - 1 {
            Sleep 50
            offsetX := Round(Random(-2, 2))
            offsetY := Round(Random(-2, 2))
            SendEvent "{Click, " button.x + offsetX ", " button.y + offsetY ", 1}"
        }
    }
    Sleep delay
}

clickHold() {
    Send "{Click down}"
    Sleep 100
    Send "{Click up}"
}

moveLocation(location, delay) {
    MouseMove location.x, location.y, 0
    Sleep 50
    MouseMove 1, 1, 0, "R"
    Sleep delay
}

scrollMouseWheel(direction, times := 1) {
    loop times {
        Send "{Wheel" direction "}"
        Sleep 50
    }
}

class Mouse {
    static holdLeftMouse() {
        Roblox.activate()
        Click "down left"
        Sleep 200
        Bubble.closeBubbleFullWindow()
    }

    static releaseLeftMouse() {
        Roblox.activate()
        Click "up left"
    }
}
