#Requires AutoHotkey v2.0

global COLORS := {
    headerBg: "0xd29922",
    headerText: "0x13171d",
    bg: "0x0a0e14",
    cardBg: "0x161b22",
    cardHover: "0x1c2128",
    text: "0xFFFFFF",
    textDim: "0xB0B0B0",
    border: "0x3A3A3A",
    success: "0x4CAF50",
    warning: "0xFFC107",
    danger: "0xF44336",
    buttonBg: "0xF5E6D3",
    buttonText: "0x000000"
}

mainGui := Gui()


; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
; @region Event Handlers
; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

OnMessage(0x200, OnMainGuiMouseMove)

OnMainGuiMouseMove(wParam, lParam, msg, hwnd) {
    ; Only act if the hovered control is a picture (image button)
    ctrl := GuiCtrlFromHwnd(hwnd)
    if IsObject(ctrl) && ctrl.Type = "Pic" {
        ; IDC_HAND = 32649 → change mouse cursor to hand
        DllCall("SetCursor", "ptr", DllCall("LoadCursor", "ptr", 0, "ptr", 32649, "ptr"))
    }
}


; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
; @region Icon Folders
; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

GUI_MENU_ICON_FOLDER := A_ScriptDir "\Assets\Icons\Menu\"
GUI_MODE_ICON_FOLDER := A_ScriptDir "\Assets\Icons\Modes\"
GUI_ACTION_ICON_FOLDER := A_ScriptDir "\Assets\Icons\Actions\"
GUI_SEASON_ICON_FOLDER := A_ScriptDir "\Assets\Icons\Season\"
GUI_EGG_IMAGE_FOLDER := A_ScriptDir "\Assets\GUI\Eggs\"
GUI_RESOURCE_IMAGE_FOLDER := A_ScriptDir "\Assets\GUI\Resources\"
GUI_BOOST_IMAGE_FOLDER := A_ScriptDir "\Assets\GUI\Boosts\"
GUI_MINIGAMES_IMAGE_FOLDER := A_ScriptDir "\Assets\GUI\Minigames\"
GUI_SHOPS_IMAGE_FOLDER := A_ScriptDir "\Assets\GUI\Shops\"
GUI_ACTIONS_IMAGE_FOLDER := A_ScriptDir "\Assets\GUI\Actions\"
GUI_TOOLS_IMAGE_FOLDER := A_ScriptDir "\Assets\GUI\Tools\"
GUI_COMPETITIVE_IMAGE_FOLDER := A_ScriptDir "\Assets\GUI\Competitive\"
GUI_SEASON_IMAGE_FOLDER := A_ScriptDir "\Assets\GUI\Season\"
GUI_EVENT_IMAGE_FOLDER := A_ScriptDir "\Assets\GUI\Event\"
GUI_SETTINGS_IMAGE_FOLDER := A_ScriptDir "\Assets\GUI\Settings\"
GUI_GENIE_IMAGE_FOLDER := A_ScriptDir "\Assets\GUI\Genie\"
GUI_MODES_IMAGE_FOLDER := A_ScriptDir "\Assets\GUI\Modes\"


; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
; @region CREATE GUI
; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

createmainGui() {
    global

    try mainGui.Destroy()

    mainGui := Gui("+Border")
    mainGui.Title := MACRO_TITLE " v" MACRO_VERSION
    mainGui.BackColor := COLORS.bg
    mainGui.MarginX := 0
    mainGui.MarginY := 0

    ; Header
    mainGui.Add("Progress", "x0 y0 w430 h100 Background" SubStr(COLORS.headerBg, 3))
    mainGui.SetFont("s20 bold c" SubStr(COLORS.headerText, 3), "Segoe UI")
    mainGui.Add("Text", "x0 y0 w430 Center BackgroundTrans", "🎮 " MACRO_TITLE)
    mainGui.SetFont("s10 c" SubStr(COLORS.headerText, 3))
    mainGui.Add("Text", "x0 y75 w430 Center BackgroundTrans", "Advanced Automation for BGSI v" MACRO_VERSION)
    
    mainGui.SetFont("s8 c" COLORS.text, "Segoe UI")

    ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
    ; @region Menu Bar
    ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

    fileMenu := Menu()
    startLabel := "Start Mode"
    pauseLabel := "Pause Mode"
    exitLabel := "Exit Mode"
    saveLabel := "Quick Save"
    fileMenu.Add(startLabel, (*) => startMacro())
    fileMenu.Add(pauseLabel, (*) => pauseMacro())
    fileMenu.Add(exitLabel, exitMacro)
    fileMenu.Add()
    fileMenu.Add("Reload Mode", (*) => reloadMacro())
    fileMenu.Add(saveLabel, (*) => Settings.save())
    fileMenu.SetIcon(startLabel, "imageres.dll", 282)
    fileMenu.SetIcon(pauseLabel, GUI_MENU_ICON_FOLDER "PlayPause.ico")
    fileMenu.SetIcon("Reload Mode", "imageres.dll", 230)
    fileMenu.SetIcon(exitLabel, "imageres.dll", 94)
    fileMenu.SetIcon(saveLabel, "shell32.dll", 259)

    toolsMenu := Menu()

    toolsMenu.Add("Reconnect", (*) => Reconnect.reconnectFromMenu())
    toolsMenu.SetIcon("Reconnect", WinGetProcessPath("ahk_exe RobloxPlayerBeta.exe"), 1)

    helpMenu := Menu()
    helpMenu.Add("Discord", openDiscord)
    helpMenu.Add("Website", openWebsite)
    helpMenu.SetIcon("Discord", GUI_MENU_ICON_FOLDER "Discord.ico")
    helpMenu.SetIcon("Website", GUI_MENU_ICON_FOLDER "PsychoHatcher.ico")
    
    MyMenuBar := MenuBar()
    MyMenuBar.Add("&File", fileMenu)
    MyMenuBar.Add("&Tools", toolsMenu)
    MyMenuBar.Add("&Help", helpMenu)
    mainGui.MenuBar := MyMenuBar


    ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
    ; @region Navigation Buttons
    ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

    settingsButton := mainGui.AddPicture("x10 y110 w40 h40", GUI_SETTINGS_IMAGE_FOLDER "Settings_Icon.png")
    settingsButton.OnEvent("Click", (*) => GuiSettings.show())
    UI.TOOLTIP_MAP[settingsButton.Hwnd] := { title: "Settings", text: "Display the Settings GUI." }

    actionsButton := mainGui.AddPicture("yp w40 h40", GUI_ACTIONS_IMAGE_FOLDER "Chest.png")
    actionsButton.OnEvent("Click", (*) => GuiActions.show())
    UI.TOOLTIP_MAP[actionsButton.Hwnd] := { title: "Actions", text: "Displays the Actions GUI, where you can select actions to add to the Actions Queue. Actions are tasks performed between modes, each with its own cooldown. Once their cooldowns finish, they are executed after the current mode ends." }

    farmButton := mainGui.AddPicture("yp w40 h40", GUI_RESOURCE_IMAGE_FOLDER "Gems.png")
    farmButton.OnEvent("Click", (*) => GuiFarm.show())
    UI.TOOLTIP_MAP[farmButton.Hwnd] := { title: "Mode: Farm", text: "Displays the Farming GUI, where you can select resources to farm. Modes are time-based tasks that run until completion, after which any pending actions are executed." }

    hatchButton := mainGui.AddPicture("yp w40 h40", GUI_EGG_IMAGE_FOLDER "Eggs.png")
    hatchButton.OnEvent("Click", (*) => GuiHatch.show())
    UI.TOOLTIP_MAP[hatchButton.Hwnd] := { title: "Mode: Hatch", text: "Displays the Hatching GUI, where you can select eggs to hatch. Modes are time-based tasks that run until completion, after which any pending actions are executed." }

    seasonButton := mainGui.AddPicture("yp w40 h40", GUI_SEASON_IMAGE_FOLDER "Season_Icon.png")
    seasonButton.OnEvent("Click", (*) => GuiSeason.show())
    UI.TOOLTIP_MAP[seasonButton.Hwnd] := { title: "Mode: Season Challenges", text: "Displays the Season Challenges Mode GUI, where you can run the mode that reads and completes active season challenges." }

    eventButton := mainGui.AddPicture("yp w40 h40", GUI_EVENT_IMAGE_FOLDER "Festival_Mystery_Box.png")
    eventButton.OnEvent("Click", (*) => GuiEventChallenges.show())
    UI.TOOLTIP_MAP[eventButton.Hwnd] := { title: "Mode: Event Challenges", text: "Displays the Event Mode GUI, where you can run the mode that reads and completes active event challenges." }

    ;competeButton := mainGui.AddPicture("yp w40 h40", GUI_COMPETITIVE_IMAGE_FOLDER "Competitive.png")
    ;competeButton.OnEvent("Click", (*) => GuiCompete.show())
    ;UI.TOOLTIP_MAP[competeButton.Hwnd] := { title: "Mode: Competitive", text: "Displays the Competitive Mode GUI, where you can run the mode that reads and completes active competitive quests." }

    toolsButton := mainGui.AddPicture("yp w40 h40", GUI_TOOLS_IMAGE_FOLDER "Infinity_Elixir_Tile.png")
    toolsButton.OnEvent("Click", (*) => GuiTools.show())
    UI.TOOLTIP_MAP[toolsButton.Hwnd] := { title: "Tools", text: "Displays the Tools GUI, where you can select tools to run. Tools operate independently of the queues and will continue running until manually stopped." }


    ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
    ; @region Show Gui
    ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

    mainGui.Show("w430 h160")
    mainGui.Move(-8, 0)

}

; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
; @region Create Sub Guis
; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

createSubGuis() {
    GuiModeQueue.create()
    GuiActionQueue.create()
    GuiTools.create()
    GuiFarm.create()
    GuiHatch.create()
    GuiActions.create()
    GuiSettings.create()
    GuiSeason.create()
    GuiCompete.create()
    GuiGenie.create()
    GuiSeasonList.create()
    GuiEventChallenges.create()
}


; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
; @region Functions
; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

updateCountdown(dropdown, countdown) {
    global
    totalMinutes := dropdown.Text + 0
    wholeMinutes := Floor(totalMinutes)
    remainingSeconds := Round((totalMinutes - wholeMinutes) * 60)

    formatted := Format("{:2}m {:02}s", wholeMinutes, remainingSeconds)
    countdown.Value := formatted            
}

buffsMasteryChange() {
    Movement.updateModifier(GuiSettings.buffsMasteryDropdown.Text) 
}

setCheckBoxes(claimCheckboxes, state) {
    for cb in claimCheckboxes
        cb.Value := state
}

updateCheckboxes(select, checkboxes) {
    if select.Value == -1
        select.Value := 0

    for checkbox in checkboxes
        checkbox.Value := select.Value
}

updateSelectAllCheckbox(select, checkboxes) {
    values := []
    for cb in checkboxes
        values.Push(cb.Value)

    all := Min(values*) = 1
    none := Max(values*) = 0

    select.Value := all ? 1 : none ? 0 : -1    
}


; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
; @region Menu Functions
; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

openDiscord(*) {
    Run "https://discord.gg/psychohatcher"
}

openWebsite(*) {
    Run "https://psychohatcher.com/"
}

openDonate(*) {
    Run "https://psychohatcher.com/donate/"
}

reloadMacro(*) {
    Reload
}