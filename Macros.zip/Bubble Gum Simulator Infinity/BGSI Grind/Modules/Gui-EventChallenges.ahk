#Requires AutoHotkey v2.0

OnMessage(0x201, ObjBindMethod(GuiEventChallenges, "handleMouseDown"))
OnMessage(0x0006, ObjBindMethod(GuiEventChallenges, "handleDeactivate"))

class GuiEventChallenges {

    static gui := ""

    static FIRST_COLUMN_X := 10
    static SECOND_COLUMN_X := 220
    static TOP_Y := 10

    static show() {
        this.gui.Show("AutoSize")
        mainGui.GetPos(&x, &y, &w, &h)
        this.gui.Move(x + 6, y + h - 8)  
    }

    static handleMouseDown(wParam, lParam, msg, hwnd) {
        if (this.gui && hwnd = this.gui.Hwnd && WinActive("ahk_id " hwnd)) {
            PostMessage 0xA1, 2,,, "ahk_id " hwnd  ; WM_NCLBUTTONDOWN, HTCAPTION
        }
    }

    static handleDeactivate(wParam, lParam, msg, hwnd) {
        if (wParam = 0 && this.gui && hwnd = this.gui.Hwnd) {
            this.gui.Hide()
        }
    }

    static create() {
        this.gui := Gui("-Caption +Border")
        this.gui.SetFont("s8 c" UI.UI_FONT_COLOUR, "Segoe UI Light")
        this.gui.BackColor := UI.UI_BACKCOLOUR
        
        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
        ; @region Timers
        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

        allEggs := []
        for eggName, eggData in Hatching.EggProperties {
            if eggData.active
                allEggs.Push(eggName)
        }

        this.gui.AddGroupBox("x" this.FIRST_COLUMN_X " y" this.TOP_Y " Section w200 h90", "Event Challenges").SetFont("w700")
        info := this.gui.AddPicture("xs+10 yp+20 w30 h30", GUI_EVENT_IMAGE_FOLDER "Festival_Mystery_Box.png")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Event Challenges", text: "Completes event challenges by reading, prioritising, and executing them automatically." }

        info := this.gui.AddText("x+10 ys+20 w80", "Duration")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Duration", text: "Defines the duration for challenge completion. Ends early if all challenges are finished ahead of time." }
        this.eventMinutes := this.gui.AddDropDownList("x+10 yp-3 w50", [5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60])
        this.eventMinutes.Value := 4

        info := this.gui.AddText("xs+50 yp+25 w80", "Check Interval")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Check Interval", text: "Specifies how frequently event challenges are re-evaluated." }
        this.eventHatchingMinutes := this.gui.AddDropDownList("x+10 yp-3 w50", [1, 2, 3, 4, 5])  
        this.eventHatchingMinutes.Value := 2

        ; Start button.
        this.eventAddButton := this.gui.AddButton("xs+10 ys+55 w30", "➕")
        this.eventAddButton.OnEvent("Click", (*) => Modes.addEventMode())

        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
        ; @region Boosts
        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

        this.gui.AddGroupBox("xs Section w200 h110", "Boosts").SetFont("w700")
        info := this.gui.AddPicture("xs+10 yp+20 w30 h30", GUI_TOOLS_IMAGE_FOLDER "Items_Icon.png")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Boosts", text: "Choose which boosts to apply during event challenge completion." }

        this.eventBoostsSelectAll := this.gui.AddCheckbox("x+10 ys+20 w20 h20 Check3", "")
        info := this.gui.AddText("x+0 yp+3 w70", "Potions")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Potions", text: "Check or uncheck all options for using potions." }
        info.SetFont("", "Segoe UI Semibold")

        this.gui.Add("Text", "xs+50 yp+20 w140 h1 BackgroundGray")

        this.eventLuckyCheckbox := this.gui.AddCheckbox("xs+50 yp+5 w20 h20", "")
        info := this.gui.AddText("x+0 yp+3 w100", "Use Lucky V Potion")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Use Lucky V Potion", text: "Automatically uses a Lucky Potion at the start of Season Challenges mode." }

        this.eventSpeedCheckbox := this.gui.AddCheckbox("xs+50 yp+15 w20 h20", "")
        info := this.gui.AddText("x+0 yp+3 w100", "Use Speed V Potion")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Use Speed V Potion", text: "Automatically uses a Speed Potion at the start of Season Challenges mode." }

        this.eventMythicCheckbox := this.gui.AddCheckbox("xs+50 yp+15 w20 h20", "")
        info := this.gui.AddText("x+0 yp+3 w100", "Use Mythic V Potion")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Use Mythic V Potion", text: "Automatically uses a Mythic Potion at the start of Season Challenges mode." }

        ; Update checkboxes.
        eventBoostSelect := this.eventBoostsSelectAll
        eventBoostcheckboxes := [this.eventLuckyCheckbox, this.eventSpeedCheckbox, this.eventMythicCheckbox]
        this.eventBoostsSelectAll.OnEvent("Click", (*) => updateCheckboxes(eventBoostSelect, eventBoostcheckboxes))
        for checkbox in eventBoostcheckboxes
            checkbox.OnEvent("Click", (*) => updateSelectAllCheckbox(eventBoostSelect, eventBoostcheckboxes))

    }

}

class GuiEventChallengesList {

    static show() {
        this.gui.Show("AutoSize")
        GuiActionQueue.gui.GetPos(&x, &y, &w, &h)
        this.gui.Move(x + w, y)
    }

    static create() {
        this.gui := Gui("-Caption +Border")
        this.gui.SetFont("s9 c" UI.UI_FONT_COLOUR, "Segoe UI Light")
        this.gui.BackColor := UI.UI_BACKCOLOUR

        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
        ; @region > Stars
        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

        this.gui.AddPicture("x10 y10 Section w30 h30", GUI_SEASON_IMAGE_FOLDER "Points.png")    
        this.competeStarsTotal := this.gui.AddText("x+10 w100 h50", 0)
        this.competeStarsTotal.SetFont("s14", "Segoe UI Light")  

        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
        ; @region > Tasks
        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

        this.eventImageList := IL_Create()

        this.eventChallengeList := this.gui.AddListView("xs yp+40 w240 h130 r6 Grid +ReadOnly", ["Challenge", "No.", "%", "Priority", "Egg", "Type"])
        list := this.eventChallengeList
        list.ModifyCol(1, 160)
        list.ModifyCol(2, 0)
        list.ModifyCol(3, 30)
        list.ModifyCol(4, 0)
        list.ModifyCol(5, 0)
        list.ModifyCol(6, 0)
        list.ModifyCol(7, 0)
        list.ModifyCol(8, 0)
        list.ModifyCol(9, 0)
        list.ModifyCol(4, "Sort")

        list.SetImageList(this.eventImageList)

    }

}