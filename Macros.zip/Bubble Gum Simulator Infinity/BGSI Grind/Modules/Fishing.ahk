#Requires AutoHotkey v2.0

class Fishing {
    static FISHING_ROD_SEARCH_AREA := {x1: 210, y1: 120, x2: 300, y2: 180}
    static SAFE_CURSOR_POSITION := {x: 790, y: 10}

    static useFishingRod(holdTimeMs := 300) {
        Loop {
            Roblox.activate()
            moveLocation(Fishing.SAFE_CURSOR_POSITION, 50)
            Roblox.setTitle("Casting")
            MouseClick("left", , , 1, 0, "D")
            Sleep holdTimeMs
            MouseClick("left", , , 1, 0, "U")
            Sleep 5000
            Roblox.setTitle("Fishing")

            Loop {
                Keys.send("e")
                MouseClick("left", , , 1, 0, "D")
                Sleep 300
                MouseClick("left", , , 1, 0, "U")
                if (Mod(A_Index, 10) = 0) {
                    Roblox.activate()
                    moveLocation(Fishing.SAFE_CURSOR_POSITION, 5)
                }
                ; if !Fishing.isFishingRodVisible()
                ;     break
            }
            Sleep 2000
        }
    }

    ; static isFishingRodVisible() {
    ; CoordMode "Pixel", "Client"
    ; area := this.FISHING_ROD_SEARCH_AREA
    ; targetColor := 0x606983
    ; return PixelSearch(&x, &y, area.x1, area.y1, area.x2, area.y2, targetColor, 10)
    ; }
}