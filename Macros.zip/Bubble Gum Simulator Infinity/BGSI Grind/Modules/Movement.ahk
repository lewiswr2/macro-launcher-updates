#Requires AutoHotkey v2.0 

class Movement {

    static IS_ROTATED := 0

    static updateModifier(level := 21) {

        walkspeed := ""

        if level = 0 {
            walkspeed := "0"
            modifier := 1.25
        }
        else if level < 3 { ; 5%
            walkspeed := "I (1)"
            modifier := 1.20 
        }
        else if level < 7 { ; 10%
            walkspeed := "II (2)"
            modifier := 1.15
        }
        else if level < 13 { ; 15%
            walkspeed := "III (3)"
            modifier := 1.1
        }        
        else {
            walkspeed := "IV (4)"
            modifier := 1
        }

        GuiSettings.walkspeedModifier.Value := Round(modifier, 2)
        GuiSettings.walkspeedLevel.Value := walkspeed
    }

    static move(keys, time) {
        static scanCodes := Map(
            "w", "SC011",
            "a", "SC01E",
            "s", "SC01F",
            "d", "SC020",
            "_", "SC039",
        )

        Roblox.activate()

        if keys = "" {
            Sleep time
            return
        }

        ; Remap directions if rotated
        if this.IS_ROTATED {
            remap := Map("w", "a", "a", "s", "s", "d", "d", "w")
            newKeys := ""
            for k in StrSplit(keys) {
                lower := StrLower(k)
                newKeys .= remap.Has(lower) ? remap[lower] : lower
            }
            keys := newKeys
        }

        down := "", up := ""
        for k in StrSplit(keys) {
            lower := StrLower(k)
            sc := scanCodes[lower]
            down .= "{" sc " down}"
            up := "{" sc " up}" . up
        }

        this.sendCritical(down)
        Sleep time * GuiSettings.walkspeedModifier.Value
        this.sendCritical(up)
    }


    static sendCritical(sequence) {
        Critical "On"
        Send sequence
        Critical "Off"
    }

    static movePath(path) {
        for step in path
            this.move(step[1], step[2])
    }

    static moveTowardScreenCoord(x, y, duration := 300) {
        ; Define screen centre
        centerX := 400
        centerY := 300

        ; Calculate difference from centre
        dx := x - centerX
        dy := y - centerY

        ; Apply deadzone threshold to avoid jitter
        deadzone := 20
        if Abs(dx) < deadzone
            dx := 0
        if Abs(dy) < deadzone
            dy := 0

        ; Determine movement direction
        move := ""
        if dy < 0
            move .= "w"
        else if dy > 0
            move .= "s"

        if dx > 0
            move .= "d"
        else if dx < 0
            move .= "a"

        ; Execute movement if direction is set
        if move {
            ; Hold down movement keys
            for char in StrSplit(move)
                Send "{" char " down}"

            Sleep duration

            ; Release movement keys
            for char in StrSplit(move)
                Send "{" char " up}"
        }
    }

}


