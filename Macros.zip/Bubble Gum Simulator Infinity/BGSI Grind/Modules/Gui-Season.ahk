#Requires AutoHotkey v2.0

OnMessage(0x201, ObjBindMethod(GuiSeason, "handleMouseDown"))
OnMessage(0x0006, ObjBindMethod(GuiSeason, "handleDeactivate"))

class GuiSeason {


    static gui := ""

    static FIRST_COLUMN_X := 10
    static SECOND_COLUMN_X := 220
    static TOP_Y := 10

    static show() {
        this.gui.Show("AutoSize")
        mainGui.GetPos(&x, &y, &w, &h)
        this.gui.Move(x + 6, y + h - 8)  
    }

    static handleMouseDown(wParam, lParam, msg, hwnd) {
        if (this.gui && hwnd = this.gui.Hwnd && WinActive("ahk_id " hwnd)) {
            PostMessage 0xA1, 2,,, "ahk_id " hwnd  ; WM_NCLBUTTONDOWN, HTCAPTION
        }
    }

    static handleDeactivate(wParam, lParam, msg, hwnd) {
        if (wParam = 0 && this.gui && hwnd = this.gui.Hwnd) {
            this.gui.Hide()
        }
    }

    static create() {
        this.gui := Gui("-Caption +Border")
        this.gui.SetFont("s8 c" UI.UI_FONT_COLOUR, "Segoe UI Light")
        this.gui.BackColor := UI.UI_BACKCOLOUR
        
        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
        ; @region Timers
        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

        allEggs := []
        for eggName, eggData in Hatching.EggProperties {
            if eggData.active
                allEggs.Push(eggName)
        }

        this.gui.AddGroupBox("x" this.FIRST_COLUMN_X " y" this.TOP_Y " Section w200 h90", "Season Challenges").SetFont("w700")
        info := this.gui.AddPicture("xs+10 yp+20 w30 h30", GUI_SEASON_IMAGE_FOLDER "Season_Icon.png")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Season Challenges", text: "Completes hourly and daily season challenges by reading, prioritising, and executing them automatically." }

        info := this.gui.AddText("x+10 ys+20 w80", "Duration")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Duration", text: "Defines the duration for challenge completion. Ends early if all challenges are finished ahead of time." }
        this.seasonMinutes := this.gui.AddDropDownList("x+10 yp-3 w50", [5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60])
        this.seasonMinutes.Value := 6

        info := this.gui.AddText("xs+50 yp+25 w80", "Check Interval")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Check Interval", text: "Specifies how frequently season challenges are re-evaluated." }
        this.seasonHatchingMinutes := this.gui.AddDropDownList("x+10 yp-3 w50", [1, 2, 3, 4, 5])  
        this.seasonHatchingMinutes.Value := 2  

        ; Start button.
        this.seasonAddButton := this.gui.AddButton("xs+10 ys+55 w30", "➕")
        this.seasonAddButton.OnEvent("Click", (*) => Modes.addSeasonMode())

        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
        ; @region Boosts
        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

        this.gui.AddGroupBox("xs Section w200 h110", "Boosts").SetFont("w700")
        info := this.gui.AddPicture("xs+10 yp+20 w30 h30", GUI_TOOLS_IMAGE_FOLDER "Items_Icon.png")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Boosts", text: "Choose which boosts to apply during season challenge completion." }
        

        this.seasonBoostsSelectAll := this.gui.AddCheckbox("x+10 ys+20 w20 h20 Check3", "")
        info := this.gui.AddText("x+0 yp+3 w70", "Potions")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Potions", text: "Check or uncheck all options for using potions." }
        info.SetFont("", "Segoe UI Semibold")

        this.gui.Add("Text", "xs+50 yp+20 w140 h1 BackgroundGray")

        this.seasonLuckyCheckbox := this.gui.AddCheckbox("xs+50 yp+5 w20 h20", "")
        info := this.gui.AddText("x+0 yp+3 w100", "Use Lucky V Potion")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Use Lucky V Potion", text: "Automatically uses a Lucky Potion at the start of Season Challenges mode." }

        this.seasonSpeedCheckbox := this.gui.AddCheckbox("xs+50 yp+15 w20 h20", "")
        info := this.gui.AddText("x+0 yp+3 w100", "Use Speed V Potion")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Use Speed V Potion", text: "Automatically uses a Speed Potion at the start of Season Challenges mode." }

        this.seasonMythicCheckbox := this.gui.AddCheckbox("xs+50 yp+15 w20 h20", "")
        info := this.gui.AddText("x+0 yp+3 w100", "Use Mythic V Potion")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Use Mythic V Potion", text: "Automatically uses a Mythic Potion at the start of Season Challenges mode." }

        ; Update checkboxes.
        seasonBoostSelect := this.seasonBoostsSelectAll
        seasonBoostcheckboxes := [this.seasonLuckyCheckbox, this.seasonSpeedCheckbox, this.seasonMythicCheckbox]
        this.seasonBoostsSelectAll.OnEvent("Click", (*) => updateCheckboxes(seasonBoostSelect, seasonBoostcheckboxes))
        for checkbox in seasonBoostcheckboxes
            checkbox.OnEvent("Click", (*) => updateSelectAllCheckbox(seasonBoostSelect, seasonBoostcheckboxes))


        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
        ; @region Egg Allocations
        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

        this.gui.AddGroupBox("x" this.SECOND_COLUMN_X " y" this.TOP_Y " Section w200 h240", "Egg Preferences").SetFont("w700")
        info := this.gui.AddPicture("xs+10 yp+20 w30 h30", GUI_EGG_IMAGE_FOLDER "Eggs.png")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Egg Allocations", text: "Select eggs to hatch for each pet rarity and variant challenge type." }

        info := this.gui.AddText("xs+50 ys+20 w80", "Pet Rarity")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Pet Variant", text: "Select eggs to hatch for each pet rarity." }
        info.SetFont("", "Segoe UI Semibold")

        info := this.gui.AddText("x+0 w60 +Right", "Egg")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Egg", text: "Set egg preferences for each rarity tier." }
        info.SetFont("", "Segoe UI Semibold")

        this.gui.Add("Text", "xs+50 yp+20 w140 h1 BackgroundGray")

        info := this.gui.AddText("xs+50 yp+10 w55", "Common")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Common", text: "Select which egg should be hatched for the hatch common pets challenge." }
        this.seasonCommonEggDropdown := this.gui.AddDropDownList("x+10 yp-3 w75")  
        this.seasonCommonEggDropdown.Add(allEggs)
        this.seasonCommonEggDropdown.Text := "Infinity" 

        info := this.gui.AddText("xs+50 yp+25 w55", "Unique")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Unique", text: "Select which egg should be hatched for the hatch unique pets challenge." }
        this.seasonUniqueEggDropdown := this.gui.AddDropDownList("x+10 yp-3 w75")  
        this.seasonUniqueEggDropdown.Add(allEggs)
        this.seasonUniqueEggDropdown.Text := "Infinity" 

        info := this.gui.AddText("xs+50 yp+25 w55", "Rare")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Rare", text: "Select which egg should be hatched for the hatch rare pets challenge." }
        this.seasonRareEggDropdown := this.gui.AddDropDownList("x+10 yp-3 w75")  
        this.seasonRareEggDropdown.Add(allEggs)
        this.seasonRareEggDropdown.Text := "Infinity" 

        info := this.gui.AddText("xs+50 yp+25 w55", "Epic")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Epic", text: "Select which egg should be hatched for the hatch epic pets challenge." }
        this.seasonEpicEggDropdown := this.gui.AddDropDownList("x+10 yp-3 w75")  
        this.seasonEpicEggDropdown.Add(allEggs)
        this.seasonEpicEggDropdown.Text := "Infinity" 

        info := this.gui.AddText("xs+50 yp+25 w55", "Legendary")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Legendary", text: "Select which egg should be hatched for the hatch legendary pets challenge." }
        this.seasonLegendaryEggDropdown := this.gui.AddDropDownList("x+10 yp-3 w75")  
        this.seasonLegendaryEggDropdown.Add(allEggs)
        this.seasonLegendaryEggDropdown.Text := "Infinity"   

        info := this.gui.AddText("xs+50 yp+30 w80", "Pet Variant")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Pet Variant", text: "Select eggs to hatch for each pet variant." }
        info.SetFont("", "Segoe UI Semibold")

        info := this.gui.AddText("x+0 w60 +Right", "Egg")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Egg", text: "Set egg preferences for each variant tier." }
        info.SetFont("", "Segoe UI Semibold")

        this.gui.Add("Text", "xs+50 yp+20 w140 h1 BackgroundGray")

        info := this.gui.AddText("xs+50 yp+10 w55", "Shiny")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Shiny", text: "Select which egg should be hatched for the hatch shiny pets challenge." }
        this.seasonShinyEggDropdown := this.gui.AddDropDownList("x+10 yp-3 w75")
        this.seasonShinyEggDropdown.Add(allEggs)
        this.seasonShinyEggDropdown.Text := "Infinity"

        info := this.gui.AddText("xs+50 yp+25 w55", "Mythic")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Mythic", text: "Select which egg should be hatched for the hatch mythic pets challenge." }
        this.seasonMythicEggDropdown := this.gui.AddDropDownList("x+10 yp-3 w75")
        this.seasonMythicEggDropdown.Add(allEggs)
        this.seasonMythicEggDropdown.Text := "Infinity"

    }

}

class GuiSeasonList {

    static show() {
        this.gui.Show("AutoSize")
        GuiActionQueue.gui.GetPos(&x, &y, &w, &h)
        this.gui.Move(x + w, y)
    }

    static create() {
        this.gui := Gui("-Caption +Border")
        this.gui.SetFont("s9 c" UI.UI_FONT_COLOUR, "Segoe UI Light")
        this.gui.BackColor := UI.UI_BACKCOLOUR

        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
        ; @region > Stars
        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

        this.pointsImage := this.gui.AddPicture("x10 y10 Section w30 h30", GUI_SEASON_IMAGE_FOLDER "Season_Points.png")    
        this.competeStarsTotal := this.gui.AddText("x+10 w100 h35", 0)
        this.competeStarsTotal.SetFont("s14", "Segoe UI Light")  

        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
        ; @region > Tasks
        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

        this.seasonImageList := IL_Create()

        this.seasonChallengeList := this.gui.AddListView("xs yp+40 w240 h130 r6 Grid +ReadOnly", ["Challenge", "No.", "%", "Priority", "Egg", "Type"])
        list := this.seasonChallengeList
        list.ModifyCol(1, 160)
        list.ModifyCol(2, 0)
        list.ModifyCol(3, 30)
        list.ModifyCol(4, 0)
        list.ModifyCol(5, 0)
        list.ModifyCol(6, 0)
        list.ModifyCol(7, 0)
        list.ModifyCol(8, 0)
        list.ModifyCol(9, 0)
        list.ModifyCol(4, "Sort")

        list.SetImageList(this.seasonImageList)

    }

}