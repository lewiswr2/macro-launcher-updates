#Requires AutoHotkey v2.0

class Camera {
    static setOverhead() {
        Roblox.setTitle("Starting | Changing to Overhead View")
        Roblox.activate()
        Sleep 250

        BlockInput("On")

        SendEvent "{Click, 400, 300, 1}"
        SendEvent "{RButton down}"

        Sleep 500
        if Bubble.closeBubbleFullWindow() {
            SendEvent "{RButton down}"
            Sleep 500
        }

        Loop 50
            DllCall("mouse_event", "uint", 1, "int", 0, "int", 5, "uint", 0, "int", 0)

        SendEvent "{RButton up}"

        BlockInput("Off")

        Roblox.setTitle()
    }


    static zoomOut(time) {
        Roblox.setTitle("Starting | Zooming Out")
        Roblox.activate()

        Loop 5
            Keys.send("o", "down")

        Sleep time

        Loop 5
            Keys.send("o", "up")

        Roblox.setTitle()
    }

    static turnNinetyDegrees(direction, times := 1) {
        loop times {
            SendInput "{" direction " up}"
            Sleep 200
            SendInput "{" direction " down}"
            ;Sleep 748
            Sleep 747
            SendInput "{" direction " up}"
            KeyWait direction
        }
    }

}