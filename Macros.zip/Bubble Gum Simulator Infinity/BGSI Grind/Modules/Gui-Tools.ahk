#Requires AutoHotkey v2.0

OnMessage(0x201, ObjBindMethod(GuiTools, "handleMouseDown"))
OnMessage(0x0006, ObjBindMethod(GuiTools, "handleDeactivate"))
OnMessage(0x0100, ObjBindMethod(GuiTools, "handleKeyDown"))

class GuiTools {

    static ignoreDeactivate := false

    static gui := ""

    static FIRST_COLUMN_X := 10
    static SECOND_COLUMN_X := 220
    static TOP_Y := 10

    static show() {
        this.gui.Show("AutoSize")
        mainGui.GetPos(&x, &y, &w, &h)
        this.gui.Move(x + 6, y + h - 8)      
    }

    static handleMouseDown(wParam, lParam, msg, hwnd) {
        if (this.gui && hwnd = this.gui.Hwnd && WinActive("ahk_id " hwnd)) {
            PostMessage 0xA1, 2,,, "ahk_id " hwnd  ; WM_NCLBUTTONDOWN, HTCAPTION
        }
    }

    static handleDeactivate(wParam, lParam, msg, hwnd) {
        if wParam == 1 || wParam == 2 {
            this.ignoreDeactivate := false
            return
        }
            
        if this.ignoreDeactivate
            return
        
        if (wParam = 0 && this.gui && hwnd = this.gui.Hwnd) {
            this.gui.Hide()
        }
    }

    static handleKeyDown(wParam, lParam, msg, hwnd) {
        if (wParam = 0x2E) { ; Delete key
            if (WinActive("ahk_id " this.gui.Hwnd) && this.enchantPetList.Focused) {
                row := this.enchantPetList.GetNext()
                if (row > 0)
                    this.enchantPetList.Delete(row)
            }
        }
    }

    static create() {
        this.gui := Gui("-Caption +Border")
        this.gui.SetFont("s8 c" UI.UI_FONT_COLOUR, "Segoe UI Light")
        this.gui.BackColor := UI.UI_BACKCOLOUR

        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
        ; @region > INFINITY ELIXIR
        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

        ; Group box.
        this.gui.AddGroupBox("x" GuiTools.FIRST_COLUMN_X " y" GuiTools.TOP_Y " Section w200 h175", "Infinity Elixir Farming").SetFont("w700")

        ; Image.
        info := this.gui.AddPicture("xs+10 ys+20 w30 h30", GUI_TOOLS_IMAGE_FOLDER "Infinity_Elixir_Tile.png")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Infinity Elixir Farming", text: "This mode is used to farm Infinity Elixir tiles in the Board Game." }

        ; Golden Dice.
        info := this.gui.AddText("x+10 yp w70", "Golden Dice")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Golden Dice", text: "Defines the maximum number of golden dice that can be used to reach a single Infinity Elixir. For example, if set to 3 and the elixir is 4 tiles away, a 6-sided die will be used instead. If the elixir is 3 tiles away, all 3 golden dice will be used." }
        this.gbGoldenDiceUseAmount := this.gui.AddDropDownList("x+10 yp-3 w60", [1, 2, 3, 4, 5])
        this.gbGoldenDiceUseAmount.Value := 3

        ; Elixir Goal.
        info := this.gui.AddText("xs+50 yp+30 w70", "Target Amount")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Target Amount", text: "Sets the number of Infinity Elixirs to collect before stopping. Each elixir grants a 12 minute 30 second boost — for reference:`n`n • 5 = ~1 hour`n • 10 = ~2 hours`n • 20 = ~4 hours`n • 40 = ~8 hours`n • 60 = ~12 hours`n • 120 = ~24 hours" }
        this.gbInfinityAmount := this.gui.AddDropDownList("x+10 yp-3 w60", [1, 5, 10, 20, 40, 60, 120, "∞"])
        this.gbInfinityAmount.Value := 2

        ; Reconnect on Goal.
        this.gbDisconnect := this.gui.AddCheckbox("xs+50 yp+25 w20 h20", "")
        info := this.gui.AddText("x+0 yp+3 w105", "Reconnect at Target")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Reconnect at Target", text: "Automatically returns to the title screen once the target number of Infinity Elixirs is reached. This helps pause the elixir countdown by disconnecting from the game." }    
        
        ; Alarm on Goal.
        this.gbAlarm := this.gui.AddCheckbox("xs+50 yp+15 w20 h20", "")
        info := this.gui.AddText("x+0 yp+3 w105", "Alarm at Target")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Alarm at Target", text: "Plays a sound alert when the target number of Infinity Elixirs has been reached." }
    
        this.gui.Add("Text", "xs+50 yp+25 w140 h1 BackgroundGray")

        ; Hatch Egg.
        this.gbFarmEgg := this.gui.AddCheckbox("xs+50 yp+10 w20 h20", "")
        info := this.gui.AddText("x+0 yp+3 w50", "Hatch Egg")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Hatch Egg", text: "Hatch and egg while farming Infinity Elixirs." }    
        this.gbFarmEgg.OnEvent("Click", (*) => this.disableOtherCheckbox(this.gbFarmEgg, this.gbBlowBubbles))
        this.gbEggToHatch := this.gui.AddDropDownList("x+10 yp-3 w60", ["Game", "Cyber", "Mining", "Showman", "Neon"])
        this.gbEggToHatch.Value := 1

        ; Blow Bubbles.
        this.gbBlowBubbles := this.gui.AddCheckbox("xs+50 yp+25 w20 h20", "")
        info := this.gui.AddText("x+0 yp+3 w120", "Blow Bubbles")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Blow Bubbles", text: "Blow bubbles while farming Infinity Elixirs." }
        this.gbBlowBubbles.OnEvent("Click", (*) => this.disableOtherCheckbox(this.gbBlowBubbles, this.gbFarmEgg))

        ; Start button.
        this.gbStart := this.gui.AddButton("xs+10 ys+55 w30", "▶️")
        this.gbStart.OnEvent("Click", (*) => BoardGame.playFromMenu())


        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
        ; @region > ENCHANTING
        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

        enchantList := []
        for colour, name in Enchant.Enchant_MAP
            enchantList.Push(name)

        ; Group box.
        this.gui.AddGroupBox("xs Section w200 h225", "Enchant Pets").SetFont("w700")

        ; Image.
        useItemImage := this.gui.AddPicture("xs+10 ys+20 w30 h30", GUI_TOOLS_IMAGE_FOLDER "Special_Enchants.png")
        UI.TOOLTIP_MAP[useItemImage.Hwnd] := { title: "Enchant Pets", text: "This mode allows you to apply an enchantment to pets you've selected from your inventory. Make sure the Pet Enchanter – Select Pet window is open before starting.`n`nNote: This mode requires Level 19 Buffs Mastery." }

        ; Items.
        info := this.gui.AddText("x+10 yp w50", "Enchant")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Enchant to Use", text: "Select the enchantment to apply to your pets." }    
        this.enchantToUse := this.gui.AddDropDownList("x+10 yp-3 w80", enchantList)
        this.enchantToUse.Value := 1
        

        info := this.gui.AddText("xs+50 yp+25 w100", "Select Pets")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Select Pets", text: "Click the ➕ button to enter pet selection mode. Once active, right-click on pets to select them — their coordinates will be added to the list. You can select any pet that's visible in your inventory without scrolling." }            
        this.gui.AddButton("x+10 yp-3 w30", "➕").OnEvent("Click", (*) => this.selectPetsToEnchant())

        this.enchantPetList := this.gui.AddListView("xs+50 yp+25 w140 h150 r10 Grid +ReadOnly", ["X", "Y"])
        list := this.enchantPetList
        list.ModifyCol(1, 50)
        list.ModifyCol(2, 50)

        ; Start button.
        this.enchantStart := this.gui.AddButton("xs+10 ys+55 w30", "▶️")
        this.enchantStart.OnEvent("Click", (*) => Enchant.applyEnchant(this.enchantToUse.Text))


        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
        ; @region > MINIGAMES
        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

        ; Group box.
        this.gui.AddGroupBox("x" GuiTools.SECOND_COLUMN_X " y" GuiTools.TOP_Y " Section w200 h100", "Farm Minigames").SetFont("w700")

        ; Image.
        this.minigameFarmImage := this.gui.AddPicture("xs+10 ys+20 w30 h30", GUI_MINIGAMES_IMAGE_FOLDER "Dice_Icon.png")
        UI.TOOLTIP_MAP[this.minigameFarmImage.Hwnd] := { title: "Farm Minigames", text: "This mode will continuously open the selected inventory item in a loop until manually stopped.`n`nNote: Ensure that your bubble gravity setting is set to 5% for this mode to function correctly." }

        ; Radio buttons.
        this.minigameFarmPetMatch := this.gui.AddRadio("xs+50 ys+20 w20 h20 Group")
        this.minigameFarmRobotClaw := this.gui.AddRadio("xs+50 ys+43 w20 h20")
        this.minigameFarmHyperDarts := this.gui.AddRadio("xs+50 ys+66 w20 h20")

        difficultyList := []
        for _, item in Minigame.DIFFICULTY_LIST
            difficultyList.Push(item["name"])  

        ; Pet Match.
        this.minigameFarmPetMatchLabel := this.gui.AddText("xs+70 ys+23 w60", "Pet Match")
        UI.TOOLTIP_MAP[this.minigameFarmPetMatchLabel.Hwnd] := { title: "Pet Match", text: "Select to farm the Pet Match minigame on Dice Island." }
        this.minigamePetMatchDifficulty := this.gui.AddDropDownList("x+0 ys+20 w60", difficultyList)
        this.minigamePetMatchDifficulty.Value := 4
        
        ; Robot Claw.
        this.minigameFarmRobotClawLabel := this.gui.AddText("xs+70 ys+46 w60", "Robot Claw")
        UI.TOOLTIP_MAP[this.minigameFarmRobotClawLabel.Hwnd] := { title: "Robot Claw", text: "Select to farm the Robot Claw minigame on Robot Factory island." }
        this.minigameRobotClawDifficulty := this.gui.AddDropDownList("x+0 ys+43 w60", difficultyList)
        this.minigameRobotClawDifficulty.Value := 4        
        
        ; Hyper Darts.
        this.minigameFarmHyperDartsLabel := this.gui.AddText("xs+70 ys+69 w60", "Hyper Darts")
        UI.TOOLTIP_MAP[this.minigameFarmHyperDartsLabel.Hwnd] := { title: "Hyper Darts", text: "Select to farm the Hyper Darts minigame on Hyperwave Island." }
        this.minigameHyperDartsDifficulty := this.gui.AddDropDownList("x+0 ys+66 w60", difficultyList)
        this.minigameHyperDartsDifficulty.Value := 4           

        ; Start button.
        this.minigameFarmStart := this.gui.AddButton("xs+10 ys+55 w30", "▶️")
        this.minigameFarmStart.OnEvent("Click", (*) => Minigame.playFromTools())

        ; Update image.
        this.minigameFarmPetMatch.OnEvent("Click", (*) => updateMinigameImage("PetMatch"))
        this.minigameFarmRobotClaw.OnEvent("Click", (*) => updateMinigameImage("RobotClaw"))
        this.minigameFarmHyperDarts.OnEvent("Click", (*) => updateMinigameImage("HyperDarts"))
        updateMinigameImage(mode) {
            imageMap := Map(
                "PetMatch", "PetMatch.png",
                "RobotClaw", "Robot_Claw.png",
                "HyperDarts", "Hyper_Darts.png"
            )

            if imageMap.Has(mode)
                this.minigameFarmImage.Value := GUI_MINIGAMES_IMAGE_FOLDER imageMap[mode]    
        }

        ; Extend clickable label.
        this.minigameFarmPetMatchLabel.OnEvent("Click", (*) => this.minigameFarmPetMatch.Value := 1)
        this.minigameFarmRobotClawLabel.OnEvent("Click", (*) => this.minigameFarmRobotClaw.Value := 1)
        this.minigameFarmHyperDartsLabel.OnEvent("Click", (*) => this.minigameFarmHyperDarts.Value := 1)


        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
        ; @region > OPEN ITEMS
        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

        ; Create item list.
        ITEM_MENU := Map(
            "Mystery Box",  { image: GUI_BOOST_IMAGE_FOLDER "Mystery_Box.png" },
            "Golden Box",   { image: GUI_BOOST_IMAGE_FOLDER "Golden_Box.png" },
            "Season 1 Egg", { image: GUI_EGG_IMAGE_FOLDER "Season_1_Egg.png" },
            "Season 2 Egg", { image: GUI_EGG_IMAGE_FOLDER "Season_2_Egg.png" },
            "Season 3 Egg", { image: GUI_EGG_IMAGE_FOLDER "Season_3_Egg.png" },
            "Series 1 Egg", { image: GUI_EGG_IMAGE_FOLDER "Series_1_Egg.png" },
            "Series 2 Egg", { image: GUI_EGG_IMAGE_FOLDER "Series_2_Egg.png" },
            "Pirate Egg", { image: GUI_EGG_IMAGE_FOLDER "Pirate_Egg.png" },
        )
        itemList := []
        for itemName, itemObj in ITEM_MENU
            itemList.Push(itemName)

        ; Group box.
        this.gui.AddGroupBox("xs Section w200 h90", "Open Inventory Items").SetFont("w700")

        ; Image.
        useItemImage := this.gui.AddPicture("xs+10 ys+20 w30 h30", GUI_TOOLS_IMAGE_FOLDER "Items_Icon.png")
        UI.TOOLTIP_MAP[useItemImage.Hwnd] := { title: "Open Inventory Items", text: "This mode continuously opens selected inventory items in a loop until manually stopped." }

        ; Items.
        info := this.gui.AddText("x+10 yp w140", "Item to Open")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Item to Open", text: "Choose the inventory item to repeatedly open until the mode is manually stopped." }    
        this.itemToUse := this.gui.AddDropDownList("xp w140", itemList)
        this.itemToUse.Value := 1
        
        ; Start button.
        this.itemsToUseStart := this.gui.AddButton("xs+10 ys+55 w30", "▶️")
        this.itemsToUseStart.OnEvent("Click", (*) => Items.ItemsTab.useItemFromMenu(this.itemToUse.Text))

        ; Update image.
        this.itemToUse.OnEvent("Change", (*) => updateUseItemImage())
        updateUseItemImage() {
            image := this.itemToUse.Text = "" ? "Items_Icon.png" : ITEM_MENU[this.itemToUse.Text].image
            useItemImage.Value := image
        }


        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
        ; @region > HATCH EGGS
        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

        ; Create egg list.
        eggList := []
        for eggName, eggData in Hatching.EggProperties {
            if eggData.active {
                eggList.Push(eggName)
            }
        }

        ; Group box.
        this.gui.AddGroupBox("xs Section w200 h90", "Hatch Eggs").SetFont("w700")

        ; Image.
        this.hatchEggImage := this.gui.AddPicture("xs+10 ys+20 w30 h30", GUI_EGG_IMAGE_FOLDER "Eggs.png")
        UI.TOOLTIP_MAP[this.hatchEggImage.Hwnd] := { title: "Hatch Eggs", text: "This mode continuously hatches eggs until manually stopped.`n`nNote: This feature is currently available to VIP users only." }

        ; Eggs.
        info := this.gui.AddText("x+10 yp w140", "Egg to Hatch")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Egg to Hatch", text: "Select the egg to repeatedly hatch until the mode is manually stopped." }
        this.eggToHatch := this.gui.AddDropDownList("xp w140", eggList)
        this.eggToHatch.Value := 1   

        ; Start button.
        this.eggToHatchStart := this.gui.AddButton("xs+10 ys+55 w30", "▶️")
        this.eggToHatchStart.OnEvent("Click", (*) => Hatching.hatchEggFromToolsMenu(this.eggToHatch.Text))

        ; Update egg image.
        this.eggToHatch.OnEvent("Change", (*) => updateHatchEggImage())
        updateHatchEggImage() {
            image := this.itemToUse.Text = "" ? "Eggs.png" : Hatching.EggProperties[this.eggToHatch.Text].image
            this.hatchEggImage.Value := GUI_EGG_IMAGE_FOLDER image
        }

        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
        ; @region > MULTI CLIENT FAST HATCH
        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

        ; Group box.
        ; this.gui.AddGroupBox("xs Section w200 h90", "Multi-Client Hatch").SetFont("w700")

        ; Image.
        ; this.multiHatchImage := this.gui.AddPicture("xs+10 ys+20 w30 h30", GUI_EGG_IMAGE_FOLDER "Eggs.png")
        ; UI.TOOLTIP_MAP[this.multiHatchImage.Hwnd] := { title: "Multi-Client Hatch", text: "Hatch eggs across multiple clients without the need for additional apps. Keeps your accounts active and prevents them from going AFK.`n`nPosition all clients at the egg they want to hatch (or already hatching), then press the start button." }

        ; Start button.
        ; this.multiHatchStart := this.gui.AddButton("xs+10 ys+55 w30", "▶️")
        ; this.multiHatchStart.OnEvent("Click", (*) => MultiCient.Hatch.run())

        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
        ; @region > AUTO BOARD GAME
        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

        ; Group box.
        this.gui.AddGroupBox("xs Section w200 h90", "Board Game Infinite").SetFont("w700")

        ; Image.
        this.boardGameImage := this.gui.AddPicture("xs+10 ys+20 w30 h30", GUI_MINIGAMES_IMAGE_FOLDER "Giant_Dice.png")
        UI.TOOLTIP_MAP[this.boardGameImage.Hwnd] := { title: "Board Game Infinite", text: "This mode automatically clicks all skip buttons and fast hatches. To use it, begin the board game (hatching optional), select your dice, and click the Auto Roll button. Once the game is underway, start the mode." }

        ; Start button.
        this.boardGameStart := this.gui.AddButton("xs+10 ys+55 w30", "▶️")
        this.boardGameStart.OnEvent("Click", (*) => BoardGame.InfiniteMode.run())

        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
        ; @region > FISHING
        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

        ; Group box.
        this.gui.AddGroupBox("xs Section w200 h90", "Fishing").SetFont("w700")

        ; Image.
        this.FishingImage := this.gui.AddPicture("xs+10 ys+20 w30 h30", GUI_TOOLS_IMAGE_FOLDER "FishingWorld.png")
        UI.TOOLTIP_MAP[this.FishingImage.Hwnd] := { title: "Fishing", text: "This mode automatically fishes for you. To use it, stand in a fishing area and press the start button." }

        ; Start button.
        this.FishingStart := this.gui.AddButton("xs+10 ys+55 w30", "▶️")
        this.FishingStart.OnEvent("Click", (*) => Fishing.useFishingRod())


    }

    static disableOtherCheckbox(ctrl, otherCtrl) {
        if ctrl.Value
            otherCtrl.Value := false
    }

    static selectPetsToEnchant() {
        this.ignoreDeactivate := true
        Hotkey("RButton", (*) => this.OnRightClick())
        Hotkey("RButton", "On")
    }

    static OnRightClick() {
        Roblox.activate()
        MouseGetPos &x, &y
        this.enchantPetList.Add(, x, y)
    }

}