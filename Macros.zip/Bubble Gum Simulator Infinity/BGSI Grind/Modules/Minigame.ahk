#Requires AutoHotkey v2.0

class Minigame {

    ; Move locations.
    static SAFE_CURSOR_POSITION := {x: 790, y: 10}

    ; Max attempts.
    static MAX_USER_TICKET_TRIES := 50
    static MAX_WAIT_FOR_REWARDS := 100
    static MAX_JUMPS_TO_RESTART := 20
    static MAX_CLOSE_ATTEMPTS := 50
    static MAX_WAIT_FOR_TRANSITION_SCREEN := 50

    ; Buttons.
    static MENU_CLOSE_BUTTON := {x: 635, y: 124}
    static USE_TICKET_BUTTON := {x: 325, y: 425}
    static REWARDS_CLAIM_BUTTON := {x: 396, y: 390}
    
    static DIFFICULTY_LIST := [
        Map("name", "Easy",   "x", 248, "y", 416),
        Map("name", "Medium", "x", 389, "y", 416),
        Map("name", "Hard",   "x", 248, "y", 456),
        Map("name", "Insane", "x", 389, "y", 456)
    ]

    ; Pixel searches.
    static INSANE_BUTTON_SEARCH := [322, 441, 456, 474, "0xcf72ff", 5]
    static SKIP_BUTTON_SEARCH_PINK := [247, 406, 391, 446, "0xe85dd7", 5]
    static SKIP_BUTTON_SEARCH_RED := [247, 406, 391, 446, "0xe52f49", 5]
    static REWARDS_WINDOW_SEARCH := [344, 340, 455, 442, "0xeb61d9", 5]
    static TRANSITION_SCREEN_SEARCH := [34, 334, 34, 334, "0x101516", 5]

    ; Image searches.
    static MINIGAME_BACKGROUND_IMAGE := A_ScriptDir "\Assets\Images\Minigames\MinigameScreen.bmp"
    static MINIGAME_SEARCH_AREA := {x1: 143, y1: 155, x2: 496, y2: 483}

    static playFromTools() {
        if GuiTools.minigameFarmPetMatch.Value
            PetMatch.playFromMenu()
        else if GuiTools.minigameFarmRobotClaw.Value
            RobotClaw.playFromMenu()
        else if GuiTools.minigameFarmHyperDarts.Value
            HyperDarts.playFromMenu()
    }

    static clickSkipButton() {  
        clickButton(this.USE_TICKET_BUTTON, 200, 1)
    }

    static clickRewardsButton() {
        if PixelSearch(&x, &y, this.REWARDS_WINDOW_SEARCH*)
            clickButton({x: x, y: y}, 200, 1)
    }

    static clickDifficultyButton(difficulty) {
        btn := this.DIFFICULTY_LIST[difficulty]
        clickButton({x: btn["x"], y: btn["y"]}, 100, 1)
    }

    static clickCloseButton() {
        clickButton(this.MENU_CLOSE_BUTTON, 500, 1)
    }

    static hasSuperTicket() {
        Roblox.activate()
        return PixelSearch(&x, &y, this.SKIP_BUTTON_SEARCH_PINK*)        
    }

    static doesNotHaveSuperTicket() {
        Roblox.activate()
        return PixelSearch(&x, &y, this.SKIP_BUTTON_SEARCH_RED*)        
    }

    static isInsaneReady() {
        Roblox.activate()
        return PixelSearch(&x, &y, this.INSANE_BUTTON_SEARCH*)
    }

    static isRewardsWindowDisplayed() {
        Roblox.activate()
        return PixelSearch(&x, &y, this.REWARDS_WINDOW_SEARCH*)           
    }

    static isMinigameWindowOpen() {
        Roblox.activate()
        area := this.MINIGAME_SEARCH_AREA
        image := "*5 " this.MINIGAME_BACKGROUND_IMAGE
        return ImageSearch(&x, &y, area.x1, area.y1, area.x2, area.y2, image)
    }

    static moveCursorToSafePosition() {
        moveLocation(this.SAFE_CURSOR_POSITION, 50)
    }

    static isTransitionScreen() {
        Roblox.activate()
        return PixelSearch(&x, &y, this.TRANSITION_SCREEN_SEARCH*)   
    }

    static waitForTransition(minigame) {
        transitionSuccess := false
        Loop this.MAX_WAIT_FOR_TRANSITION_SCREEN {
            Roblox.setTitle(minigame " | Waiting for Transition (" A_Index ")")
            if this.isTransitionScreen() {
                transitionSuccess := true
                break
            }
            Sleep 100
        }

        if !transitionSuccess
            return false

        gameSuccess := false
        Loop this.MAX_WAIT_FOR_TRANSITION_SCREEN {
            Roblox.setTitle(minigame " | Waiting for Game (" A_Index ")")
            if !this.isTransitionScreen() {
                gameSuccess := true
                break
            }
                
            Sleep 100
        }

        return gameSuccess      
    }

    static useTicket(minigame, difficulty := 4) {
        Roblox.activate()
        Loop this.MAX_USER_TICKET_TRIES {
            Roblox.setTitle(minigame " | Purchasing Game (" A_Index ")")

            this.moveCursorToSafePosition()

            if this.doesNotHaveSuperTicket() {
                this.clickCloseButton()
                return
            }

            if !this.isMinigameWindowOpen()
                break

            if this.isInsaneReady()
                this.clickDifficultyButton(difficulty)

            if this.hasSuperTicket()
                this.clickSkipButton()

            Sleep 50
        }

        if !this.waitForTransition(minigame)
            return false

        this.sendMinigameStartedWebhook(minigame)
        return true
    }

    static claimRewards(minigame) {
        Roblox.setTitle(minigame " | Claiming Rewards")
        Loop this.MAX_WAIT_FOR_REWARDS {
            if this.isRewardsWindowDisplayed() {
                Roblox.Leaderboard.forceClose()
                Sleep 500
                this.sendRewardsWebhook(minigame)
                this.clickRewardsButton()
                break
            }
            Sleep 50
        }
    }

    static closeMenu() {
        Loop this.MAX_CLOSE_ATTEMPTS {
            this.clickCloseButton()
            if !this.isMinigameWindowOpen()
                return
        }
    }

    static restartGame(minigame, jumps := this.MAX_JUMPS_TO_RESTART) {
        Loop jumps {
            Roblox.setTitle(minigame " | Restarting Game (" A_Index "/" this.MAX_JUMPS_TO_RESTART ")")
            if this.isMinigameWindowOpen()
                break
            Keys.send("space", "down")
            Sleep 250
            Keys.send("space", "up")
            Sleep 250
        }
    }

    static moveToMinigame(minigame, path) {
        Roblox.setTitle(minigame " | Moving to Game")
        for step in path
            Movement.move(step[1], step[2])            
    }

    static teleportToMinigame(minigame, island) {
        Roblox.setTitle(minigame " | Teleporting to Island")
        Teleport.teleportTo(island)
        Roblox.activate()
        Roblox.Leaderboard.close()
    }

    static isInStartArea(minigame) {
        if !this.isMinigameWindowOpen() {
            this.restartGame(minigame, 5)
            if !this.isMinigameWindowOpen() {
                MsgBox minigame " | Must must standing in the start area.", MACRO_TITLE, "Icon!"
                return false
            }
        }
        return true
    }

    static sendRewardsWebhook(minigame) {
        if GuiSettings.webhookMinigames.Value
            PersonalWebhook.rewardsWebhook(minigame)
    }

    static sendMinigameStartedWebhook(minigame) {
        if GuiSettings.webhookMinigames.Value
            PersonalWebhook.minigameStartedWebhook(minigame)
    }

}