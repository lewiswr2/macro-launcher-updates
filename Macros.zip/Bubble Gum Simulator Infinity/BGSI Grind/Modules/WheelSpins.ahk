#Requires AutoHotkey v2.0

; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
; @region SPIN TO WIN
; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

class WheelSpins {
    static SPIN_WHEELS := Map()

    ; Configuration constants
    static FREE_SPIN_BUTTON := {x: 528, y: 231}
    static SPIN_BUTTON := {x: 532, y: 483}
    static CLOSE_BUTTON := {x: 591, y: 117}
    static SAFE_CURSOR_LOCATION := {x: 790, y: 10}
    static COOLDOWN := 20
    static MAX_CHECK_WINDOW_OPEN := 50
    static MAX_CHECK_SPIN_AVAILABLE := 20
    static MAX_CLOSE_WINDOW := 20
    
    ; Detection areas
    static WINDOW_PIXEL := [180, 120, 185, 125, "0x1badec", 2]
    static FREE_SPIN_AREA := [453, 217, 630, 250, "0xd73fc5"]
    static ZERO_TICKETS_AREA := [534, 472, 550, 492, "0xae7526"]
    
    ; State tracking
    static TIMER := 0

    static init() {
        this.SPIN_WHEELS := Map(
            "Wheel", {
                key: "Wheel",
                name: "Wheel Spin",
                world: "1-1",
                path: [
                    ["aw", 100],
                    ["a", 800]
                ],
                spin: GuiActions.useWheelSpinCheckbox.Value,
            },
            /*
            "Ancient", {
                key: "Ancient",
                name: "Ancient Wheel",
                world: "1-0",
                path: [["sd", 450], ["s", 2600], ["as", 900], ["", 2000], ["d", 6400], ["", 2000], ["a", 2700], ["aw", 1000]],
                spin: GuiActions.useAncientSpinCheckbox.Value,
            },
            */
        )
    }


    ; Check if the wheel window is open
    static isWindowOpen() {
        Roblox.activate()
        return PixelSearch(&x, &y, this.WINDOW_PIXEL*)
    }

    ; Check if free spin is available
    static isFreeSpinAvailable() {
        Roblox.activate()
        return PixelSearch(&x, &y, this.FREE_SPIN_AREA*)
    }

    ; Check if no tickets are available for spin
    static noTicketsAvailable() {
        Roblox.activate()
        return PixelSearch(&x, &y, this.ZERO_TICKETS_AREA*)
    }

    ; Navigate to the wheel location
    static goToWheel(data) {

        Teleport.teleportTo(data.world)
        Roblox.Leaderboard.close()  

        Movement.movePath(data.path)

        Loop this.MAX_CHECK_WINDOW_OPEN {
            Roblox.setTitle(data.name " | Waiting For Window (" A_Index "/" this.MAX_CHECK_WINDOW_OPEN ")")
            if this.isWindowOpen()
                return true
            Sleep 50
        }
        return true
    }

    ; Claim free spin if available
    static claimSpin(data) {

        if !this.goToWheel(data)
            return false
        
        Sleep 1000
        moveLocation(this.SAFE_CURSOR_LOCATION, 50)

        if !this.isFreeSpinAvailable()
            return false

        Loop this.MAX_CHECK_SPIN_AVAILABLE {
            Roblox.setTitle(data.name " | Claiming Free Spin (" A_Index "/" this.MAX_CHECK_SPIN_AVAILABLE ")")
            if !this.isFreeSpinAvailable()
                break
            clickButton(this.FREE_SPIN_BUTTON, 50, 5)
            moveLocation(this.SAFE_CURSOR_LOCATION, 50)
            Sleep 50
        }
    }

    ; Use available spin ticket
    static useSpin(data) {
        if data.spin && !this.noTicketsAvailable()
            clickButton(this.SPIN_BUTTON, 100, 2)
    }

    static close(data) {
        Loop this.MAX_CLOSE_WINDOW {
            Roblox.setTitle(data.name " | Closing Window (" A_Index "/" this.MAX_CLOSE_WINDOW ")")
            if !this.isWindowOpen()
                return true
            clickButton(this.CLOSE_BUTTON, 50, 2)
            Sleep 50
        }
        return false
    }

    class Wheel {
        static run() {
            data := WheelSpins.SPIN_WHEELS["Wheel"]
            Roblox.setTitle(data.name " | Claiming Free Spin")
            WheelSpins.claimSpin(data)
            WheelSpins.useSpin(data)
            WheelSpins.close(data)
            Roblox.setTitle()            
        }
    }

    /*
    class Ancient {
        static run() {
            Roblox.setTitle("Ancient Wheel | Claiming Free Spin")
            WheelSpins.claimSpin("Ancient")
            WheelSpins.useSpin("Ancient")
            WheelSpins.close()
            Roblox.setTitle()            
        }
    }
    */
}
