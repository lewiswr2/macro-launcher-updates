#Requires AutoHotkey v2.0

class Chests {
    static VIP_CHEST_MULTIPLIER := 0.85
    static MAP_COLLECT_BUTTON_AREA := [170, 250, 551, 525, "0xe251d0", 5]

    static PROPERTIES := Map(
        "Infinity", {
            island: "1-0",
            world: 1,
            path: [["sd", 550], ["s", 5200], ["as", 600]],
            baseCooldown: 40,
            cooldown: 40,
            timer: 0,
            fromMap: true
        },
        "Giant", {
            island: "1-1",
            world: 1,
            path: [["s", 550], ["as", 750], ["a", 200]],
            baseCooldown: 15,
            cooldown: 15,
            timer: 0,
            fromMap: true
        },
        "Void", {
            island: "1-4",
            world: 1,
            path: [["sd", 850], ["d", 450], ["sd", 850], ["d", 450], ["sd", 850], ["d", 300], ["sd", 150]],
            baseCooldown: 40,
            cooldown: 40,
            timer: 0,
            fromMap: true
        },
        "Ticket", {
            island: "2-1",
            world: 2,
            path: [["w", 550], ["a", 1000]],
            baseCooldown: 40,
            cooldown: 40,
            timer: 0,
            fromMap: true
        }        
    )

    static open(name) {
        chest := this.PROPERTIES[name]
        Roblox.setTitle(name " Chest")
        Farming.selectTeam(chest.world)
        if chest.fromMap && hasGiantChestsBuff() {
            Roblox.setTitle(name " Chest | Claiming From Map")
            Teleport.openMenu()
            Teleport.findAndClick(chest.island)
            Sleep 1000
            this.clickCollectButton()
            Teleport.closeMenu()
        } else {
            Roblox.setTitle(name " Chest | Teleporting to Island")
            Teleport.teleportTo(chest.island)
            Roblox.Leaderboard.close()
            Roblox.setTitle(name " Chest | Moving to Chest")
            for _, step in chest.path
                Movement.move(step[1], step[2])
            Roblox.setTitle(name " Chest | Claiming Chest")
            Loop 5 {
                Keys.send("e")
                Sleep 10
            }
        }
        Roblox.setTitle()
    }

    static clickCollectButton() {
        if !PixelSearch(&x, &y, this.MAP_COLLECT_BUTTON_AREA*)
            return false
        
        Sleep 1000
        if PixelSearch(&x, &y, this.MAP_COLLECT_BUTTON_AREA*)
            clickButton({x: x, y: y}, 50, 5)
        
    }

    static getVipCooldownMultiplier() {
        return GuiSettings.vipGamepassCheckbox.Value ? this.VIP_CHEST_MULTIPLIER : 1
    }

    static setVipCooldownMultiplier() {
        multiplier := this.getVipCooldownMultiplier()
        for _, chest in this.PROPERTIES
            chest.cooldown := chest.baseCooldown * multiplier
    }
}
