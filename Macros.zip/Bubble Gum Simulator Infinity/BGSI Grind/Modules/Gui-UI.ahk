#Requires AutoHotkey v2.0

OnMessage(0x200, ObjBindMethod(UI, "WatchHover"))

class UI {

    static UI_BACKCOLOUR := "0x0a0e14"
    static UI_FONT_COLOUR := "FFFFFF"

    static TOOLTIP_MAP := Map()
    static TOOLTIP_GUI := ""
    static LAST_TOOLTIP_HWND := 0

    static WatchHover(wParam, lParam, msg, hwnd) {
        MouseGetPos ,, &win, &ctrlHwnd, 2

        if (ctrlHwnd != this.LAST_TOOLTIP_HWND) {
            this.LAST_TOOLTIP_HWND := ctrlHwnd
            ToolTip()  ; Clear default tooltip
            this.HideTooltip()

            if this.TOOLTIP_MAP.Has(ctrlHwnd) {
                ctrl := GuiCtrlFromHwnd(ctrlHwnd)
                if IsSet(ctrl) && ctrl.Visible {
                    CoordMode "Mouse", "Screen"
                    MouseGetPos &x, &y, , , 1 
                    CoordMode "Mouse", "Client"
                    tip := this.TOOLTIP_MAP[ctrlHwnd]
                    this.ShowTooltip(tip.title, tip.text, x + 10, y - 20)
                }
            }
        }
    }

    static ShowTooltip(title, text, x, y) {
        try this.TOOLTIP_GUI.Destroy()

        this.TOOLTIP_GUI := Gui("+ToolWindow -Caption +Border +Owner", "WrappedTooltip")
        this.TOOLTIP_GUI.BackColor := "161b22"
        this.TOOLTIP_GUI.SetFont("s9 cFFFFFF", "Segoe UI")

        titleCtrl := this.TOOLTIP_GUI.Add("Text", "w250", title)
        titleCtrl.SetFont("bold")

        this.TOOLTIP_GUI.Add("Text", "w250", text)

        this.TOOLTIP_GUI.Show("x" x " y" y " NoActivate")
    }

    static HideTooltip() {
        try this.TOOLTIP_GUI.Destroy()
    }

    static restrictEdit(ctrl, allowedChars) {
        maxLen := 6
        text := StrUpper(ctrl.Value) ; Force uppercase
        filtered := ""

        for char in StrSplit(text)
            if InStr(allowedChars, char)
                filtered .= char

        if StrLen(filtered) > maxLen
            filtered := SubStr(filtered, 1, maxLen)

        if (text != filtered) {
            ctrl.Value := filtered
            SendMessage(0xB1, StrLen(filtered), StrLen(filtered), ctrl.Hwnd) ; Move caret to end
        }
    }



}