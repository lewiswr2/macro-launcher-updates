#Requires AutoHotkey v2.0

; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
; @region EVENT
; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

class Event {

    ; Search areas.
    static ICON_AREA := {x1: 195, y1: 335, x2: 350, y2: 433}

    ; Search images.
    static EVENT_ICON := A_ScriptDir "\Assets\UI\EventIcon.bmp"
    static DOG_ICON := [229, 109, 360, 404, "0x853011"]

    ; Max attempts.
    static MAX_OPEN_WINDOW := 50

    ; Buttons.
    static CLOSE_BUTTON := {x: 607, y: 62}

    static PATH := [["as", 4000], ["s", 250], ["as", 4200], ["s", 1100], ["as", 900]]

    static openWindow() {
        maxLoops := 3
        Loop maxLoops {
            Roblox.setTitle("Travelling to Festival Pass (" A_Index "/" maxLoops ")")
            Teleport.teleportTo("1-0")
            Roblox.Leaderboard.close()

            for _, step in this.PATH
                Movement.move(step[1], step[2])

            Bubble.closeBubbleFullWindow()
            Roblox.Leaderboard.close()

            if this.isWindowOpen()
                break
        }
    }

/*
    static openWindow() {
        Bubble.closeBubbleFullWindow()
        Roblox.Leaderboard.close()

        if this.isWindowOpen()
            return

        a := this.ICON_AREA
        image := "*5 " this.EVENT_ICON

        Loop this.MAX_OPEN_WINDOW {
            if this.isWindowOpen()
                return            
            if ImageSearch(&x, &y, a.x1, a.y1, a.x2, a.y2, image)
                clickButton({x: x, y: y}, 100)
            Sleep 100
        }
    }
*/
    static isWindowOpen() {
        Roblox.activate()
        return PixelSearch(&x, &y, this.DOG_ICON*)
    }

    static close() {
        clickButton(this.CLOSE_BUTTON, 1000)  
        Roblox.Leaderboard.close() 
    }

    class Challenges {

        ; Buttons.
        static CHALLENGES_TAB_BUTTON := {x: 230, y: 124} 
        

        ; Pixel searches.
        static CHALLENGE_COMPLETED_COLOUR := "0x00ff00"

        ; Max attempts.
        static MAX_SELECT_TAB := 10
        static MAX_INCREASE_SCALE_TIMES := 39

        static PROGRESS_BAR_WIDTH := 149
        static CURRENT_EGG := ""

            static SAFE_CURSOR_LOCATION := {x: 178, y: 365}        
            static RESET_PASS_BUTTON := [291, 10, 393, 47, "0xcf71ff", 5]
            static MAX_RESET_CHECKS := 50

        static CHALLENGE_BOXES := Map(
            1, {
                OCR_AREA: {x: 48, y: 219, w: 155, h: 20},
                BOX_AREA: {x1: 44, y1: 219, x2: 158, y2: 281},
                PROGRESS_BAR: [56, 250, 205, 246, "0x0f3b6d", 2],  
            },
            2, {
                OCR_AREA: { x: 48, y: 287, w: 155, h: 20},
                BOX_AREA: {x1: 44, y1: 287, x2: 158, y2: 350},  
                PROGRESS_BAR: [56, 319, 205, 316, "0x0f3b6d", 2],
            },
            3, {
                OCR_AREA: {x: 48, y: 357, w: 155, h: 20},
                BOX_AREA: {x1: 44, y1: 357, x2: 158, y2: 419},
                PROGRESS_BAR: [56, 388, 205, 385, "0x0f3b6d", 2],
            },
        )

        static isChallengeContainerVisible() {
            imagePath := "*10 " A_ScriptDir "\Assets\Images\Season\ChallengeBackground.bmp"
            return ImageSearch(&x, &y, 165, 246, 396, 307, imagePath)
        }

        static run(mode) {

            ;Teleport.teleportTo("1-0")

            EventChallenges.setChallenges(mode)

            end := A_TickCount + (mode["duration"] * 60 * 1000)
            GuiModeQueue.modeQueueList.Modify(1, , , end)
            Timers.Mode.reset()

            Loop {
                if this.shouldExit() {
                    this.CURRENT_EGG := ""
                    return
                }

                Event.openWindow()

                Event.Rewards.claim()
                Sleep 1000
                this.resetPass()
                this.getPoints()
                this.getChallenges(mode)
                if GuiSeasonList.seasonChallengeList.GetCount() == 0
                    break
                    
                if A_Index == 1 {
                    this.useBuffs(mode)
                }

                this.doChallenge(mode)
                Sleep 500
            }
        }

        static resetPass() {
            Loop this.MAX_RESET_CHECKS {
                if !PixelSearch(&x, &y, this.RESET_PASS_BUTTON*)
                    break

                clickButton({x: x + 5, y: y}, 100, 1)
                moveLocation(this.SAFE_CURSOR_LOCATION, 100)
            }
        }

        static useBuffs(mode) {
            if !mode["useLucky"] && !mode["useSpeed"] && !mode["useMythic"]
                return false

            Items.open()
            Items.ItemsTab.open()
            if mode["useLucky"] {
                item := "Lucky V"
                Roblox.setTitle(mode["mode"] " | Using " item)
                Items.ItemsTab.useItem(item)
            }
            if mode["useSpeed"] {
                item := "Speed V"
                Roblox.setTitle(mode["mode"] " | Using " item)
                Items.ItemsTab.useItem(item)
            }
            if mode["useMythic"] {
                item := "Mythic V"
                Roblox.setTitle(mode["mode"] " | Using " item)
                Items.ItemsTab.useItem(item)
            }            
            Items.ItemsTab.close()
            Roblox.setTitle()
        }

        static getChallenges(mode) {
            Roblox.activate()
            
            GuiSeasonList.seasonChallengeList.Delete()

            for _, box in this.CHALLENGE_BOXES {
                matchedChallenge := ""
                matchedChallengeName := ""
                matchedAmount := ""
                scale := 1
                index := A_Index

                challengeMatched := false
                amountMatched := false

                if this.isCompleted(box.BOX_AREA)
                    continue

                Loop this.MAX_INCREASE_SCALE_TIMES {

                    text := getOcr(box.OCR_AREA.x, box.OCR_AREA.y, box.OCR_AREA.w, box.OCR_AREA.h, scale)
                    Logs.writeOcrLog("[" index "] (" A_Index "/" this.MAX_INCREASE_SCALE_TIMES ") Raw: " text " | Scale: " scale)
                    
                    trimmed := Trim(text)

                    if !challengeMatched {
                        challengeMatched := this.matchChallenge(trimmed, &matchedChallenge, &matchedChallengeName)
                        if matchedChallengeName = "Hatch Eggs" && A_Index < 20 {
                            challengeMatched := false
                            scale += 1
                            continue
                        }

                        if challengeMatched && !matchedChallenge.needAmount
                            amountMatched := true
                        if challengeMatched
                            Logs.writeOcrLog("[" index "] Matched Challenge: " matchedChallengeName)
                    }

                    text := this.cleanOcrNumbers(text)

                    if !amountMatched {
                        amountMatched := this.matchAmount(text, &matchedAmount)
                    }

                    if challengeMatched && amountMatched
                        break

                    scale += 1
                }

                ; Fallback to 100 if no amount is matched.
                matchedAmount := matchedAmount = "" ? 100 : matchedAmount

                ; Get the progress of the challenge.
                progress := Floor(this.getProgress(box))

                ; Fallback in case no challenge is matched.
                if !matchedChallengeName {
                    GuiSeasonList.seasonChallengeList.Add(, "?" trimmed, matchedAmount, progress, 99, "Infinity")
                    continue
                }

                iconIndex := IL_Add(GuiSeasonList.seasonImageList, matchedChallenge.icon)
                GuiSeasonList.seasonChallengeList.Add("Icon" iconIndex, matchedChallengeName, matchedAmount, progress, matchedChallenge.priority, matchedChallenge.egg, matchedChallenge.type)
                Logs.writeOcrLog("[" index "] Text: " matchedChallengeName " | Progress: " progress "%")
            }

            GuiSeasonList.seasonChallengeList.ModifyCol(4, "Sort")

            Roblox.Leaderboard.close()
            Event.close()
        }

        static getPoints() {
            scale := 1
            Loop 18 {
                ;text := getOcr(270, 172, 120, 50, scale)
                text := getOcr(270, 10, 130, 550, scale)
                text := RegExReplace(text, "[oO]", "0")
                text := RegExReplace(text, "[sS]", "5")
                text := RegExReplace(text, "q", "4")
                if RegExMatch(text, "^-?\d{1,3}(,\d{3})*$|^-?\d+$")
                    break
                scale += 1
            }
            GuiSeasonList.competeStarsTotal.Value := text
        }  

        static matchChallenge(trimmed, &matchedChallenge, &matchedChallengeName) {
            for name, challenge in EventChallenges.EVENT_CHALLENGES {
                if RegExMatch(trimmed, challenge.regex) {
                    matchedChallenge := challenge
                    matchedChallengeName := name
                    return true
                }
            }
            return false
        }    

        static shouldExit() {
            return GuiModeQueue.modeQueueList.GetText(1, 3) = "Ended"
        }

        static matchAmount(text, &matchedAmount) {
            trimmed := Trim(text)
            amount := RegExReplace(trimmed, "\D")
            if amount != "" && amount != 0 {
                matchedAmount := amount
                return true
            }
            return false
        }

        static cleanOcrNumbers(text) {
            text := RegExReplace(text, "i)SOO", "500")
            text := RegExReplace(text, "i)[S5][0O]", "50")
            text := RegExReplace(text, "i)[l1][0O]", "10")
            text := RegExReplace(text, "i)ooo", "000")
            text := RegExReplace(text, "li", "1,")
            text := RegExReplace(text, "A5", "45")
            text := RegExReplace(text, "9S", "95")
            text := RegExReplace(text, Chr(34), "4") ; Replace double quotes.
            return text
        }        

        static getProgress(challenge) {
            progress := 100
            Roblox.activate()
            if PixelSearch(&x, &y, challenge.PROGRESS_BAR*) {
                calc := ((x - challenge.PROGRESS_BAR[1]) / this.PROGRESS_BAR_WIDTH) * 100
                progress := clamp(calc, 0, 100)
            }
            return progress
        }

        static isCompleted(area) {
            Roblox.activate()
            return PixelSearch(&x, &y, area.x1, area.y1, area.x2, area.y2, this.CHALLENGE_COMPLETED_COLOUR, 2)
        }

        static isChallengeComplete() {
            imagePath := "*10 " A_ScriptDir "\Assets\Images\Event\EventBubble.bmp"
            return ImageSearch(&x, &y, 548, 313, 703, 434, imagePath)
        }

        static doChallenge(mode) {

            type := GuiSeasonList.seasonChallengeList.GetText(1, 6)

            switch type {
                case "Hatch":
                    this.doHatchChallenge(mode)
                case "Coins":
                    this.doCoinsChallenge(mode)
                case "Bubbles":
                    this.doBubbleChallenge(mode)
                default:
            }
       
        }

        static doCoinsChallenge(mode) {

            Roblox.setTitle(mode["mode"] " | Teleporting to Island")
            Teleport.teleportTo("1-5")
            Farming.selectTeam(1)

            maxTime := A_TickCount + (mode["hatchTime"] * 60000)
            lastTitleUpdate := 0

            Loop {
                Roblox.setTitle(mode["mode"] " | Running Path (" A_Index ")")
                Roblox.activate()
                Roblox.Leaderboard.close()

                for step in Farming.Gems.PATH {

                    Movement.move(step[1], step[2])

                    ; Update title only once per second
                    if (A_TickCount - lastTitleUpdate >= 1000) {
                        remaining := Ceil((maxTime - A_TickCount) / 1000)
                        Roblox.setTitle(mode["mode"] " | Farming Coins (" remaining "s)")
                        lastTitleUpdate := A_TickCount
                    }

                    ; Check for challenge completion
                    if this.isChallengeComplete() {
                        Roblox.setTitle(mode["mode"] " | Completed a Challenge")
                        break 2
                    }

                    ; Check for timeout
                    if A_TickCount > maxTime {
                        Roblox.setTitle(mode["mode"] " | Timer Expired")
                        break 2
                    }  

                }

                Roblox.setTitle(mode["mode"] " | Teleporting to Island")
                Teleport.teleportTo("1-5")                    
            }
            Roblox.setTitle()

        }

        static doBubbleChallenge(mode) {
            currency := BubbleGum.PROPERTIES["Coins"]
            Teleport.teleportTo(currency.island)
            Farming.selectTeam(1)
            
            Roblox.activate()
            Roblox.Leaderboard.close()

            for _, step in currency.path
                Movement.move(step[1], step[2])            

            maxTime := A_TickCount + (mode["hatchTime"] * 60000)
            lastTitleUpdate := 0
            Loop {

                Mouse.holdLeftMouse()

                ; Check for challenge completion
                if this.isChallengeComplete() {
                    Roblox.setTitle(mode["mode"] " | Completed a Challenge")
                    break
                }

                ; Check for timeout
                if A_TickCount > maxTime {
                    Roblox.setTitle(mode["mode"] " | Timer Expired")
                    break
                }

                ; Update title only once per second
                if (A_TickCount - lastTitleUpdate >= 1000) {
                    remaining := Ceil((maxTime - A_TickCount) / 1000)
                    Roblox.setTitle(mode["mode"] " | Blowing Bubbles (" remaining "s)")
                    lastTitleUpdate := A_TickCount
                }

                Sleep 10

            }
            Roblox.setTitle()
            Mouse.releaseLeftMouse()

        }            

        static doHatchChallenge(mode) {
            egg := GuiSeasonList.seasonChallengeList.GetText(1, 5)

            ;if egg != this.CURRENT_EGG || !Hatching.isAtEgg()
            Hatching.moveToEgg(egg)
            
            Bubble.closeBubbleFullWindow()
            Roblox.setTitle(mode["mode"] " | Hatching Egg: " egg "")

            maxTime := A_TickCount + (mode["hatchTime"] * 60000)
            lastTitleUpdate := 0

            Loop {
                ; Send interaction
                Send "{e}"

                ; Check for challenge completion
                if this.isChallengeComplete() {
                    Roblox.setTitle(mode["mode"] " | Completed a Challenge")
                    break
                }

                ; Check for timeout
                if A_TickCount > maxTime {
                    Roblox.setTitle(mode["mode"] " | Hatching Timer Expired")
                    break
                }

                ; Update title only once per second
                if (A_TickCount - lastTitleUpdate >= 1000) {
                    remaining := Ceil((maxTime - A_TickCount) / 1000)
                    Roblox.setTitle(mode["mode"] " | Hatching Egg: " egg " (" remaining "s)")
                    lastTitleUpdate := A_TickCount
                }

                Sleep 10
            }

            ; Finish hatching animations
            Loop 10 {
                if Teleport.isMainGameVisible()
                    break
                Sleep 1000
            }

            ;this.CURRENT_EGG := egg
        }    

    }

    class Rewards {
        static SAFE_CURSOR_LOCATION := {x: 178, y: 365}        
        static CLAIM_AREA := [381, 10, 537, 577, "0x7ff312", 5]
        static MAX_CLAIM_CHECKS := 50

        static claim() {
            Loop this.MAX_CLAIM_CHECKS {
                if !PixelSearch(&x, &y, this.CLAIM_AREA*)
                    break

                clickButton({x: x + 5, y: y}, 100, 1)
                moveLocation(this.SAFE_CURSOR_LOCATION, 100)
            }
        }
    
    }

}

class EventChallenges {
    static setChallenges(mode) {
        this.EVENT_CHALLENGES := Map(
            "Play Minutes", {
                regex: "i)play",
                priority: 99,
                egg: "",
                type: "Play",
                icon: GUI_SEASON_ICON_FOLDER "Timer_Icon.ico",
                needAmount: false
            },
            "Hatch Spotted Eggs", {
                regex: "i)spot",
                priority: 1,
                egg: "Spotted",
                type: "Hatch",
                icon: GUI_MODE_ICON_FOLDER "Spotted_Egg.ico",
                needAmount: true
            },
            "Hatch Common Eggs", {
                regex: "i)com",
                priority: 1,
                egg: "Common",
                type: "Hatch",
                icon: GUI_MODE_ICON_FOLDER "Common_Egg.ico",
                needAmount: true
            },            
            "Hatch Iceshard Eggs", {
                regex: "i)icesh",
                priority: 1,
                egg: "Iceshard",
                type: "Hatch",
                icon: GUI_MODE_ICON_FOLDER "Iceshard_Egg.ico",
                needAmount: true
            },
            "Hatch Spikey Eggs", {
                regex: "i)spik",
                priority: 1,
                egg: "Spikey",
                type: "Hatch",
                icon: GUI_MODE_ICON_FOLDER "Spikey_Egg.ico",
                needAmount: true
            },
            "Hatch Magma Eggs", {
                regex: "i)mag",
                priority: 1,
                egg: "Magma",
                type: "Hatch",
                icon: GUI_MODE_ICON_FOLDER "Magma_Egg.ico",
                needAmount: true
            },
            "Hatch Crystal Eggs", {
                regex: "i)cry",
                priority: 1,
                egg: "Crystal",
                type: "Hatch",
                icon: GUI_MODE_ICON_FOLDER "Crystal_Egg.ico",
                needAmount: true
            },
            "Hatch Lunar Eggs", {
                regex: "i)lun",
                priority: 1,
                egg: "Lunar",
                type: "Hatch",
                icon: GUI_MODE_ICON_FOLDER "Lunar_Egg.ico",
                needAmount: true
            },
            "Hatch Void Eggs", {
                regex: "i)void",
                priority: 1,
                egg: "Void",
                type: "Hatch",
                icon: GUI_MODE_ICON_FOLDER "Void_Egg.ico",
                needAmount: true
            },
            "Hatch Hell Eggs", {
                regex: "i)hell",
                priority: 1,
                egg: "Hell",
                type: "Hatch",
                icon: GUI_MODE_ICON_FOLDER "Hell_Egg.ico",
                needAmount: true
            },
            "Hatch Nightmare Eggs", {
                regex: "i)night",
                priority: 1,
                egg: "Nightmare",
                type: "Hatch",
                icon: GUI_MODE_ICON_FOLDER "Nightmare_Egg.ico",
                needAmount: true
            },
            "Hatch Rainbow Eggs", {
                regex: "i)rain",
                priority: 1,
                egg: "Rainbow",
                type: "Hatch",
                icon: GUI_MODE_ICON_FOLDER "Rainbow_Egg.ico",
                needAmount: true
            },
            "Hatch Showman Eggs", {
                regex: "i)ow",
                priority: 1,
                egg: "Showman",
                type: "Hatch",
                icon: GUI_MODE_ICON_FOLDER "Showman_Egg.ico",
                needAmount: true
            },
            "Hatch Mining Eggs", {
                regex: "i)mining",
                priority: 1,
                egg: "Mining",
                type: "Hatch",
                icon: GUI_MODE_ICON_FOLDER "Mining_Egg.ico",
                needAmount: true
            },
            "Hatch Cyber Eggs", {
                regex: "i)cyb",
                priority: 1,
                egg: "Cyber",
                type: "Hatch",
                icon: GUI_MODE_ICON_FOLDER "Cyber_Egg.ico",
                needAmount: true
            },
            "Hatch Neon Eggs", {
                regex: "i)(neo|nep)",
                priority: 1,
                egg: "Neon",
                type: "Hatch",
                icon: GUI_MODE_ICON_FOLDER "Neon_Egg.ico",
                needAmount: true
            },
            "Hatch Eggs", {
                regex: "i)^(?!.*(myth|leg|unique|shiny|epic|rare|comm|spot|icesh|spik|mag|cry|lun|void|hell|night|rain|show|ow|mining|cyb|neo|nep)).*hatch.*egg",
                priority: 20,
                egg: "Infinity",
                type: "Hatch",
                icon: GUI_SEASON_ICON_FOLDER "Eggs_Icon.ico",
                needAmount: true
            },
            "Collect Coins", {
                regex: "i)coins",
                priority: 98,
                egg: "",
                type: "Coins",
                icon: GUI_SEASON_ICON_FOLDER "Coins_Icon.ico",
                needAmount: false
            },
            "Blow Bubbles", {
                regex: "i)(blow|ubb)",
                priority: 98,
                egg: "",
                type: "Bubbles",
                icon: GUI_SEASON_ICON_FOLDER "Bubble_Gum_Icon.ico",
                needAmount: false
            },                            
        )
    }
}