#Requires AutoHotkey v2.0

OnMessage(0x201, ObjBindMethod(GuiHatch, "handleMouseDown"))
OnMessage(0x0006, ObjBindMethod(GuiHatch, "handleDeactivate"))

class GuiHatch {

    static gui := ""

    static FIRST_COLUMN_X := 10
    static SECOND_COLUMN_X := 220
    static TOP_Y := 10

    static show() {
        this.gui.Show("AutoSize")
        mainGui.GetPos(&x, &y, &w, &h)
        this.gui.Move(x + 6, y + h - 8)  
    }

    static handleMouseDown(wParam, lParam, msg, hwnd) {
        if (this.gui && hwnd = this.gui.Hwnd && WinActive("ahk_id " hwnd)) {
            PostMessage 0xA1, 2,,, "ahk_id " hwnd  ; WM_NCLBUTTONDOWN, HTCAPTION
        }
    }

    static handleDeactivate(wParam, lParam, msg, hwnd) {
        if (wParam = 0 && this.gui && hwnd = this.gui.Hwnd) {
            this.gui.Hide()
        }
    }

    static create() {
        this.gui := Gui("-Caption +Border")
        this.gui.SetFont("s8 c" UI.UI_FONT_COLOUR, "Segoe UI Light")
        this.gui.BackColor := UI.UI_BACKCOLOUR

        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
        ; @region HATCHING
        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

        ; Egg group.
        this.gui.AddGroupBox("x" GuiHatch.FIRST_COLUMN_X " y" GuiHatch.TOP_Y " Section w200 h200", "Hatch Eggs").SetFont("w700")

        this.eggImage := this.gui.AddPicture("xs+10 yp+20 w30 h30", GUI_EGG_IMAGE_FOLDER "Eggs.png")
        UI.TOOLTIP_MAP[this.eggImage.Hwnd] := { title: "Hatch Eggs", text: "This section allows Hatch modes to be added to the Mode Queue. Multiple eggs with different configurations can be queued.`n`nNote: This feature is currently available to VIP users only." }   

        info := this.gui.AddText("x+10 w55", "Hatch Egg")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Hatch Egg", text: "Select the egg to hatch." }    
        this.hatchingEggDropdown := this.gui.AddDropDownList("x+10 yp-3 w75")
        allEggs := []
        for eggName, eggData in Hatching.EggProperties {
            if eggData.active
                allEggs.Push(eggName)
        }
        this.hatchingEggDropdown.Add(allEggs)    
        this.hatchingEggDropdown.Value := 1

        info := this.gui.AddText("xs+50 yp+25 w55", "Duration")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Duration", text: "Select how long the egg should be hatched for. A 20-minute duration is recommended when using automated boosts." }
        this.hatchingCooldownDropdown := this.gui.AddDropDownList("x+10 yp-3 w75", [5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60])
        this.hatchingCooldownDropdown.Value := 6

        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
        ; @region Boosts
        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

        this.hatchingBoostsSelectAllCheckbox := this.gui.AddCheckbox("xs+50 yp+30 w20 h20 Check3", "")
        info := this.gui.AddText("x+0 yp+3 w70", "Potions")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Potions", text: "Check or uncheck all options for using potions." }
        info.SetFont("", "Segoe UI Semibold")

        this.gui.Add("Text", "xs+50 yp+20 w140 h1 BackgroundGray")

        this.hatchingLuckyCheckbox := this.gui.AddCheckbox("xs+50 yp+5 w20 h20", "")
        info := this.gui.AddText("x+0 yp+3 w100", "Use Lucky V Potion")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Use Lucky V Potion", text: "Automatically uses a Lucky Potion before beginning to hatch the egg." }

        this.hatchingSpeedCheckbox := this.gui.AddCheckbox("xs+50 yp+15 w20 h20", "")
        info := this.gui.AddText("x+0 yp+3 w100", "Use Speed V Potion")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Use Speed V Potion", text: "Automatically uses a Speed Potion before beginning to hatch the egg." }

        this.hatchingMythicCheckbox := this.gui.AddCheckbox("xs+50 yp+15 w20 h20", "")
        info := this.gui.AddText("x+0 yp+3 w100", "Use Mythic V Potion")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Use Mythic V Potion", text: "Automatically uses a Mythic Potion before beginning to hatch the egg." }

        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
        ; @region Team
        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

        this.gui.Add("Text", "xs+50 yp+20 w140 h1 BackgroundGray")

        this.hatchingChangeTeam := this.gui.AddCheckbox("xs+50 yp+10 w20 h20", "")
        info := this.gui.AddText("x+0 yp+3 w60", "Pet Team")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Pet Team", text: "Select which pet team should be used for hatching." }
        this.hatchingPetTeam := this.gui.AddDropDownList("x+10 yp-3 w45", [1, 2, 3, 4, 5])
        this.hatchingPetTeam.Value := 4

        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
        ; @region Start Button
        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

        ; Start button.
        this.hatchAddButton := this.gui.AddButton("xs+10 ys+60 w30", "➕")
        this.hatchAddButton.OnEvent("Click", (*) => Modes.addHatchMode())
    
        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
        ; @region Updates.
        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

        ; Update checkboxes.
        hatchSelect := this.hatchingBoostsSelectAllCheckbox
        hatchCheckboxes := [this.hatchingLuckyCheckbox, this.hatchingSpeedCheckbox, this.hatchingMythicCheckbox]
        this.hatchingBoostsSelectAllCheckbox.OnEvent("Click", (*) => updateCheckboxes(hatchSelect, hatchCheckboxes))
        for checkbox in hatchCheckboxes
            checkbox.OnEvent("Click", (*) => updateSelectAllCheckbox(hatchSelect, hatchCheckboxes))

        ; Update image.
        this.hatchingEggDropdown.OnEvent("Change", (*) => this.updateEggIcon())




    }

    static hatchingUpdateSelectAllCheckbox() {
        select := this.hatchingBoostsSelectAllCheckbox
        checkboxes := [this.hatchingLuckyCheckbox, this.hatchingSpeedCheckbox, this.hatchingMythicCheckbox]
        updateSelectAllCheckbox(select, checkboxes)
    }

    static updateEggIcon() {
        image := this.hatchingEggDropdown.Text = "" ? "Eggs.png" : Hatching.EggProperties[this.hatchingEggDropdown.Text].image
        this.eggImage.Value := GUI_EGG_IMAGE_FOLDER image
    }     

}