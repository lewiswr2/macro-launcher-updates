#Requires AutoHotkey v2.0 

class MultiCient {

    static getClients() {
        clients := WinGetList("ahk_exe RobloxPlayerBeta.exe")
        if clients.Length == 0 {
            MsgBox("No Roblox windows found.")
            return false
        }
        return clients
    }


    class Hatch {

        static clients := []

        static run() {
            clients := MultiCient.getClients()

            Loop {
                for client in clients {
                    Roblox.activate(client)
                    Send "{r down}"
                    Sleep 10
                    Send "{r up}"
                }
            }
        }

    }

}