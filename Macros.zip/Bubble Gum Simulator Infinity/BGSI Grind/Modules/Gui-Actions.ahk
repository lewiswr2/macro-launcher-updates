#Requires AutoHotkey v2.0

OnMessage(0x201, ObjBindMethod(GuiActions, "handleMouseDown"))
OnMessage(0x0006, ObjBindMethod(GuiActions, "handleDeactivate"))

class GuiActions {

    static gui := ""

    static FIRST_COLUMN_X := 10
    static SECOND_COLUMN_X := 220
    static TOP_Y := 10

    static show() {
        this.gui.Show("AutoSize")
        mainGui.GetPos(&x, &y, &w, &h)
        this.gui.Move(x + 6, y + h - 8)       
    }

    static handleMouseDown(wParam, lParam, msg, hwnd) {
        if (this.gui && hwnd = this.gui.Hwnd && WinActive("ahk_id " hwnd)) {
            PostMessage 0xA1, 2,,, "ahk_id " hwnd
        }
    }

    static handleDeactivate(wParam, lParam, msg, hwnd) {
        if (wParam = 0 && this.gui && hwnd = this.gui.Hwnd) {
            this.gui.Hide()
        }
    }

    static create() {
        this.gui := Gui("-Caption +Border")
        this.gui.SetFont("s8 c" UI.UI_FONT_COLOUR, "Segoe UI Light")
        this.gui.BackColor := UI.UI_BACKCOLOUR


        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
        ; @region > REWARDS
        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

        this.gui.AddGroupBox("x" GuiActions.FIRST_COLUMN_X " y" GuiActions.TOP_Y " Section w200 h130", "Collect Rewards").SetFont("w700")
        info := this.gui.AddPicture("xs+10 yp+20 w30 h30", GUI_ACTIONS_IMAGE_FOLDER "Playtime.png")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Collect Rewards", text: "Select which chests should be automatically collected when rewards are ready. If the player has at least Level 15 Buffs Mastery, chests will be collected via the map. Otherwise, they will be collected manually from each island." }    

        this.rewardsSelectAllCheckbox := this.gui.AddCheckbox("x+10 w20 h20 Check3", "")
        info := this.gui.AddText("x+0 yp+3 w70", "Rewards")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Rewards", text: "Check or uncheck all options for collecting rewards." }
        info.SetFont("", "Segoe UI Semibold")

        this.gui.Add("Text", "xs+50 yp+20 w140 h1 BackgroundGray")

        this.rewardsPlaytimeCheckbox := this.gui.AddCheckbox("xs+50 yp+5 w20 h20", "")
        info := this.gui.AddText("x+0 yp+3 w100", "Playtime Rewards")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Playtime Rewards", text: "Automatically collects rewards from the Infinity Chest on The Overworld. Requires the VIP gamepass." }
        
        this.rewardsIndexCheckbox := this.gui.AddCheckbox("xs+50 yp+15 w20 h20", "")
        info := this.gui.AddText("x+0 yp+3 w100", "Index Rewards")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Index Rewards", text: "Automatically collects rewards from the Giant Chest on Floating Island." }
        
        this.rewardsSeasonCheckbox := this.gui.AddCheckbox("xs+50 yp+15 w20 h20", "")
        info := this.gui.AddText("x+0 yp+3 w115", "Season Rewards")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Season Rewards", text: "Automatically collects rewards from the Void Chest on The Void." }    

        this.rewardsQuestsCheckbox := this.gui.AddCheckbox("xs+50 yp+15 w20 h20", "")
        
        info := this.gui.AddText("x+0 yp+3 w115", "Quest Prizes")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Quest Prizes", text: "Automatically collects rewards from the Ticket Chest on Dice Island." }   

        ; Checkbox updates.
        rewardsSelect := this.rewardsSelectAllCheckbox
        rewardsCheckboxes := [this.rewardsPlaytimeCheckbox, this.rewardsIndexCheckbox, this.rewardsSeasonCheckbox, this.rewardsQuestsCheckbox]
        rewardsSelect.OnEvent("Click", (*) => updateCheckboxes(rewardsSelect, rewardsCheckboxes))
        for checkbox in rewardsCheckboxes
            checkbox.OnEvent("Click", (*) => updateSelectAllCheckbox(rewardsSelect, rewardsCheckboxes))


        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
        ; @region > CHESTS
        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

        this.gui.AddGroupBox("xs Section w200 h130", "Collect Chest Rewards").SetFont("w700")
        info := this.gui.AddPicture("xs+10 yp+20 w30 h30", GUI_ACTIONS_IMAGE_FOLDER "Chest.png")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Collect Chest Rewards", text: "Select which chests should be automatically collected when rewards are ready. If the player has at least Level 15 Buffs Mastery, chests will be collected via the map. Otherwise, they will be collected manually from each island." }    

        this.chestsSelectAllCheckbox := this.gui.AddCheckbox("x+10 w20 h20 Check3", "")
        info := this.gui.AddText("x+0 yp+3 w70", "Chests")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Chests", text: "Check or uncheck all options for collecting chests." }
        info.SetFont("", "Segoe UI Semibold")

        this.gui.Add("Text", "xs+50 yp+20 w140 h1 BackgroundGray")

        this.chestsInfiniteCheckbox := this.gui.AddCheckbox("xs+50 yp+5 w20 h20", "")
        info := this.gui.AddText("x+0 yp+3 w100", "Infinity Chest")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Infinity Chest", text: "Automatically collects rewards from the Infinity Chest on The Overworld. Requires the VIP gamepass." }
        
        this.chestsGiantCheckbox := this.gui.AddCheckbox("xs+50 yp+15 w20 h20", "")
        info := this.gui.AddText("x+0 yp+3 w100", "Giant Chest")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Giant Chest", text: "Automatically collects rewards from the Giant Chest on Floating Island." }
        
        this.chestsVoidCheckbox := this.gui.AddCheckbox("xs+50 yp+15 w20 h20", "")
        info := this.gui.AddText("x+0 yp+3 w115", "Void Chest")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Void Chest", text: "Automatically collects rewards from the Void Chest on The Void." }    

        this.chestsTicketCheckbox := this.gui.AddCheckbox("xs+50 yp+15 w20 h20", "")
        info := this.gui.AddText("x+0 yp+3 w115", "Ticket Chest")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Ticket Chest", text: "Automatically collects rewards from the Ticket Chest on Dice Island." }   

        ; Update checkboxes.
        chestsSelect := this.chestsSelectAllCheckbox
        chestsCheckboxes := [this.chestsInfiniteCheckbox, this.chestsGiantCheckbox, this.chestsVoidCheckbox, this.chestsTicketCheckbox]
        chestsSelect.OnEvent("Click", (*) => updateCheckboxes(chestsSelect, chestsCheckboxes))
        for checkbox in chestsCheckboxes
            checkbox.OnEvent("Click", (*) => updateSelectAllCheckbox(chestsSelect, chestsCheckboxes))
        
        
        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
        ; @region > BUBBLES
        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

        this.gui.AddGroupBox("xs Section w200 h100", "Sell Bubbles").SetFont("w700")

        info := this.gui.AddPicture("xs+10 yp+20 w30 h30", GUI_ACTIONS_IMAGE_FOLDER "Bubble_Sell_Icon.png")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Sell Bubbles", text: "Automatically convert bubbles into resources at regular intervals based on the selected time." }

        this.sellBubbleGumCheckbox := this.gui.AddCheckbox("x+10 w20 h20", "")
        info := this.gui.AddText("x+0 yp+3 w115", "Sell Bubbles")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Sell Bubbles", text: "Select to automatically sell bubbles." }
        info.SetFont("", "Segoe UI Semibold")
        
        this.gui.Add("Text", "xs+50 yp+20 w140 h1 BackgroundGray")

        info := this.gui.AddText("xs+50 yp+10 w70", "Currency")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Currency", text: "Select which currency to receive when selling bubbles." }   
        this.gumCurrencyDropdown := this.gui.AddDropDownList("x+10 yp-3 w60", ["Coins", "Tickets"])
        this.gumCurrencyDropdown.Value := 1
        
        info := this.gui.AddText("xs+50 yp+25 w70", "Cooldown")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Cooldown", text: "Select how frequently (in minutes) bubbles should be automatically sold." }       
        this.sellGumDropdown := this.gui.AddDropDownList("x+10 yp-3 w60", [0.5, 1, 1.5, 2, 2.5, 3, 3.5, 4, 4.5, 5, 5.5, 6, 6.5, 7, 7.5, 8, 8.5, 9, 9.5, 10])
        this.sellGumDropdown.Value := 10

        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
        ; @region > WHEEL SPINS
        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

        this.gui.AddGroupBox("xs Section w200 h75", "Collect Wheel Spins").SetFont("w700")
        info := this.gui.AddPicture("xs+10 yp+20 w30 h30", GUI_ACTIONS_IMAGE_FOLDER "Wheel_Spin_Icon.png")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Collect Wheel Spins", text: "Select which wheels to collect free spins from and spin automatically." }

        this.spinSelectAllCheckbox := this.gui.AddCheckbox("x+10 w20 h20 Check3", "")
        
        info := this.gui.AddText("x+0 yp+3 w70", "Spinners")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Spinners", text: "Check or uncheck all options for collecting free spins from spinners." }
        info.SetFont("", "Segoe UI Semibold")

        info := this.gui.AddText("x+0 w50 +Right", "Spin")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Cooldown", text: "Set the cooldown duration in minutes for each minigame—this determines how often each one will be played." }
        info.SetFont("", "Segoe UI Semibold")

        this.gui.Add("Text", "xs+50 yp+20 w140 h1 BackgroundGray")

        this.collectWheelCheckbox := this.gui.AddCheckbox("xs+50 yp+5 w20 h20", "")
        info := this.gui.AddText("x+0 yp+3 w105", "Wheel Spin")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Wheel Spin", text: "Automatically collect free spins from the Wheel Spin on Floating Island." }    
        this.useWheelSpinCheckbox := this.gui.AddCheckbox("x+0 yp-3 w20 h20", "")

        /*
        this.collectAncientCheckbox := this.gui.AddCheckbox("xs+50 yp+20 w20 h20", "")
        info := this.gui.AddText("x+0 yp+3 w105", "Ancient Spin")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Ancient Spin", text: "Automatically collect free spins from the Ancient Spin in the event area." }
        this.useAncientSpinCheckbox := this.gui.AddCheckbox("x+0 yp-3 w20 h20", "")    
        */

        ; Update checkboxes.
        wheelsSelect := this.spinSelectAllCheckbox
        ;wheelsCheckboxes := [this.collectWheelCheckbox, this.collectAncientCheckbox]
        wheelsCheckboxes := [this.collectWheelCheckbox]
        wheelsSelect.OnEvent("Click", (*) => updateCheckboxes(wheelsSelect, wheelsCheckboxes))
        for checkbox in wheelsCheckboxes
            checkbox.OnEvent("Click", (*) => updateSelectAllCheckbox(wheelsSelect, wheelsCheckboxes))


        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
        ; @region > SHOPS
        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

        this.gui.AddGroupBox("x" GuiActions.SECOND_COLUMN_X " y" GuiActions.TOP_Y " Section w200 h165", "Purchase From Shops").SetFont("w700")

        info := this.gui.AddPicture("xs+10 yp+20 w30 h30", GUI_SHOPS_IMAGE_FOLDER "Shop.png")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Purchase From Shops", text: "Select which shops to automatically purchase all available items from. After the items have been successfully bought, the cooldown timer for that shop will be detected and automatically updated in the action queue." }    

        this.shopSelectAllCheckbox := this.gui.AddCheckbox("x+10 w20 h20 Check3", "")
        info := this.gui.AddText("x+0 yp+3 w70", "Shops")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Shops", text: "Check or uncheck all options for buying from shops." }
        info.SetFont("", "Segoe UI Semibold")

        info := this.gui.AddText("x+0 w50 +Right", "Reroll")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Reroll", text: "Select which shop will use the reroll feature to refresh and purchase new items." }
        info.SetFont("", "Segoe UI Semibold")

        this.gui.Add("Text", "xs+50 yp+20 w140 h1 BackgroundGray")

        this.alienShopCheckbox := this.gui.AddCheckbox("xs+50 yp+5 w20 h20", "")
        info := this.gui.AddText("x+0 yp+3 w100", "Alien Shop")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Alien Shop", text: "Automatically purchases items from the Alien Shop on Zen island." }
        
        this.blackmarketCheckbox := this.gui.AddCheckbox("xs+50 yp+15 w20 h20", "")
        info := this.gui.AddText("x+0 yp+3 w100", "Blackmarket")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Blackmarket", text: "Automatically purchases items from the Blackmarket on The Void Island. Requires a minimum Pets Mastery level of 9." }
        
        this.diceMarketCheckbox := this.gui.AddCheckbox("xs+50 yp+15 w20 h20", "")
        info := this.gui.AddText("x+0 yp+3 w115", "Dice Merchant")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Dice Merchant", text: "Automatically purchases items from the Dice Merchant on Minigame Paradise surface." }    

        this.travelingMerchantCheckbox := this.gui.AddCheckbox("xs+50 yp+15 w20 h20", "")
        info := this.gui.AddText("x+0 yp+3 w115", "Traveling Merchant")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Traveling Merchant", text: "Automatically purchases items from the Dice Merchant on Minigame Paradise surface." }    

        this.festivalShopCheckbox := this.gui.AddCheckbox("xs+50 yp+15 w20 h20", "")
        info := this.gui.AddText("x+0 yp+3 w115", "Festival Shop")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Festival Shop", text: "Automatically purchases items from the Festival Shop on The Overworld surface." }    

        this.fishingShopCheckbox := this.gui.AddCheckbox("xs+50 yp+15 w20 h20", "")
        info := this.gui.AddText("x+0 yp+3 w115", "Fishing Shop")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Fishing Shop", text: "Automatically purchases items from the Fishing Shop on Seven Seas island." }
        /*
        this.eventShopCheckbox := this.gui.AddCheckbox("xs+50 yp+15 w20 h20", "")
        info := this.gui.AddText("x+0 yp+3 w115", "Event Shop")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Event Shop", text: "Automatically purchases items from the Event Shop in the Beach Festival." }    
        */

        this.rerollAlienShop := this.gui.AddRadio("xs+175 ys+50 w20 h20 Group")
        this.rerollBlackmarket := this.gui.AddRadio("xs+175 ys+68 w20 h20")
        this.rerollDiceMerchant := this.gui.AddRadio("xs+175 ys+86 w20 h20")
        this.rerollTravelingMerchant := this.gui.AddRadio("xs+175 ys+104 w20 h20")
        this.rerollFestivalShop := this.gui.AddRadio("xs+175 ys+122 w20 h20")
        this.rerollFishingShop := this.gui.AddRadio("xs+175 ys+140 w20 h20")
        ;this.rerollEventShop := this.gui.AddRadio("xs+175 ys+122 w20 h20")

        ; Update checkboxes.
        shopsSelect := this.shopSelectAllCheckbox
        shopsCheckboxes := [this.alienShopCheckbox, this.blackmarketCheckbox, this.diceMarketCheckbox, this.travelingMerchantCheckbox, this.festivalShopCheckbox, this.fishingShopCheckbox]
        shopsSelect.OnEvent("Click", (*) => updateCheckboxes(shopsSelect, shopsCheckboxes))
        for checkbox in shopsCheckboxes
            checkbox.OnEvent("Click", (*) => updateSelectAllCheckbox(shopsSelect, shopsCheckboxes))


        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
        ; @region > POTIONS
        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

        this.gui.AddGroupBox("xs Section w200 h80", "Upgrade Potions").SetFont("w700")

        info := this.gui.AddPicture("xs+10 yp+20 w30 h30", GUI_SHOPS_IMAGE_FOLDER "Alchemist_III_Icon.png")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Upgrade Potions", text: "Upgrade all lower-tier potions into their V versions using the Potion Shrine on Zen Island." }        

        this.upgradePotionsCheckbox := this.gui.AddCheckbox("x+10 w20 h20", "")
        info := this.gui.AddText("x+0 yp+3 w115", "Upgrade Potions")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Upgrade Potions", text: "Select to automatically upgrade potions." }
        info.SetFont("", "Segoe UI Semibold")   
        
        this.gui.Add("Text", "xs+50 yp+20 w140 h1 BackgroundGray")
    
        info := this.gui.AddText("xs+50 yp+10 w70", "Cooldown")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Cooldown", text: "Select how frequently (in minutes) potions should be automatically upgraded." }      
        this.upgradePotionsDropdown := this.gui.AddDropDownList("x+10 yp-3 w60", [10, 20, 30, 40, 50, 60])
        this.upgradePotionsDropdown.Value := 3


        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
        ; @region > GAMING
        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

        this.gui.AddGroupBox("xs Section w200 h120", "Play Minigames").SetFont("w700")

        info := this.gui.AddPicture("xs+10 yp+20 w30 h30", GUI_MINIGAMES_IMAGE_FOLDER "Dice_Icon.png")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Play Minigames", text: "Select which minigames should be automatically played, along with their respective cooldown times." }

        this.minigamesSelectAllCheckbox := this.gui.AddCheckbox("x+10 w20 h20 Check3", "")
        info := this.gui.AddText("x+0 yp+3 w60", "Minigames")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Minigames", text: "Check or uncheck all options for playing minigames." }
        info.SetFont("", "Segoe UI Semibold")

        info := this.gui.AddText("x+0 w60 +Right", "Cooldown")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Cooldown", text: "Set the cooldown duration in minutes for each minigame—this determines how often each one will be played." }
        info.SetFont("", "Segoe UI Semibold")

        this.gui.Add("Text", "xs+50 yp+20 w140 h1 BackgroundGray")

        this.petMatchCheckbox := this.gui.AddCheckbox("xs+50 yp+5 w20 h20", "")
        info := this.gui.AddText("x+0 yp+3 w70", "Pet Match")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Pet Match", text: "Automatically play the Pet Match minigame on Dice Island." }    
        this.petMatchCooldownDropdown := this.gui.AddDropDownList("x+10 yp-3 w40", [5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60])    
        this.petMatchCooldownDropdown.Value := 2

        this.robotClawCheckbox := this.gui.AddCheckbox("xs+50 yp+20 w20 h20", "")
        info := this.gui.AddText("x+0 yp+3 w70", "Robot Claw")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Robot Claw", text: "Automatically play the Robot Claw minigame on Robot Factory island." }    
        this.robotClawCooldownDropdown := this.gui.AddDropDownList("x+10 yp-3 w40", [30, 35, 40, 45, 50, 55, 60])    
        this.robotClawCooldownDropdown.Value := 2

        this.hyperDartsCheckbox := this.gui.AddCheckbox("xs+50 yp+20 w20 h20", "") 
        info := this.gui.AddText("x+0 yp+3 w70", "Hyper Darts")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Hyper Darts", text: "Automatically play the Hyper Darts minigame on Hyperwave island." }    
        this.hyperDartsCooldown := this.gui.AddDropDownList("x+10 yp-3 w40", [15, 20, 25, 30, 60])    
        this.hyperDartsCooldown.Value := 1

        ; Update checkboxes.
        minigamesSelect := this.minigamesSelectAllCheckbox
        minigamesCheckboxes := [this.petMatchCheckbox, this.robotClawCheckbox, this.hyperDartsCheckbox]
        minigamesSelect.OnEvent("Click", (*) => updateCheckboxes(minigamesSelect, minigamesCheckboxes))
        for checkbox in minigamesCheckboxes
            checkbox.OnEvent("Click", (*) => updateSelectAllCheckbox(minigamesSelect, minigamesCheckboxes))


        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
        ; @region > RECONNECT
        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

        this.gui.AddGroupBox("xs Section w200 h125", "Schedule Reconnect").SetFont("w700")
        info := this.gui.AddPicture("xs+10 yp+20 w30 h30", GUI_ACTIONS_IMAGE_FOLDER "Roblox_Menu_Icon.png")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Schedule Reconnect", text: "Schedule an automatic reconnect to occur on a timer. Reconnecting helps reduce lag, enforce private server connections, and resolve issues that may arise while running the mode AFK." }

        this.timedReconnectCheckbox := this.gui.AddCheckbox("x+10 w20 h20", "")
        info := this.gui.AddText("x+0 yp+3 w115", "Schedule Reconnect")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Schedule Reconnect", text: "Select to schedule a reconnect." }
        info.SetFont("", "Segoe UI Semibold")
        
        this.gui.Add("Text", "xs+50 yp+20 w140 h1 BackgroundGray")
    
        info := this.gui.AddText("xs+50 yp+10 w70", "Cooldown")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Cooldown", text: "Select how frequently (in minutes) the client should reconnect to the game." }      
        this.timedReconnectCooldownDropdown := this.gui.AddDropDownList("x+10 yp-3 w60", [30, 60, 90, 120, 240, 360, 480])
        this.timedReconnectCooldownDropdown.Value := 2

        info := this.gui.AddText("xs+50 yp+30 w140", "Private Server Link Code")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Private Server Link Code", text: "To get your private server code, first copy your Roblox private server share link (it will look something like https://www.roblox.com/share?code=...). Paste this link into your browser and press Enter. Roblox will redirect you to a new page where the URL now includes privateServerLinkCode=.... The code that appears after this is your actual private server code. Copy just the numbers after privateServerLinkCode= and paste them into the Private Server Link Code field." }    
        this.timedReconnectPrivateLinkCode := this.gui.AddEdit("xs+50 yp+15 w140", "")    

        ; Start button.
        this.reconnectTest := this.gui.AddButton("xs+10 ys+60 w30", "Test")
        this.reconnectTest.OnEvent("Click", (*) => Reconnect.reconnect())

    }

    static chestsUpdateSelectAllCheckbox() {
        select := this.chestsSelectAllCheckbox
        checkboxes := [this.chestsInfiniteCheckbox, this.chestsGiantCheckbox, this.chestsVoidCheckbox, this.chestsTicketCheckbox]
        updateSelectAllCheckbox(select, checkboxes)
    }

}

/*




updateSpinnyOptions() {
    isApplicable := (minigamesMasteryDropdown.Text < 3)
    collectWheelCheckbox.Value := isApplicable
    collectWheelCheckbox.Enabled := isApplicable
}
*/