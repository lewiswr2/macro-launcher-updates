#Requires AutoHotkey v2.0

; #Requires AutoHotkey v2.0

class BoardGame {

    static BOARD_GAME_FOLDER := A_ScriptDir "\Assets\Images\BoardGame\"

    ; Paths.
    static PATH_TO_DOGGYTON := [["w", 2150], ["wa", 1550], ["w", 650]]
    static HATCH_EGG := Map(
        "Game", {
            path: [["d", 500], ["wd", 700]],
        },
        "Cyber", {
            path: [["s", 1700], ["as", 750]],
        },
        "Mining", {
            path: [["s", 2150], ["as", 450]],
        },
        "Showman", {
            path: [["s", 2550], ["as", 150]],
        },
        "Neon", {
            path: [["ds", 350], ["d", 2500], ["", 2000], ["a", 1100]],
        },                             
    )

    ; Pixel searches.
    static DOGGYTON_CHAT_BOX := [204, 65, 597, 134, "0x1ca2e8", 5]
    static CONTINUE_BUTTON := [314, 217, 486, 380, "0x58ed1b", 5]
    static SKIP_BUTTON := [306, 337, 486, 431, "0x6ff116", 5] 

    ; Image searches.
    static SELECT_YOUR_DICE_IMAGE := A_ScriptDir "\Assets\Images\BoardGame\SelectYourDice.bmp"
    static DICE_BAG_IMAGE := A_ScriptDir "\Assets\Images\BoardGame\DiceBag.bmp"
    static AUTO_SIX_SIDED_DIE := A_ScriptDir "\Assets\Images\BoardGame\Auto.bmp"    
    static INFINITY_ELIXIR_IMAGE := A_ScriptDir "\Assets\Images\BoardGame\InfinityElixir.bmp"
    static ROLL_BUTTON := A_ScriptDir "\Assets\Images\BoardGame\Roll_Button.bmp"

    static SELECT_YOUR_DICE_SEARCH_AREA := {x1: 319, y1: 467, x2: 482, y2: 494}

    static DICE_SEARCH_AREA := {x1: 276, y1: 492, x2: 529, y2: 567}
    static BOARD_GAME_OPTIONS := {x1: 276, y1: 492, x2: 582, y2: 567}
    static UPCOMING_TILES := {x1: 58, y1: 54, x2: 740, y2: 116}

    static MAX_DICE_CHECKS := 5

    ; Buttons.
    static DOGGYTON_CHAT_BOX_BUTTON := {x: 322, y: 425}  ; Can be anywhere on the screen.

    ; Max attempts.
    static MAX_DOGGYTON_CLOSE_CLICKS := 10
    static MAX_CONTINUE_GAME_CLICKS := 10
    static MAX_SIX_SIDED_DIE_SEARCHES := 50
    static MAX_INFINITY_ELIXIR_SEARCHES := 1
    static MAX_IMAGE_SEARCHES := 25
    static MAX_WAIT_FOR_CONTINUE_BUTTON := 50

    ; Move locations.
    static SAFE_CURSOR_POSITION := {x: 790, y: 10}    

    static DIE := Map(
        10, {
            image: "ten_sided_die.bmp",
            first: [59, 55, 75, 71, "0x4ddcec", 2],
            upcoming: Map(
                1, {x1:  58, y1: 54, x2: 119, y2: 116},
                2, {x1: 127, y1: 54, x2: 188, y2: 116},
                3, {x1: 196, y1: 54, x2: 257, y2: 116},
                4, {x1: 265, y1: 54, x2: 326, y2: 116},
                5, {x1: 334, y1: 54, x2: 395, y2: 116},
                6, {x1: 403, y1: 54, x2: 464, y2: 116},
                7, {x1: 472, y1: 54, x2: 533, y2: 116},
                8, {x1: 541, y1: 54, x2: 602, y2: 116},
                9, {x1: 610, y1: 54, x2: 671, y2: 116},
                10, {x1: 679, y1: 54, x2: 740, y2: 116}
            ),
        }, 
        6, {
            image: "six_sided_die.bmp",
            first: [197, 55, 213, 71, "0x4ddcec", 2],
            upcoming: Map(
                1, {x1: 196, y1: 54, x2: 257, y2: 116},
                2, {x1: 265, y1: 54, x2: 326, y2: 116},
                3, {x1: 334, y1: 54, x2: 395, y2: 116},
                4, {x1: 403, y1: 54, x2: 464, y2: 116},
                5, {x1: 472, y1: 54, x2: 533, y2: 116},
                6, {x1: 541, y1: 54, x2: 602, y2: 116},
            )
        }, 
        1, {
            image: "One_Sided_Die.bmp",
            first: [368, 55, 387, 71, "0x4ddcec", 2],
        },
    )

    static isMainMenuDisplayed() {
        area := this.DICE_SEARCH_AREA
        image := "*Transff0000 *25 " this.DICE_BAG_IMAGE

        Loop this.MAX_IMAGE_SEARCHES {

            Roblox.activate()
            if GuiTools.gbBlowBubbles.Value
                clickButton(this.SAFE_CURSOR_POSITION, 50)    
            else
                moveLocation(this.SAFE_CURSOR_POSITION, 50)

            if ImageSearch(&x, &y, area.x1, area.y1, area.x2, area.y2, image)
                return true
        }
        return false
    }

    static checkMainMenu() {
        Roblox.activate()
        moveLocation(this.SAFE_CURSOR_POSITION, 50)
        
        area := this.DICE_SEARCH_AREA
        image := "*Transff0000 *25 " this.DICE_BAG_IMAGE
        return ImageSearch(&x, &y, area.x1, area.y1, area.x2, area.y2, image)        
    }

    static isStopButtonVisible() {
        ; Check for the red Stop button in the specified area
        Roblox.activate()
    
        ; Using the exact color with some variation tolerance
        if PixelSearch(&x, &y, 340, 510, 450, 550, "0xDB254B", 15)
            return true
    
        return false
    }

    static isDiceMenuDisplayed() {
        Roblox.activate()
        moveLocation(this.SAFE_CURSOR_POSITION, 50)
        
        image := "*Transff0000 *10 " this.SELECT_YOUR_DICE_IMAGE
        area := this.SELECT_YOUR_DICE_SEARCH_AREA
        return ImageSearch(&x, &y, area.x1, area.y1, area.x2, area.y2, image)
    }

    static openDiceMenu() {
        Loop {
            Roblox.activate()
            moveLocation(this.SAFE_CURSOR_POSITION, 50)

            if this.isMainMenuDisplayed()
                this.clickDiceBagButton()

            if this.isDiceMenuDisplayed()
                return true

            Sleep 100
        }
    }

    static getDieType() {
        local dieTypes := [
            {type: 10, firstTile: [59, 55, 75, 71, "0x4ddcec", 2]},
            {type: 6,  firstTile: [197, 55, 213, 71, "0x4ddcec", 2]},
            {type: 1,  firstTile: [368, 55, 387, 71, "0x4ddcec", 2]},
        ]

        Loop this.MAX_DICE_CHECKS {
            for _, die in dieTypes {
                if PixelSearch(&x, &y, die.firstTile*)
                    return die.type
            }
        }

        return 0
    }

    static selectDie(sides) {
        ; Ensure dice menu is open first
        if !this.isDiceMenuDisplayed() {
            this.openDiceMenu()
        }

        area := this.DICE_SEARCH_AREA
        image := "*Transff0000 *25 " this.BOARD_GAME_FOLDER this.DIE[sides].image
        attempts := 0
        maxAttempts := this.MAX_IMAGE_SEARCHES

        Loop maxAttempts {
            attempts++
            Roblox.activate()
            moveLocation(this.SAFE_CURSOR_POSITION, 50)
            
            ; Check if menu closed unexpectedly
            if !this.isDiceMenuDisplayed() {
                this.openDiceMenu()
            }
            
            if ImageSearch(&x, &y, area.x1, area.y1, area.x2, area.y2, image) {
                moveLocation({x: x, y: y}, 50)
                clickButton({x: x, y: y}, 500, 1)
                Sleep 500  ; Give it time to register
                return true
            }
            Sleep 100
        }

        ; If we couldn't find the die after all attempts, fallback to 10-sided
        if sides != 10 {
            Roblox.setTitle("Board Game | Failed to find " sides "-sided die, using 10-sided instead")
            Sleep 1000
            return this.selectDie(10)
        }

        return false
    }

    static play() {

        Roblox.setTitle("Board Game | Playing Game")

        elixirCount := 0

        ; Enable bubble blowing.
        if GuiTools.gbBlowBubbles.Value {
            Send "{shift down}"
            Send "{l}"
            Send "{shift up}"
        }

        Loop {

            Roblox.setTitle("Board Game | Infinity Elixirs (" elixirCount "/" GuiTools.gbInfinityAmount.Text ")")

            ; If the dice bag is opened, select a die.
            if this.isDiceMenuDisplayed()
                this.selectDie(10)

            currentDie := this.getDieType()
            if currentDie != 10 && currentDie != 0 {
                this.selectDie(10)
            }

            infinityPosition := this.isInfinityElixir()

            if infinityPosition != 0 {
                if infinityPosition <= GuiTools.gbGoldenDiceUseAmount.Text {
                    if !this.selectDie(1) {
                        ; If 1-sided die fails, skip this optimization
                        continue
                    }

                    Loop infinityPosition - 1 {
                        this.clickRollButton()
                        Sleep 500

                        Loop 250 {
                            if this.checkMainMenu()
                                break

                            this.clickSkipButton()
                            Sleep 100
                        }
                    }

                    elixirCount++
                }
                else if infinityPosition < 10 {
                    this.selectDie(6)  ; Will auto-fallback to 10-sided if fails
                }
            }
            this.clickRollButton()
            Sleep 500

            Loop 250 {
                if this.checkMainMenu()
                    break

                this.clickSkipButton()
                Sleep 100
            }

            if GuiTools.gbInfinityAmount.Text == "∞"
                continue

            if elixirCount >= GuiTools.gbInfinityAmount.Text
                break
        }

        if GuiTools.gbDisconnect.Value
            Roblox.leave()

        if GuiTools.gbAlarm.Value {
            Loop {
                SoundBeep(2000, 200)
                Sleep 100
            }
        }

    }

    static findAndClickButton(button, area, item) {
        Roblox.activate()
        Roblox.setTitle("Searching for " item)
        maxLoops := this.MAX_IMAGE_SEARCHES
        Loop maxLoops {
            Roblox.activate()
            moveLocation(this.SAFE_CURSOR_POSITION, 50)
            Roblox.setTitle("Searching for " item " (" A_Index "/" maxLoops ")")
            if ImageSearch(&x, &y, area.x1, area.y1, area.x2, area.y2, "*Transff0000 *15 " button) {
                moveLocation({x: x, y: y}, 50)
                sleep 100
                clickButton({x: x, y: y}, 500, 1)
                Roblox.setTitle()
                return true
            }
            Sleep 100
        }
        return false
    }


    static clickDiceBagButton() {
        this.findAndClickButton(this.DICE_BAG_IMAGE, this.BOARD_GAME_OPTIONS, "dice bag")
    }

    static clickRollButton() {
        if !this.findAndClickButton(this.ROLL_BUTTON, this.BOARD_GAME_OPTIONS, "roll button")
            this.selectDie(10)

    }

    static isInfinityElixir() {
        Roblox.activate()
        Roblox.setTitle("Searching for infinity elixir")
        maxLoops := this.MAX_INFINITY_ELIXIR_SEARCHES
        area := this.UPCOMING_TILES
        die := this.getDieType()

        Loop maxLoops {
            Roblox.setTitle("Searching for infinity elixir (" A_Index "/" maxLoops ")")
            moveLocation(this.SAFE_CURSOR_POSITION, 50)
            if ImageSearch(&x, &y, area.x1, area.y1, area.x2, area.y2, "*Transff0000 *25 " this.INFINITY_ELIXIR_IMAGE) {
                foundTile := 0
                for tileNum, bounds in this.DIE[die].upcoming {
                    if (x >= bounds.x1 && x <= bounds.x2 && y >= bounds.y1 && y <= bounds.y2) {
                        return tileNum
                    }
                }
            }
            Sleep 50
        }
        return 0 
    }

    static playFromMenu() {
        Roblox.activate()

        Roblox.setTitle("Board Game | Teleporting to Island")
        Teleport.teleportTo("2-0")

        Roblox.setTitle("Board Game | Moving to Game")
        Movement.movePath(this.PATH_TO_DOGGYTON)

        doggytonFound := false
        Loop 25 {
            if this.isDoggytonChatBoxDisplayed() {
                doggytonFound := true
                break
            }
            Movement.move("w", 100)
        }

        if !doggytonFound
            return false

        maxAttempts := this.MAX_DOGGYTON_CLOSE_CLICKS
        Loop this.MAX_DOGGYTON_CLOSE_CLICKS {
            Roblox.setTitle("Board Game | Closing Doggyton Chat (" A_Index "/" maxAttempts ")")
            clickButton(this.DOGGYTON_CHAT_BOX_BUTTON, 200, 4)       
            if !this.isDoggytonChatBoxDisplayed()
                break
            Sleep 100
        }

        maxAttempts := this.MAX_WAIT_FOR_CONTINUE_BUTTON
        Loop maxAttempts {
            Roblox.setTitle("Board Game | Waiting for Continue Button (" A_Index "/" maxAttempts ")")
            if this.isContinueButtonDisplayed()
                break
            Sleep 100
        }

        ; Farm Game Egg.
        if GuiTools.gbFarmEgg.Value {
            eggName := GuiTools.gbEggToHatch.Text

            Roblox.setTitle("Board Game | Moving to " eggName " Egg")
            Movement.movePath(this.HATCH_EGG[eggName].path)
            Roblox.setTitle("Board Game | Opening " eggName " Egg")
            Sleep 500
            Keys.send("r")
            Sleep 2000
        }

        maxAttempts := this.MAX_CONTINUE_GAME_CLICKS
        Loop maxAttempts {
            roblox.activate()
            Roblox.setTitle("Board Game | Continuing Game (" A_Index "/" maxAttempts ")")
            this.clickContinueButton()
            if !this.isContinueButtonDisplayed()
                break
            Sleep 100            
        }

        this.play()

    }

    static clickSkipButton() {
        Roblox.activate()
        if PixelSearch(&x, &y, this.SKIP_BUTTON*)
            clickButton({x: x + 20, y: y}, 100)
    }

    static isDoggytonChatBoxDisplayed() {
        Roblox.activate()
        return PixelSearch(&x, &y, this.DOGGYTON_CHAT_BOX*)
    }

    static isContinueButtonDisplayed() {
        Roblox.activate()
        return PixelSearch(&x, &y, this.CONTINUE_BUTTON*)
    }

    static clickContinueButton() {
        Roblox.activate()
        if PixelSearch(&x, &y, this.CONTINUE_BUTTON*)
            clickButton({x: x + 20, y: y}, 500, 5)
    }

    class InfiniteMode {

        static run() {
            Loop {
                Roblox.activate()
                moveLocation(BoardGame.SAFE_CURSOR_POSITION, 50)
                Send "{e}"
                BoardGame.clickSkipButton()
            }            
        }

    }

}