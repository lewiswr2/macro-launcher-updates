#Requires AutoHotkey v2.0

class HyperDarts {

    ; Minigame settings.
    static GAME_TITLE := "Hyper Darts"
    static GAME_ISLAND := "2-4"
    static PATH := [["a", 150], ["wa", 1000]]  
  
    ; Image searches.
    static IMAGES_MINIGAMES_FOLDER := A_ScriptDir "\Assets\Images\Minigames\HyperDarts"
    static TARGET_SEARCH := {x1: 2, y1: 100, x2: 798, y2: 400}
    static TARGETS := Map(
        "Bomb", this.IMAGES_MINIGAMES_FOLDER "\Bomb.bmp",
        "Mine", this.IMAGES_MINIGAMES_FOLDER "\Mine.bmp",
        "Dart", this.IMAGES_MINIGAMES_FOLDER "\Dart.bmp"
    )

    ; Pixel searches.
    static GAME_INTERFACE_SEARCH := [274, 526, 347, 540, "0x64ef18", 5]
    static BALLOON_COLOURS := [
        "0x007300", "0x8a0a00", "0x979700",
        "0x004199", "0xa1004e", "0xff00ff",
    ]

    ; Max attempts.
    static MAX_GAME_TIME := 2

    static playFromMenu() {
        Roblox.activate()

        if !Minigame.isInStartArea(this.GAME_TITLE)
            return

        Loop {
            if Minigame.useTicket(this.GAME_TITLE, GuiTools.minigameHyperDartsDifficulty.Value) {
                this.shootBalloons()
                Minigame.claimRewards(this.GAME_TITLE)
            }
            Minigame.restartGame(this.GAME_TITLE)
        }
    }

    static play() {
        Minigame.teleportToMinigame(this.GAME_TITLE, this.GAME_ISLAND)
        Minigame.moveToMinigame(this.GAME_TITLE, this.PATH)
        Sleep 1000

        if !Minigame.isMinigameWindowOpen()
            return

        Minigame.useTicket(this.GAME_TITLE)
        this.shootBalloons()
        Roblox.Leaderboard.close() ; Sometimes there is a rogue dart that opens the leaderboard.
        Minigame.claimRewards(this.GAME_TITLE)
        Bubble.closeBubbleFullWindow()
        Roblox.Respawn.resetCharacter()
        ;Camera.turnNinetyDegrees("right")
        ;Camera.turnNinetyDegrees("right")
        ;Camera.setOverhead()
        ;Camera.zoomOut(2000)        
        Roblox.setTitle()        
    }

    static shootBalloons() {
        Roblox.setTitle(this.GAME_TITLE " | Playing Game")
        Roblox.activate()

        area := this.TARGET_SEARCH

        WinGetClientPos(&cx, &cy, &cw, &ch, "ahk_exe RobloxPlayerBeta.exe")
        targetPin := Pin(cx + 1, cy + 100, cx + 799, cy + 400, 0, "b2 cFFFFFF flash0")
        Mouse.holdLeftMouse()

        maxTime := A_TickCount + (this.MAX_GAME_TIME * 60 * 1000)
        Loop {
            Roblox.activate()
            Roblox.setTitle(this.GAME_TITLE " | Shooting Balloons (" A_Index ")")

            if A_TickCount > maxTime
                break

            if Minigame.isRewardsWindowDisplayed()
                break      

            Mouse.holdLeftMouse()

            for name, imagePath in this.TARGETS {
                if ImageSearch(&x, &y, area.x1, area.y1, area.x2, area.y2, "*5 " imagePath) {
                    moveLocation({x: x, y: y - 30}, 500)
                }
            }
            for index, colour in this.BALLOON_COLOURS {
                if PixelSearch(&x, &y, area.x1, area.y1, area.x2, area.y2, colour, 20) {
                    moveLocation({x: x, y: y}, 200)
                    continue
                }
            }
        }

        Mouse.releaseLeftMouse()
        targetPin.destroy()
    }

}

