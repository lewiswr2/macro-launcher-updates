#Requires AutoHotkey v2.0

; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
; @region POTION SHRINE
; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

class PotionShrine {
    static TIMER := 0
    static PATH := [["sd", 1600], ["d", 2200], ["wd", 400]]
    static CRAFT_ALL_BUTTON := {x: 208, y: 472}
    static MAX_CLOSE_ATTEMPTS := 50    
    static CLOSE_BUTTON := {x: 654, y: 115}
    static RECIPES_AREA := [655, 215, 655, 493, "0x9ce0f3"]
    static IS_OPEN_PIXEL := [125, 151, 141, 170, "0xe1f3ff"]
    static SCROLL_LOCATION := {x: 650, y: 218}
    static SCROLL_UPS := 15
    static MAX_SCROLL_DOWNS := 50
    static SCROLLBAR_END_PIXEL := [670, 495, 670, 495, "0xa9e0fa"]
    static ENABLE_CHECKBOX => GuiActions.upgradePotionsCheckbox

    static upgrade() {
        Teleport.teleportTo("1-5")
        Roblox.activate()
        Roblox.Leaderboard.close()
        this.move()

        if !this.isOpen()
            return

        moveLocation(this.SCROLL_LOCATION, 500)
        scrollMouseWheel("Up", this.SCROLL_UPS)

        Loop this.MAX_SCROLL_DOWNS {
            if !PixelSearch(&x, &y, this.RECIPES_AREA*) {
                moveLocation(this.SCROLL_LOCATION, 50)
                scrollMouseWheel("Down")
                Sleep 100
            } else {
                clickButton({x: x, y: y + 20}, 100, 2)
                clickButton(this.CRAFT_ALL_BUTTON, 200, 2)
            }
            if this.atEnd()
                break
        }

    }

    static close() {
        Roblox.Leaderboard.close()
        Loop this.MAX_CLOSE_ATTEMPTS {
            clickButton(this.CLOSE_BUTTON, 500, 2)
            if !this.isOpen()
                return true
        }
        return false
    }

    static move() {
        for step in this.PATH
            Movement.move(step[1], step[2])        
    }

    static isOpen() {
        Roblox.activate()
        return PixelSearch(&x, &y, this.IS_OPEN_PIXEL*)
    }

    static atEnd() {
        Roblox.activate()
        return PixelSearch(&x, &y, this.SCROLLBAR_END_PIXEL*)
    }

    static getTimer() {
        return this.TIMER
    }

    static setTimerFromMinutes(minutes) {
        this.TIMER := A_TickCount + (minutes * 60 * 1000)
    }

    static getTimeLeftMs() {
        return Max(this.TIMER - A_TickCount, 0)
    }

    static getTimeLeftFormatted() {
        ms := this.getTimeLeftMs()
        secs := Floor(ms / 1000)
        mins := Floor(secs / 60)
        secs := Mod(secs, 60)
        return Format("{:2}:{:02}", mins, secs)
    }

    static runIfReady() {      
        if !this.ENABLE_CHECKBOX.Value || A_TickCount <= this.TIMER
            return

        Roblox.setTitle("Upgrading potions")
        this.upgrade()
        
        this.close()
        Roblox.setTitle()
        this.setTimerFromMinutes(GuiActions.upgradePotionsDropdown.Text)
    } 

}