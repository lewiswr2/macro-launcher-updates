#Requires AutoHotkey v2.0

class Settings {
    static MAP := Map()
    static FOLDER := ""

    static save() {
        this.getSettingsFolder()
        path := this.FOLDER "Default.ini"
        Roblox.setTitle("Starting | Saving Settings")
        for section, keys in this.MAP {
            for key, control in keys {
                IniWrite control.Value, path, section, key
            }
        }

        filename := this.getFileName()
        if filename != "" && filename != "Default.ini"
            FileCopy this.FOLDER "Default.ini", this.FOLDER filename, true

        this.populateDropdowns() 

        Roblox.setTitle()
    }

    static populateDropdowns() {
        files := this.getSettingsFiles()
        GuiSettings.settingsLoadDropdown.Delete()
        GuiSettings.settingsLoadDropdown.Add(files)
        GuiSettings.settingsSaveFile.Delete()
        GuiSettings.settingsSaveFile.Add(files)
    }

    static getFileName() {
        if GuiSettings.settingsSaveFile.Text == ""
            return ""

        filename := StrReplace(GuiSettings.settingsSaveFile.Text, " ", "_")
        if !InStr(filename, ".ini")
            filename := filename ".ini"

        return filename
    }

    static load() {
        this.getSettingsFolder()
        filename := GuiSettings.settingsLoadDropdown.Text != "" ? GuiSettings.settingsLoadDropdown.Text : "Default.ini"
        path := this.FOLDER filename

        if !FileExist(path)
            return

        for section, keys in this.MAP {
            for key, control in keys {
                try val := IniRead(path, section, key, control.Value)
                catch {
                    MsgBox key 
                }
                try control.Value := val
            }
        }

        GuiHatch.updateEggIcon()
        
        GuiSettings.updateVipOptions()

        ;updateShopsOptions()
        ;buffsMasteryChange()
        ;updateCompetitiveOptions()



        ; Update all select all checkboxes.
        ;minigamesUpdateSelectAllCheckbox()
        ;shopsUpdateSelectAllCheckbox()
        ;chestsUpdateSelectAllCheckbox()
        ;spinUpdateSelectAllCheckbox()
        ;rewardsUpdateSelectAllCheckbox()
        GuiHatch.hatchingUpdateSelectAllCheckbox()
        GuiSettings.applyColour()

        GuiSettings.updatePreview(GuiSettings.backgroundColour, GuiSettings.backgroundPreview)
        GuiSettings.updatePreview(GuiSettings.fontColour, GuiSettings.fontPreview)


    }

    static getSettingsFolder() {
        try {
            processPath := WinGetProcessPath("ahk_exe Psycho Hatcher.exe")
        } catch {
            processPath := ""
        }

        if processPath
            this.FOLDER := StrReplace(processPath, "Psycho Hatcher.exe", "") "Settings\\BGSI\\"
        else
            this.FOLDER := A_ScriptDir "\Settings\"
    }

    static getSettingsFiles() {
        list := []
        Loop Files this.FOLDER "\*.ini", "F"
            list.Push(A_LoopFileName)
        return list
    }

    static initialiseMap() {
        Settings.MAP := Map(
            "Hatching", Map(
                "Egg", GuiHatch.hatchingEggDropdown,
                "Cooldown", GuiHatch.hatchingCooldownDropdown,
                "UseLuckyPotion", GuiHatch.hatchingLuckyCheckbox,
                "UseSpeedPotion", GuiHatch.hatchingSpeedCheckbox,
                "UseMythicPotion", GuiHatch.hatchingMythicCheckbox,
                "ChangePetTeam", GuiHatch.hatchingChangeTeam,
                "HatchPetTeam", GuiHatch.hatchingPetTeam,
            ),
            "Farming", Map(
                "TicketsCooldown", GuiFarm.farmTicketsCooldown,
                "TicketsPathing", GuiFarm.farmTicketsPathing,
                "TicketsTicketsPotion", GuiFarm.farmTicketsTicketsPotionCheckbox,
                "TicketsGoldenOrb", GuiFarm.farmTicketsGoldenOrbCheckbox,
                "TicketsBlowBubbles", GuiFarm.farmTicketsBlowBubbles,
                "GemsCooldown", GuiFarm.farmGemsCooldown,
                "GemsCoinsPotion", GuiFarm.farmGemsCoinsPotionCheckbox,
                "GemsGoldenOrb", GuiFarm.farmGemsGoldenOrbCheckbox,
                "GemBlowBubbles", GuiFarm.farmGemsBlowBubbles,
                "FestivalCoinsCooldown", GuiFarm.farmFestivalCoinsCooldown,
                "FestivalCoinsCoinsPotion", GuiFarm.farmFestivalCoinsCoinsPotionCheckbox,
                "FestivalCoinsGoldenOrb", GuiFarm.farmFestivalCoinsGoldenOrbCheckbox,           
                "FestivalCoinsBlowBubbles", GuiFarm.farmFestivalCoinsBlowBubbles,
                ;"SeashellsCooldown", GuiFarm.farmSeashellsCooldown, 
                ;"SeashellsLocation", GuiFarm.farmSeashellsLocation,
            ),      
            "Competitive", Map(
                "Cooldown", GuiCompete.competitiveMinutes,
                "Hatching", GuiCompete.competitiveHatchingMinutes,
                "ShinyEgg", GuiCompete.shinyEggDropdown,
                "EpicEgg", GuiCompete.epicEggDropdown,
                "UniqueEgg", GuiCompete.uniqueEggDropdown,
                "LegendaryEgg", GuiCompete.legendaryEggDropdown,
                "MythicEgg", GuiCompete.mythicEggDropdown,
                "RerollShiny", GuiCompete.competitiveRerollShiny,
                "RerollEpic", GuiCompete.competitiveRerollEpic,
                "RerollUnique", GuiCompete.competitiveRerollUnique,
                "RerollLegendary", GuiCompete.competitiveRerollLegendary,
                "RerollMythic", GuiCompete.competitiveRerollMythic,
                "RerollTimedEvents", GuiCompete.competitiveRerollTimedEvents,
            ),
            "Season", Map(
                "ModeMinutes", GuiSeason.seasonMinutes,
                "HatchingMinutes", GuiSeason.seasonHatchingMinutes,
                "ShinyEgg", GuiSeason.seasonShinyEggDropdown,
                "EpicEgg", GuiSeason.seasonEpicEggDropdown,
                "RareEgg", GuiSeason.seasonRareEggDropdown,
                "UniqueEgg", GuiSeason.seasonUniqueEggDropdown,
                "CommonEgg", GuiSeason.seasonCommonEggDropdown,
                "LegendaryEgg", GuiSeason.seasonLegendaryEggDropdown,
                "MythicEgg", GuiSeason.seasonMythicEggDropdown,
                "UseLuckyPotion", GuiSeason.seasonLuckyCheckbox,
                "UseSpeedPotion", GuiSeason.seasonSpeedCheckbox,
                "UseMythicPotion", GuiSeason.seasonMythicCheckbox,
            ),
            "Event", Map(
                "ModeMinutes", GuiEventChallenges.eventMinutes,
                "HatchingMinutes", GuiEventChallenges.eventHatchingMinutes,
                "UseLuckyPotion", GuiEventChallenges.eventLuckyCheckbox,
                "UseSpeedPotion", GuiEventChallenges.eventSpeedCheckbox,
                "UseMythicPotion", GuiEventChallenges.eventMythicCheckbox,
            ),            
            "BoardGame", Map(       
                "GoldenDice", GuiTools.gbGoldenDiceUseAmount,
                "InfinityAmount", GuiTools.gbInfinityAmount,
                "EggToHatch", GuiTools.gbEggToHatch,
                "AlarmOnGoal", GuiTools.gbAlarm,
                "ReconnectOnGoal", GuiTools.gbDisconnect,
                "HatchEgg", GuiTools.gbFarmEgg,
                "BlowBubbles", GuiTools.gbBlowBubbles,                
            ),
            "Enchanting", Map(
                "EnchantToUse", GuiTools.enchantToUse,
            ),
            "PetMatch", Map(
                "Play", GuiActions.petMatchCheckbox,
                "Cooldown", GuiActions.petMatchCooldownDropdown,
            ),
            "RobotClaw", Map(
                "Play", GuiActions.robotClawCheckbox,
                "Cooldown", GuiActions.robotClawCooldownDropdown,
            ),        
            "HyperDarts", Map(
                "Play", GuiActions.hyperDartsCheckbox,
                "Cooldown", GuiActions.hyperDartsCooldown,
            ),                    
            "Gamepasses", Map(
                "VIP", GuiSettings.vipGamepassCheckbox
            ),
            "Masteries", Map(
                "Buffs", GuiSettings.buffsMasteryDropdown,
                "Pets", GuiSettings.petsMasteryDropdown,
                "Shops", GuiSettings.shopsMasteryDropdown,
                "Minigames", GuiSettings.minigamesMasteryDropdown,
                "Walkspeed", GuiSettings.walkspeedModifier
            ),
            "Shops", Map(
                "UseAlienShop", GuiActions.alienShopCheckbox,
                "UseBlackmarket", GuiActions.blackmarketCheckbox,
                "UseDiceMerchant", GuiActions.diceMarketCheckbox,
                "UseTravelingMerchant", GuiActions.travelingMerchantCheckbox,
                "UseFestivalShop", GuiActions.festivalShopCheckbox,
                "UseFishingShop", GuiActions.fishingShopCheckbox,
                ;"UseEventShop", GuiActions.eventShopCheckbox,
                "RerollAlienShop", GuiActions.rerollAlienShop,
                "RerollBlackmarket", GuiActions.rerollBlackmarket,
                "RerollDiceMerchant", GuiActions.rerollDiceMerchant,
                "RerollTravelingMerchant", GuiActions.rerollTravelingMerchant,
                "RerollFestivalShop", GuiActions.rerollFestivalShop,
                "RerollFishingShop", GuiActions.rerollFishingShop,
                ;"RerollEventShop", GuiActions.rerollEventShop,
            ),
            "Genie", Map(
                "ChooseQuest", GuiGenie.gemGenieCheckbox
            ),        
            "BubbleGum", Map(
                "SellGum", GuiActions.sellBubbleGumCheckbox,
                "Currency", GuiActions.gumCurrencyDropdown,
                "Cooldown", GuiActions.sellGumDropdown
            ),
            "Rewards", Map(
                "Playtime", GuiActions.rewardsPlaytimeCheckbox,
                "Index", GuiActions.rewardsIndexCheckbox,
                "Season", GuiActions.rewardsSeasonCheckbox,
                "Quests", GuiActions.rewardsQuestsCheckbox,
            ),
            "Chests", Map(
                "Infinity", GuiActions.chestsInfiniteCheckbox,
                "Giant", GuiActions.chestsGiantCheckbox,
                "Void", GuiActions.chestsVoidCheckbox,
                "Ticket", GuiActions.chestsTicketCheckbox,
            ),
            "Spin", Map(
                "CollectWheel", GuiActions.collectWheelCheckbox,
                ;"CollectAncient", GuiActions.collectAncientCheckbox,
                "SpinWheel", GuiActions.useWheelSpinCheckbox,
                ;"SpinAncient", GuiActions.useAncientSpinCheckbox,
            ),
            "Potions", Map(
                "UpgradePotions", GuiActions.upgradePotionsCheckbox,
                "Cooldown", GuiActions.upgradePotionsDropdown
            ),
            "Webhook", Map(
                "WebhookUrl", GuiSettings.webhookUrl,
                "webhookRewards", GuiSettings.webhookMinigames,
                "webhookShops", GuiSettings.webhookShops,
            ),
            "Reconnect", Map(
                "Reconnect", GuiActions.timedReconnectCheckbox,
                "Cooldown", GuiActions.timedReconnectCooldownDropdown,
                "Private", GuiActions.timedReconnectPrivateLinkCode,
            ),       
            "Hotkeys", Map(
                "Start", GuiSettings.startHotkey,
                "Pause", GuiSettings.pauseHotkey,
                "Exit", GuiSettings.exitHotkey,
            ),       
            "PetTeam", Map(
                "World1", GuiSettings.teamWorld1Checkbox,
                "World2", GuiSettings.teamWorld2Checkbox,
                ;"Event", GuiSettings.teamEventWorldCheckbox,
                "World1Team", GuiSettings.teamWorld1,
                "World2Team", GuiSettings.teamWorld2,
                ;"EventTeam", GuiSettings.teamEventWorld,                
            ),
            "Theme", Map(
                "BackgroundColour", GuiSettings.backgroundColour,
                "FontColour", GuiSettings.fontColour,
            ),            
            "Minigames", Map(
                "PetMatchDifficulty", GuiTools.minigamePetMatchDifficulty,
                "RobotClawDifficulty", GuiTools.minigameRobotClawDifficulty,
                "HyperDartsDifficulty", GuiTools.minigameHyperDartsDifficulty,
            ),  

            
        )
    }
}
