#Requires AutoHotkey v2.0

; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
; @region SEASON
; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

class Season {

    ; Search areas.
    static ICON_AREA := {x1: 730, y1: 150, x2: 780, y2: 450}

    ; Search images.
    static SEASON_ICON := A_ScriptDir "\Assets\UI\SeasonIcon.bmp"
    static POINTS_ICON := [168, 151, 208, 196, "0xfdd610"]
    static NO_ACTIVE_WINDOW_ICON := [493, 191, 536, 234, "0xde294a"]

    ; Max attempts.
    static MAX_OPEN_WINDOW := 50

    ; Buttons.
    static CLOSE_BUTTON := {x: 614, y: 128}
    static NO_ACTIVE_SEASON_CLOSE_BUTTON := {x: 515, y: 212}

    static openWindow() {
        Bubble.closeBubbleFullWindow()
        Roblox.Leaderboard.close()

        if this.isWindowOpen()
            return 1

        a := this.ICON_AREA
        image := "*5 " this.SEASON_ICON

        Loop this.MAX_OPEN_WINDOW {
            if this.isWindowOpen()
                return 1
            if this.isNoActiveSeasonOpen() {
                this.closeNoActiveSeason()
                return 0
            }
            if ImageSearch(&x, &y, a.x1, a.y1, a.x2, a.y2, image)
                clickButton({x: x, y: y}, 100)
            Sleep 100
        }
    }

    static closeNoActiveSeason() {
        clickButton(this.NO_ACTIVE_SEASON_CLOSE_BUTTON, 1000)   
    }

    static isNoActiveSeasonOpen() {
        Roblox.activate()
        return PixelSearch(&x, &y, this.NO_ACTIVE_WINDOW_ICON*)
    }

    static isWindowOpen() {
        Roblox.activate()
        return PixelSearch(&x, &y, this.POINTS_ICON*)
    }

    static close() {
        clickButton(this.CLOSE_BUTTON, 1000)   
    }


    class Challenges {

        ; Buttons.
        static CHALLENGES_TAB_BUTTON := {x: 230, y: 124} 
        

        ; Pixel searches.
        static CHALLENGE_COMPLETED_COLOUR := "0x00ff00"

        ; Max attempts.
        static MAX_SELECT_TAB := 10
        static MAX_INCREASE_SCALE_TIMES := 39

        static PROGRESS_BAR_WIDTH := 152
        static CURRENT_EGG := ""

        static CHALLENGE_BOXES := Map(
            1, {
                OCR_AREA: {x: 236, y: 245, w: 155, h: 20},
                BOX_AREA: {x1: 166, y1: 245, x2: 396, y2: 307},
                PROGRESS_BAR: [240, 271, 391, 271, "0x040608", 5],  
            },
            2, {
                OCR_AREA: { x: 236, y: 315, w: 155, h: 20},
                BOX_AREA: {x1: 166, y1: 315, x2: 396, y2: 377},  
                PROGRESS_BAR: [240, 342, 391, 342, "0x040608", 5],
            },
            3, {
                OCR_AREA: {x: 236, y: 385, w: 155, h: 20},
                BOX_AREA: {x1: 166, y1: 385, x2: 396, y2: 447},
                PROGRESS_BAR: [240, 411, 391, 411, "0x040608", 5],
            },
            4, {
                OCR_AREA: {x: 473, y: 245, w: 155, h: 20},
                BOX_AREA: {x1: 403, y1: 245, x2: 633, y2: 307},
                PROGRESS_BAR: [479, 271, 630, 271, "0x040608", 5],
            },
            5, {
                OCR_AREA: {x: 473, y: 315, w: 155, h: 20},
                BOX_AREA: {x1: 403, y1: 315, x2: 633, y2: 377},                
                PROGRESS_BAR: [479, 342, 630, 342, "0x040608", 5],
            },
            6, {
                OCR_AREA: {x: 473, y: 385, w: 155, h: 20},
                BOX_AREA: {x1: 403, y1: 385, x2: 633, y2: 447},                          
                PROGRESS_BAR: [479, 411, 630, 411, "0x040608", 5],
            },
        )

        static isChallengeContainerVisible() {
            imagePath := "*10 " A_ScriptDir "\Assets\Images\Season\ChallengeBackground.bmp"
            return ImageSearch(&x, &y, 165, 246, 396, 307, imagePath)
        }

        static selectTab() {
            Loop this.MAX_SELECT_TAB {
                if this.isChallengeContainerVisible()
                    break                
                clickButton(this.CHALLENGES_TAB_BUTTON, 100 1)
            }
        }

        static run(mode) {

            SeasonChallenges.setChallenges(mode)

            end := A_TickCount + (mode["duration"] * 60 * 1000)
            GuiModeQueue.modeQueueList.Modify(1, , , end)
            Timers.Mode.reset()

            Loop {
                if this.shouldExit() {
                    this.CURRENT_EGG := ""
                    return
                }

                if !Season.openWindow()
                    return 0
                this.selectTab()
                this.getPoints()
                this.getChallenges(mode)
                if GuiSeasonList.seasonChallengeList.GetCount() == 0
                    break
                    
                if A_Index == 1 {
                    this.useBuffs(mode)
                }

                this.doChallenge(mode)
                Sleep 1000
            }
        }

        static useBuffs(mode) {
            if !mode["useLucky"] && !mode["useSpeed"] && !mode["useMythic"]
                return false

            Items.open()
            Items.ItemsTab.open()
            if mode["useLucky"] {
                item := "Lucky V"
                Roblox.setTitle(mode["mode"] " | Using " item)
                Items.ItemsTab.useItem(item)
            }
            if mode["useSpeed"] {
                item := "Speed V"
                Roblox.setTitle(mode["mode"] " | Using " item)
                Items.ItemsTab.useItem(item)
            }
            if mode["useMythic"] {
                item := "Mythic V"
                Roblox.setTitle(mode["mode"] " | Using " item)
                Items.ItemsTab.useItem(item)
            }            
            Items.ItemsTab.close()
            Roblox.setTitle()
        }

        static getChallenges(mode) {
            Roblox.activate()
            
            GuiSeasonList.seasonChallengeList.Delete()

            for _, box in this.CHALLENGE_BOXES {
                matchedChallenge := ""
                matchedChallengeName := ""
                matchedAmount := ""
                scale := 1
                index := A_Index

                challengeMatched := false
                amountMatched := false

                if this.isCompleted(box.BOX_AREA)
                    continue

                Loop this.MAX_INCREASE_SCALE_TIMES {

                    text := getOcr(box.OCR_AREA.x, box.OCR_AREA.y, box.OCR_AREA.w, box.OCR_AREA.h, scale)
                    Logs.writeOcrLog("[" index "] (" A_Index "/" this.MAX_INCREASE_SCALE_TIMES ") Raw: " text " | Scale: " scale)
                    
                    text := this.cleanOcrNumbers(text)
                    trimmed := Trim(text)

                    if !challengeMatched {
                        challengeMatched := this.matchChallenge(trimmed, &matchedChallenge, &matchedChallengeName)
                        if challengeMatched && !matchedChallenge.needAmount
                            amountMatched := true
                    }

                    if !amountMatched {
                        amountMatched := this.matchAmount(text, &matchedAmount)
                    }

                    if challengeMatched && amountMatched
                        break

                    scale += 1
                }

                ; Fallback to 100 if no amount is matched.
                matchedAmount := matchedAmount = "" ? 100 : matchedAmount

                ; Get the progress of the challenge.
                progress := Floor(this.getProgress(box))

                ; Fallback in case no challenge is matched.
                if !matchedChallengeName {
                    GuiSeasonList.seasonChallengeList.Add(, "?" trimmed, matchedAmount, progress, 99, "Infinity")
                    continue
                }

                iconIndex := IL_Add(GuiSeasonList.seasonImageList, matchedChallenge.icon)
                GuiSeasonList.seasonChallengeList.Add("Icon" iconIndex, matchedChallengeName, matchedAmount, progress, matchedChallenge.priority, matchedChallenge.egg, matchedChallenge.type)
                Logs.writeOcrLog("[" index "] Text: " matchedChallengeName " | Progress: " progress "%")
            }

            GuiSeasonList.seasonChallengeList.ModifyCol(4, "Sort")

            Roblox.Leaderboard.close()
            Season.close()
        }


        static matchChallenge(trimmed, &matchedChallenge, &matchedChallengeName) {
            for name, challenge in SeasonChallenges.SEASONAL_CHALLENGES {
                if RegExMatch(trimmed, challenge.regex) {
                    matchedChallenge := challenge
                    matchedChallengeName := name
                    return true
                }
            }
            return false
        }    

        static shouldExit() {
            return GuiModeQueue.modeQueueList.GetText(1, 3) = "Ended"
        }

        static matchAmount(text, &matchedAmount) {
            trimmed := Trim(text)
            amount := RegExReplace(trimmed, "\D")
            if amount != "" && amount != 0 {
                matchedAmount := amount
                return true
            }
            return false
        }

        static cleanOcrNumbers(text) {
            text := RegExReplace(text, "i)SOO", "500")
            text := RegExReplace(text, "i)[S5][0O]", "50")
            text := RegExReplace(text, "i)[l1][0O]", "10")
            text := RegExReplace(text, "i)ooo", "000")
            text := RegExReplace(text, "li", "1,")
            text := RegExReplace(text, "A5", "45")
            text := RegExReplace(text, "9S", "95")
            text := RegExReplace(text, Chr(34), "4") ; Replace double quotes.
            return text
        }        

        static getProgress(challenge) {
            progress := 100
            Roblox.activate()
            if PixelSearch(&x, &y, challenge.PROGRESS_BAR*) {
                calc := ((x - challenge.PROGRESS_BAR[1]) / this.PROGRESS_BAR_WIDTH) * 100
                progress := clamp(calc, 0, 100)
            }
            return progress
        }

        static isCompleted(area) {
            Roblox.activate()
            return PixelSearch(&x, &y, area.x1, area.y1, area.x2, area.y2, this.CHALLENGE_COMPLETED_COLOUR, 2)
        }

        static isChallengeComplete() {
            imagePath := "*10 " A_ScriptDir "\Assets\Images\Season\SeasonCoin.bmp"
            return ImageSearch(&x, &y, 548, 313, 703, 434, imagePath)
        }

        static doChallenge(mode) {

            type := GuiSeasonList.seasonChallengeList.GetText(1, 6)

            switch type {
                case "Hatch":
                    this.doHatchChallenge(mode)
                case "Coins":
                    this.doCoinsChallenge(mode)
                case "Bubbles":
                    this.doBubbleChallenge(mode)
                default:
            }
       
        }

        static doCoinsChallenge(mode) {

            Roblox.setTitle(mode["mode"] " | Teleporting to Island")
            Teleport.teleportTo("1-5")
            Farming.selectTeam(1)

            maxTime := A_TickCount + (mode["hatchTime"] * 60000)
            lastTitleUpdate := 0

            Loop {
                Roblox.setTitle(mode["mode"] " | Running Path (" A_Index ")")
                Roblox.activate()
                Roblox.Leaderboard.close()

                for step in Farming.Gems.PATH {

                    Movement.move(step[1], step[2])

                    ; Update title only once per second
                    if (A_TickCount - lastTitleUpdate >= 1000) {
                        remaining := Ceil((maxTime - A_TickCount) / 1000)
                        Roblox.setTitle(mode["mode"] " | Farming Coins (" remaining "s)")
                        lastTitleUpdate := A_TickCount
                    }

                    ; Check for challenge completion
                    if this.isChallengeComplete() {
                        Roblox.setTitle(mode["mode"] " | Completed a Challenge")
                        break 2
                    }

                    ; Check for timeout
                    if A_TickCount > maxTime {
                        Roblox.setTitle(mode["mode"] " | Timer Expired")
                        break 2
                    }  

                }

                Roblox.setTitle(mode["mode"] " | Teleporting to Island")
                Teleport.teleportTo("1-5")                    
            }
            Roblox.setTitle()

        }

        static doBubbleChallenge(mode) {
            currency := BubbleGum.PROPERTIES["Coins"]
            Teleport.teleportTo(currency.island)
            Farming.selectTeam(1)
            
            Roblox.activate()
            Roblox.Leaderboard.close()

            for _, step in currency.path
                Movement.move(step[1], step[2])            

            maxTime := A_TickCount + (mode["hatchTime"] * 60000)
            lastTitleUpdate := 0
            Loop {

                Mouse.holdLeftMouse()

                ; Check for challenge completion
                if this.isChallengeComplete() {
                    Roblox.setTitle("Season | Completed a Challenge")
                    break
                }

                ; Check for timeout
                if A_TickCount > maxTime {
                    Roblox.setTitle("Season | Timer Expired")
                    break
                }

                ; Update title only once per second
                if (A_TickCount - lastTitleUpdate >= 1000) {
                    remaining := Ceil((maxTime - A_TickCount) / 1000)
                    Roblox.setTitle("Season | Blowing Bubbles (" remaining "s)")
                    lastTitleUpdate := A_TickCount
                }

                Sleep 10

            }
            Roblox.setTitle()
            Mouse.releaseLeftMouse()

        }            

        static doHatchChallenge(mode) {
            egg := GuiSeasonList.seasonChallengeList.GetText(1, 5)

            if egg != this.CURRENT_EGG || !Hatching.isAtEgg()
                Hatching.moveToEgg(egg)
            
            Bubble.closeBubbleFullWindow()
            Roblox.setTitle(mode["mode"] " | Hatching Egg: " egg "")

            maxTime := A_TickCount + (mode["hatchTime"] * 60000)
            lastTitleUpdate := 0

            Loop {
                ; Send interaction
                Send "{e}"

                ; Check for challenge completion
                if this.isChallengeComplete() {
                    Roblox.setTitle(mode["mode"] " | Completed a Challenge")
                    break
                }

                ; Check for timeout
                if A_TickCount > maxTime {
                    Roblox.setTitle(mode["mode"] " | Hatching Timer Expired")
                    break
                }

                ; Update title only once per second
                if (A_TickCount - lastTitleUpdate >= 1000) {
                    remaining := Ceil((maxTime - A_TickCount) / 1000)
                    Roblox.setTitle(mode["mode"] " | Hatching Egg: " egg " (" remaining "s)")
                    lastTitleUpdate := A_TickCount
                }

                Sleep 10
            }

            this.CURRENT_EGG := egg
        }

        static getPoints() {
            scale := 1
            Loop 39 {
                text := getOcr(211, 163, 90, 20, scale)
                text := RegExReplace(text, "[oO]", "0")
                text := RegExReplace(text, "[sS]", "5")
                text := RegExReplace(text, "q", "4")
                if RegExMatch(text, "^-?\d{1,3}(,\d{3})*$|^-?\d+$")
                    break
                scale += 1
            }
            GuiCompete.competeStarsTotal.Value := text
        }        

    }

    class Rewards {
        static TIMER := 0
        static COOLDOWN := 30
        static INFINITE_BUTTON := {x: 376, y: 124}
        static PROGRESS_BAR_AREA := {x1: 167, y1: 355, x2: 214, y2: 371}
        static PROGRESS_BAR_COLOURS := ["0xfdc820", "0x00295e", "0x000000"]
        static SAFE_CURSOR_LOCATION := {x: 178, y: 365}        
        static CLAIM_AREA := [187, 207, 582, 243, "0x7ff312"]
        static PREMIUM_PASS_WARNING := [410, 282, 560, 300, "0xffe942", 2]
        static PREMIUM_PASS_WARNING_CLAIM_BUTTON := {x: 335, y: 386}
        static MAX_CLAIM_CHECKS := 50
        static MAX_SELECT_TAB := 50
        static ENABLE_CHECKBOX => GuiActions.rewardsSeasonCheckbox

        static isProgressBarVisible() {
            area := this.PROGRESS_BAR_AREA
            for colour in this.PROGRESS_BAR_COLOURS {
                if PixelSearch(&x, &y, area.x1, area.y1, area.x2, area.y2, colour, 3)
                    return true
            }
            return false
        }

        static openTab() {
            Loop this.MAX_SELECT_TAB {
                if this.isProgressBarVisible()
                    break                
                clickButton(this.INFINITE_BUTTON, 100 1)
            }
        }

        static claim() {
            Loop this.MAX_CLAIM_CHECKS {
                if !PixelSearch(&x, &y, this.CLAIM_AREA*)
                    break

                clickButton({x: x + 5, y: y}, 100, 1)
                moveLocation(this.SAFE_CURSOR_LOCATION, 100)

                if PixelSearch(&x, &y, this.PREMIUM_PASS_WARNING*)
                    clickButton(this.PREMIUM_PASS_WARNING_CLAIM_BUTTON, 100, 1)

            }
        }

        static getTimer() {
            return this.TIMER
        }

        static setTimer() {
            this.TIMER := A_TickCount + (this.COOLDOWN * 60 * 1000)
        }

        static run() {
            if !this.ENABLE_CHECKBOX.Value || A_TickCount <= this.TIMER
                return

            Roblox.setTitle("Action | Claiming Season Rewards")
            if !Season.openWindow()
                return
            this.openTab()
            this.claim()
            this.setTimer()
            Season.close()
            Roblox.setTitle()
        }        
    }

}




class SeasonChallenges {
    static setChallenges(mode) {
        this.SEASONAL_CHALLENGES := Map(
            "Hatch Mythic Pets", {
                regex: "i)myth",
                priority: 9,
                egg: mode["mythicPetEgg"],
                type: "Hatch",
                icon: GUI_SEASON_ICON_FOLDER "Mythic.ico",
                needAmount: true
            },
            "Hatch Legendary Pets", {
                regex: "i)leg",
                priority: 7,
                egg: mode["legendaryPetEgg"],
                type: "Hatch",
                icon: GUI_SEASON_ICON_FOLDER "Legend_Rarity.ico",
                needAmount: true
            },
            "Hatch Unique Pets", {
                regex: "i)unique",
                priority: 8,
                egg: mode["uniquePetEgg"],
                type: "Hatch",
                icon: GUI_SEASON_ICON_FOLDER "Unique_Rarity.ico",
                needAmount: true
            },
            "Hatch Shiny Pets", {
                regex: "i)shiny",
                priority: 6,
                egg: mode["shinyPetEgg"],
                type: "Hatch",
                icon: GUI_SEASON_ICON_FOLDER "Shiny.ico",
                needAmount: true
            },
            "Hatch Epic Pets", {
                regex: "i)epic",
                priority: 6,
                egg: mode["epicPetEgg"],
                type: "Hatch",
                icon: GUI_SEASON_ICON_FOLDER "Epic_Rarity.ico",
                needAmount: true
            },
            "Hatch Rare Pets", {
                regex: "i)rare",
                priority: 6,
                egg: mode["rarePetEgg"],
                type: "Hatch",
                icon: GUI_SEASON_ICON_FOLDER "Rare_Rarity.ico",
                needAmount: true
            },
            "Hatch Common Pets", {
                regex: "i)comm.*p",
                priority: 1,
                egg: mode["commonPetEgg"],
                type: "Hatch",
                icon: GUI_SEASON_ICON_FOLDER "Common_Rarity.ico",
                needAmount: true
            },            
            "Hatch Common Eggs", {
                regex: "i)comm.*g",
                priority: 1,
                egg: "Common",
                type: "Hatch",
                icon: GUI_MODE_ICON_FOLDER "Common_Egg.ico",
                needAmount: true
            },
            "Hatch Spotted Eggs", {
                regex: "i)spot",
                priority: 1,
                egg: "Spotted",
                type: "Hatch",
                icon: GUI_MODE_ICON_FOLDER "Spotted_Egg.ico",
                needAmount: true
            },
            "Hatch Iceshard Eggs", {
                regex: "i)icesh",
                priority: 1,
                egg: "Iceshard",
                type: "Hatch",
                icon: GUI_MODE_ICON_FOLDER "Iceshard_Egg.ico",
                needAmount: true
            },
            "Hatch Spikey Eggs", {
                regex: "i)spik",
                priority: 1,
                egg: "Spikey",
                type: "Hatch",
                icon: GUI_MODE_ICON_FOLDER "Spikey_Egg.ico",
                needAmount: true
            },
            "Hatch Magma Eggs", {
                regex: "i)mag",
                priority: 1,
                egg: "Magma",
                type: "Hatch",
                icon: GUI_MODE_ICON_FOLDER "Magma_Egg.ico",
                needAmount: true
            },
            "Hatch Crystal Eggs", {
                regex: "i)cry",
                priority: 1,
                egg: "Crystal",
                type: "Hatch",
                icon: GUI_MODE_ICON_FOLDER "Crystal_Egg.ico",
                needAmount: true
            },
            "Hatch Lunar Eggs", {
                regex: "i)lun",
                priority: 1,
                egg: "Lunar",
                type: "Hatch",
                icon: GUI_MODE_ICON_FOLDER "Lunar_Egg.ico",
                needAmount: true
            },
            "Hatch Void Eggs", {
                regex: "i)void",
                priority: 1,
                egg: "Void",
                type: "Hatch",
                icon: GUI_MODE_ICON_FOLDER "Void_Egg.ico",
                needAmount: true
            },
            "Hatch Hell Eggs", {
                regex: "i)hell",
                priority: 1,
                egg: "Hell",
                type: "Hatch",
                icon: GUI_MODE_ICON_FOLDER "Hell_Egg.ico",
                needAmount: true
            },
            "Hatch Nightmare Eggs", {
                regex: "i)night",
                priority: 1,
                egg: "Nightmare",
                type: "Hatch",
                icon: GUI_MODE_ICON_FOLDER "Nightmare_Egg.ico",
                needAmount: true
            },
            "Hatch Rainbow Eggs", {
                regex: "i)rain",
                priority: 1,
                egg: "Rainbow",
                type: "Hatch",
                icon: GUI_MODE_ICON_FOLDER "Rainbow_Egg.ico",
                needAmount: true
            },
            "Hatch Showman Eggs", {
                regex: "i)show",
                priority: 1,
                egg: "Showman",
                type: "Hatch",
                icon: GUI_MODE_ICON_FOLDER "Showman_Egg.ico",
                needAmount: true
            },
            "Hatch Mining Eggs", {
                regex: "i)mining",
                priority: 1,
                egg: "Mining",
                type: "Hatch",
                icon: GUI_MODE_ICON_FOLDER "Mining_Egg.ico",
                needAmount: true
            },
            "Hatch Cyber Eggs", {
                regex: "i)cyb",
                priority: 1,
                egg: "Cyber",
                type: "Hatch",
                icon: GUI_MODE_ICON_FOLDER "Cyber_Egg.ico",
                needAmount: true
            },
            "Hatch Neon Eggs", {
                regex: "i)(neo|nep)",
                priority: 1,
                egg: "Neon",
                type: "Hatch",
                icon: GUI_MODE_ICON_FOLDER "Neon_Egg.ico",
                needAmount: true
            },
            "Hatch Eggs", {
                regex: "i)^(?!.*(myth|leg|unique|shiny|epic|rare|comm|spot|icesh|spik|mag|cry|lun|void|hell|night|rain|show|mining|cyb|neo|nep)).*hatch.*egg",
                priority: 20,
                egg: "Infinity",
                type: "Hatch",
                icon: GUI_SEASON_ICON_FOLDER "Eggs_Icon.ico",
                needAmount: true
            },
            "Collect Coins", {
                regex: "i)coins",
                priority: 99,
                egg: "",
                type: "Coins",
                icon: GUI_SEASON_ICON_FOLDER "Coins_Icon.ico",
                needAmount: false
            },
            "Blow Bubbles", {
                regex: "i)(blow|bubb)",
                priority: 99,
                egg: "",
                type: "Bubbles",
                icon: GUI_SEASON_ICON_FOLDER "Bubble_Gum_Icon.ico",
                needAmount: false
            },                            
        )
    }
}