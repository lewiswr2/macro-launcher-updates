#Requires AutoHotkey v2.0

class BubbleGum {
    static TIMER := 0
    static COOLDOWN_DROPDOWN => GuiActions.sellGumDropdown

    static PROPERTIES := Map(
        "Coins", {
            island: "1-3",
            path: [["sa", 350], ["a", 750]]
        },
        "Tickets", {
            island: "2-3",
            path: [["wa", 700], ["w", 500]]
        },
    )

    static sell(name) {
        currency := this.PROPERTIES[name]
        Roblox.setTitle("Bubbles | Teleporting to Island")
        Teleport.teleportTo(currency.island)
        Windows.closeAllWindows()
        Roblox.setTitle("Bubbles | Moving to Sell Area")
        for _, step in currency.path
            Movement.move(step[1], step[2])
        Roblox.setTitle("Bubbles | Selling for " name)
        Sleep 500
        this.setTimer()
        Roblox.setTitle()
    }

    static setTimer() {
        this.TIMER := A_TickCount + (this.COOLDOWN_DROPDOWN.Text * 60 * 1000)
    }

    static getTimer() {
        return this.TIMER
    }

    static run() {
        this.sell(GuiActions.gumCurrencyDropdown.Text)
    }
   
}

class Bubble {
    static BUBBLE_FULL_SEARCH := [300, 226, 496, 243, "0xffe942", 2]
    static BUBBLE_FULL_X := {x: 570, y: 176}

    static closeBubbleFullWindow() {
        if this.isBubbleFullWindowDisplayed() {
            clickButton(this.BUBBLE_FULL_X, 100)
            return true
        }
        return false
    }

    static isBubbleFullWindowDisplayed() {
        return PixelSearch(&x, &y, this.BUBBLE_FULL_SEARCH*)
    }    
}