#Requires AutoHotkey v2.0

; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
; INITIALISATION SETTINGS/FUNCTIONS
; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

completeInitialisationTasks() {
    Roblox.activate()
   
    updateTrayIcon()

    Roblox.setTitle("Initialising | Resizing Roblox")
    Roblox.resize()

    Windows.closeAllWindows()

    Roblox.setTitle("Initialising | Checking Display Scaling")
    checkDisplayScaling()

    Roblox.setTitle("Initialising | Checking Background Transparency")
    isMaxBackgroundTransparency()

    Roblox.setTitle()
}

updateTrayIcon() {
    iconFile := GUI_MENU_ICON_FOLDER "Application.ico"
    TraySetIcon iconFile
}

checkDisplayScaling() {
    scaling := Round(A_ScreenDPI / 96 * 100)

    if scaling != 100 {
        MsgBox "Display scaling must be set to 100%.`nUpdate it in Windows display settings.", MACRO_TITLE, 0x30
        ExitApp
    }
}

isMaxBackgroundTransparency() {
    Roblox.activate()

    if Roblox.Leaderboard.isDisplayed() {
        Roblox.Leaderboard.close()
        return
    }

    Roblox.Leaderboard.open()
    Sleep 250
    if !Roblox.Leaderboard.isDisplayed() {
        MsgBox "Background Transparency in the Roblox Settings menu is not full (Opaque).", MACRO_TITLE, 0x30
        ExitApp
    }
    Roblox.Leaderboard.close()
}
