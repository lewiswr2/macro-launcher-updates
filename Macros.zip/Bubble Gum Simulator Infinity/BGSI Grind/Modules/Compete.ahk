#Requires AutoHotkey v2.0

class Compete {
    static BUTTON := { x: 754, y: 404 }
    static TASKS_BUTTON := { x: 121, y: 272 }
    static CLOSE_BUTTON := { x: 614, y: 138 }
    static WINDOW_PIXEL := { x: 185, y: 138, colour: "0xfac500"}
    static PROGRESS_BAR_WIDTH := 220
    static INCREASE_SCALE_TIMES := 39

    static CURRENT_EGG := ""

    static TASK_BOXES := Map(
        1, {
            OCR_AREA: { x: 166, y: 442, w: 230, h: 17},
            REROLL_AREA: [170, 359, 214, 403, "0xd63fc4", 5],
            PROGRESS_BAR: [170, 468, 390, 468, "0x0f3b6d", 5],
            REROLL_BUTTON: { x: 194, y: 381 }
        },
        2, {
            OCR_AREA: { x: 404, y: 442, w: 230, h: 17},
            REROLL_AREA: [407, 359, 453, 403, "0xd63fc4", 5],
            PROGRESS_BAR: [408, 468, 628, 468, "0x0f3b6d", 5],
            REROLL_BUTTON: { x: 431, y: 381 }
        }
    )

    static getProgress(task) {
        progress := 100
        Roblox.activate()
        if PixelSearch(&x, &y, task.PROGRESS_BAR*) {
            calc := ((x - task.PROGRESS_BAR[1]) / this.PROGRESS_BAR_WIDTH) * 100
            progress := clamp(calc, 0, 100)
        }
        return progress
    }

    static matchCompetitiveTask(trimmed, &matchedTask, &matchedTaskName, index) {
        for name, task in CompetitiveTasks.COMPETITIVE_TASKS {
            if RegExMatch(trimmed, task.regex) {
                matchedTask := task
                matchedTaskName := name
                return true
            }
        }
        return false
    }

    static matchHatchAmount(text, &matchedAmount) {
        text := this.cleanOcrNumbers(text)
        trimmed := Trim(text)
        amount := RegExReplace(trimmed, "\D")
        if amount != "" && amount <= 1250 {
            matchedAmount := amount
            return true
        }
        return false
    }

    static getTasks() {
        Roblox.activate()
        Roblox.Leaderboard.close()
        GuiCompete.competeTaskList.Delete()

        for _, box in this.TASK_BOXES {
            matchedTask := ""
            matchedTaskName := ""
            matchedAmount := ""
            scale := 1
            index := A_Index

            Loop this.INCREASE_SCALE_TIMES {
                TaskRerolledRepeat:

                taskMatched := false
                amountMatched := false

                text := getOcr(box.OCR_AREA.x, box.OCR_AREA.y, box.OCR_AREA.w, box.OCR_AREA.h, scale)
                Logs.writeOcrLog("[" index "] (" A_Index "/" this.INCREASE_SCALE_TIMES ") Raw: " text " | Scale: " scale)

                trimmed := Trim(text)

                if !taskMatched {
                    taskMatched := this.matchCompetitiveTask(trimmed, &matchedTask, &matchedTaskName, index)
                    if taskMatched && matchedTask.REROLL {
                        this.openWindow()
                        if this.rerollTask(index) {
                            Sleep 250
                            goto TaskRerolledRepeat
                        }
                    }
                }

                if !amountMatched {
                    amountMatched := this.matchHatchAmount(text, &matchedAmount)
                }

                if taskMatched && amountMatched
                    break

                scale += 1
            }

            ; Fallback to 100 if no amount is matched.
            matchedAmount := matchedAmount = "" ? 100 : matchedAmount

            ; Get the progress of the task.
            progress := Floor(this.getProgress(box))

            ; Fallback in case no task is matched.
            if !matchedTaskName {
                GuiCompete.competeTaskList.Add(, "*" trimmed, matchedAmount, progress, 99, "Infinity")
                continue
            }

            GuiCompete.competeTaskList.Add(, matchedTaskName, matchedAmount, progress, matchedTask.priority, matchedTask.egg)
            Logs.writeOcrLog("[" index "] Text: " matchedTaskName " | Progress: " progress "%")
        }

        GuiCompete.competeTaskList.ModifyCol(4, "Sort")
    }

    static doTask() {

        egg := GuiCompete.competeTaskList.GetText(1, 5)

        Roblox.Leaderboard.close()
        clickButton(this.CLOSE_BUTTON, 1000)

        if egg != this.CURRENT_EGG
            Hatching.moveToEgg(egg)
        
        Bubble.closeBubbleFullWindow()
        Roblox.setTitle("Competitive | Hatching Egg: " egg "")

        maxTime := A_TickCount + (GuiCompete.competitiveHatchingMinutes.Text * 60000)
        lastTitleUpdate := 0

        Loop {
            ; Send interaction
            Send "{e}"

            ; Check for task completion
            if this.isTaskComplete() {
                Roblox.setTitle("Competitive | Completed a Task")
                break
            }

            ; Check for timeout
            if A_TickCount > maxTime {
                Roblox.setTitle("Competitive | Hatching Timer Expired")
                break
            }

            ; Update title only once per second
            if (A_TickCount - lastTitleUpdate >= 1000) {
                remaining := Ceil((maxTime - A_TickCount) / 1000)
                Roblox.setTitle("Competitive | Hatching Egg: " egg " (" remaining "s)")
                lastTitleUpdate := A_TickCount
            }

            Sleep 10
        }

        this.CURRENT_EGG := egg
    
    }

    static isTaskComplete() {
        imagePath := "*10 " A_ScriptDir "\Assets\Images\Compete\CompetitiveStar.bmp"
        return ImageSearch(&x, &y, 548, 313, 703, 434, imagePath)
    }

    static rerollTask(index) {
        task := this.TASK_BOXES[Integer(index)]
        if this.isRerollAvailable(task.REROLL_AREA) {
            clickButton(task.REROLL_BUTTON, 500)
            return true
        }
        return false
    }

    static run() {

        Loop {
            if this.shouldExit() {
                this.CURRENT_EGG := ""
                return
            }
                
            this.openWindow()
            this.getPoints()
            this.getTasks()
            this.doTask()
        }
    }

    static getPoints() {
        scale := 1
        Loop 39 {
            text := getOcr(200, 126, 90, 20, scale)
            text := RegExReplace(text, "[oO]", "0")
            text := RegExReplace(text, "[sS]", "5")
            text := RegExReplace(text, "q", "4")
            if RegExMatch(text, "^-?\d{1,3}(,\d{3})*$|^-?\d+$")
                break
            scale += 1
        }
        GuiCompete.competeStarsTotal.Value := text
    }

    static cleanOcrNumbers(text) {
        text := RegExReplace(text, "SO", "50")
        text := RegExReplace(text, "li", "1,")
        text := RegExReplace(text, "A5", "45")
        text := RegExReplace(text, "91", "Pl")
        text := RegExReplace(text, Chr(34), "4") ; Replace double quotes.
        return text
    }

    static shouldExit() {
        return GuiModeQueue.modeQueueList.GetText(1, 3) = "Ended"
    }

    static isRerollAvailable(rerollButton) {
        Roblox.activate()
        return PixelSearch(&x, &y, rerollButton*)
    }

    static openWindow() {
        Bubble.closeBubbleFullWindow()
        if this.isWindowOpen()
            return

        Loop {
            clickButton(this.BUTTON, 100)
            if this.isWindowOpen()
                break
            Sleep 10
        }

        clickButton(this.TASKS_BUTTON, 1000)
    }

    static isWindowOpen() {
        Roblox.activate()
        p := this.WINDOW_PIXEL
        return PixelSearch(&x, &y, p.x, p.y, p.x, p.y, p.colour, 2)
    }
}

class CompetitiveTasks {
    static setTasks() {
        this.COMPETITIVE_TASKS := Map(
            "Hatch Mythic", {
                regex: "i)myth",
                priority: 9,
                egg: GuiCompete.mythicEggDropdown.Text,
                reroll: GuiCompete.competitiveRerollMythic.Value
            },
            "Hatch Legendary", {
                regex: "i)leg",
                priority: 7,
                egg: GuiCompete.legendaryEggDropdown.Text,
                reroll: GuiCompete.competitiveRerollLegendary.Value
            },
            "Hatch Unique", {
                regex: "i)unique",
                priority: 8,
                egg: GuiCompete.uniqueEggDropdown.Text,
                reroll: GuiCompete.competitiveRerollUnique.Value
            },
            "Hatch Shiny", {
                regex: "i)shiny",
                priority: 6,
                egg: GuiCompete.shinyEggDropdown.Text,
                reroll: GuiCompete.competitiveRerollShiny.Value
            },
            "Hatch Epic", {
                regex: "i)epic",
                priority: 6,
                egg: GuiCompete.epicEggDropdown.Text,
                reroll: GuiCompete.competitiveRerollEpic.Value
            },
            "Play Minutes", {
                regex: "i)minut",
                priority: 99,
                egg: "Infinity",
                reroll: GuiCompete.competitiveRerollTimedEvents.Value
            },
            "Hatch Common", {
                regex: "i)comm",
                priority: 1,
                egg: "Common",
                reroll: false
            },
            "Hatch Spotted", {
                regex: "i)spot",
                priority: 1,
                egg: "Spotted",
                reroll: false
            },
            "Hatch Iceshard", {
                regex: "i)icesh",
                priority: 1,
                egg: "Iceshard",
                reroll: false
            },
            "Hatch Spikey", {
                regex: "i)spik",
                priority: 1,
                egg: "Spikey",
                reroll: false
            },
            "Hatch Magma", {
                regex: "i)mag",
                priority: 1,
                egg: "Magma",
                reroll: false
            },
            "Hatch Crystal", {
                regex: "i)cry",
                priority: 1,
                egg: "Crystal",
                reroll: false
            },
            "Hatch Lunar", {
                regex: "i)lun",
                priority: 1,
                egg: "Lunar",
                reroll: false
            },
            "Hatch Void", {
                regex: "i)void",
                priority: 1,
                egg: "Void",
                reroll: false
            },
            "Hatch Hell", {
                regex: "i)hell",
                priority: 1,
                egg: "Hell",
                reroll: false
            },
            "Hatch Nightmare", {
                regex: "i)night",
                priority: 1,
                egg: "Nightmare",
                reroll: false
            },
            "Hatch Rainbow", {
                regex: "i)rain",
                priority: 1,
                egg: "Rainbow",
                reroll: false
            },
            "Hatch Showman", {
                regex: "i)show",
                priority: 1,
                egg: "Showman",
                reroll: false
            },
            "Hatch Mining", {
                regex: "i)mining",
                priority: 1,
                egg: "Mining",
                reroll: false
            },
            "Hatch Cyber", {
                regex: "i)cyb",
                priority: 1,
                egg: "Cyber",
                reroll: false
            },
            "Hatch Neon", {
                regex: "i)(neo|nep)",
                priority: 1,
                egg: "Neon",
                reroll: false
            },
            "Hatch Eggs", {
                regex: "i)(1,250|950)",
                priority: 20,
                egg: "Infinity",
                reroll: false
            },
        )
    }
}