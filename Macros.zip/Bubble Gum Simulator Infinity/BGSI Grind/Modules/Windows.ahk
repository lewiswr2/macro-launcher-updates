#Requires AutoHotkey v2.0

class Windows {

    static IMAGE_SEARCH_FOLDER := A_ScriptDir "\Assets\ImageSearch\"
    static CLOSE_BUTTON := "CloseButton.bmp"
    static CLOSE_BUTTON_ANGLED := "CloseButtonAngled.bmp"
    static CLOSE_BUTTON_SEARCH_AREA := {x1: 450, y1: 0, x2: 800, y2: 250}

    static closeAllWindows() {
        Roblox.activate()
        Roblox.Leaderboard.close()

        if this.isWindowOpen(&x, &y) {
            location := {x: x + 10, y: y}
            moveLocation(location, 50)
            clickButton(location, 50)
        }

        Roblox.Leaderboard.close()
    }

    static isWindowOpen(&x, &y) {
        area := this.CLOSE_BUTTON_SEARCH_AREA
        image := "*10 " this.IMAGE_SEARCH_FOLDER this.CLOSE_BUTTON
        if ImageSearch(&x, &y, area.x1, area.y1, area.x2, area.y2, image)
            return true
        image := "*10 " this.IMAGE_SEARCH_FOLDER this.CLOSE_BUTTON_ANGLED
        if ImageSearch(&x, &y, area.x1, area.y1, area.x2, area.y2, image)
            return true
        return false
    }

}