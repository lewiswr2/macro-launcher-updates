class Hatching {
    static Timer := 0
    static ClickSpot := {x: 750, y: 50}
    static AfkReportPixel := {x: 244, y: 198, colour: "0x1ca7ea"}
    static AfkContinueButton := {x: 400, y: 398}
    static AfkCloseButton := {x: 569, y: 197}

    static MAX_ATTEMPTS_TO_MOVE_TO_EGG := 5

    static EggProperties := Map(

    ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
    ; @region Eggs: Standard
    ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰  

        "Common", {
            island: "1-0",
            path: [["wd", 250], ["w", 1800], ["wa", 750], ["a", 350]],
            image: "Common_Egg.png",
            icon: "Common_Egg.ico",
            pattern: "i)comm",
            mythic: false,
            active: true
        },
        "Spotted", {
            island: "1-0",
            path: [["wd", 250], ["w", 1800], ["wa", 1250], ["a", 250]],
            image: "Spotted_Egg.png",
            icon: "Spotted_Egg.ico",
            pattern: "i)spot",
            mythic: false,
            active: true
        },
        "Iceshard", {
            island: "1-0",
            path: [["wd", 250], ["w", 2500], ["wa", 1350], ["a", 200]],
            image: "Iceshard_Egg.png",
            icon: "Iceshard_Egg.ico",
            pattern: "i)icesh",
            mythic: false,
            active: true
        },
        "Spikey", {
            island: "1-0",
            path: [["wd", 250], ["w", 2500], ["wa", 1400], ["w", 200]],
            image: "Spikey_Egg.png",
            icon: "Spikey_Egg.ico",
            pattern: "i)spik",
            mythic: true,
            active: true
        },
        "Magma", {
            island: "1-0",
            path: [["wd", 250], ["w", 2500], ["wa", 1250], ["w", 550]],
            image: "Magma_Egg.png",
            icon: "Magma_Egg.ico",
            pattern: "i)mag",
            mythic: true,
            active: true
        },
        "Crystal", {
            island: "1-0",
            path: [["wd", 250], ["w", 2500], ["wa", 900], ["w", 950]],
            image: "Crystal_Egg.png",
            icon: "Crystal_Egg.ico",
            pattern: "i)cry",
            mythic: true,   
            active: true
        },
        "Lunar", {
            island: "1-0",
            path: [["wd", 250], ["w", 2500], ["wa", 500], ["w", 1350]],
            image: "Lunar_Egg.png",
            icon: "Lunar_Egg.ico",
            pattern: "i)lun",
            mythic: true,
            active: true
        },
        "Void", {
            island: "1-0",
            path: [["wd", 250], ["w", 2500], ["wa", 1000], ["wd", 950], ["w", 550]],
            image: "Void_Egg.png",
            icon: "Void_Egg.ico",
            pattern: "i)void",
            mythic: true,
            active: true
        },
        "Hell", {
            island: "1-0",
            path: [["wd", 250], ["w", 2500], ["wd", 400], ["w", 1500]],
            image: "Hell_Egg.png",
            icon: "Hell_Egg.ico",
            pattern: "i)hell",
            mythic: true,
            active: true
        },
        "Nightmare", {
            island: "1-0",
            path: [["wd", 250], ["w", 2500], ["wd", 850], ["w", 1100]],
            image: "Nightmare_Egg.png",
            icon: "Nightmare_Egg.ico",
            pattern: "i)night",
            mythic: true,
            active: true
        },
        "Rainbow", {
            island: "1-0",
            path: [["wd", 250], ["w", 2500], ["wd", 1150], ["w", 700]],
            image: "Rainbow_Egg.png",
            icon: "Rainbow_Egg.ico",
            pattern: "i)rain",
            mythic: true,
            active: true
        },
        "Showman", {
            island: "1-0",
            path: [["wd", 250], ["w", 2500], ["wd", 1450], ["w", 250]],
            image: "Showman_Egg.png",
            icon: "Showman_Egg.ico",
            pattern: "i)show",
            mythic: true,
            active: true
        },
        "Mining", {
            island: "1-0",
            path: [["wd", 250], ["w", 2500], ["wd", 1450], ["d", 100]],
            image: "Mining_Egg.png",
            icon: "Mining_Egg.ico",
            pattern: "i)mining",
            mythic: true,
            active: true
        },
        "Cyber", {
            island: "1-0",
            path: [["wd", 250], ["w", 1800], ["wd", 1200], ["d", 250]],
            image: "Cyber_Egg.png",
            icon: "Cyber_Egg.ico",
            pattern: "i)cyb",
            mythic: true,
            active: true
        },
        "Neon", {
            island: "1-0",
            path: [["wd", 250], ["w", 1800], ["wd", 800], ["d", 300]],
            image: "Neon_Egg.png",
            icon: "Neon_Egg.ico",
            pattern: "i)(neo|nep)",
            mythic: true,
            active: true
        },     
        "Icy", {
            island: "1-0",
            path: [["wd", 250], ["w", 1500], ["a_", 750]],
            image: "Icy_Egg.png",
            icon: "Icy_Egg.ico",
            pattern: "i)icy",
            mythic: true,
            active: true
        },        
        "Vine", {
            island: "1-0",
            path: [["wd", 250], ["w", 1500], ["a_", 750], ["aw", 500]],
            image: "Vine_Egg.png",
            icon: "Vine_Egg.ico",
            pattern: "i)vine",
            mythic: true,
            active: true
        },        
        "Lava", {
            island: "1-0",
            path: [["wd", 250], ["w", 1500], ["a_", 750], ["aw", 850]],
            image: "Lava_Egg.png",
            icon: "Lava_Egg.ico",
            pattern: "i)lava",
            mythic: true,
            active: true
        },        
        "Atlantis", {
            island: "1-0",
            path: [["wd", 250], ["w", 1500], ["a_", 750], ["aw", 1000]],
            image: "Atlantis_Egg.png",
            icon: "Atlantis_Egg.ico",
            pattern: "i)atla",
            mythic: true,
            active: true
        },        
        "Classic", {
            island: "1-0",
            path: [["wd", 250], ["w", 1500], ["a_", 750], ["aw", 1500]],
            image: "Classic_Egg.png",
            icon: "Classic_Egg.ico",
            pattern: "i)classic",
            mythic: true,
            active: true
        },          

    ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
    ; @region Eggs: Special
    ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰   

        "Chance", {
            island: "2-0",
            path: [["w", 2150], ["wd", 1150], ["wa", 1100], ["w", 800]],
            image: "Chance_Egg.png",
            icon: "Chance_Egg.ico",
            pattern: "i)game",
            mythic: true,
            active: true
        },
        "Game", {
            island: "2-0",
            path: [["w", 2150], ["wd", 1150], ["wa", 1100], ["w", 800]],
            image: "Game_Egg.png",
            icon: "Game_Egg.ico",
            pattern: "i)game",
            mythic: true,
            active: false
        },
        "Infinity", {
            island: "1-0",
            path: [["wd", 250], ["w", 2500], ["w", 500]],
            image: "Infinity_Egg.png",
            icon: "Infinity_Egg.ico",
            pattern: "i)infinity",
            mythic: true,
            active: true
        },
        "100M", {
            island: "1-0",
            path: [["as", 800]],
            image: "100M_Egg.png",
            icon: "100M_Egg.ico",
            pattern: "i)100m",
            mythic: false,
            active: false
        },
        "Throwback", {
            island: "1-0",
            path: [["wd", 250], ["w", 2500], ["wd", 1450], ["w", 500]],
            image: "Throwback_Egg.png",
            icon: "Throwback_Egg.ico",
            pattern: "i)throwback",
            mythic: true,
            active: false
        },
        "200M", {
            island: "1-0",
            path: [["as", 800]],
            image: "200M_Egg.png",
            icon: "200M_Egg.ico",
            pattern: "i)200m",
            mythic: true,
            active: false
        },
        "Beach", {
            island: "1-0",
            path: [["sd", 450], ["s", 2600], ["as", 900], ["", 2000], ["sd", 600], ["s", 800]],
            image: "Beach_Egg.png",
            icon: "Beach_Egg.ico",
            pattern: "i)beach",
            mythic: true,
            active: false
        }, 
        "Icecream", {
            island: "1-0",
            path: [["sd", 450], ["s", 2600], ["as", 900], ["", 2000], ["sd", 100], ["s", 1450]],
            image: "Icecream_Egg.png",
            icon: "Icecream_Egg.ico",
            pattern: "i)cream",
            mythic: true,
            active: false
        },                 
        "Fruit", {
            island: "1-0",
            path: [["sd", 450], ["s", 2600], ["as", 900], ["", 2000], ["as", 200], ["s", 1500]],
            image: "Fruit_Egg.png",
            icon: "Fruit_Egg.ico",
            pattern: "i)fruit",
            mythic: true,
            active: false
        },
        "Fossil", {
            island: "1-0",
            path: [["sd", 450], ["s", 2600], ["as", 900], ["", 2000], ["d", 6400], ["", 2000], ["a", 1700], ["as", 1500]],
            image: "Fossil_Egg.png",
            icon: "Fossil_Egg.ico",
            pattern: "i)fossil",
            mythic: true,
            active: false
        },
        "Light", {
            island: "1-0",
            path: [["as", 800]],
            image: "Light_Egg.png",
            icon: "Light_Egg.ico",
            pattern: "i)light",
            mythic: true,
            active: false
        },
        "Dark", {
            island: "1-0",
            path: [["as", 800]],
            image: "Dark_Egg.png",
            icon: "Dark_Egg.ico",
            pattern: "i)dark",
            mythic: true,
            active: false
        },
        "Voidcrystal", {
            island: "1-0",
            path: [["sd", 450], ["s", 2500], ["as", 1100], ["", 2000], ["s", 2500]], 
            image: "Voidcrystal_Egg.png",
            icon: "Voidcrystal_Egg.ico",
            pattern: "i)voidcrystal",
            mythic: true,
            active: false
        },            
        "July4th", {
            island: "1-0",
            path: [["as", 4000], ["s", 250], ["as", 4200], ["", 500], ["a", 1000], ["as", 1200], ["s", 600], ["as", 400]], 
            image: "July4th_Egg.png",
            icon: "July4th_Egg.ico",
            pattern: "i)july",
            mythic: true,
            active: false
        },
        "500M", {
            island: "1-0",
            path: [["sd", 500], ["s", 1100], ["as", 800], ["a", 1000]], 
            image: "500M_Egg.png",
            icon: "500M_Egg.ico",
            pattern: "i)500m",
            mythic: true,
            active: false
        },        
        "Candy", {
            island: "1-0",
            path: [["as", 4000], ["s", 250], ["as", 4200], ["", 500], ["a", 1000], ["as", 1200], ["s", 600], ["as", 400]], 
            image: "Common_Egg.png",
            icon: "Common_Egg.ico",
            pattern: "i)candy",
            mythic: true,
            active: false
        },
        "Shadow", {
            island: "1-0",
            path: [["sd", 750], ["s", 250], ["as", 5000]], 
            image: "500M_Egg.png",
            icon: "500M_Egg.ico",
            pattern: "i)shadow",
            mythic: true,
            active: false
        },
        "Pumpkin", {
            island: "1-0",
            path: [["s", 1500], ["", 3000], ["as", 750]], 
            image: "Pumpkin_Egg.png",
            icon: "Pumpkin_Egg.ico",
            pattern: "i)pumpkin",
            mythic: true,
            active: false
        },
        "Costume", {
            island: "1-0",
            path: [["s", 1500], ["", 3000], ["as", 250], ["a", 500]], 
            image: "Costume_Egg.png",
            icon: "Costume_Egg.ico",
            pattern: "i)costume",
            mythic: true,
            active: false
        },
        "Sinister", {
            island: "1-0",
            path: [["s", 1500], ["", 3000], ["a", 500]], 
            image: "Sinister_Egg.png",
            icon: "Sinister_Egg.ico",
            pattern: "i)sinister",
            mythic: true,
            active: false
        },
        "Mutant", {
            island: "1-0",
            path: [["s", 1500], ["", 3000], ["aw", 750]],  
            image: "Mutant_Egg.png",
            icon: "Mutant_Egg.ico",
            pattern: "i)mutant",
            mythic: true,
            active: false
        },
        "OG", {
            island: "1-0",
            path: [["as", 3500]],  
            image: "OG_Egg.png",
            icon: "OG_Egg.ico",
            pattern: "i)og",
            mythic: true,
            active: true
        },

    )

    static runQueue(mode) {
        Roblox.setTitle(mode["mode"])
        this.moveToEgg(mode["egg"])
        Bubble.closeBubbleFullWindow()
        this.useBuffs(mode)

        end := A_TickCount + (mode["duration"] * 60 * 1000)
        GuiModeQueue.modeQueueList.Modify(1, , , end)

        Timers.Mode.start()

        if mode["duration"]
            Items.PetsTab.selectTeam(mode["petTeam"])

        this.startHatchingEgg()

        Loop {
            Roblox.setTitle(mode["mode"] " | " A_Index)
            duration := GuiModeQueue.modeQueueList.GetText(1, 3)
            if duration = "Ended"
                break

            Keys.send("e")
            Sleep 100

            if !Teleport.isMainGameVisible() {
                Sleep 100
                Keys.send("e")
            }

            MouseMove 750, 50
            Click
        }

        this.moveAwayFromEgg()
        Roblox.setTitle()

    }

    static useBuffs(mode) {
        if !mode["useLucky"] && !mode["useSpeed"] && !mode["useMythic"]
            return false

        Items.open()
        Items.ItemsTab.open()
        if mode["useLucky"] {
            item := "Lucky V"
            Roblox.setTitle(mode["mode"] " | Using " item)
            Items.ItemsTab.useItem(item)
        }
        if mode["useSpeed"] {
            item := "Speed V"
            Roblox.setTitle(mode["mode"] " | Using " item)
            Items.ItemsTab.useItem(item)
        }
        if mode["useMythic"] {
            item := "Mythic V"
            Roblox.setTitle(mode["mode"] " | Using " item)
            Items.ItemsTab.useItem(item)
        }            
        Items.ItemsTab.close()
        Roblox.setTitle()
    }

    static hatchEggFromToolsMenu(eggName) {
        global STOP_MACRO
        Movement.updateModifier(GuiSettings.buffsMasteryDropdown.Text)
        this.moveToEgg(eggName)
        Bubble.closeBubbleFullWindow()
        this.startHatchingEgg()
        STOP_MACRO := false
        startTime := A_TickCount
        Loop {
            elapsed := A_TickCount - startTime
            Roblox.setTitle("Hatching Egg: " eggName " (" this.formatTimeElapsed(elapsed) ") {Press F4 to Stop}")
            if STOP_MACRO {
                Roblox.setTitle("Idle")
                break
            }
            Keys.send("e")
            Sleep 50
        }
    }

    static moveToEgg(eggName) {
        Loop this.MAX_ATTEMPTS_TO_MOVE_TO_EGG {
            if !this.EggProperties.Has(eggName) {
                Roblox.setTitle("Unknown Egg: " eggName)
                return
            }
            egg := this.EggProperties[eggName]

            Roblox.setTitle("Hatching Egg: " eggName)
            Teleport.teleportTo(egg.island)
            Roblox.Leaderboard.close()
            Mouse.holdLeftMouse()
            for _, step in egg.path
                Movement.move(step[1], step[2])
            Mouse.releaseLeftMouse()
            Roblox.setTitle()

            if this.isAtEgg()
                return true

            Roblox.Respawn.resetCharacter()
        }
        return false
    }

    static isAtEgg() {
        imagePath := "*10 " A_ScriptDir "\Assets\ImageSearch\HatchingMultiButton.bmp"
        return ImageSearch(&x, &y, 373, 227, 421, 308, imagePath)        
    }

    static startHatchingEgg() {
        Roblox.activate()
        Loop 5 {
            Keys.send("e")
            Sleep 50
        }
    }

    static moveAwayFromEgg() {
        Movement.move("s", 2000)
        Loop 500 {
            if Teleport.isMainGameVisible()
                break
            Sleep 50
        }
    }

    static isAfkReportOpen() {
        Roblox.activate()
        p := this.AfkReportPixel
        return PixelSearch(&x, &y, p.x, p.y, p.x, p.y, p.colour, 2)
    }

    static closeAfkReportWindow() {
        Loop 3 {
            if this.isAfkReportOpen() {
                Sleep 250
                clickButton(this.AfkCloseButton, 100, 4)
            }
            Sleep 100
        }
    }

    static formatTimeElapsed(ms) {
        totalSeconds := Floor(ms / 1000)
        hours := Floor(totalSeconds / 3600)
        minutes := Floor(Mod(totalSeconds, 3600) / 60)
        seconds := Mod(totalSeconds, 60)
        out := ""
        if hours
            out .= hours "h "
        if minutes
            out .= minutes "m "
        if seconds || (!hours && !minutes)
            out .= seconds "s"
        return Trim(out)
    }
}
