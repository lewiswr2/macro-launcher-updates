#Requires AutoHotkey v2.0

getOcr(x, y, w, h, scale, text := true, border := true) {

   WinGetClientPos &rX, &rY, , , "ahk_exe RobloxPlayerBeta.exe"

   ocrX := rX + x
   ocrY := rY + y

   if border
      ocrPin := createPin(ocrX, ocrY, w, h)

   result := OCR.FromRect(ocrX, ocrY, w, h, , scale)
   
   if border
      ocrPin.Destroy()

   return text ? result.Text : result
   
}

createPin(x, y, w, h) {
   pinX1 := x
   pinY1 := y
   pinX2 := x + w
   pinY2 := y + H

   return Pin(pinX1, pinY1, pinX2, pinY2, 0, "b2 flash0 cred")
}