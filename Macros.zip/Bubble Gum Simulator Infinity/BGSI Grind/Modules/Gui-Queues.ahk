OnMessage(0x0100, ObjBindMethod(GuiModeQueue, "handleKeyDown"))
OnMessage(0x201, ObjBindMethod(GuiModeQueue, "handleMouseDown"))
OnMessage(0x200, ObjBindMethod(GuiModeQueue, "handleMouseMove"))

class GuiModeQueue {

    static gui := ""

    static handleMouseDown(wParam, lParam, msg, hwnd) {
        if (this.gui && hwnd = this.gui.Hwnd && WinActive("ahk_id " hwnd)) {
            PostMessage 0xA1, 2,,, "ahk_id " hwnd  ; WM_NCLBUTTONDOWN, HTCAPTION
        }
    }

    static handleKeyDown(wParam, lParam, msg, hwnd) {
        if (wParam = 0x2E) { ; Delete key
            if (WinActive("ahk_id " this.gui.Hwnd) && this.modeQueueList.Focused) {
                row := this.modeQueueList.GetNext()
                if (row > 0)
                    this.modeQueueList.Delete(row)
            }
        }
    }

    static handleMouseMove(wParam, lParam, msg, hwnd) {
        ctrl := GuiCtrlFromHwnd(hwnd)
        if IsObject(ctrl) && ctrl.Type = "Pic" {
            DllCall("SetCursor", "ptr", DllCall("LoadCursor", "ptr", 0, "ptr", 32649, "ptr"))
        }
    }

    static create() {

        this.gui := Gui("-Caption +Border")
        this.gui.SetFont("s9 c" UI.UI_FONT_COLOUR, "Segoe UI Light")
        this.gui.BackColor := UI.UI_BACKCOLOUR
        
        this.modeImageList := IL_Create()

        ; Mode queue list.
        this.modeQueueList := this.gui.AddListView("w240 h270 r10 Icon Report Grid +ReadOnly -Multi", ["Mode", "Due", "Duration", "Options", "Index"])
        this.modeQueueList.ModifyCol(1, 140)
        this.modeQueueList.ModifyCol(2, 0)
        this.modeQueueList.ModifyCol(3, 70)
        this.modeQueueList.ModifyCol(4, 0)
        this.modeQueueList.ModifyCol(5, 0)

        this.modeQueueList.SetImageList(this.modeImageList)


        info := this.gui.AddText("xp w100", "Reorder Modes")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Reorder Modes", text: "Check or uncheck all options for using boosts." }        

        ; Add the up arrow.
        this.upArrow := this.gui.AddPicture("x+10 w20 h20", GUI_MODES_IMAGE_FOLDER "UpArrow.png")
        UI.TOOLTIP_MAP[this.upArrow.Hwnd] := { title: "Move Up", text: "Move the selected mode up in the order." }
        this.upArrow.OnEvent("Click", (*) => this.swapRow("up"))

        ; Add the down arrow.
        this.downArrow := this.gui.AddPicture("x+5 w20 h20", GUI_MODES_IMAGE_FOLDER "DownArrow.png")
        UI.TOOLTIP_MAP[this.downArrow.Hwnd] := { title: "Move Down", text: "Move the selected mode down in the order." }
        this.downArrow.OnEvent("Click", (*) => this.swapRow("down"))

    }

    static show() {
        this.gui.Show("AutoSize")
        mainGui.GetPos(&x, &y, &w, &h)
        this.gui.Move(x + w - 7, y)
    }

    static swapRow(direction) {
        selected := this.modeQueueList.GetNext()
        totalRows := this.modeQueueList.GetCount()
        if !selected
            return

        ; Determine the target row index
        if (direction = "up" && selected > 1)
            target := selected - 1
        else if (direction = "down" && selected < totalRows)
            target := selected + 1
        else
            return

        ; Swap the values in column 5
        val1 := this.modeQueueList.GetText(selected, 5)
        val2 := this.modeQueueList.GetText(target, 5)

        this.modeQueueList.Modify(selected, "Col5", val2)
        this.modeQueueList.Modify(target, "Col5", val1)

        ; Sort numerically by column 5
        this.modeQueueList.ModifyCol(5, "Sort Integer")

        ; Try to reselect the row that now has the old selected value
        Loop totalRows {
            if (this.modeQueueList.GetText(A_Index, 5) = val2) {
                this.modeQueueList.Modify(A_Index, "Select Vis Focus")
                break
            }
        }
    }



}

OnMessage(0x0100, ObjBindMethod(GuiActionQueue, "handleKeyDown"))
OnMessage(0x201, ObjBindMethod(GuiActionQueue, "handleMouseDown"))

class GuiActionQueue {

    static gui := ""

    static handleMouseDown(wParam, lParam, msg, hwnd) {
        if (this.gui && hwnd = this.gui.Hwnd && WinActive("ahk_id " hwnd)) {
            PostMessage 0xA1, 2,,, "ahk_id " hwnd  ; WM_NCLBUTTONDOWN, HTCAPTION
        }
    }

    static handleKeyDown(wParam, lParam, msg, hwnd) {
        if (wParam = 0x2E) { ; Delete key
            if (WinActive("ahk_id " this.gui.Hwnd) && this.actionQueueList.Focused) {
                row := this.actionQueueList.GetNext()
                if (row > 0)
                    this.actionQueueList.Delete(row)
            }
        }
    }

    static create() {

        this.gui := Gui("-Caption +Border")
        this.gui.SetFont("s9 c" UI.UI_FONT_COLOUR, "Segoe UI Light")
        this.gui.BackColor := UI.UI_BACKCOLOUR
        
        this.actionImageList := IL_Create()

        this.actionQueueList := this.gui.AddListView("w240 h270 r10 Icon Report Grid +ReadOnly -Multi", ["Action", "Due", "Cooldown"])
        this.actionQueueList.ModifyCol(1, 140)
        this.actionQueueList.ModifyCol(2, 0)
        this.actionQueueList.ModifyCol(3, 70)

        this.actionQueueList.SetImageList(this.actionImageList)
    }

    static show() {

        this.gui.Show("AutoSize")
        GuiModeQueue.gui.GetPos(&x, &y, &w, &h)
        this.gui.Move(x + w, y)

    }
}