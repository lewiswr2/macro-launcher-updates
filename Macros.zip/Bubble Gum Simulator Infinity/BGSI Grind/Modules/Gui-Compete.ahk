#Requires AutoHotkey v2.0

OnMessage(0x201, ObjBindMethod(GuiCompete, "handleMouseDown"))
OnMessage(0x0006, ObjBindMethod(GuiCompete, "handleDeactivate"))

class GuiCompete {

    static gui := ""

    static FIRST_COLUMN_X := 10
    static SECOND_COLUMN_X := 220
    static TOP_Y := 10

    static show() {
        this.gui.Show("AutoSize")
        mainGui.GetPos(&x, &y, &w, &h)
        this.gui.Move(x + 6, y + h - 8)  
    }

    static handleMouseDown(wParam, lParam, msg, hwnd) {
        if (this.gui && hwnd = this.gui.Hwnd && WinActive("ahk_id " hwnd)) {
            PostMessage 0xA1, 2,,, "ahk_id " hwnd  ; WM_NCLBUTTONDOWN, HTCAPTION
        }
    }

    static handleDeactivate(wParam, lParam, msg, hwnd) {
        if (wParam = 0 && this.gui && hwnd = this.gui.Hwnd) {
            this.gui.Hide()
        }
    }

    static create() {
        this.gui := Gui("-Caption +Border")
        this.gui.SetFont("s8 c" UI.UI_FONT_COLOUR, "Segoe UI Light")
        this.gui.BackColor := UI.UI_BACKCOLOUR

        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
        ; @region > Timers
        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

        this.gui.AddGroupBox("x" this.FIRST_COLUMN_X " y" this.TOP_Y " Section w200 h70", "Timers").SetFont("w700")
        this.gui.AddPicture("xs+10 yp+20 w30 h30", GUI_COMPETITIVE_IMAGE_FOLDER "Competitive.png")

        this.gui.AddText("x+10 ys+20 w55", "Duration")
        this.competitiveMinutes := this.gui.AddDropDownList("x+10 yp-3 w75", [5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60])
        this.competitiveMinutes.Value := 6

        this.gui.AddText("xs+50 yp+30 w55", "Read Tasks")
        this.competitiveHatchingMinutes := this.gui.AddDropDownList("x+10 yp-3 w75", [1, 2, 3, 4, 5])  
        this.competitiveHatchingMinutes.Value := 2  

        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
        ; @region > Egg Allocations
        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
        this.gui.AddGroupBox("xs Section w200 h145", "Egg Allocations").SetFont("w700")
        this.gui.AddPicture("xs+10 yp+20 w30 h30", GUI_EGG_IMAGE_FOLDER "Eggs.png")

        allEggs := []
        for eggName, eggData in Hatching.EggProperties {
            if eggData.active
                allEggs.Push(eggName)
        }

        this.gui.AddText("x+10 ys+20 w55", "Shiny")
        this.shinyEggDropdown := this.gui.AddDropDownList("x+10 yp-3 w75")
        this.shinyEggDropdown.Add(allEggs)
        this.shinyEggDropdown.Value := 1

        this.gui.AddText("xs+50 yp+30 w55", "Epic")
        this.epicEggDropdown := this.gui.AddDropDownList("x+10 yp-3 w75")  
        this.epicEggDropdown.Add(allEggs)
        this.epicEggDropdown.Value := 1   

        this.gui.AddText("xs+50 yp+30 w55", "Unique")
        this.uniqueEggDropdown := this.gui.AddDropDownList("x+10 yp-3 w75")  
        this.uniqueEggDropdown.Add(allEggs)
        this.uniqueEggDropdown.Value := 1   

        this.gui.AddText("xs+50 yp+30 w55", "Legendary")
        this.legendaryEggDropdown := this.gui.AddDropDownList("x+10 yp-3 w75")  
        this.legendaryEggDropdown.Add(allEggs)
        this.legendaryEggDropdown.Value := 1      

        this.gui.AddText("xs+50 yp+30 w55", "Mythic")
        this.mythicEggDropdown := this.gui.AddDropDownList("x+10 yp-3 w75")
        this.mythicEggDropdown.Add(allEggs)
        this.mythicEggDropdown.Value := 1      

        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
        ; @region > Reroll
        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

        this.gui.AddGroupBox("xs Section w200 h105", "Reroll Tasks").SetFont("w700")
        this.gui.AddPicture("xs+10 yp+20 w30 h30", GUI_COMPETITIVE_IMAGE_FOLDER "Reroll_Orb.png")

        this.chestsSelectAll := this.gui.Add("Text", "x+10 w65 ", "Select All")
        this.chestsSelectAll.SetFont("underline cBlue")
        this.chestsSelectAll.OnEvent("Click", (*) => setCheckBoxes(rerollCheckboxes, true))

        this.chestsSelectNone := this.gui.Add("Text", "x+10 w65 ", "Select None")
        this.chestsSelectNone.SetFont("underline cBlue")
        this.chestsSelectNone.OnEvent("Click", (*) => setCheckBoxes(rerollCheckboxes, false))

        this.competitiveRerollShiny := this.gui.AddCheckbox("xs+50 yp+20 w65", "Shiny")
        this.competitiveRerollEpic := this.gui.AddCheckbox("x+10 yp w65", "Epic")
        this.competitiveRerollUnique := this.gui.AddCheckbox("xs+50 yp+20 w65", "Unique")
        this.competitiveRerollLegendary := this.gui.AddCheckbox("x+10 yp w65", "Legend")
        this.competitiveRerollMythic := this.gui.AddCheckbox("xs+50 yp+20 w65", "Mythic")
        this.competitiveRerollTimedEvents := this.gui.AddCheckbox("x+10 yp w65", "Play")

        rerollCheckboxes := [
            this.competitiveRerollShiny,
            this.competitiveRerollEpic,
            this.competitiveRerollUnique,
            this.competitiveRerollLegendary,
            this.competitiveRerollMythic,
            this.competitiveRerollTimedEvents,
        ]

        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
        ; @region > Stars
        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

        this.gui.AddGroupBox("Section x" this.SECOND_COLUMN_X " y" this.TOP_Y " w200 h60", "Stars").SetFont("w700")
        this.gui.AddPicture("xs+10 yp+20 w30 h30", GUI_COMPETITIVE_IMAGE_FOLDER "Competitive_Stars.png")    
        this.gui.SetFont("s8 c" UI.UI_FONT_COLOUR, "Segoe UI Light")
        this.gui.BackColor := UI.UI_BACKCOLOUR

        this.competeStarsTotal := this.gui.AddText("x+10 ys+20 w100 h30", 0)
        this.competeStarsTotal.SetFont("s14 c" UI.UI_FONT_COLOUR, "Segoe UI Light") 

        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
        ; @region > Tasks
        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

        this.gui.AddGroupBox("xs Section Section w200 h115", "Tasks").SetFont("w700")
        
        this.competeTaskList := this.gui.AddListView("xs+10 yp+20 w180 h80 r2 +ReadOnly", ["Task", "No.", "%", "Priority", "Egg", "Reroll", "Index", "Hatches", "MinHatches"])
        this.competeTaskList.ModifyCol(1, 100)
        this.competeTaskList.ModifyCol(2, 40)
        this.competeTaskList.ModifyCol(3, 30)
        this.competeTaskList.ModifyCol(4, 0)
        this.competeTaskList.ModifyCol(5, 0)
        this.competeTaskList.ModifyCol(6, 0)
        this.competeTaskList.ModifyCol(7, 0)
        this.competeTaskList.ModifyCol(8, 0)
        this.competeTaskList.ModifyCol(9, 0)
        this.competeTaskList.ModifyCol(4, "Sort")

    }
}