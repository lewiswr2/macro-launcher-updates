#Requires AutoHotkey v2.0

class Reconnect {
    static PLACE_ID := 85896571713843

    ; Buttons.
    static PLAY_BUTTON := {x: 396, y: 323}
    static OPTIMIZED_BUTTON := {x: 508, y: 382}

    ; Pixel checks.
    static TITLE_SCREEN_PLAY_BUTTON := [308, 265, 493, 333, "0x40ea20", 2]
    static DISPLAY_SCREEN_BUTTONS := [198, 212, 601, 384, "0x217bd9", 2]
    static ROBLOX_MENU_CHAT_BUTTON := [126, 12, 162, 55, "0x121215", 2]

    static reconnectFromMenu() {
        Roblox.setTitle("Reconnecting")
        try Run this.getRunCommand()
        Sleep 5000
        this.waitForTitleScreen()
        this.waitForDisplaySelectionScreen()
        this.waitForGameScreen()
    }

    static reconnect() {
        this.reconnectFromMenu()
        Camera.setOverhead()
        Camera.zoomOut(2000)
        Roblox.Leaderboard.close()        
    }

    static getRunCommand() {
        command := "roblox://placeID=" this.PLACE_ID
        if GuiActions.timedReconnectPrivateLinkCode.Value != "" {
            command .= "&linkCode=" GuiActions.timedReconnectPrivateLinkCode.Value
        }
        return command
    }

    static waitForTitleScreen() {
        Loop {
            Roblox.setTitle("Reconnecting | Waiting for Title Screen (" A_Index ")")
            if PixelSearch(&x, &y, this.TITLE_SCREEN_PLAY_BUTTON*) {
                Roblox.setTitle("Reconnecting | Clicking Play Button")
                clickButton(this.PLAY_BUTTON, 100)
                break
            }
            Sleep 500
        }
        Roblox.setTitle()
    }

    static waitForDisplaySelectionScreen() {
        Loop {
            Roblox.setTitle("Reconnecting | Waiting for Display Selection (" A_Index ")")
            if PixelSearch(&x, &y, this.DISPLAY_SCREEN_BUTTONS*) {
                Roblox.setTitle("Reconnecting | Clicking Optimized Button")
                clickButton(this.OPTIMIZED_BUTTON, 100)
                break
            }
            Sleep 500
        }
        Roblox.setTitle()
    }

    static waitForGameScreen() {
        Loop {
            Roblox.setTitle("Reconnecting | Waiting for Game Screen (" A_Index ")")
            if PixelSearch(&x, &y, this.ROBLOX_MENU_CHAT_BUTTON*)
                break
            Sleep 500
        }
        Roblox.setTitle()
    }
}
