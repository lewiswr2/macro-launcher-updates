#Requires AutoHotkey v2.0

; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
; @region ISLANDS
; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

class Islands {
    static NUMBER := Map(
        "1-0", {index: 1, name: "The Overworld", image: "TheOverworld.bmp"},
        "1-1", {index: 2, name: "Floating Island", image: "FloatingIsland.bmp"},
        "1-2", {index: 3, name: "Outer Space", image: "OuterSpace.bmp"},
        "1-3", {index: 4, name: "Twilight", image: "Twilight.bmp"},
        "1-4", {index: 5, name: "The Void", image: "TheVoid.bmp"},
        "1-5", {index: 6, name: "Zen", image: "Zen.bmp"},
        "2-0", {index: 7, name: "Minigame Paradise", image: "MinigameParadise.bmp"},
        "2-1", {index: 8, name: "Dice Island", image: "DiceIsland.bmp"},
        "2-2", {index: 9, name: "Minecart Forest", image: "MinecartForest.bmp"},
        "2-3", {index: 10, name: "Robot Factory", image: "RobotFactory.bmp"},
        "2-4", {index: 11, name: "Hyperwave Island", image: "HyperwaveIsland.bmp"},
        "3-0", {index: 12, name: "Seven Seas", image: "SevenSeas.bmp"},
        "3-1", {index: 13, name: "Blizzard Hills"},
        "3-2", {index: 14, name: "Poison Jungle"},
        "3-3", {index: 15, name: "Infernite Volcano"},
        "3-4", {index: 16, name: "Lost Atlantis"},
        "3-5", {index: 17, name: "Dream Island"},
        "3-6", {index: 18, name: "Classic Island"},
    )
}

; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
; @region TELEPORT
; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

class Teleport {
    static BUTTON_AREA := [325, 531, 474, 579, "0x5bee1a"]
    static MAX_TRIES := 10
    static ISLAND_SEARCH_AREA := {x1: 250, y1: 0, x2: 550, y2: 525}
    static IMAGE_FOLDER := A_ScriptDir "\Assets\Map\"

    static BUTTON := {x: 337, y: 566}
    static MOVE_UP_BUTTON := {x: 649, y: 133}
    static MOVE_DOWN_BUTTON := {x: 649, y: 467}
    static CLOSE_BUTTON := {x: 720, y: 58}
    static DOWN_ARROW_PIXEL := [648, 468, 648, 468, "0xffffff"]
    static BUBBLE_GUM_PIXEL := [15, 313, 51, 433,"0xff66c4"]
    static SCROLL_LOCATION := {x: 649, y: 133}
    static SURROUND_ISLANDS := Map(
        13, {x: 490, y: 80},   ; Blizzard Hills
        14, {x: 350, y: 80},   ; Poison Jungle
        15, {x: 230, y: 130},  ; Infernite Volcano
        16, {x: 160, y: 240},  ; Lost Atlantis
        17, {x: 150, y: 370},  ; Dream Island
        18, {x: 200, y: 500}   ; Classic Island
)

    static MAX_MAP_LOOPS := 50

    static isOpen() {
        Roblox.activate()
        return PixelSearch(&x, &y, this.BUTTON_AREA*)
    }

    static openMenu() {
        Loop this.MAX_TRIES {
            ;Roblox.setTitle("Opening the Map (" A_Index "/" this.MAX_TRIES ")")
            Roblox.activate()

            moveLocation(this.MOVE_DOWN_BUTTON, 100)

            if this.isOpen()
                return true

            Keys.send("m")

            Loop 100 {
                if !this.isMainGameVisible() && this.isOpen()
                    return true
                Sleep 100
            }

            Sleep 100
        }
        return false
    }

    static teleportTo(number) {
        this.openMenu()
        Roblox.Leaderboard.close()
        
        Loop 5 {
            if this.findAndClick(number)
                break
        }
        
        this.clickTeleport()
        Roblox.Leaderboard.close()
        Bubble.closeBubbleFullWindow()
    }

    static findAndClick(number) {
        a := this.ISLAND_SEARCH_AREA
        image := "*5 " this.IMAGE_FOLDER Islands.NUMBER[number].image
        index := Islands.NUMBER[number].index
        
        currentIsland := this.findCurrentIsland()

        Loop this.MAX_MAP_LOOPS {
            if index > currentIsland
                clickButton(this.MOVE_UP_BUTTON, 250, 1)
            else if index < currentIsland
                clickButton(this.MOVE_DOWN_BUTTON, 250, 1)

            if ImageSearch(&x, &y, a.x1, a.y1, a.x2, a.y2, image) {
                moveLocation({x: x, y: y}, 20)
                clickButton({x: x, y: y}, 25)
                return true
            }
        }
        return false
    }
    
    static navigateToIsland(targetIndex) {
        a := this.ISLAND_SEARCH_AREA
        image := "*5 " this.IMAGE_FOLDER Islands.NUMBER["3-0"].image
        currentIsland := this.findCurrentIsland()

        Loop this.MAX_MAP_LOOPS {
            if targetIndex > currentIsland
                clickButton(this.MOVE_UP_BUTTON, 250, 1)
            else if targetIndex < currentIsland
                clickButton(this.MOVE_DOWN_BUTTON, 250, 1)

            if ImageSearch(&x, &y, a.x1, a.y1, a.x2, a.y2, image) {
                return true
            }
            
            ; Update current position
            currentIsland := this.findCurrentIsland()
        }
        return false
    }

    static findCurrentIsland() {
        Roblox.activate()
        for key, island in Islands.NUMBER {
            imagePath := this.IMAGE_FOLDER island.image
            if ImageSearch(&x, &y, 150, 200, 650, 400, "*5 " imagePath)
                return island.index 
        }
        return 0
    }


    static scrollToBottom() {
        Loop 100 {
            if !this.canScrollDown()
                break
            clickButton(this.MOVE_DOWN_BUTTON, 50, 1)
        }
    }

    static canScrollDown() {
        Roblox.activate()
        return PixelSearch(&x, &y, this.DOWN_ARROW_PIXEL*)
    }

    static moveToScrollLocation() {
        Roblox.activate()
        MouseMove this.BUTTON.x, this.BUTTON.y
        MouseMove 1, 0, , "R"
        Sleep 10
        MouseMove this.SCROLL_LOCATION.x, this.SCROLL_LOCATION.y
        MouseMove 1, 0, , "R"
    }

    static clickTeleport() {
        Roblox.activate()
        clickButton(this.BUTTON, 10, 5)
        Loop 100 {
            if this.isMainGameVisible()
                return true
            Sleep 10
        }
        return false
    }

    static isMainGameVisible() {
        Roblox.activate()
        return PixelSearch(&x, &y, this.BUBBLE_GUM_PIXEL*)
    }

    static closeMenu() {
        Loop this.MAX_TRIES {
            if !this.isOpen()
                break
            clickButton(this.CLOSE_BUTTON, 100, 1)
        }
        Roblox.Leaderboard.close()
    }
}
