#Requires AutoHotkey v2.0

class Logs {

    static FOLDER := ""
    static DATE_TODAY := FormatTime(A_Now, "yyyyMMdd")

    static getLogFolder() {
        try {
            processPath := WinGetProcessPath("ahk_exe Psycho Hatcher.exe")
        } catch {
            processPath := ""
        }

        if processPath
            this.FOLDER := StrReplace(processPath, "Psycho Hatcher.exe", "") "Logs\\BGSI\\"
        else
            this.FOLDER := A_ScriptDir "\Logs\"
    }

    static writeOcrLog(message) {
        this.getLogFolder()
        logDateTime := FormatTime(A_Now, "yyyy-MM-dd HH:mm:ss")
        logFile := this.FOLDER "OCR_" this.DATE_TODAY ".log"
        
        formattedMessage := "[" logDateTime "]   " message "`n"
        try {
            FileAppend(formattedMessage, logFile)
        }
    }

}