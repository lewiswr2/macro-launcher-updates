#Requires AutoHotkey v2.0

class Enchant {

    static ENCHANT_MAP := Map(
        "0xff85d4", "Bubbler V",
        "0xff0a0a", "Infinity",
        "0xff5289", "High Roller",
        "0x5eff52", "Team Up V",
        "0xffed25", "Looter V",
        "0xffffff", "Magnetism",
        "0xa14eff", "Gleaming III",
        "0xff0000", "Determination",
        "0x5555fe", "Secret Hunter",
        "0xbdff07", "Ultra Roller",
        "0xf2cb25", "Shiny Seeker",

    )

    static ENCHANTING_IN_PROGRESS_SEARCH_AREA := [280, 168, 395, 259, "0x7ecdf4", 2]
    
    static CHANGE_PET_BUTTON := {x: 177, y: 144}

    static DISCOVERED_ENCHANTS_AREA := {x: 277, y: 169, w: 147, h: 350}
    
    static SCROLL_BAR_TOP_LOCATION := [699, 171, 699, 171, "0xa9e0fa", 2]
    static SCROLL_BAR_BOTTOM_LOCATION := [699, 505, 699, 505, "0xa9e0fa", 2]
    
    static MOUSE_SCROLL_LOCATION := {x: 533, y: 172}

    static ARE_YOU_SURE_REROLL_BUTTON := {x: 333, y: 360}

    static AUTO_REROLL_SEARCH := {x1: 442, y1: 220, x2: 527, y2: 512}

    static SELECT_CURRENCY_GEMS_BUTTON := {x: 280, y: 370}

    static DOUBLE_CHECK_AREA := {x1: 115, y1: 335, x2: 250, y2: 430}

    static getEnchantName(x, y) {
        area := {x1: x - 140, y1: y - 60, x2: x - 40, y2: y - 40}   
        for colour, name in this.ENCHANT_MAP {
            if PixelSearch(&x, &y, area.x1, area.y1, area.x2, area.y2, colour, 2) {
                return name
            }                        
        }
        return "not identified"
    }

    static applyEnchant(enchant) {
        Hotkey("RButton", "Off")

        if GuiTools.enchantPetList.GetCount() == 0 {
            MsgBox "No pets selected to enchant.", MACRO_TITLE, 0x30
            return
        }
        
        GuiTools.show()
        Loop {
            
            x  := GuiTools.enchantPetList.GetText(1, 1)
            y  := GuiTools.enchantPetList.GetText(1, 2)

            Roblox.activate()
            clickButton({x: x, y: y}, 500, 1)
            

            this.scrollToTop()
            found := false

            yOffset := this.AUTO_REROLL_SEARCH.y1

            Loop {
                if this.findAutoRerollButton(&x, &y, yOffset) {
                    name := this.getEnchantName(x, y)
                    
                    if name == enchant
                        break

                    yOffset := y + 10
                }
                else {
                    if this.isScrollBarAtBottom()
                        break

                    scrollMouseWheel("down", 1)
                    yOffset := this.AUTO_REROLL_SEARCH.y1
                    Sleep 500
                }
            }

            clickButton({x: x + 10, y: y}, 50)
            Sleep 500
            clickButton(this.ARE_YOU_SURE_REROLL_BUTTON, 50)
            Sleep 500
            clickButton(this.SELECT_CURRENCY_GEMS_BUTTON, 50)

            maxTime := A_TickCount + 300000
            timedOut := false
            Loop {
                secondsLeft := Round((maxTime - A_TickCount) / 1000)
                if (secondsLeft < 0)
                    secondsLeft := 0

                Roblox.setTitle("Enchanting (" secondsLeft "s)")

               if this.isEnchantingDone() {
                    area := this.DOUBLE_CHECK_AREA
                    doubleCheckName := "not identified"
                    for colour, name in this.ENCHANT_MAP {
                        if PixelSearch(&x, &y, area.x1, area.y1, area.x2, area.y2, colour, 2) {
                            doubleCheckName := name
                            break
                        }
                    }
                    if doubleCheckName == enchant
                        break
                    else {
                        this.scrollToTop()
                        continue 2
                    }
                }

                if (A_TickCount > maxTime) {
                    timedOut := true
                    break
                }

                Sleep 500
            }

            clickButton(this.CHANGE_PET_BUTTON, 500)

            if timedOut
                continue
            
            GuiTools.enchantPetList.Delete(1)
            if GuiTools.enchantPetList.GetCount() == 0
                break

        }
    }

    static findAutoRerollButton(&x, &y, yOffset) {
        area := this.AUTO_REROLL_SEARCH
        return PixelSearch(&x, &y, area.x1, yOffset, area.x2, area.y2, "0xb26dff", 2)
    }

    static scrollToTop() {
        moveLocation(this.MOUSE_SCROLL_LOCATION, 50)
        Loop {
            if this.isScrollBarAtTop()
                break
            scrollMouseWheel("up", 1)
        }
    }

    static isScrollBarAtTop() {
        Roblox.activate()
        return PixelSearch(&x, &y, this.SCROLL_BAR_TOP_LOCATION*)
    }

    static isScrollBarAtBottom() {
        Roblox.activate()
        return PixelSearch(&x, &y, this.SCROLL_BAR_BOTTOM_LOCATION*)
    }    

    static isEnchantingDone() {
        Roblox.activate()
        return PixelSearch(&x, &y, this.ENCHANTING_IN_PROGRESS_SEARCH_AREA*)
    }

}