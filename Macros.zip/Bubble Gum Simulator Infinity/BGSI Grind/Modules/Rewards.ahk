#Requires AutoHotkey v2.0



; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
; @region INDEX REWARDS.
; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

INDEX_BUTTON := {x: 759, y: 543} ; Button to open the index menu.
INDEX_INDICATOR_AREA := {x1: 717, y1: 512, x2: 740, y2: 530, colour: "0xff2929"} ; Area where the index reward indicator appears.
INDEX_PETS_BUTTON := {x: 495, y: 149} ; Button to select the pets tab.
INDEX_NORMAL_BUTTON := {x: 197, y: 165} ; Button to select the normal pets list.
INDEX_SHINY_BUTTON := {x: 287, y: 165} ; Button to select the shiny pets list.
INDEX_SCROLL_LOCATION := {x: 377, y: 221} ; Location to move to for scrolling the index window.
INDEX_CLAIM_AREA := {x1: 188, y1: 197, x2: 297, y2: 452, colour: "0x3be921"} ; Area to search for claimable index rewards.
INDEX_CLOSE_BUTTON := {x: 713, y: 125} ; Button to close the index window.
INDEX_COOLDOWN := 120

; Checks if index rewards are available to claim.
areIndexRewardsAvailable() {
    area := INDEX_INDICATOR_AREA
    return PixelSearch(&x, &y, area.x1, area.y1, area.x2, area.y2, area.colour, 2)
}

; Claims the available index rewards.
claimIndexRewards() {

    Teleport.closeMenu()

    ; Check if index rewards are available.
    if !areIndexRewardsAvailable()
        return

    ; Close the Roblox.Leaderboard if it is open.
    Roblox.Leaderboard.close()

    ; Open the index menu.
    clickButton(INDEX_BUTTON, 1000, 1)

    ; Update status to claiming index rewards.
    Roblox.setTitle("Claiming index rewards")

    ; Click the pets button.
    clickButton(INDEX_PETS_BUTTON, 500)

    ; Click the normal pets button.
    clickButton(INDEX_NORMAL_BUTTON, 500)

    ; Move to the scroll location.
    moveLocation(INDEX_SCROLL_LOCATION, 500)
    
    ; Claim normal index rewards.
    findClaimButtons(INDEX_CLAIM_AREA, INDEX_SCROLL_LOCATION, 10, 500)

    ; Click the shiny pets button.
    clickButton(INDEX_SHINY_BUTTON, 500)

    ; Move to the scroll location.
    moveLocation(INDEX_SCROLL_LOCATION, 500)

    ; Claim shiny index rewards.
    findClaimButtons(INDEX_CLAIM_AREA, INDEX_SCROLL_LOCATION, 10, 500)

    ; Close the index window.
    clickButton(INDEX_CLOSE_BUTTON, 1000)

    ; Clear the status update.
    Roblox.setTitle()
}

; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
; @region SEASON REWARDS.
; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

SEASON_BUTTON := {x: 756, y: 326} ; Button to open the season menu.
SEASON_INDICATOR_AREA := {x1: 720, y1: 295, x2: 740, y2: 312, colour: "0xff2929"} ; Area where the season reward indicator appears.
SEASON_REWARDS_BUTTON := {x: 370, y: 126} ; Button to select the rewards tab.
SEASON_CLAIM_AREA := {x1: 160, y1: 194, x2: 636, y2: 247, colour: "0x3be921"} ; Area to search for claimable season rewards.
SEASON_SCROLL_LOCATION := {x: 377, y: 364} ; Location to move to for scrolling the rewards window.
SEASON_CLOSE_BUTTON := {x: 614, y: 128} ; Button to close the season window.
SEASON_COOLDOWN := 20

; Checks if season rewards are available to claim.
areSeasonRewardsAvailable() {
    area := SEASON_INDICATOR_AREA
    return PixelSearch(&x, &y, area.x1, area.y1, area.x2, area.y2, area.colour, 2)
}

; Claims the available season rewards.
claimSeasonRewards(checkIndicator := true) {

    Teleport.closeMenu()

    ; Check if season rewards are available.
    if checkIndicator && !areSeasonRewardsAvailable()
        return

    ; Close the Roblox.Leaderboard if it is open.
    Roblox.Leaderboard.close()

    ; Open the season menu.
    clickButton(SEASON_BUTTON, 1000, 1)

    ; Update status to claiming season rewards.
    Roblox.setTitle("Claiming season rewards")

    ; Click the rewards tab button.
    clickButton(SEASON_REWARDS_BUTTON, 500)

    ; Move to the scroll location.
    moveLocation(SEASON_SCROLL_LOCATION, 500)

    ; Claim available rewards.
    findClaimButtons(SEASON_CLAIM_AREA, SEASON_SCROLL_LOCATION, 15, 1000, true)

    ; Close the season window.
    clickButton(SEASON_CLOSE_BUTTON, 1000)

    ; Clear the status update.
    Roblox.setTitle()
}

; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
; @region QUESTS REWARDS.
; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

QUESTS_INDICATOR_AREA := {x1: 64, y1: 252, x2: 83, y2: 266, colour: "0xff2929"}  ; Area where the quest reward indicator appears.
QUESTS_BUTTON := {x: 91, y: 276}  ; Button to open the quests menu.
QUESTS_BUBBLES_BUTTON := {x: 179, y: 292}  ; Button to select the bubbles tab.
QUESTS_EGGS_BUTTON := {x: 179, y: 345}  ; Button to select the eggs tab.
QUESTS_CLAIM_AREA := {x1: 375, y1: 201, x2: 486, y2: 441, colour: "0xe251d0"}  ; Area to search for claimable rewards.
QUESTS_SCROLL_LOCATION := {x: 555, y: 212}  ; Location to move to for scrolling the quests window.
QUESTS_CLOSE_BUTTON := {x: 554, y: 164}  ; Button to close the quests window.
QUESTS_COOLDOWN := 20

; Checks if quest rewards are available to claim.
areQuestRewardsAvailable() {
    area := QUESTS_INDICATOR_AREA
    return PixelSearch(&x, &y, area.x1, area.y1, area.x2, area.y2, area.colour, 2)
}

claimQuestRewards() {

    Teleport.closeMenu()

    ; Check if quest rewards are available.
    if !areQuestRewardsAvailable()
        return

    ; Close the Roblox.Leaderboard if it is open.
    Roblox.Leaderboard.close()

    ; Open the quests menu.
    clickButton(QUESTS_BUTTON, 1000, 1)

    ; Update status to claiming quest rewards.
    Roblox.setTitle("Claiming quest rewards")

    ; Click the bubbles tab button.
    clickButton(QUESTS_BUBBLES_BUTTON, 500)

    ; Move to the scroll location.
    moveLocation(QUESTS_SCROLL_LOCATION, 500)

    ; Claim rewards in the bubbles tab.
    findClaimButtons(QUESTS_CLAIM_AREA, QUESTS_SCROLL_LOCATION, 8, 1000, false, 10)

    ; Click the eggs tab button.
    clickButton(QUESTS_EGGS_BUTTON, 500)

    ; Move to the scroll location.
    moveLocation(QUESTS_SCROLL_LOCATION, 500)

    ; Claim rewards in the eggs tab.
    findClaimButtons(QUESTS_CLAIM_AREA, QUESTS_SCROLL_LOCATION, 8, 1000, false, 10)

    ; Close the quests window.
    clickButton(QUESTS_CLOSE_BUTTON, 1000)

    ; Clear the status update.
    Roblox.setTitle()
}



; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
; @region SHARED FUNCTIONS
; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

findClaimButtons(area, location, times, delay, earlyExit := false, clicks := 1) {
    ; Scroll up to reset the scroll position.
    scrollMouseWheel("Up", times)

    Loop times {
        ; Activate Roblox window.
        Roblox.activate()

        ; Search for the button colour in the given area.
        if PixelSearch(&x, &y, area.x1, area.y1, area.x2, area.y2, area.colour, 5) {
            ; If found, move to the button and click it.
            found := {x: x, y: y}
            moveLocation(found, 100)
            clickButton(found, 100, clicks)

            ; Move mouse back to the original location.
            moveLocation(location, 500)
        }
        else if earlyExit
            break

        ; Scroll down to search the next area.
        scrollMouseWheel("Down")

        Sleep delay
    }
}

