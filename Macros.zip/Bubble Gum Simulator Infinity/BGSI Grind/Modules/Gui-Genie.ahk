#Requires AutoHotkey v2.0

OnMessage(0x201, ObjBindMethod(GuiGenie, "handleMouseDown"))
OnMessage(0x0006, ObjBindMethod(GuiGenie, "handleDeactivate"))

class GuiGenie {

    static gui := ""

    static FIRST_COLUMN_X := 10
    static SECOND_COLUMN_X := 220
    static TOP_Y := 10

    static show() {
        this.gui.Show("AutoSize")
        this.gui.GetPos(&x, &y, &w, &h)
        this.gui.Move(x + 6, y + h - 8)      
    }

    static handleMouseDown(wParam, lParam, msg, hwnd) {
        if (this.gui && hwnd = this.gui.Hwnd && WinActive("ahk_id " hwnd)) {
            PostMessage 0xA1, 2,,, "ahk_id " hwnd  ; WM_NCLBUTTONDOWN, HTCAPTION
        }
    }

    static handleDeactivate(wParam, lParam, msg, hwnd) {
        if (wParam = 0 && this.gui && hwnd = this.gui.Hwnd) {
            this.gui.Hide()
        }
    }

    static create() {
        this.gui := Gui("-Caption +Border")
        this.gui.SetFont("s8 c" UI.UI_FONT_COLOUR, "Segoe UI Light")
        this.gui.BackColor := UI.UI_BACKCOLOUR

        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
        ; @region > Gem Genie
        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

        this.questingCheckbox := this.gui.AddCheckbox("x" this.FIRST_COLUMN_X " y" this.TOP_Y " w200 Section", "Quest")
        this.questingCheckbox.SetFont("w700")

        this.gui.AddGroupBox("xs yp+20 Section w200 h150", "Gem Genie Tasks").SetFont("w700")

        this.gui.AddPicture("xs+10 yp+20 w30 h30", GUI_GENIE_IMAGE_FOLDER "Gem_Genie.png")
        this.gemGenieCheckbox := this.gui.AddCheckbox("x+10 w100", "Choose Destiny")
        this.genieDoTasksCheckbox := this.gui.AddCheckbox("xs+50 yp+20 w100 Disabled", "Do Tasks")
        
        this.genieTaskList := this.gui.AddListView("xs+10 yp+20 w180 h80 +ReadOnly", ["Task", "Source"])
        this.genieTaskList.ModifyCol(1, 125)
        this.genieTaskList.ModifyCol(2, 50)

    }
}