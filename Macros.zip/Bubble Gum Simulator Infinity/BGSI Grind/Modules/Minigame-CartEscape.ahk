#Requires AutoHotkey v2.0


/*
class CartEscape {

    ; Image searches.
    static IMAGES_MINIGAMES_FOLDER := A_ScriptDir "\Assets\Images\Minigames\CartEscape"
    static ACTIONS_SEARCH := {x1: 200, y1: 100, x2: 600, y2: 500}
    static ACTIONS := Map(
        "Duck", this.IMAGES_MINIGAMES_FOLDER "\Duck.png",
        ;"Duck", this.IMAGES_MINIGAMES_FOLDER "\k.png",
        ;"Duck", this.IMAGES_MINIGAMES_FOLDER "\D.png",
        ;"Right", this.IMAGES_MINIGAMES_FOLDER "\R.png",
        ;"Left", this.IMAGES_MINIGAMES_FOLDER "\L.png",
    )

    static JUMP_MODE := false

    static run() {
        Loop {
            Roblox.setTitle("Cart Escape (" A_Index ")")
            Roblox.activate()
            
            area := this.ACTIONS_SEARCH
            for name, imagePath in this.ACTIONS {
                
                if ImageSearch(&x, &y, area.x1, area.y1, area.x2, area.y2, "*Transff0000 *5 " imagePath) {
                    Roblox.activate()                    
                    switch name {
                        case "Duck":
                            Send "{s down}"
                            Sleep 1000
                            Send "{s up}"
                            break
                        case "Right":
                            Send "{d down}"
                            Sleep 1000
                            Send "{d up}"
                            break
                        case "Left":
                            Send "{a down}"
                            Sleep 1000
                            Send "{a up}"
                            break                            
                    }
                }
                ;else
                ;    Keys.send("w")

            }
            ;else
            ;    Keys.send("w")            

        } 
    }

}


/*
    Loop {
        text := getOcr(200, 100, 600, 500, 1)
        if text != "" {
            if RegExMatch(text, "i)left") {
                unholdKeys()
                Keys.send("a", "down")
            }
            else if RegExMatch(text, "i)ri") {
                unholdKeys()
                Keys.send("d", "down")
            }
            else if RegExMatch(text, "i)duck") {
                unholdKeys()
                Keys.send("s", "down")
            }
            else if RegExMatch(text, "i)jump") {
                unholdKeys()
                JUMP_MODE := true
            }
            else if RegExMatch(text, "i)win") {
                break
            }            
        }
        
        if JUMP_MODE
            Keys.send("w")

        ;Logs.writeOcrLog(text)
        Sleep 100
    }
msgbox "done"


unholdKeys() {
    Keys.send("a", "up")
    Keys.send("s", "up")
    Keys.send("d", "up")
    JUMP_MODE := false
}