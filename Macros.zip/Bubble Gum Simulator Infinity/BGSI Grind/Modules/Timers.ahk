#Requires AutoHotkey v2.0

class Timers {

    class Mode {
        static IS_RUNNING := false
        static TIMER_FUNC := ""

        static init() {
            this.TIMER_FUNC := ObjBindMethod(this, "refresh")
        }

        static start() {
            if !this.IS_RUNNING {
                if !this.TIMER_FUNC
                    this.TIMER_FUNC := ObjBindMethod(this, "refresh")

                SetTimer(this.TIMER_FUNC, 1000)
                this.IS_RUNNING := true
            }
        }

        static stop() {
            if this.IS_RUNNING {
                SetTimer(this.TIMER_FUNC, 0)
                this.IS_RUNNING := false
            }            
        }

        static refresh() {
            if GuiModeQueue.modeQueueList.GetCount() = 0
                return

            runTime := GuiModeQueue.modeQueueList.GetText(1, 2)
            if !runTime
                return

            remaining := runTime - A_TickCount
            cooldown := (remaining <= 0) ? "Ended" : formatTimeMs(remaining)
            GuiModeQueue.modeQueueList.Modify(1, , , , cooldown)
        }

        static reset() {
            this.stop()
            this.start()
        }

    }

    class Action {
        static IS_RUNNING := false
        static TIMER_FUNC := ""

        static init() {
            this.TIMER_FUNC := ObjBindMethod(this, "refresh")
        }

        static start() {
            if !this.IS_RUNNING {
                if !this.TIMER_FUNC
                    this.TIMER_FUNC := ObjBindMethod(this, "refresh")

                SetTimer(this.TIMER_FUNC, 1000)
                this.IS_RUNNING := true
            }
        }

        static stop() {
            if this.IS_RUNNING {
                SetTimer(this.TIMER_FUNC, 0)
                this.IS_RUNNING := false
            }            
        }

        static refresh() {

            Loop GuiActionQueue.actionQueueList.GetCount() {
                row := A_Index
                runTime := GuiActionQueue.actionQueueList.GetText(row, 2)
                if !runTime
                    continue

                remaining := runTime - A_TickCount
                cooldown := (remaining <= 0) ? "Ready" : formatTimeMs(remaining)
                GuiActionQueue.actionQueueList.Modify(row, , , , cooldown)
            }
        }

        static reset() {
            this.stop()
            this.start()
        }        
    }
}