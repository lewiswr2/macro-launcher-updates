#Requires AutoHotkey v2.0

class Actions {

    static isActionReady() {
        if GuiActionQueue.actionQueueList.GetCount() = 0
            return false
        if GuiActionQueue.actionQueueList.GetText(1, 3) == "Ready"
            return true
        return false
    }

    static doNextAction() {
        if GuiActionQueue.actionQueueList.GetCount() = 0 {
            global QUEUE := "Mode"
            return      
        }

        firstRow := Map(
            "Action",   GuiActionQueue.actionQueueList.GetText(1, 1),
            "RunTime",  GuiActionQueue.actionQueueList.GetText(1, 2),
            "Cooldown", GuiActionQueue.actionQueueList.GetText(1, 3)
        )

        if (firstRow["Cooldown"] != "Ready") {
            global QUEUE := "Mode"
            return
        }

        action := firstRow["Action"]
        roblox.setTitle("Action: " action)

        for entry in this.ActionList {
            if entry["label"] = action {
                entry["run"]()
                
                ; ✅ New structure preferred
                cooldown := entry.Has("getCooldown")
                    ? entry["getCooldown"]()
                    : entry["cooldown"]  ; fallback to old style

                GuiActionQueue.actionQueueList.Delete(1)

                if !this.isInQueue(action)
                    this.addAction(action, GUI_ACTION_ICON_FOLDER entry["icon"], cooldown)

                roblox.setTitle()
                return
            }
        }

        ; Failsafe in case label was unmatched
        GuiActionQueue.actionQueueList.Delete(1)
        roblox.setTitle()
    }


    static isInQueue(actionName) {
        Loop GuiActionQueue.actionQueueList.GetCount() {
            if GuiActionQueue.actionQueueList.GetText(A_Index, 1) = actionName
                return true
        }
        return false
    }

    static addAction(action, icon, time := 0) {

        iconIndex := IL_Add(GuiActionQueue.actionImageList, icon)

        if time == 0 {
            GuiActionQueue.actionQueueList.Add("Icon" iconIndex, action, 0, "Ready")
            return
        }

        due := A_TickCount + (time * 60 * 1000)
        cooldown := formatTimeMs(due - A_TickCount)
        GuiActionQueue.actionQueueList.Add("Icon" iconIndex, action, due, cooldown)
        GuiActionQueue.actionQueueList.ModifyCol(2, "Sort Integer")
    }

    static populateFromSettings() {
        GuiActionQueue.actionQueueList.Delete()
        this.setupActionList()

        for action in this.ActionList {
            if action.Has("enabled") && action["enabled"] {
                if action.Has("delay")
                    this.addAction(action["label"], GUI_ACTION_ICON_FOLDER action["icon"], action["cooldown"])
                else
                    this.addAction(action["label"], GUI_ACTION_ICON_FOLDER action["icon"])
            }
        }
    }

    static setupActionList() {
        this.ActionList := [
            Map(  ; ✅ New structure
                "label", "Playtime Rewards",
                "run", (*) => Playtime.claimRewards(),
                "getCooldown", (*) => Playtime.COOLDOWN,
                "enabled", GuiActions.rewardsPlaytimeCheckbox.Value,
                "icon", "Playtime_Icon.ico",
            ),
            Map(
                "label", "Index Rewards",
                "run", (*) => claimIndexRewards(),
                "getCooldown", (*) => INDEX_COOLDOWN,
                "enabled", GuiActions.rewardsIndexCheckbox.Value,
                "icon", "Index_Icon.ico",
            ),
            Map(
                "label", "Season Rewards",
                "run", (*) => Season.Rewards.run(),
                "getCooldown", (*) => SEASON_COOLDOWN,
                "enabled", GuiActions.rewardsSeasonCheckbox.Value,
                "icon", "Season_Icon.ico",
            ),
            Map(
                "label", "Quest Rewards",
                "run", (*) => claimQuestRewards(),
                "getCooldown", (*) => QUESTS_COOLDOWN,
                "enabled", GuiActions.rewardsQuestsCheckbox.Value,
                "icon", "Quests_Icon.ico",
            ),
            Map(
                "label", "Infinity Chest",
                "run", (*) => Chests.open("Infinity"),
                "getCooldown", (*) => Chests.PROPERTIES["Infinity"].cooldown,
                "enabled", GuiActions.chestsInfiniteCheckbox.Value,
                "icon", "Infinity_Chest_Icon.ico",
            ),
            Map(
                "label", "Giant Chest",
                "run", (*) => Chests.open("Giant"),
                "getCooldown", (*) => Chests.PROPERTIES["Giant"].cooldown,
                "enabled", GuiActions.chestsGiantCheckbox.Value,
                "icon", "Giant_Chest_Icon.ico",
            ),
            Map(
                "label", "Void Chest",
                "run", (*) => Chests.open("Void"),
                "getCooldown", (*) => Chests.PROPERTIES["Void"].cooldown,
                "enabled", GuiActions.chestsVoidCheckbox.Value,
                "icon", "Void_Chest_Icon.ico",
            ),
            Map(
                "label", "Ticket Chest",
                "run", (*) => Chests.open("Ticket"),
                "getCooldown", (*) => Chests.PROPERTIES["Ticket"].cooldown,
                "enabled", GuiActions.chestsTicketCheckbox.Value,
                "icon", "Giant_Chest_Icon.ico",
            ),
            Map(
                "label", "Wheel Spin",
                "run", (*) => WheelSpins.Wheel.run(),
                "cooldown", WheelSpins.COOLDOWN,
                "enabled", GuiActions.collectWheelCheckbox.Value,
                "icon", "Wheel_Spin_Icon.ico",
            ),
            /*
            Map(
                "label", "Ancient Spin",
                "run", (*) => WheelSpins.Ancient.run(),
                "cooldown", WheelSpins.COOLDOWN,
                "enabled", GuiActions.collectAncientCheckbox.Value,
                "icon", "Wheel_Spin_Icon.ico",
            ),
            */            
            Map(  ; ⛔ Legacy (uses .Text)
                "label", "Sell Bubblegum",
                "run", (*) => BubbleGum.run(),
                "cooldown", BubbleGum.COOLDOWN_DROPDOWN.Text,
                "enabled", GuiActions.sellBubbleGumCheckbox.Value,
                "icon", "Bubble_Gum_Icon.ico",
            ),
            Map(
                "label", "Alien Shop",
                "run", (*) => Shops.useShop(Shops.SHOP_DATA["Alien Shop"]),
                "getCooldown", (*) => Shops.SHOP_DATA["Alien Shop"]["Timer"],
                "enabled", GuiActions.alienShopCheckbox.Value,
                "icon", "Shop_Icon.ico",
            ),
            Map(
                "label", "Blackmarket",
                "run", (*) => Shops.useShop(Shops.SHOP_DATA["Blackmarket"]),
                "getCooldown", (*) => Shops.SHOP_DATA["Blackmarket"]["Timer"],
                "enabled", GuiActions.blackmarketCheckbox.Value,
                "icon", "Blackmarket_Icon.ico",
            ),
            Map(
                "label", "Dice Merchant",
                "run", (*) => Shops.useShop(Shops.SHOP_DATA["Dice Merchant"]),
                "getCooldown", (*) => Shops.SHOP_DATA["Dice Merchant"]["Timer"],
                "enabled", GuiActions.diceMarketCheckbox.Value,
                "icon", "Shop_Icon.ico",
            ),
            Map(
                "label", "Traveling Merchant",
                "run", (*) => Shops.useShop(Shops.SHOP_DATA["Traveling Merchant"]),
                "getCooldown", (*) => Shops.SHOP_DATA["Traveling Merchant"]["Timer"],
                "enabled", GuiActions.travelingMerchantCheckbox.Value,
                "icon", "Shop_Icon.ico",
            ),
            Map(
                "label", "Festival Shop",
                "run", (*) => Shops.useShop(Shops.SHOP_DATA["Festival Shop"]),
                "getCooldown", (*) => Shops.SHOP_DATA["Festival Shop"]["Timer"],
                "enabled", GuiActions.festivalShopCheckbox.Value,
                "icon", "Shop_Icon.ico",
            ),            
            Map(
                "label", "Fishing Shop",
                "run", (*) => Shops.useShop(Shops.SHOP_DATA["Fishing Shop"]),
                "getCooldown", (*) => Shops.SHOP_DATA["Fishing Shop"]["Timer"],
                "enabled", GuiActions.fishingShopCheckbox.Value,
                "icon", "Shop_Icon.ico",
            ),
            /*            
            Map(
                "label", "Event Shop",
                "run", (*) => Shops.useShop(Shops.SHOP_DATA["Event Shop"]),
                "getCooldown", (*) => Shops.SHOP_DATA["Event Shop"  ]["Timer"],
                "enabled", GuiActions.eventShopCheckbox.Value,
                "icon", "Shop_Icon.ico",
            ),
            */
            Map(
                "label", "Potion Shrine",
                "run", (*) => PotionShrine.upgrade(),
                "cooldown", GuiActions.upgradePotionsDropdown.Text,
                "enabled", GuiActions.upgradePotionsCheckbox.Value,
                "icon", "Alchemist_III_Icon.ico",
            ),
            Map(
                "label", "Pet Match",
                "run", (*) => PetMatch.play(),
                "cooldown", GuiActions.petMatchCooldownDropdown.Text,
                "enabled", GuiActions.petMatchCheckbox.Value,
                "icon", "Pet_Match_Icon.ico",
            ),
            Map(
                "label", "Robot Claw",
                "run", (*) => RobotClaw.play(),
                "cooldown", GuiActions.robotClawCooldownDropdown.Text,
                "enabled", GuiActions.robotClawCheckbox.Value,
                "icon", "Robot_Claw_Icon.ico",
            ),
            Map(
                "label", "Hyper Darts",
                "run", (*) => HyperDarts.play(),
                "cooldown", GuiActions.hyperDartsCooldown.Text,
                "enabled", GuiActions.hyperDartsCheckbox.Value,
                "icon", "Hyper_Darts_Icon.ico",
            ),            
            Map(
                "label", "Reconnect",
                "run", (*) => Reconnect.reconnect(),
                "cooldown", GuiActions.timedReconnectCooldownDropdown.Text,
                "enabled", GuiActions.timedReconnectCheckbox.Value,
                "icon", "Roblox_Menu_Icon.ico",
                "delay", true
            ),            
        ]
    }


}