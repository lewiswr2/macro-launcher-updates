#Requires AutoHotkey v2.0

; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
; @region ITEMS
; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

class Items {
    
    static MAX_TRIES := 10

    ; Image searches.
    static ICON_SEARCH_AREA := {x1: 0, y1: 185, x2: 164, y2: 380}
    static PETS_BUTTON := A_ScriptDir "\Assets\UI\PetsIcon.bmp"
    static ITEMS_BUTTON := A_ScriptDir "\Assets\UI\ItemsIcon.bmp"

    ; Pixel searches.
    static MENU_CLOSE_BUTTON := [574, 117, 744, 193, "0xdc274a"]

    static isOpen() {
        area := this.ICON_SEARCH_AREA
        image := "*15 " this.PETS_BUTTON

        return ImageSearch(&x, &y, area.x1, area.y1, area.x2, area.y2, image)
    }

    static open() {
        Roblox.activate()
        Loop this.MAX_TRIES {
            if this.isOpen()
                return true
            Keys.send("f")
            Sleep 500
        }
        return false
    }

    static close() {
        Roblox.activate()
        Loop this.MAX_TRIES {
            if !this.isOpen()
                return true
            Keys.send("f")
            Sleep 100
        }
        return false
    }

; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
; @region .PETS
; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

    class PetsTab {
        static IS_OPEN_PIXEL := [192, 530, 192, 530, "0xff8831"]
        static MAX_TRIES := 10
        static MAX_SCROLLS := 100
        static CLOSE_BUTTON := {x: 722, y: 110}
        static LEFT_ARROW_AREA := [219, 180, 252, 260, "0xffffff", 2]
        static RIGHT_ARROW_AREA := [687, 180, 720, 260, "0xffffff", 2]
        static TOP_SCROLL_PIXEL := [737, 148, 737, 148, "0xa9e0fa", 2]
        static SCROLL_POSITION := {x: 730, y: 153}

        static isOpen() {
            area := Items.ICON_SEARCH_AREA
            image := "*25 " Items.PETS_BUTTON

            return PixelSearch(&x, &y, this.IS_OPEN_PIXEL*)
        }

        static open() {
            area := Items.ICON_SEARCH_AREA
            image := "*25 " Items.PETS_BUTTON
   
            Loop this.MAX_TRIES {
                if this.isOpen()
                    break
                if ImageSearch(&x, &y, area.x1, area.y1, area.x2, area.y2, image)
                    clickButton({x: x, y: y}, 100, 1)
                Sleep 100
            }
        }

        static close() {
            Loop this.MAX_TRIES {
                if !this.isOpen()
                    return true
                clickButton(this.CLOSE_BUTTON, 100, 1)
            }
            return false
        }

        static selectTeam(slot) {
            Items.open()
            this.open()
            Roblox.Leaderboard.close()

            this.scrollToTop()

            Loop this.MAX_TRIES {
                Roblox.setTitle("Looking for Left Arrow (" A_Index "/" this.MAX_TRIES ")")
                if !this.isArrowVisible(this.LEFT_ARROW_AREA)
                    break
                this.clickArrow(this.LEFT_ARROW_AREA)
                Sleep 100
            }

            Loop slot - 1 {
                this.clickArrow(this.RIGHT_ARROW_AREA)
                Sleep 100
            }

            Items.close()
            Roblox.setTitle()
        }

        static equipBestTeam() {
            Items.open()
            this.open()
            Loop 3 {
                Keys.send("b")
            }
            Items.close()
        }

        static scrollToTop() {
            Roblox.activate()
            clickButton(this.SCROLL_POSITION, 50)
            Loop this.MAX_SCROLLS {
                Roblox.setTitle("Scrolling to Top (" A_Index "/" this.MAX_SCROLLS ")")
                if this.isAtTop()
                    break
                scrollMouseWheel("Up")
                Sleep 100
            }
        }

        static isAtTop() {
            Roblox.activate()
            return PixelSearch(&x, &y, this.TOP_SCROLL_PIXEL*)
        }

        static clickArrow(area) {
            Roblox.activate()
            if PixelSearch(&x, &y, area*)
                clickButton({x: x, y: y}, 100)
        }

        static isArrowVisible(area) {
            Roblox.activate()
            return PixelSearch(&x, &y, area*)
        }
    }

; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
; @region .ItemsTab
; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

    class ItemsTab {
        static IS_OPEN_PIXEL := [387, 123, 387, 123, "0xffffff"]
        static MAX_TRIES := 10
        static CLOSE_BUTTON := {x: 722, y: 110}
        static ITEM_SEARCH_AREA := {x1: 203, y1: 146, x2: 717, y2: 500}
        static EMPTY_SLOT_COLOUR := "0xe1f3ff"
        static FIRST_ITEM := {x: 246, y: 382}
        static ITEM_SPACING := {x: 88, y: 82}
        static ITEM_ROWS := 2
        static ITEM_COLUMNS := 6
        static OCR_ATTEMPTS := 4
        static OCR_SCALE_START := 5
        static OCR_SCALE_INCREMENT := 5
        static OCR_AREA := [56, 120, 133, 100]
        static USE_BUTTON := {x: 121, y: 473}
        static SAFE_CURSOR_LOCATION := {x: 725, y: 155} 
        static SCROLLBAR_TOP_PIXEL := [737, 148, 737, 148, "0xa9e0fa"]
        static SCROLLBAR_BOTTOM_PIXEL := [737, 500, 737, 500, "0xa9e0fa"]
        static SCROLL_LOCATION := {x: 724, y: 367}

        static IMAGE_FOLDER := A_ScriptDir "\Assets\Images\Items\"

        static ITEM_DATA := Map(
            "Tickets V", {scrolls: 1, image: "Tickets_V.png"},
            "Speed V", {scrolls: 1, image: "Speed_V.png"},
            "Mythic V", {scrolls: 1, image: "Mythic_V.png"},
            "Coins V", {scrolls: 1, image: "Coins_V.png"},
            "Lucky V", {scrolls: 1, image: "Lucky_V.png"},
            "Golden Orb", {scrolls: 8, image: "Golden_Orb.png"},
            "Mystery Box", {scrolls: 8, image: "Mystery_Box.png"},
            "Golden Box", {scrolls: 8, image: "Golden_Box.png"},
            "Season 1 Egg", {scrolls: 8, image: "Season_1_Egg.png"},
            "Season 2 Egg", {scrolls: 8, image: "Season_2_Egg.png"},
            "Season 3 Egg", {scrolls: 8, image: "Season_3_Egg.png"},
            "Series 1 Egg", {scrolls: 8, image: "Series_1_Egg.png"},
            "Series 2 Egg", {scrolls: 8, image: "Series_2_Egg.png"},
            "Pirate Egg", {scrolls: 8, image: "Pirate_Egg.png"},
        )

        static isOpen() {
            return PixelSearch(&x, &y, this.IS_OPEN_PIXEL*)
        }

        static open() {
            area := Items.ICON_SEARCH_AREA
            image := "*25 " Items.ITEMS_BUTTON
            Loop this.MAX_TRIES {
                if this.isOpen()
                    break
                if ImageSearch(&x, &y, area.x1, area.y1, area.x2, area.y2, image)
                    clickButton({x: x, y: y}, 100, 1)
            }
        }

        static scrollTo(direction) {
            moveLocation(this.SCROLL_LOCATION, 10)
            isAtEnd := direction = "up" ? this.isScrollbarAtTop : this.isScrollbarAtBottom
            wheel := direction = "up" ? "Up" : "Down"

            Loop this.MAX_TRIES {
                if isAtEnd.Call(this)
                    break
                scrollMouseWheel(wheel)
                Sleep 50
            }
        }

        static scrollToTop() {
            this.scrollTo("up")
        }

        static scrollToBottom() {
            this.scrollTo("down")
        }

        static isScrollbarAtTop() {
            return PixelSearch(&x, &y, this.SCROLLBAR_TOP_PIXEL*)
        }

        static isScrollbarAtBottom() {
            return PixelSearch(&x, &y, this.SCROLLBAR_BOTTOM_PIXEL*)
        }

        static close() {
            Loop this.MAX_TRIES {
                if !this.isOpen()
                    return true
                clickButton(this.CLOSE_BUTTON, 100, 1)
            }
            return false
        }

        static useItem(item) {
            data := this.ITEM_DATA[item]
            imagePath := this.IMAGE_FOLDER data.image
            scrolls := data.scrolls

            this.scrollToTop()

            moveLocation(this.SCROLL_LOCATION, 10)
            scrollMouseWheel("down", scrolls)

            Roblox.activate()
            moveLocation(this.SAFE_CURSOR_LOCATION, 50)

            if ImageSearch(&x, &y, 200, 142, 743, 509, "*15 *TransFF0000 " imagePath) {
                clickButton({x: x, y: y}, 100)
                clickButton(this.USE_BUTTON, 100)
                return true
            }

            return false
        }

        static useItemFromMenu(item) {
            Items.open()
            Items.ItemsTab.open()
            this.useItem(item)
            Items.ItemsTab.close()
            Roblox.setTitle()
        }

    }
}