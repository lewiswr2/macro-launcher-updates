#Requires AutoHotkey v2.0

; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
; @region Event Handlers
; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

OnMessage(0x201, ObjBindMethod(GuiSettings, "handleMouseDown"))
OnMessage(0x0006, ObjBindMethod(GuiSettings, "handleDeactivate"))


; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
; @region GUI Creation
; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

class GuiSettings {

    static gui := ""

    static FIRST_COLUMN_X := 10
    static SECOND_COLUMN_X := 220
    static TOP_Y := 10

    static show() {
        this.gui.Show("AutoSize")
        mainGui.GetPos(&x, &y, &w, &h)
        this.gui.Move(x + 6, y + h - 8)  
    }

    static handleMouseDown(wParam, lParam, msg, hwnd) {
        if (this.gui && hwnd = this.gui.Hwnd && WinActive("ahk_id " hwnd)) {
            PostMessage 0xA1, 2,,, "ahk_id " hwnd
        }
    }

    static handleDeactivate(wParam, lParam, msg, hwnd) {
        if (wParam = 0 && this.gui && hwnd = this.gui.Hwnd) {
            this.gui.Hide()
        }
    }

    static create() {
        this.gui := Gui("-Caption +Border")
        this.gui.SetFont("s8 c" UI.UI_FONT_COLOUR, "Segoe UI Light")
        this.gui.BackColor := UI.UI_BACKCOLOUR

        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
        ; @region > Masteries
        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
        
        this.gui.AddGroupBox("x" this.FIRST_COLUMN_X " y" this.TOP_Y " Section w200 h115", "Masteries").SetFont("w700")

        info := this.gui.AddPicture("xs+10 yp+20 w30 h30", GUI_SETTINGS_IMAGE_FOLDER "Mastery_Icon.png")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Masteries", text: "Select your mastery level for each mastery you have in the game. If you've reached max level, you can use the MAX button to quickly set it. Masteries affect various features such as walk speed, chest claiming, and shop interactions." }

        info := this.gui.AddText("x+10 w55", "Buffs")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Masteries", text: "Select your Buffs mastery level." }
        this.buffsMasteryDropdown := this.gui.AddDropDownList("x+10 yp-3 w40", [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21])
        this.buffsMasteryDropdown.Value := 1
        this.maxBuffsImage := this.gui.AddPicture("x+5 yp+4 w30 h12", GUI_SETTINGS_IMAGE_FOLDER "Max.png")

        info := this.gui.AddText("xs+50 yp+20 w55", "Pets")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Masteries", text: "Select your Pets mastery level." }
        this.petsMasteryDropdown := this.gui.AddDropDownList("x+10 yp-3 w40", [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17])
        this.petsMasteryDropdown.Value := 1
        this.maxPetsImage := this.gui.AddPicture("x+5 yp+4 w30 h12", GUI_SETTINGS_IMAGE_FOLDER "Max.png")

        info := this.gui.AddText("xs+50 yp+20 w55", "Shops")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Masteries", text: "Select your Shops mastery level." }
        this.shopsMasteryDropdown := this.gui.AddDropDownList("x+10 yp-3 w40", [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]) 
        this.shopsMasteryDropdown.Value := 1
        this.maxShopsImage := this.gui.AddPicture("x+5 yp+4 w30 h12 +0x100", GUI_SETTINGS_IMAGE_FOLDER "Max.png")

        info := this.gui.AddText("xs+50 yp+20 w55", "Minigames")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Masteries", text: "Select your Minigames mastery level." }
        this.minigamesMasteryDropdown := this.gui.AddDropDownList("x+10 yp-3 w40", [0, 1, 2, 3, 4, 5, 6, 7, 8]) 
        this.minigamesMasteryDropdown.Value := 1
        this.maxMinigamesImage := this.gui.AddPicture("x+5 yp+4 w30 h12 +0x100", GUI_SETTINGS_IMAGE_FOLDER "Max.png")

        this.maxBuffsImage.OnEvent("Click", (*) => this.setMaxMastery(this.buffsMasteryDropdown))
        this.maxPetsImage.OnEvent("Click", (*) => this.setMaxMastery(this.petsMasteryDropdown))
        this.maxShopsImage.OnEvent("Click", (*) => this.setMaxMastery(this.shopsMasteryDropdown))
        this.maxMinigamesImage.OnEvent("Click", (*) => this.setMaxMastery(this.minigamesMasteryDropdown))

        this.buffsMasteryDropdown.OnEvent("Change", (*) => buffsMasteryChange())
        ;petsMasteryDropdown.OnEvent("Change", (*) => updateShopsOptions())
        ;minigamesMasteryDropdown.OnEvent("Change", (*) => updateSpinnyOptions())

        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
        ; @region > Gamepasses
        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
    
        this.gui.AddGroupBox("xs Section w200 h65", "Gamepasses").SetFont("w700")

        info := this.gui.AddPicture("xs+10 yp+20 w30 h30", GUI_SETTINGS_IMAGE_FOLDER "Gamepass_VIP.png")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Gamepasses", text: "Select the gamepasses you have in the game. Gamepasses affect various features such as chest availability, and cooldowns." }

        info := this.vipGamepassCheckbox := this.gui.AddCheckbox("x+10 w100", "VIP")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "VIP", text: "Select if you have the VIP gamepass." }
        this.vipGamepassCheckbox.OnEvent("Click", (*) => this.updateVipOptions())
        
        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
        ; @region > Pet Teams
        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

        ; Pet Team group.
        this.gui.AddGroupBox("xs Section w200 h75", "Pet Teams").SetFont("w700")

        info := this.gui.AddPicture("xs+10 yp+20 w30 h30", GUI_SETTINGS_IMAGE_FOLDER "Pet_Equips.png")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Pet Teams", text: "Select your pet teams for each world. The chosen teams will be equipped automatically when performing actions in their respective worlds." }

        this.teamWorld1Checkbox := this.gui.AddCheckbox("x+10 w20 h20", "")
        info := this.gui.AddText("x+0 yp+3 w65", "World 1 Team")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "World 1 Team", text: "Select the team you wish to use for World 1." }
        this.teamWorld1 := this.gui.AddDropDownList("x+10 yp-2 w45", [1, 2, 3, 4, 5, "Best"])
        this.teamWorld1.Value := 1

        this.teamWorld2Checkbox := this.gui.AddCheckbox("xs+50 yp+20 w20 h20", "")
        info := this.gui.AddText("x+0 yp+3 w65", "World 2 Team")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "World 2 Team", text: "Select the team you wish to use for World 2." }
        this.teamWorld2 := this.gui.AddDropDownList("x+10 yp-2 w45", [1, 2, 3, 4, 5, "Best"])
        this.teamWorld2.Value := 2

        /*
        this.teamEventWorldCheckbox := this.gui.AddCheckbox("xs+50 yp+20 w20 h20", "")
        info := this.gui.AddText("x+0 yp+3 w65", "Event Team")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Event Team", text: "Select the team you wish to use for the event world." }
        this.teamEventWorld := this.gui.AddDropDownList("x+10 yp-2 w45", [1, 2, 3, 4, 5, "Best"])
        this.teamEventWorld.Value := 3
        */


        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
        ; @region > Walkspeed
        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
    
        this.gui.AddGroupBox("xs Section w200 h65", "Walkspeed").SetFont("w700")

        info := this.gui.AddPicture("xs+10 yp+20 w30 h30", GUI_SETTINGS_IMAGE_FOLDER "Walkspeed_Icon.png")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Walkspeed", text: "Player walk speed is based on the Buffs Mastery level. If movement appears slightly off, you can adjust the modifier to fine-tune path accuracy." }

        info := this.gui.AddText("x+10 w55", "Level")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Level", text: "This level is automatically calculated and updated based on the selected Buffs Mastery." }
        this.walkspeedLevel := this.gui.AddText("x+10 yp w55", "IV (4)")

        info := this.gui.AddText("xs+50 yp+20 w55", "Modifier")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Modifier", text: "A lower modifier shortens the player's travel distance, while a higher modifier increases it. This value is usually accurate based on the Buffs Mastery and typically doesn't require adjustment — it's available as a last resort for fine-tuning movement." }
        this.walkspeedModifier := this.gui.AddEdit("x+10 yp-3 w75", "1")


        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
        ; @region > Theme
        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

        this.gui.AddGroupBox("xs Section w200 h90", "Theme").SetFont("w700")

        info := this.gui.AddPicture("xs+10 yp+20 w30 h30", GUI_SETTINGS_IMAGE_FOLDER "Microsoft_Paint.png")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Theme", text: "Change the user interface theme, including background and font colours." }

        info := this.gui.AddText("x+10 w60", "Background")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Background Colour", text: "Change the background colour. Must be a valid hexadecimal colour code." }
        this.backgroundColour := this.gui.AddEdit("x+5 yp-3 w50 h20", "F0F0F0")
        this.backgroundPreview := this.gui.AddText("x+5 yp+2 w17 h17 +Border Background" this.backgroundColour.Text)
        this.backgroundColour.OnEvent("Change", (*) => this.updatePreview(this.backgroundColour, this.backgroundPreview))

        info := this.gui.AddText("xs+50 yp+25 w60", "Font")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Font Colour", text: "Change the font colour. Must be a valid hexadecimal colour code." }
        this.fontColour := this.gui.AddEdit("x+5 yp-3 w50 h20", "000000")
        this.fontPreview := this.gui.AddText("x+5 yp+2 w17 h17 +Border Background" this.fontColour.Text)
        this.fontColour.OnEvent("Change", (*) => this.updatePreview(this.fontColour, this.fontPreview))

        this.setColour := this.gui.AddButton("xs+10 ys+55 w30", "Set")
        this.setColour.OnEvent("Click", (*) => this.applyColour())


        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
        ; @region > Key Binds
        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

        this.gui.AddGroupBox("x" this.SECOND_COLUMN_X " y" this.TOP_Y " Section w200 h90", "Keybinds").SetFont("w700")

        info := this.keybindsImage := this.gui.AddPicture("xs+10 yp+20 w30 h30", GUI_SETTINGS_IMAGE_FOLDER "F1_Key.png")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Keybinds", text: "Add additional keybinds to control the mode. F1 will always start the mode, F2 will pause it, and F3 will exit it.`n`nNote: Avoid selecting keys that are used for in-game actions (e.g., E, M)." }

        info := this.gui.AddText("x+10 yp w95", "Start Mode")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Start Mode", text: "Select a key to start the mode." }
        this.startHotkey := this.gui.AddHotkey("x+10 yp-3 w35 vStartHotkey")
        this.startHotkey.Value := "F1"

        info := this.gui.AddText("xs+50 yp+25 w95", "Pause Mode")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Pause Mode", text: "Select a key to pause and unpause the mode." }
        this.pauseHotkey := this.gui.AddHotkey("x+10 yp-3 w35 vPauseHotkey")
        this.pauseHotkey.Value := "F2"

        info := this.gui.AddText("xs+50 yp+25 w95", "Exit Mode")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Exit Mode", text: "Select a key to exit the mode." }
        this.exitHotkey := this.gui.AddHotkey("x+10 yp-3 w35 vExitHotkey")
        this.exitHotkey.Value := "F3"


        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
        ; @region > Save/Load
        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

        this.gui.AddGroupBox("xs Section w200 h120", "Settings").SetFont("w700")

        info := this.settingsImage := this.gui.AddPicture("xs+10 yp+20 w30 h30", GUI_SETTINGS_IMAGE_FOLDER "Settings_Icon.png")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Settings", text: "Load and save all configured settings. You can create and manage multiple profiles for easy access. Each time the mode is started, the current settings are automatically saved to the Default profile. Using Quick Save from the File menu will also save to the Default profile. The Default settings are loaded automatically whenever the mode starts.`n`nSettings are saved in the Psycho Hatcher → Settings → BGSI folder." }

        info := this.gui.AddText("x+10 w140", "Load Settings")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Load Settings", text: "Select a profile and click Load to apply its settings." }
        this.settingsLoadDropdown := this.gui.AddDropDownList("xs+50 yp+20 w115", ) 
        this.settingsLoadButton := this.gui.AddButton("x+5 yp-1 w25", "📂")
        this.settingsLoadButton.OnEvent("Click", (*) => Settings.load())

        info := this.gui.AddText("xs+50 yp+30 w140", "Save Settings")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Save Settings", text: "Select an existing profile or enter a new profile name, then click Save to store the current settings to file." }
        this.settingsSaveFile := this.gui.AddComboBox("xs+50 yp+20 w115", [])
        this.settingsSaveButton := this.gui.AddButton("x+5 yp-1 w25", "💾")
        this.settingsSaveButton.OnEvent("Click", (*) => Settings.save())


        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
        ; @region > Webhook
        ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

        this.gui.AddGroupBox("xs Section w200 h145", "Discord Webhook").SetFont("w700")
        info := this.gui.AddPicture("xs+10 yp+20 w30 h30", GUI_SETTINGS_IMAGE_FOLDER "Webhook_Icon.png")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Discord Webhook", text: "Set up your webhooks to send in-game notifications directly to your Discord channel." }

        info := this.gui.AddText("x+10 w140", "Webhook URL")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Webhook URL", text: "Enter the URL of your personal Discord webhook. You can find it in your server under Server Settings → Integrations → Webhooks. After entering the URL, click the Test button to confirm it's set up correctly." }
        this.webhookUrl := this.gui.AddEdit("xs+50 yp+20 w140", "")

        info := this.gui.AddText("xs+50 yp+30 w140", "Notifications")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Notifications", text: "Choose which webhook notifications to send." }
        info.SetFont("", "Segoe UI Semibold")        

        this.gui.Add("Text", "xs+50 yp+20 w140 h1 BackgroundGray")

        this.webhookMinigames := this.gui.AddCheckbox("xs+50 yp+5 w20 h20", "")
        info := this.gui.AddText("x+0 yp+3 w100", "Minigame Rewards")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Minigame Rewards", text: "Send a screenshot notification to Discord that includes an image of the rewards screen for each completed minigame." }

        this.webhookShops := this.gui.AddCheckbox("xs+50 yp+15 w20 h20", "")
        info := this.gui.AddText("x+0 yp+3 w100", "Shop Items")
        UI.TOOLTIP_MAP[info.Hwnd] := { title: "Shop Items", text: "Send a screenshot notification to Discord showing the available items in each shop." }

        ; Test button.
        this.webhookTest := this.gui.AddButton("xs+10 ys+55 w30", "Test")
        this.webhookTest.OnEvent("Click", (*) => PersonalWebhook.test())

    }


    ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
    ; @region Functions
    ; ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

    static updateVipOptions() {
        hasVip := this.vipGamepassCheckbox.Value
        if hasVip
            GuiActions.chestsInfiniteCheckbox.Enabled := true
        else {
            GuiActions.chestsInfiniteCheckbox.Enabled := false
            GuiActions.chestsInfiniteCheckbox.Value := false
        }
        Chests.setVipCooldownMultiplier()
        GuiActions.chestsUpdateSelectAllCheckbox()
    }

    static updateShopsOptions() {
        isApplicable := (this.petsMasteryDropdown.Text >= 9)
        
        GuiActions.blackmarketCheckbox.Enabled := isApplicable
        if !isApplicable
            GuiActions.blackmarketCheckbox.Value := false
    }    

    static setMaxMastery(control) {
        count := SendMessage(0x146, 0, 0, control.Hwnd) ; CB_GETCOUNT = 0x146
        control.Value := count    
        GuiSettings.updateShopsOptions()
        buffsMasteryChange()
    }

    static updatePreview(colourCtrl, previewControl) {
        UI.restrictEdit(colourCtrl, "0123456789ABCDEF")
        colour := colourCtrl.Text
        if RegExMatch(colour, "^[0-9a-fA-F]{6}$") {
            previewControl.Opt("Background0x" colour)
            previewControl.Redraw()
        }
    }

    static applyColour() {
        UI.UI_BACKCOLOUR := this.backgroundColour.Text
        UI.UI_FONT_COLOUR := this.fontColour.Text

        this.refreshGui(mainGui)
        this.refreshGui(GuiModeQueue.gui)
        this.refreshGui(GuiActionQueue.gui)
        this.refreshGui(GuiTools.gui)
        this.refreshGui(GuiFarm.gui)
        this.refreshGui(GuiHatch.gui)
        this.refreshGui(GuiActions.gui)
        this.refreshGui(GuiSettings.gui)
        this.refreshGui(GuiSeason.gui)
        this.refreshGui(GuiCompete.gui)
        this.refreshGui(GuiGenie.gui)
        this.refreshGui(GuiSeasonList.gui)
        this.refreshGui(GuiEventChallenges.gui)
    }

    static refreshGui(gui) {
        gui.BackColor := "0x" UI.UI_BACKCOLOUR
        for ctrl in gui {
            try {
                if (ctrl.Type = "Edit" || ctrl.Type = "ListView")
                    continue
                ctrl.Opt("c" UI.UI_FONT_COLOUR)
            }
        }
    }

}