#Requires AutoHotkey v2.0

class Keys {
    static keyToScan := Map(
        ; Letters
        "a", "SC01E", "b", "SC030", "c", "SC02E", "d", "SC020",
        "e", "SC012", "f", "SC021", "g", "SC022", "h", "SC023",
        "i", "SC017", "j", "SC024", "k", "SC025", "l", "SC026",
        "m", "SC032", "n", "SC031", "o", "SC018", "p", "SC019",
        "q", "SC010", "r", "SC013", "s", "SC01F", "t", "SC014",
        "u", "SC016", "v", "SC02F", "w", "SC011", "x", "SC02D",
        "y", "SC015", "z", "SC02C",

        ; Numbers
        "0", "SC00B", "1", "SC002", "2", "SC003", "3", "SC004", "4", "SC005",
        "5", "SC006", "6", "SC007", "7", "SC008", "8", "SC009", "9", "SC00A",

        ; Arrows
        "up", "SC148", "down", "SC150", "left", "SC14B", "right", "SC14D",

        ; Common Keys
        "space", "SC039",
        "enter", "SC01C",
        "esc", "SC001",
        "tab", "SC00F",
        "backspace", "SC00E",
        "delete", "SC153",
        "capslock", "SC03A",

        ; Modifiers
        "lctrl", "SC01D",
        "rctrl", "SC11D",
        "lalt", "SC038",
        "ralt", "SC138",
        "lshift", "SC02A",
        "rshift", "SC136",

        ; Function Keys
        "f1", "SC03B", "f2", "SC03C", "f3", "SC03D", "f4", "SC03E",
        "f5", "SC03F", "f6", "SC040", "f7", "SC041", "f8", "SC042",
        "f9", "SC043", "f10", "SC044", "f11", "SC057", "f12", "SC058"
    )

    static send(key, action := "tap") {
        if !this.keyToScan.Has(key) {
            MsgBox "Unknown key: " key
            return
        }

        sc := this.keyToScan[key]

        switch action {
            case "tap":
                Send "{" sc "}"
            case "down":
                Send "{" sc " down}"
            case "up":
                Send "{" sc " up}"
            default:
                MsgBox "Invalid action: " action
        }
    }
}

