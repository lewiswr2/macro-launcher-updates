#Requires AutoHotkey v2.0

class Roblox {
    static WIN_TITLE := "ahk_exe RobloxPlayerBeta.exe"

    static activate(client := 0) {
        try {
            if client == 0
                WinActivate this.WIN_TITLE
            else
                WinActivate "ahk_id " client
        } catch {
            MsgBox "Roblox window not found."
            ExitApp
        }
        Sleep 5
    }

    static resize() {
        WinActivate this.WIN_TITLE
        WinRestore this.WIN_TITLE
        WinMove , , A_ScreenWidth, 600, this.WIN_TITLE
        WinMove , , 800, 600, this.WIN_TITLE
    }

    static setTitle(message := "") {
        title := (message = "") ? "Roblox" : message
        try WinSetTitle(title, this.WIN_TITLE)
    }

    static leave() {
        Roblox.Menu.open()
        Send "{l}"
        Sleep 500
        Send "{Enter}"
    }

    class Menu {

        static OCR_SETTINGS_SECTION := {x1: 1, y1: 109, x2: 798, y2: 378}
        static OCR_SETTINGS_TABS := {x: 1, y: 60, w: 798, h: 58}
        static MAX_OPEN_ATTEMPTS := 20

        static open() {
            Loop this.MAX_OPEN_ATTEMPTS {
                if this.isOpen()
                    return 1
                Send "{Esc}"
                Sleep 250                
            }
            return 0
        }

        static isOpen() {
            area := this.OCR_SETTINGS_TABS
            ocrText := getOcr(area.x, area.y, area.w, area.h, 5, true, false)
            return RegExMatch(ocrText, "Settings")
        }

    }

    class Leaderboard {
        static COLOURS := [
            "0x121215", "0x000000", "0x494a4c",
            "0x494b4c", "0x434446", "0x191b1d"
        ]
        static CLOSE_BUTTON := {x: 487, y: 72}
        static PIXEL_CHECK := {x1: 484, y1: 90, x2: 484, y2: 90}

        static isDisplayed() {
            Roblox.activate()
            for _, colour in this.COLOURS {
                if PixelSearch(&x, &y, this.PIXEL_CHECK.x1, this.PIXEL_CHECK.y1, this.PIXEL_CHECK.x2, this.PIXEL_CHECK.y2, colour, 2)
                    return 1
            }
            return 0
        }

        static close() {
            Roblox.activate()
            Loop 10 {
                if !this.isDisplayed()
                    break
                clickButton(this.CLOSE_BUTTON, 50)
                Sleep 50
            }
            Sleep 50
        }

        static forceClose() {
            Roblox.activate()
            clickButton(this.CLOSE_BUTTON, 50)
        }   

        static open() {
            Roblox.activate()
            if !this.isDisplayed() {
                Keys.send("tab")
                Sleep 200
            }
        }
    }

    class Respawn {

        static ROBLOX_MENU_BUTTON := {x: 6, y: 67, colour: "0x000000"}
        static RESET_BUTTON := {x: 288, y: 361}
        static RESET_BUTTON_SEARCH_NEW := [202, 346, 370, 373, "0x142666", 5]
        static RESET_BUTTON_SEARCH_OLD := [202, 346, 370, 373, "0x38393b", 5]

        static GUMBALL_SEARCH := [400, 200, 600, 300, "0xc13394", 5]
        static GUM_STORE_PAD := [300, 200, 400, 400, "0x6bf8f6", 5]
        static SELL_PAD := [400, 100, 700, 300, "0xf7e53e", 5]
        static PURPLE_THING := [500, 150, 700, 450, "0x661b96", 5]

        static MAX_RESET_ATTEMPTS := 50

        static resetCharacter() {
            Roblox.activate()

            Roblox.setTitle("Resetting Character")
            Windows.closeAllWindows()
            this.openRobloxMenu()
            sleep 500
            this.selectRespawnOption()
            sleep 250
            this.selectResetCharacter()
            Roblox.Leaderboard.close()
            Sleep 4000
            Movement.IS_ROTATED := this.isRotated()
  
            Camera.setOverhead()
            Camera.zoomOut(2000)   
            Roblox.setTitle()
        }

        static openRobloxMenu() {
            if this.isEscapeMenuDisplayed()
                return 1

            Loop 100 {
                Send "{Esc}"
                Sleep 50
                Loop 10 {
                    if this.isEscapeMenuDisplayed()
                        return 1
                    Sleep 50
                }
            }
            return 0
        }

        static isRotated() {
            Roblox.activate()
            if PixelSearch(&x, &y, this.PURPLE_THING*)
                return 1            
            if PixelSearch(&x, &y, this.SELL_PAD*)
                return 1
            if PixelSearch(&x, &y, this.GUMBALL_SEARCH*)
                return 1
            if PixelSearch(&x, &y, this.GUM_STORE_PAD*)
                return 1
            return 0
        }

        static selectRespawnOption() {
            if this.isResetButtonDisplayed()
                return 1

            Loop 100 {
                Send "{r}"
                Sleep 50
                Loop 10 {
                    if this.isResetButtonDisplayed()
                        return 1
                    Sleep 50
                }
            }    
            return 0
        }

        static selectResetCharacter() {
            Loop 100 {
                moveLocation(this.RESET_BUTTON, 50)
                clickButton(this.RESET_BUTTON, 50)
                Loop 10 {
                    if !this.isResetButtonDisplayed()
                        return 1
                    Sleep 50            
                }
            }
            return 0
        }

        static isResetButtonDisplayed() {
            if PixelSearch(&x, &y, this.RESET_BUTTON_SEARCH_NEW*)    
                return 1
            if PixelSearch(&x, &y, this.RESET_BUTTON_SEARCH_OLD*)
                return 1
            return 0
        }

        static isEscapeMenuDisplayed() {
            search := this.ROBLOX_MENU_BUTTON
            return PixelSearch(&x, &y, search.x, search.y, search.x, search.y, search.colour, 2)
        }

    }

}