#Requires AutoHotkey v2.0

; #Requires AutoHotkey v2.0

class RobotClaw {
    
    ; Minigame settings.
    static GAME_TITLE := "Robot Claw"
    static GAME_ISLAND := "2-3"
    static PATH := [["a", 1000]]  

    ; Max attempts.
    static MAX_WAIT_FOR_CLAW_RETURN := 50
    static MAX_WAIT_FOR_GAME_TO_START := 50  

    ; Pixel searches.
    static GAME_INTERFACE_SEARCH := [80, 179, 128, 190, "0xbc6800", 5]
    static CLAW_RETURNED_SEARCH := [
        [283, 85, 288, 107, "0x505935", 5],
        [283, 85, 288, 107, "0x75826a", 5],
        [283, 85, 288, 107, "0x73806a", 5]
    ]

    ; Claw locations.
    static FIXED_POSITIONS := Map(
        1, ["d", 525],
        2, ["w", 525],
        3, ["wd", 700],
        4, ["wd", 1100]
    )
    static FALLBACK_INDEX := 1
    static FALLBACK_POSITIONS := [
        ["w", 500], ["w", 1000], [["w", 1000], ["d", 500]]
    ]
    static CLAW_POSITIONS := Map(
        1, Map("checks", [[400, 356], [420, 356]], "move", ["d", 500]),
        2, Map("checks", [[456, 356], [470, 356]], "move", ["d", 700]),
        3, Map("checks", [[426, 294], [441, 294]], "move", ["wd", 700]),
        4, Map("checks", [[450, 301], [465, 274]], "move", ["wd", 1200])
    )

    static playFromMenu() {
        Roblox.activate()

        if !Minigame.isInStartArea(this.GAME_TITLE)
            return

        Loop {
            Minigame.useTicket(this.GAME_TITLE, GuiTools.minigameRobotClawDifficulty.Value)
            this.doClaw()
            Minigame.claimRewards(this.GAME_TITLE)
            Minigame.restartGame(this.GAME_TITLE)
        }
    }

    static play() {
        Minigame.teleportToMinigame(this.GAME_TITLE, this.GAME_ISLAND)
        Minigame.moveToMinigame(this.GAME_TITLE, this.PATH)
        Sleep 1000

        if !Minigame.isMinigameWindowOpen()
            return

        Minigame.useTicket(this.GAME_TITLE)
        this.doClaw()
        Minigame.claimRewards(this.GAME_TITLE)
        Roblox.Respawn.resetCharacter()
        ;Camera.turnNinetyDegrees("right")
        ;Camera.setOverhead()
        ;Camera.zoomOut(2000)        
        Roblox.setTitle()
    }

    static chooseFixedPosition(index) {
        if this.FIXED_POSITIONS.Has(index) {
            Roblox.setTitle(this.GAME_TITLE " | Fixed Position " index)
            key := this.FIXED_POSITIONS[index][1]
            duration := this.FIXED_POSITIONS[index][2]
            Movement.move(key, duration)
            Sleep 100
            Keys.send("f")
        }
    }

    static findAvailableClawPosition() {
        Roblox.setTitle(this.GAME_TITLE " | Finding Item Balls")
        for index, data in this.CLAW_POSITIONS {
            if this.isClawPositionAvailable(data["checks"]) {
                return index
            }
        }
        return 0
    }

    static isClawPositionAvailable(checks) {
        for _, pos in checks {
            if PixelSearch(&x, &y, pos[1], pos[2], pos[1], pos[2], "0x151b21", 25)
            || PixelSearch(&x, &y, pos[1], pos[2], pos[1], pos[2], "0x293847", 25) {
                return false
            }
        }
        return true
    }

    static doClaw() {
        
        index := 0

        Loop {
            Roblox.setTitle("Robot Claw | Playing Game (" A_Index ")")

            Loop this.MAX_WAIT_FOR_CLAW_RETURN {

                if Minigame.isRewardsWindowDisplayed()
                    return                

                Roblox.setTitle(this.GAME_TITLE " | Waiting for Claw to Return (" A_Index ")")
                if this.isClawReturned() {
                    Roblox.setTitle(this.GAME_TITLE " | Claw Returned")
                    break
                }
  
                Sleep 10

            }

            Sleep 500

            index++
            if index <= 4 {
                this.chooseFixedPosition(index)
                continue
            }

            posIndex := this.findAvailableClawPosition()
            this.chooseClawPosition(posIndex)

        }

    }

    static chooseClawPosition(posIndex) {
        if posIndex {
            data := this.CLAW_POSITIONS[posIndex]
            Roblox.setTitle(this.GAME_TITLE " | Choosing Found Position " posIndex)
            Movement.move(data["move"][1], data["move"][2])
        } else {
            move := this.FALLBACK_POSITIONS[this.FALLBACK_INDEX]
            this.FALLBACK_INDEX := Mod(this.FALLBACK_INDEX, this.FALLBACK_POSITIONS.Length) + 1

            Roblox.setTitle(this.GAME_TITLE " | Choosing Fallback Position")

            if Type(move[1]) = "Array" {
                for each in move
                    Movement.move(each[1], each[2])
            } else {
                Movement.move(move[1], move[2])
            }
        }

        Keys.send("f")
    }

    static isClawReturned() {
        for each in this.CLAW_RETURNED_SEARCH {
            if PixelSearch(&x, &y, each*)
                return true
        }
        return false
    }

}